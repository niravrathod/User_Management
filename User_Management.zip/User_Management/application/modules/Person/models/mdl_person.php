<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Mdl_person extends CI_Model {

function __construct() {
parent::__construct();
}

function get_table() {
    $table = "person";
    return $table;
}

function delete_person(){
	$table = $this->get_table();
	$id=$this->input->post('id');
	$this->db->where('id', $id);
	$result=$this->db->delete($table);
	return $result;
}

function update_person(){
	$table = $this->get_table();
	$id=$this->input->post('id');
	$name=$this->input->post('name');
	$email=$this->input->post('email');
	$contact=$this->input->post('contact');

	$this->db->set('email', $email);
	$this->db->set('contact', $contact);
	$this->db->set('name', $name);
	$this->db->where('id', $id);
	$result=$this->db->update($table);
	return $result;
}

function insert_person($insert_data){
	$table = $this->get_table();
	$result=$this->db->insert($table,$insert_data);
	return $result;
}

function person_list(){
	$table = $this->get_table();
	$query = $this->db->get($table);
	return $query->result();
}

function get($order_by){
$table = $this->get_table();
$this->db->order_by($order_by);
$query=$this->db->get($table);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$table = $this->get_table();
$this->db->limit($limit, $offset);
$this->db->order_by($order_by);
$query=$this->db->get($table);
return $query;
}

function get_where($id){
$table = $this->get_table();
$this->db->where('id', $id);
$query=$this->db->get($table);
return $query;
}

function get_where_custom($col, $value) {
$table = $this->get_table();
$this->db->where($col, $value);
$query=$this->db->get($table);
return $query;
}

function _insert($data){
$table = $this->get_table();
$this->db->insert($table, $data);
}

function _update($id, $data){
$table = $this->get_table();
$this->db->where('id', $id);
$this->db->update($table, $data);
}

function _delete($id){
$table = $this->get_table();
$this->db->where('id', $id);
$this->db->delete($table);
}

function count_where($column, $value) {
$table = $this->get_table();
$this->db->where($column, $value);
$query=$this->db->get($table);
$num_rows = $query->num_rows();
return $num_rows;
}

function count_all() {
$table = $this->get_table();
$query=$this->db->get($table);
$num_rows = $query->num_rows();
return $num_rows;
}

function get_max() {
$table = $this->get_table();
$this->db->select_max('id');
$query = $this->db->get($table);
$row=$query->row();
$id=$row->id;
return $id;
}

function _custom_query($mysql_query) {
$query = $this->db->query($mysql_query);
return $query;
}

}