<?php
class Person extends MX_Controller 
{

function __construct() {
parent::__construct();
$this->load->model('mdl_person');

}

public function index(){
	$this->load->view('home');
}

function person_data(){
	$data=$this->mdl_person->person_list();
	echo json_encode($data);
}



function insert_data(){
	$insert_data = array(
				'name' 	=> $this->input->post('name'), 
				'email' => $this->input->post('email'), 
				'contact' => $this->input->post('contact'), 
			);
	$data=$this->_insert($insert_data);
	echo json_encode($data);

}

function update_data(){
	$data=$this->mdl_person->update_person();
	echo json_encode($data);
}


function delete_data(){
	$data=$this->mdl_person->delete_person();
	echo json_encode($data);
}






function get($order_by){
$this->load->model('mdl_person');
$query = $this->mdl_person->get($order_by);
return $query;
}

function get_with_limit($limit, $offset, $order_by) {
$this->load->model('mdl_person');
$query = $this->mdl_person->get_with_limit($limit, $offset, $order_by);
return $query;
}

function get_where($id){
$this->load->model('mdl_person');
$query = $this->mdl_person->get_where($id);
return $query;
}

function get_where_custom($col, $value) {
$this->load->model('mdl_person');
$query = $this->mdl_person->get_where_custom($col, $value);
return $query;
}

function _insert($data){
$this->load->model('mdl_person');
$this->mdl_person->_insert($data);
}

function _update($id, $data){
$this->load->model('mdl_person');
$this->mdl_person->_update($id, $data);
}

function _delete($id){
$this->load->model('mdl_person');
$this->mdl_person->_delete($id);
}

function count_where($column, $value) {
$this->load->model('mdl_person');
$count = $this->mdl_person->count_where($column, $value);
return $count;
}

function get_max() {
$this->load->model('mdl_person');
$max_id = $this->mdl_person->get_max();
return $max_id;
}

function _custom_query($mysql_query) {
$this->load->model('mdl_person');
$query = $this->mdl_person->_custom_query($mysql_query);
return $query;
}

}