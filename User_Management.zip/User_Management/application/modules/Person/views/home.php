<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css">
  <script src="<?= base_url() ?>assets/js/jquery.min.js"></script>
  <script src="<?= base_url() ?>assets/js/popper.min.js"></script>
  <script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>CRUD Operations</h2>
  <!-- insert -->
  <div class="float-left"><a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#Modal_Insert"><span class="fa fa-plus"></span> Insert Data</a></div>

<br><br>
  <p>Please See Available Records Below.</p>            
  <table class="table table-dark">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact</th>
        <th style="text-align: right;">Action</th>
      </tr>
    </thead>
    <tbody id="show_data">
                    
    </tbody>
  </table>
</div>


<!-- MODAL INSERT -->
            <form>
            <div class="modal fade" id="Modal_Insert" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Insert New User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Name</label>
                            <div class="col-md-10">
                              <input type="text" name="name" id="name" class="form-control" placeholder="Your Name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Email</label>
                            <div class="col-md-10">
                              <input type="text" name="email" id="email" class="form-control" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Contact</label>
                            <div class="col-md-10">
                              <input type="text" name="contact" id="contact" class="form-control" placeholder="Contact">
                            </div>
                        </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL INSERT-->


        <!-- MODAL EDIT -->
        <form>
            <div class="modal fade" id="Modal_Edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Person</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Name</label>
                            <div class="col-md-10">
                              <input type="text" name="name_edit" id="name_edit" class="form-control" placeholder="Your Name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Email</label>
                            <div class="col-md-10">
                              <input type="text" name="email_edit" id="email_edit" class="form-control" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Contact</label>
                            <div class="col-md-10">
                              <input type="text" name="contact_edit" id="contact_edit" class="form-control" placeholder="Contact">
                            </div>
                        </div>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="id_edit" id="id_edit">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" type="submit" id="btn_update" class="btn btn-primary">Update</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL EDIT-->


        <!--MODAL DELETE-->
         <form>
            <div class="modal fade" id="Modal_Delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Person</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Are you sure to delete this record?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="id_delete" id="id_delete" class="form-control">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="button" type="submit" id="btn_delete" class="btn btn-primary">Yes</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL DELETE-->



<script type="text/javascript">
  $(document).ready(function(){
    show_persons(); //show persons
    function show_persons(){
          $.ajax({
              type  : 'ajax',
              url   : '<?= base_url()?>person/person_data/',
              async : false,
              dataType : 'json',
              success : function(data){
                  var html = '';
                  var i;
                  for(i=0; i<data.length; i++){
                      html += '<tr>'+
                            '<td>'+data[i].id+'</td>'+
                            '<td>'+data[i].name+'</td>'+
                              '<td>'+data[i].email+'</td>'+
                              '<td>'+data[i].contact+'</td>'+
                              '<td style="text-align:right;">'+
                                      '<a href="javascript:void(0);" class="btn btn-info item_edit" data-id="'+data[i].id+'" data-name="'+data[i].name+'" data-email="'+data[i].email+'" data-contact="'+data[i].contact+'">Edit</a>'+' '+
                                      '<a href="javascript:void(0);" class="btn btn-danger item_delete" data-id="'+data[i].id+'">Delete</a>'+
                                  '</td>'+
                              '</tr>';
                  }
                  $('#show_data').html(html);
              }

          });
      }

      //Insert Person
        $('#btn_save').on('click',function(){
            var name = $('#name').val();
            var email = $('#email').val();
            var contact = $('#contact').val();
            $.ajax({
                type : "POST",
                url  : "<?= base_url()?>person/insert_data/",
                dataType : "JSON",
                data : {name:name , email:email, contact:contact},
                success: function(data){
                    $('[name="name"]').val("");
                    $('[name="email"]').val("");
                    $('[name="contact"]').val("");
                    $('#Modal_Insert').modal('hide');
                    show_persons();
                }
            });
            return false;
        });

        //get data from show data
        $('#show_data').on('click','.item_edit',function(){
            var id = $(this).data('id');
            var name = $(this).data('name');
            var email = $(this).data('email');
            var contact = $(this).data('contact');
            
            $('#Modal_Edit').modal('show');
            $('[id="id_edit"]').val(id);
            $('[name="name_edit"]').val(name);
            $('[name="email_edit"]').val(email);
            $('[name="contact_edit"]').val(contact);
        });

        //update person
         $('#btn_update').on('click',function(){
            var id = $('#id_edit').val();
            var name = $('#name_edit').val();
            var email = $('#email_edit').val();
            var contact = $('#contact_edit').val();
            $.ajax({
                type : "POST",
                url  : "<?= base_url() ?>person/update_data/",
                dataType : "JSON",
                data : {id:id, name:name , email:email, contact:contact},
                success: function(data){
                    $('[id="id_edit"]').val("");
                    $('[name="name_edit"]').val("");
                    $('[name="email_edit"]').val("");
                    $('[name="contact_edit"]').val("");
                    $('#Modal_Edit').modal('hide');
                    show_persons();
                }
            });
            return false;
        });

        //get data from show data
        $('#show_data').on('click','.item_delete',function(){
            var id = $(this).data('id');
            
            $('#Modal_Delete').modal('show');
            $('[name="id_delete"]').val(id);
        });

        //delete person
         $('#btn_delete').on('click',function(){
            var id = $('#id_delete').val();
            $.ajax({
                type : "POST",
                url  : "<?= base_url() ?>person/delete_data/",
                dataType : "JSON",
                data : {id:id},
                success: function(data){
                    $('[name="id_delete"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_persons();
                }
            });
            return false;
        });

});
</script>
</body>
</html>
