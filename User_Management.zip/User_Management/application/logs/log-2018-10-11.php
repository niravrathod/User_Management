<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-11 09:55:35 --> Config Class Initialized
INFO - 2018-10-11 09:55:35 --> Hooks Class Initialized
DEBUG - 2018-10-11 09:55:44 --> UTF-8 Support Enabled
INFO - 2018-10-11 09:55:44 --> Utf8 Class Initialized
INFO - 2018-10-11 09:55:46 --> URI Class Initialized
DEBUG - 2018-10-11 09:55:47 --> No URI present. Default controller set.
INFO - 2018-10-11 09:55:47 --> Router Class Initialized
INFO - 2018-10-11 09:55:47 --> Output Class Initialized
INFO - 2018-10-11 09:55:47 --> Security Class Initialized
DEBUG - 2018-10-11 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-11 09:55:48 --> Input Class Initialized
INFO - 2018-10-11 09:55:48 --> Language Class Initialized
INFO - 2018-10-11 09:55:49 --> Language Class Initialized
INFO - 2018-10-11 09:55:49 --> Config Class Initialized
INFO - 2018-10-11 09:55:49 --> Loader Class Initialized
INFO - 2018-10-11 09:55:50 --> Helper loaded: url_helper
INFO - 2018-10-11 09:55:50 --> Helper loaded: form_helper
INFO - 2018-10-11 09:55:52 --> Database Driver Class Initialized
INFO - 2018-10-11 09:55:54 --> Email Class Initialized
INFO - 2018-10-11 09:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-11 09:55:54 --> Form Validation Class Initialized
INFO - 2018-10-11 09:55:54 --> Controller Class Initialized
DEBUG - 2018-10-11 09:55:54 --> Person MX_Controller Initialized
INFO - 2018-10-11 09:55:55 --> Model Class Initialized
DEBUG - 2018-10-11 09:55:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-11 09:55:55 --> Model Class Initialized
DEBUG - 2018-10-11 09:55:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-11 09:55:55 --> Final output sent to browser
DEBUG - 2018-10-11 09:55:55 --> Total execution time: 20.6572
INFO - 2018-10-11 09:57:09 --> Config Class Initialized
INFO - 2018-10-11 09:57:09 --> Hooks Class Initialized
DEBUG - 2018-10-11 09:57:10 --> UTF-8 Support Enabled
INFO - 2018-10-11 09:57:10 --> Utf8 Class Initialized
INFO - 2018-10-11 09:57:10 --> URI Class Initialized
DEBUG - 2018-10-11 09:57:11 --> No URI present. Default controller set.
INFO - 2018-10-11 09:57:11 --> Router Class Initialized
INFO - 2018-10-11 09:57:11 --> Output Class Initialized
INFO - 2018-10-11 09:57:11 --> Security Class Initialized
DEBUG - 2018-10-11 09:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-11 09:57:11 --> Input Class Initialized
INFO - 2018-10-11 09:57:11 --> Language Class Initialized
INFO - 2018-10-11 09:57:13 --> Language Class Initialized
INFO - 2018-10-11 09:57:13 --> Config Class Initialized
INFO - 2018-10-11 09:57:13 --> Loader Class Initialized
INFO - 2018-10-11 09:57:14 --> Helper loaded: url_helper
INFO - 2018-10-11 09:57:14 --> Helper loaded: form_helper
INFO - 2018-10-11 09:57:15 --> Database Driver Class Initialized
INFO - 2018-10-11 09:57:15 --> Email Class Initialized
INFO - 2018-10-11 09:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-11 09:57:16 --> Form Validation Class Initialized
INFO - 2018-10-11 09:57:16 --> Controller Class Initialized
DEBUG - 2018-10-11 09:57:16 --> Person MX_Controller Initialized
INFO - 2018-10-11 09:57:16 --> Model Class Initialized
DEBUG - 2018-10-11 09:57:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-11 09:57:17 --> Model Class Initialized
DEBUG - 2018-10-11 09:57:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-11 09:57:17 --> Final output sent to browser
DEBUG - 2018-10-11 09:57:17 --> Total execution time: 8.8335
INFO - 2018-10-11 09:57:30 --> Config Class Initialized
INFO - 2018-10-11 09:57:30 --> Hooks Class Initialized
DEBUG - 2018-10-11 09:57:31 --> UTF-8 Support Enabled
INFO - 2018-10-11 09:57:31 --> Utf8 Class Initialized
INFO - 2018-10-11 09:57:31 --> URI Class Initialized
INFO - 2018-10-11 09:57:31 --> Router Class Initialized
INFO - 2018-10-11 09:57:31 --> Output Class Initialized
INFO - 2018-10-11 09:57:32 --> Security Class Initialized
DEBUG - 2018-10-11 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-11 09:57:32 --> Input Class Initialized
INFO - 2018-10-11 09:57:32 --> Language Class Initialized
INFO - 2018-10-11 09:57:32 --> Language Class Initialized
INFO - 2018-10-11 09:57:32 --> Config Class Initialized
INFO - 2018-10-11 09:57:32 --> Loader Class Initialized
INFO - 2018-10-11 09:57:32 --> Helper loaded: url_helper
INFO - 2018-10-11 09:57:32 --> Helper loaded: form_helper
INFO - 2018-10-11 09:57:32 --> Database Driver Class Initialized
INFO - 2018-10-11 09:57:32 --> Email Class Initialized
INFO - 2018-10-11 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-11 09:57:32 --> Form Validation Class Initialized
INFO - 2018-10-11 09:57:32 --> Controller Class Initialized
DEBUG - 2018-10-11 09:57:32 --> Person MX_Controller Initialized
INFO - 2018-10-11 09:57:32 --> Model Class Initialized
DEBUG - 2018-10-11 09:57:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-11 09:57:32 --> Model Class Initialized
INFO - 2018-10-11 09:57:34 --> Final output sent to browser
DEBUG - 2018-10-11 09:57:34 --> Total execution time: 3.5162
INFO - 2018-10-11 10:44:10 --> Config Class Initialized
INFO - 2018-10-11 10:44:11 --> Hooks Class Initialized
DEBUG - 2018-10-11 10:44:14 --> UTF-8 Support Enabled
INFO - 2018-10-11 10:44:14 --> Utf8 Class Initialized
INFO - 2018-10-11 10:44:15 --> URI Class Initialized
DEBUG - 2018-10-11 10:44:16 --> No URI present. Default controller set.
INFO - 2018-10-11 10:44:16 --> Router Class Initialized
INFO - 2018-10-11 10:44:17 --> Output Class Initialized
INFO - 2018-10-11 10:44:17 --> Security Class Initialized
DEBUG - 2018-10-11 10:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-11 10:44:17 --> Input Class Initialized
INFO - 2018-10-11 10:44:18 --> Language Class Initialized
INFO - 2018-10-11 10:44:18 --> Language Class Initialized
INFO - 2018-10-11 10:44:18 --> Config Class Initialized
INFO - 2018-10-11 10:44:19 --> Loader Class Initialized
INFO - 2018-10-11 10:44:19 --> Helper loaded: url_helper
INFO - 2018-10-11 10:44:19 --> Helper loaded: form_helper
INFO - 2018-10-11 10:44:20 --> Database Driver Class Initialized
INFO - 2018-10-11 10:44:20 --> Email Class Initialized
INFO - 2018-10-11 10:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-11 10:44:21 --> Form Validation Class Initialized
INFO - 2018-10-11 10:44:21 --> Controller Class Initialized
DEBUG - 2018-10-11 10:44:21 --> Person MX_Controller Initialized
INFO - 2018-10-11 10:44:21 --> Model Class Initialized
DEBUG - 2018-10-11 10:44:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-11 10:44:21 --> Model Class Initialized
DEBUG - 2018-10-11 10:44:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-11 10:44:21 --> Final output sent to browser
DEBUG - 2018-10-11 10:44:21 --> Total execution time: 11.2584
