<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-16 11:18:37 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-16 11:18:37 --> Config Class Initialized
INFO - 2018-10-16 11:18:37 --> Hooks Class Initialized
INFO - 2018-10-16 11:18:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:18:38 --> UTF-8 Support Enabled
DEBUG - 2018-10-16 11:18:38 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:18:38 --> Utf8 Class Initialized
INFO - 2018-10-16 11:18:38 --> Utf8 Class Initialized
INFO - 2018-10-16 11:18:40 --> URI Class Initialized
INFO - 2018-10-16 11:18:40 --> URI Class Initialized
DEBUG - 2018-10-16 11:18:41 --> No URI present. Default controller set.
DEBUG - 2018-10-16 11:18:41 --> No URI present. Default controller set.
INFO - 2018-10-16 11:18:41 --> Router Class Initialized
INFO - 2018-10-16 11:18:41 --> Router Class Initialized
INFO - 2018-10-16 11:18:42 --> Output Class Initialized
INFO - 2018-10-16 11:18:42 --> Output Class Initialized
INFO - 2018-10-16 11:18:42 --> Security Class Initialized
INFO - 2018-10-16 11:18:42 --> Security Class Initialized
DEBUG - 2018-10-16 11:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:18:43 --> Input Class Initialized
DEBUG - 2018-10-16 11:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:18:43 --> Input Class Initialized
INFO - 2018-10-16 11:18:43 --> Language Class Initialized
INFO - 2018-10-16 11:18:43 --> Language Class Initialized
INFO - 2018-10-16 11:18:44 --> Language Class Initialized
INFO - 2018-10-16 11:18:44 --> Language Class Initialized
INFO - 2018-10-16 11:18:44 --> Config Class Initialized
INFO - 2018-10-16 11:18:44 --> Config Class Initialized
INFO - 2018-10-16 11:18:44 --> Loader Class Initialized
INFO - 2018-10-16 11:18:44 --> Loader Class Initialized
INFO - 2018-10-16 11:18:45 --> Helper loaded: url_helper
INFO - 2018-10-16 11:18:45 --> Helper loaded: url_helper
INFO - 2018-10-16 11:18:45 --> Helper loaded: form_helper
INFO - 2018-10-16 11:18:45 --> Helper loaded: form_helper
INFO - 2018-10-16 11:18:46 --> Database Driver Class Initialized
INFO - 2018-10-16 11:18:46 --> Database Driver Class Initialized
INFO - 2018-10-16 11:18:50 --> Email Class Initialized
INFO - 2018-10-16 11:18:50 --> Email Class Initialized
INFO - 2018-10-16 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:18:51 --> Form Validation Class Initialized
INFO - 2018-10-16 11:18:51 --> Controller Class Initialized
DEBUG - 2018-10-16 11:18:51 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:18:51 --> Form Validation Class Initialized
INFO - 2018-10-16 11:18:51 --> Controller Class Initialized
INFO - 2018-10-16 11:18:51 --> Model Class Initialized
DEBUG - 2018-10-16 11:18:51 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:18:51 --> Model Class Initialized
DEBUG - 2018-10-16 11:18:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
DEBUG - 2018-10-16 11:18:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-16 11:18:51 --> Model Class Initialized
INFO - 2018-10-16 11:18:51 --> Model Class Initialized
DEBUG - 2018-10-16 11:18:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
DEBUG - 2018-10-16 11:18:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-16 11:18:52 --> Final output sent to browser
DEBUG - 2018-10-16 11:18:52 --> Total execution time: 16.4603
INFO - 2018-10-16 11:18:52 --> Final output sent to browser
DEBUG - 2018-10-16 11:18:52 --> Total execution time: 16.4528
INFO - 2018-10-16 11:18:58 --> Config Class Initialized
INFO - 2018-10-16 11:18:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:18:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:18:58 --> Utf8 Class Initialized
INFO - 2018-10-16 11:18:58 --> URI Class Initialized
INFO - 2018-10-16 11:18:58 --> Router Class Initialized
INFO - 2018-10-16 11:18:58 --> Output Class Initialized
INFO - 2018-10-16 11:18:59 --> Security Class Initialized
DEBUG - 2018-10-16 11:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:18:59 --> Input Class Initialized
INFO - 2018-10-16 11:18:59 --> Language Class Initialized
INFO - 2018-10-16 11:18:59 --> Language Class Initialized
INFO - 2018-10-16 11:18:59 --> Config Class Initialized
INFO - 2018-10-16 11:18:59 --> Loader Class Initialized
INFO - 2018-10-16 11:18:59 --> Helper loaded: url_helper
INFO - 2018-10-16 11:18:59 --> Helper loaded: form_helper
INFO - 2018-10-16 11:18:59 --> Database Driver Class Initialized
INFO - 2018-10-16 11:18:59 --> Email Class Initialized
INFO - 2018-10-16 11:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:18:59 --> Form Validation Class Initialized
INFO - 2018-10-16 11:18:59 --> Controller Class Initialized
DEBUG - 2018-10-16 11:18:59 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:18:59 --> Model Class Initialized
DEBUG - 2018-10-16 11:18:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-16 11:18:59 --> Model Class Initialized
INFO - 2018-10-16 11:19:00 --> Final output sent to browser
DEBUG - 2018-10-16 11:19:00 --> Total execution time: 2.4550
INFO - 2018-10-16 11:23:30 --> Config Class Initialized
INFO - 2018-10-16 11:23:30 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:23:30 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:23:30 --> Utf8 Class Initialized
INFO - 2018-10-16 11:23:30 --> URI Class Initialized
INFO - 2018-10-16 11:23:30 --> Router Class Initialized
INFO - 2018-10-16 11:23:30 --> Output Class Initialized
INFO - 2018-10-16 11:23:30 --> Security Class Initialized
DEBUG - 2018-10-16 11:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:23:30 --> Input Class Initialized
INFO - 2018-10-16 11:23:30 --> Language Class Initialized
INFO - 2018-10-16 11:23:30 --> Language Class Initialized
INFO - 2018-10-16 11:23:30 --> Config Class Initialized
INFO - 2018-10-16 11:23:30 --> Loader Class Initialized
INFO - 2018-10-16 11:23:30 --> Helper loaded: url_helper
INFO - 2018-10-16 11:23:30 --> Helper loaded: form_helper
INFO - 2018-10-16 11:23:30 --> Database Driver Class Initialized
INFO - 2018-10-16 11:23:30 --> Email Class Initialized
INFO - 2018-10-16 11:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:23:30 --> Form Validation Class Initialized
INFO - 2018-10-16 11:23:30 --> Controller Class Initialized
DEBUG - 2018-10-16 11:23:30 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:23:30 --> Model Class Initialized
DEBUG - 2018-10-16 11:23:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-16 11:23:30 --> Model Class Initialized
INFO - 2018-10-16 11:23:31 --> Final output sent to browser
DEBUG - 2018-10-16 11:23:31 --> Total execution time: 1.1676
INFO - 2018-10-16 11:23:31 --> Config Class Initialized
INFO - 2018-10-16 11:23:31 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:23:31 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:23:31 --> Utf8 Class Initialized
INFO - 2018-10-16 11:23:31 --> URI Class Initialized
INFO - 2018-10-16 11:23:31 --> Router Class Initialized
INFO - 2018-10-16 11:23:31 --> Output Class Initialized
INFO - 2018-10-16 11:23:31 --> Security Class Initialized
DEBUG - 2018-10-16 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:23:31 --> Input Class Initialized
INFO - 2018-10-16 11:23:31 --> Language Class Initialized
INFO - 2018-10-16 11:23:31 --> Language Class Initialized
INFO - 2018-10-16 11:23:31 --> Config Class Initialized
INFO - 2018-10-16 11:23:32 --> Loader Class Initialized
INFO - 2018-10-16 11:23:32 --> Helper loaded: url_helper
INFO - 2018-10-16 11:23:32 --> Helper loaded: form_helper
INFO - 2018-10-16 11:23:32 --> Database Driver Class Initialized
INFO - 2018-10-16 11:23:32 --> Email Class Initialized
INFO - 2018-10-16 11:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:23:32 --> Form Validation Class Initialized
INFO - 2018-10-16 11:23:32 --> Controller Class Initialized
DEBUG - 2018-10-16 11:23:32 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:23:32 --> Model Class Initialized
DEBUG - 2018-10-16 11:23:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-16 11:23:32 --> Model Class Initialized
INFO - 2018-10-16 11:23:32 --> Final output sent to browser
DEBUG - 2018-10-16 11:23:32 --> Total execution time: 0.9150
INFO - 2018-10-16 11:46:52 --> Config Class Initialized
INFO - 2018-10-16 11:46:52 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:46:52 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:46:52 --> Utf8 Class Initialized
INFO - 2018-10-16 11:46:52 --> URI Class Initialized
DEBUG - 2018-10-16 11:46:53 --> No URI present. Default controller set.
INFO - 2018-10-16 11:46:53 --> Router Class Initialized
INFO - 2018-10-16 11:46:54 --> Output Class Initialized
INFO - 2018-10-16 11:46:54 --> Security Class Initialized
DEBUG - 2018-10-16 11:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:46:54 --> Input Class Initialized
INFO - 2018-10-16 11:46:54 --> Language Class Initialized
INFO - 2018-10-16 11:46:54 --> Language Class Initialized
INFO - 2018-10-16 11:46:54 --> Config Class Initialized
INFO - 2018-10-16 11:46:55 --> Loader Class Initialized
INFO - 2018-10-16 11:46:55 --> Helper loaded: url_helper
INFO - 2018-10-16 11:46:55 --> Helper loaded: form_helper
INFO - 2018-10-16 11:46:55 --> Database Driver Class Initialized
INFO - 2018-10-16 11:46:55 --> Email Class Initialized
INFO - 2018-10-16 11:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:46:56 --> Form Validation Class Initialized
INFO - 2018-10-16 11:46:56 --> Controller Class Initialized
DEBUG - 2018-10-16 11:46:56 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:46:56 --> Model Class Initialized
DEBUG - 2018-10-16 11:46:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-16 11:46:56 --> Model Class Initialized
DEBUG - 2018-10-16 11:46:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-16 11:46:56 --> Final output sent to browser
DEBUG - 2018-10-16 11:46:56 --> Total execution time: 4.7476
INFO - 2018-10-16 11:46:58 --> Config Class Initialized
INFO - 2018-10-16 11:46:58 --> Hooks Class Initialized
DEBUG - 2018-10-16 11:46:58 --> UTF-8 Support Enabled
INFO - 2018-10-16 11:46:58 --> Utf8 Class Initialized
INFO - 2018-10-16 11:46:58 --> URI Class Initialized
INFO - 2018-10-16 11:46:59 --> Router Class Initialized
INFO - 2018-10-16 11:46:59 --> Output Class Initialized
INFO - 2018-10-16 11:46:59 --> Security Class Initialized
DEBUG - 2018-10-16 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 11:46:59 --> Input Class Initialized
INFO - 2018-10-16 11:46:59 --> Language Class Initialized
INFO - 2018-10-16 11:46:59 --> Language Class Initialized
INFO - 2018-10-16 11:46:59 --> Config Class Initialized
INFO - 2018-10-16 11:46:59 --> Loader Class Initialized
INFO - 2018-10-16 11:46:59 --> Helper loaded: url_helper
INFO - 2018-10-16 11:46:59 --> Helper loaded: form_helper
INFO - 2018-10-16 11:46:59 --> Database Driver Class Initialized
INFO - 2018-10-16 11:46:59 --> Email Class Initialized
INFO - 2018-10-16 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 11:46:59 --> Form Validation Class Initialized
INFO - 2018-10-16 11:46:59 --> Controller Class Initialized
DEBUG - 2018-10-16 11:47:00 --> Person MX_Controller Initialized
INFO - 2018-10-16 11:47:00 --> Model Class Initialized
DEBUG - 2018-10-16 11:47:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-16 11:47:00 --> Model Class Initialized
INFO - 2018-10-16 11:47:03 --> Final output sent to browser
DEBUG - 2018-10-16 11:47:03 --> Total execution time: 4.9701
