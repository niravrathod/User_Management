<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-17 07:02:40 --> Config Class Initialized
INFO - 2018-10-17 07:02:40 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:02:41 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:02:41 --> Utf8 Class Initialized
INFO - 2018-10-17 07:02:42 --> URI Class Initialized
DEBUG - 2018-10-17 07:02:43 --> No URI present. Default controller set.
INFO - 2018-10-17 07:02:43 --> Router Class Initialized
INFO - 2018-10-17 07:02:43 --> Output Class Initialized
INFO - 2018-10-17 07:02:43 --> Security Class Initialized
DEBUG - 2018-10-17 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:02:43 --> Input Class Initialized
INFO - 2018-10-17 07:02:43 --> Language Class Initialized
INFO - 2018-10-17 07:02:43 --> Language Class Initialized
INFO - 2018-10-17 07:02:43 --> Config Class Initialized
INFO - 2018-10-17 07:02:44 --> Loader Class Initialized
INFO - 2018-10-17 07:02:44 --> Helper loaded: url_helper
INFO - 2018-10-17 07:02:44 --> Helper loaded: form_helper
INFO - 2018-10-17 07:02:44 --> Database Driver Class Initialized
INFO - 2018-10-17 07:02:45 --> Email Class Initialized
INFO - 2018-10-17 07:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:02:45 --> Form Validation Class Initialized
INFO - 2018-10-17 07:02:45 --> Controller Class Initialized
DEBUG - 2018-10-17 07:02:45 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:02:45 --> Model Class Initialized
DEBUG - 2018-10-17 07:02:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-17 07:02:45 --> Model Class Initialized
DEBUG - 2018-10-17 07:02:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-17 07:02:45 --> Final output sent to browser
DEBUG - 2018-10-17 07:02:45 --> Total execution time: 5.8301
INFO - 2018-10-17 07:03:02 --> Config Class Initialized
INFO - 2018-10-17 07:03:02 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:03:02 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:03:02 --> Utf8 Class Initialized
INFO - 2018-10-17 07:03:02 --> URI Class Initialized
INFO - 2018-10-17 07:03:02 --> Router Class Initialized
INFO - 2018-10-17 07:03:02 --> Output Class Initialized
INFO - 2018-10-17 07:03:03 --> Security Class Initialized
DEBUG - 2018-10-17 07:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:03:03 --> Input Class Initialized
INFO - 2018-10-17 07:03:03 --> Language Class Initialized
INFO - 2018-10-17 07:03:03 --> Language Class Initialized
INFO - 2018-10-17 07:03:03 --> Config Class Initialized
INFO - 2018-10-17 07:03:03 --> Loader Class Initialized
INFO - 2018-10-17 07:03:03 --> Helper loaded: url_helper
INFO - 2018-10-17 07:03:03 --> Helper loaded: form_helper
INFO - 2018-10-17 07:03:03 --> Database Driver Class Initialized
INFO - 2018-10-17 07:03:03 --> Email Class Initialized
INFO - 2018-10-17 07:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:03:03 --> Form Validation Class Initialized
INFO - 2018-10-17 07:03:03 --> Controller Class Initialized
DEBUG - 2018-10-17 07:03:03 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:03:03 --> Model Class Initialized
DEBUG - 2018-10-17 07:03:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:03:03 --> Model Class Initialized
INFO - 2018-10-17 07:03:04 --> Final output sent to browser
DEBUG - 2018-10-17 07:03:04 --> Total execution time: 1.8050
INFO - 2018-10-17 07:04:19 --> Config Class Initialized
INFO - 2018-10-17 07:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:04:19 --> Utf8 Class Initialized
INFO - 2018-10-17 07:04:19 --> URI Class Initialized
INFO - 2018-10-17 07:04:19 --> Router Class Initialized
INFO - 2018-10-17 07:04:19 --> Output Class Initialized
INFO - 2018-10-17 07:04:19 --> Security Class Initialized
DEBUG - 2018-10-17 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:04:19 --> Input Class Initialized
INFO - 2018-10-17 07:04:20 --> Language Class Initialized
INFO - 2018-10-17 07:04:20 --> Language Class Initialized
INFO - 2018-10-17 07:04:20 --> Config Class Initialized
INFO - 2018-10-17 07:04:20 --> Loader Class Initialized
INFO - 2018-10-17 07:04:20 --> Helper loaded: url_helper
INFO - 2018-10-17 07:04:20 --> Helper loaded: form_helper
INFO - 2018-10-17 07:04:20 --> Database Driver Class Initialized
INFO - 2018-10-17 07:04:20 --> Email Class Initialized
INFO - 2018-10-17 07:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:04:20 --> Form Validation Class Initialized
INFO - 2018-10-17 07:04:21 --> Controller Class Initialized
DEBUG - 2018-10-17 07:04:21 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:04:21 --> Model Class Initialized
DEBUG - 2018-10-17 07:04:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:04:21 --> Model Class Initialized
INFO - 2018-10-17 07:04:21 --> Final output sent to browser
DEBUG - 2018-10-17 07:04:21 --> Total execution time: 2.2642
INFO - 2018-10-17 07:04:21 --> Config Class Initialized
INFO - 2018-10-17 07:04:21 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:04:21 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:04:21 --> Utf8 Class Initialized
INFO - 2018-10-17 07:04:21 --> URI Class Initialized
INFO - 2018-10-17 07:04:21 --> Router Class Initialized
INFO - 2018-10-17 07:04:21 --> Output Class Initialized
INFO - 2018-10-17 07:04:21 --> Security Class Initialized
DEBUG - 2018-10-17 07:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:04:21 --> Input Class Initialized
INFO - 2018-10-17 07:04:21 --> Language Class Initialized
INFO - 2018-10-17 07:04:21 --> Language Class Initialized
INFO - 2018-10-17 07:04:21 --> Config Class Initialized
INFO - 2018-10-17 07:04:21 --> Loader Class Initialized
INFO - 2018-10-17 07:04:22 --> Helper loaded: url_helper
INFO - 2018-10-17 07:04:22 --> Helper loaded: form_helper
INFO - 2018-10-17 07:04:22 --> Database Driver Class Initialized
INFO - 2018-10-17 07:04:22 --> Email Class Initialized
INFO - 2018-10-17 07:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:04:22 --> Form Validation Class Initialized
INFO - 2018-10-17 07:04:22 --> Controller Class Initialized
DEBUG - 2018-10-17 07:04:22 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:04:22 --> Model Class Initialized
DEBUG - 2018-10-17 07:04:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:04:22 --> Model Class Initialized
INFO - 2018-10-17 07:04:22 --> Final output sent to browser
DEBUG - 2018-10-17 07:04:22 --> Total execution time: 0.7000
INFO - 2018-10-17 07:04:56 --> Config Class Initialized
INFO - 2018-10-17 07:04:56 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:04:56 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:04:56 --> Utf8 Class Initialized
INFO - 2018-10-17 07:04:56 --> URI Class Initialized
INFO - 2018-10-17 07:04:56 --> Router Class Initialized
INFO - 2018-10-17 07:04:56 --> Output Class Initialized
INFO - 2018-10-17 07:04:56 --> Security Class Initialized
DEBUG - 2018-10-17 07:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:04:56 --> Input Class Initialized
INFO - 2018-10-17 07:04:56 --> Language Class Initialized
INFO - 2018-10-17 07:04:56 --> Language Class Initialized
INFO - 2018-10-17 07:04:56 --> Config Class Initialized
INFO - 2018-10-17 07:04:56 --> Loader Class Initialized
INFO - 2018-10-17 07:04:56 --> Helper loaded: url_helper
INFO - 2018-10-17 07:04:56 --> Helper loaded: form_helper
INFO - 2018-10-17 07:04:56 --> Database Driver Class Initialized
INFO - 2018-10-17 07:04:56 --> Email Class Initialized
INFO - 2018-10-17 07:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:04:56 --> Form Validation Class Initialized
INFO - 2018-10-17 07:04:56 --> Controller Class Initialized
DEBUG - 2018-10-17 07:04:56 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:04:56 --> Model Class Initialized
DEBUG - 2018-10-17 07:04:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:04:56 --> Model Class Initialized
INFO - 2018-10-17 07:04:57 --> Final output sent to browser
DEBUG - 2018-10-17 07:04:57 --> Total execution time: 0.8775
INFO - 2018-10-17 07:04:57 --> Config Class Initialized
INFO - 2018-10-17 07:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:04:57 --> Utf8 Class Initialized
INFO - 2018-10-17 07:04:57 --> URI Class Initialized
INFO - 2018-10-17 07:04:57 --> Router Class Initialized
INFO - 2018-10-17 07:04:57 --> Output Class Initialized
INFO - 2018-10-17 07:04:57 --> Security Class Initialized
DEBUG - 2018-10-17 07:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:04:57 --> Input Class Initialized
INFO - 2018-10-17 07:04:57 --> Language Class Initialized
INFO - 2018-10-17 07:04:57 --> Language Class Initialized
INFO - 2018-10-17 07:04:57 --> Config Class Initialized
INFO - 2018-10-17 07:04:57 --> Loader Class Initialized
INFO - 2018-10-17 07:04:57 --> Helper loaded: url_helper
INFO - 2018-10-17 07:04:57 --> Helper loaded: form_helper
INFO - 2018-10-17 07:04:57 --> Database Driver Class Initialized
INFO - 2018-10-17 07:04:57 --> Email Class Initialized
INFO - 2018-10-17 07:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:04:57 --> Form Validation Class Initialized
INFO - 2018-10-17 07:04:57 --> Controller Class Initialized
DEBUG - 2018-10-17 07:04:57 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:04:57 --> Model Class Initialized
DEBUG - 2018-10-17 07:04:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:04:58 --> Model Class Initialized
INFO - 2018-10-17 07:04:58 --> Final output sent to browser
DEBUG - 2018-10-17 07:04:58 --> Total execution time: 0.7850
INFO - 2018-10-17 07:05:22 --> Config Class Initialized
INFO - 2018-10-17 07:05:22 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:05:22 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:05:22 --> Utf8 Class Initialized
INFO - 2018-10-17 07:05:22 --> URI Class Initialized
INFO - 2018-10-17 07:05:22 --> Router Class Initialized
INFO - 2018-10-17 07:05:22 --> Output Class Initialized
INFO - 2018-10-17 07:05:22 --> Security Class Initialized
DEBUG - 2018-10-17 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:05:22 --> Input Class Initialized
INFO - 2018-10-17 07:05:22 --> Language Class Initialized
INFO - 2018-10-17 07:05:23 --> Language Class Initialized
INFO - 2018-10-17 07:05:23 --> Config Class Initialized
INFO - 2018-10-17 07:05:23 --> Loader Class Initialized
INFO - 2018-10-17 07:05:23 --> Helper loaded: url_helper
INFO - 2018-10-17 07:05:23 --> Helper loaded: form_helper
INFO - 2018-10-17 07:05:23 --> Database Driver Class Initialized
INFO - 2018-10-17 07:05:23 --> Email Class Initialized
INFO - 2018-10-17 07:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:05:23 --> Form Validation Class Initialized
INFO - 2018-10-17 07:05:23 --> Controller Class Initialized
DEBUG - 2018-10-17 07:05:23 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:05:23 --> Model Class Initialized
DEBUG - 2018-10-17 07:05:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:05:23 --> Model Class Initialized
INFO - 2018-10-17 07:05:23 --> Final output sent to browser
DEBUG - 2018-10-17 07:05:23 --> Total execution time: 1.0258
INFO - 2018-10-17 07:05:23 --> Config Class Initialized
INFO - 2018-10-17 07:05:23 --> Hooks Class Initialized
DEBUG - 2018-10-17 07:05:23 --> UTF-8 Support Enabled
INFO - 2018-10-17 07:05:23 --> Utf8 Class Initialized
INFO - 2018-10-17 07:05:23 --> URI Class Initialized
INFO - 2018-10-17 07:05:24 --> Router Class Initialized
INFO - 2018-10-17 07:05:24 --> Output Class Initialized
INFO - 2018-10-17 07:05:24 --> Security Class Initialized
DEBUG - 2018-10-17 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-17 07:05:24 --> Input Class Initialized
INFO - 2018-10-17 07:05:24 --> Language Class Initialized
INFO - 2018-10-17 07:05:24 --> Language Class Initialized
INFO - 2018-10-17 07:05:24 --> Config Class Initialized
INFO - 2018-10-17 07:05:24 --> Loader Class Initialized
INFO - 2018-10-17 07:05:24 --> Helper loaded: url_helper
INFO - 2018-10-17 07:05:24 --> Helper loaded: form_helper
INFO - 2018-10-17 07:05:24 --> Database Driver Class Initialized
INFO - 2018-10-17 07:05:24 --> Email Class Initialized
INFO - 2018-10-17 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-17 07:05:24 --> Form Validation Class Initialized
INFO - 2018-10-17 07:05:24 --> Controller Class Initialized
DEBUG - 2018-10-17 07:05:24 --> Person MX_Controller Initialized
INFO - 2018-10-17 07:05:24 --> Model Class Initialized
DEBUG - 2018-10-17 07:05:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-17 07:05:24 --> Model Class Initialized
INFO - 2018-10-17 07:05:24 --> Final output sent to browser
DEBUG - 2018-10-17 07:05:24 --> Total execution time: 0.8375
