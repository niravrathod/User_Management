<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-10 07:01:44 --> Config Class Initialized
INFO - 2018-10-10 07:01:44 --> Hooks Class Initialized
DEBUG - 2018-10-10 07:01:44 --> UTF-8 Support Enabled
INFO - 2018-10-10 07:01:44 --> Utf8 Class Initialized
INFO - 2018-10-10 07:01:45 --> URI Class Initialized
DEBUG - 2018-10-10 07:01:46 --> No URI present. Default controller set.
INFO - 2018-10-10 07:01:46 --> Router Class Initialized
INFO - 2018-10-10 07:01:46 --> Output Class Initialized
INFO - 2018-10-10 07:01:46 --> Security Class Initialized
DEBUG - 2018-10-10 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-10 07:01:46 --> Input Class Initialized
INFO - 2018-10-10 07:01:46 --> Language Class Initialized
INFO - 2018-10-10 07:01:47 --> Language Class Initialized
INFO - 2018-10-10 07:01:47 --> Config Class Initialized
INFO - 2018-10-10 07:01:47 --> Loader Class Initialized
INFO - 2018-10-10 07:01:48 --> Helper loaded: url_helper
INFO - 2018-10-10 07:01:48 --> Helper loaded: form_helper
INFO - 2018-10-10 07:01:49 --> Database Driver Class Initialized
INFO - 2018-10-10 07:01:54 --> Email Class Initialized
INFO - 2018-10-10 07:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-10 07:01:54 --> Form Validation Class Initialized
INFO - 2018-10-10 07:01:54 --> Controller Class Initialized
DEBUG - 2018-10-10 07:01:54 --> Person MX_Controller Initialized
INFO - 2018-10-10 07:01:54 --> Model Class Initialized
DEBUG - 2018-10-10 07:01:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-10 07:01:54 --> Model Class Initialized
DEBUG - 2018-10-10 07:01:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-10 07:01:55 --> Final output sent to browser
DEBUG - 2018-10-10 07:01:55 --> Total execution time: 11.7020
INFO - 2018-10-10 08:43:02 --> Config Class Initialized
INFO - 2018-10-10 08:43:02 --> Hooks Class Initialized
DEBUG - 2018-10-10 08:43:03 --> UTF-8 Support Enabled
INFO - 2018-10-10 08:43:03 --> Utf8 Class Initialized
INFO - 2018-10-10 08:43:04 --> URI Class Initialized
DEBUG - 2018-10-10 08:43:04 --> No URI present. Default controller set.
INFO - 2018-10-10 08:43:04 --> Router Class Initialized
INFO - 2018-10-10 08:43:04 --> Output Class Initialized
INFO - 2018-10-10 08:43:05 --> Security Class Initialized
DEBUG - 2018-10-10 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-10 08:43:05 --> Input Class Initialized
INFO - 2018-10-10 08:43:05 --> Language Class Initialized
INFO - 2018-10-10 08:43:05 --> Language Class Initialized
INFO - 2018-10-10 08:43:05 --> Config Class Initialized
INFO - 2018-10-10 08:43:06 --> Loader Class Initialized
INFO - 2018-10-10 08:43:06 --> Helper loaded: url_helper
INFO - 2018-10-10 08:43:06 --> Helper loaded: form_helper
INFO - 2018-10-10 08:43:07 --> Database Driver Class Initialized
INFO - 2018-10-10 08:43:12 --> Email Class Initialized
INFO - 2018-10-10 08:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-10 08:43:13 --> Form Validation Class Initialized
INFO - 2018-10-10 08:43:13 --> Controller Class Initialized
DEBUG - 2018-10-10 08:43:13 --> Person MX_Controller Initialized
INFO - 2018-10-10 08:43:13 --> Model Class Initialized
DEBUG - 2018-10-10 08:43:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-10 08:43:13 --> Model Class Initialized
DEBUG - 2018-10-10 08:43:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-10 08:43:13 --> Final output sent to browser
DEBUG - 2018-10-10 08:43:13 --> Total execution time: 11.9077
