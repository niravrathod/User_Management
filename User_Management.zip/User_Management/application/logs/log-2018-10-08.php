<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-08 09:03:24 --> Config Class Initialized
INFO - 2018-10-08 09:03:24 --> Hooks Class Initialized
DEBUG - 2018-10-08 09:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-08 09:03:26 --> Utf8 Class Initialized
INFO - 2018-10-08 09:03:27 --> URI Class Initialized
DEBUG - 2018-10-08 09:03:29 --> No URI present. Default controller set.
INFO - 2018-10-08 09:03:29 --> Router Class Initialized
INFO - 2018-10-08 09:03:30 --> Output Class Initialized
INFO - 2018-10-08 09:03:30 --> Security Class Initialized
DEBUG - 2018-10-08 09:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 09:03:30 --> Input Class Initialized
INFO - 2018-10-08 09:03:30 --> Language Class Initialized
INFO - 2018-10-08 09:03:30 --> Language Class Initialized
INFO - 2018-10-08 09:03:31 --> Config Class Initialized
INFO - 2018-10-08 09:03:31 --> Loader Class Initialized
INFO - 2018-10-08 09:03:31 --> Controller Class Initialized
DEBUG - 2018-10-08 09:03:31 --> Welcome MX_Controller Initialized
DEBUG - 2018-10-08 09:03:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Welcome/views/welcome_message.php
INFO - 2018-10-08 09:03:31 --> Final output sent to browser
DEBUG - 2018-10-08 09:03:31 --> Total execution time: 8.2275
INFO - 2018-10-08 09:59:30 --> Config Class Initialized
INFO - 2018-10-08 09:59:30 --> Hooks Class Initialized
DEBUG - 2018-10-08 09:59:32 --> UTF-8 Support Enabled
INFO - 2018-10-08 09:59:32 --> Utf8 Class Initialized
INFO - 2018-10-08 09:59:33 --> URI Class Initialized
DEBUG - 2018-10-08 09:59:33 --> No URI present. Default controller set.
INFO - 2018-10-08 09:59:33 --> Router Class Initialized
INFO - 2018-10-08 09:59:34 --> Output Class Initialized
INFO - 2018-10-08 09:59:34 --> Security Class Initialized
DEBUG - 2018-10-08 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 09:59:34 --> Input Class Initialized
INFO - 2018-10-08 09:59:34 --> Language Class Initialized
INFO - 2018-10-08 09:59:35 --> Language Class Initialized
INFO - 2018-10-08 09:59:35 --> Config Class Initialized
INFO - 2018-10-08 09:59:36 --> Loader Class Initialized
INFO - 2018-10-08 09:59:36 --> Controller Class Initialized
DEBUG - 2018-10-08 09:59:36 --> Welcome MX_Controller Initialized
DEBUG - 2018-10-08 09:59:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Welcome/views/welcome_message.php
INFO - 2018-10-08 09:59:36 --> Final output sent to browser
DEBUG - 2018-10-08 09:59:36 --> Total execution time: 8.6505
INFO - 2018-10-08 10:01:16 --> Config Class Initialized
INFO - 2018-10-08 10:01:16 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:01:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:01:17 --> Utf8 Class Initialized
INFO - 2018-10-08 10:01:17 --> URI Class Initialized
DEBUG - 2018-10-08 10:01:17 --> No URI present. Default controller set.
INFO - 2018-10-08 10:01:17 --> Router Class Initialized
INFO - 2018-10-08 10:01:18 --> Output Class Initialized
INFO - 2018-10-08 10:01:18 --> Security Class Initialized
DEBUG - 2018-10-08 10:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:01:18 --> Input Class Initialized
INFO - 2018-10-08 10:01:18 --> Language Class Initialized
INFO - 2018-10-08 10:01:18 --> Language Class Initialized
INFO - 2018-10-08 10:01:18 --> Config Class Initialized
INFO - 2018-10-08 10:01:18 --> Loader Class Initialized
INFO - 2018-10-08 10:01:18 --> Helper loaded: url_helper
INFO - 2018-10-08 10:01:18 --> Helper loaded: form_helper
INFO - 2018-10-08 10:01:19 --> Database Driver Class Initialized
ERROR - 2018-10-08 10:01:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'users' C:\xampp\htdocs\User_Management\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2018-10-08 10:01:24 --> Unable to connect to the database
INFO - 2018-10-08 10:01:25 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-08 10:01:54 --> Config Class Initialized
INFO - 2018-10-08 10:01:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:01:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:01:55 --> Utf8 Class Initialized
INFO - 2018-10-08 10:01:55 --> URI Class Initialized
DEBUG - 2018-10-08 10:01:55 --> No URI present. Default controller set.
INFO - 2018-10-08 10:01:55 --> Router Class Initialized
INFO - 2018-10-08 10:01:55 --> Output Class Initialized
INFO - 2018-10-08 10:01:55 --> Security Class Initialized
DEBUG - 2018-10-08 10:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:01:56 --> Input Class Initialized
INFO - 2018-10-08 10:01:56 --> Language Class Initialized
INFO - 2018-10-08 10:01:56 --> Language Class Initialized
INFO - 2018-10-08 10:01:56 --> Config Class Initialized
INFO - 2018-10-08 10:01:56 --> Loader Class Initialized
INFO - 2018-10-08 10:01:56 --> Helper loaded: url_helper
INFO - 2018-10-08 10:01:56 --> Helper loaded: form_helper
INFO - 2018-10-08 10:01:56 --> Database Driver Class Initialized
INFO - 2018-10-08 10:01:56 --> Email Class Initialized
INFO - 2018-10-08 10:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:01:57 --> Form Validation Class Initialized
INFO - 2018-10-08 10:01:57 --> Controller Class Initialized
DEBUG - 2018-10-08 10:01:57 --> Welcome MX_Controller Initialized
DEBUG - 2018-10-08 10:01:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Welcome/views/welcome_message.php
INFO - 2018-10-08 10:01:57 --> Final output sent to browser
DEBUG - 2018-10-08 10:01:57 --> Total execution time: 3.2822
INFO - 2018-10-08 10:11:24 --> Config Class Initialized
INFO - 2018-10-08 10:11:24 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:11:24 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:11:24 --> Utf8 Class Initialized
INFO - 2018-10-08 10:11:24 --> URI Class Initialized
INFO - 2018-10-08 10:11:25 --> Router Class Initialized
INFO - 2018-10-08 10:11:25 --> Output Class Initialized
INFO - 2018-10-08 10:11:25 --> Security Class Initialized
DEBUG - 2018-10-08 10:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:11:25 --> Input Class Initialized
INFO - 2018-10-08 10:11:25 --> Language Class Initialized
ERROR - 2018-10-08 10:11:25 --> 404 Page Not Found: ../modules/person/controllers//index
INFO - 2018-10-08 10:11:32 --> Config Class Initialized
INFO - 2018-10-08 10:11:32 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:11:32 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:11:32 --> Utf8 Class Initialized
INFO - 2018-10-08 10:11:32 --> URI Class Initialized
INFO - 2018-10-08 10:11:32 --> Router Class Initialized
INFO - 2018-10-08 10:11:32 --> Output Class Initialized
INFO - 2018-10-08 10:11:32 --> Security Class Initialized
DEBUG - 2018-10-08 10:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:11:32 --> Input Class Initialized
INFO - 2018-10-08 10:11:32 --> Language Class Initialized
ERROR - 2018-10-08 10:11:32 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:11:42 --> Config Class Initialized
INFO - 2018-10-08 10:11:42 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:11:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:11:42 --> Utf8 Class Initialized
INFO - 2018-10-08 10:11:42 --> URI Class Initialized
INFO - 2018-10-08 10:11:42 --> Router Class Initialized
INFO - 2018-10-08 10:11:42 --> Output Class Initialized
INFO - 2018-10-08 10:11:42 --> Security Class Initialized
DEBUG - 2018-10-08 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:11:43 --> Input Class Initialized
INFO - 2018-10-08 10:11:43 --> Language Class Initialized
ERROR - 2018-10-08 10:11:43 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:12:34 --> Config Class Initialized
INFO - 2018-10-08 10:12:34 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:12:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:12:34 --> Utf8 Class Initialized
INFO - 2018-10-08 10:12:34 --> URI Class Initialized
INFO - 2018-10-08 10:12:35 --> Router Class Initialized
INFO - 2018-10-08 10:12:35 --> Output Class Initialized
INFO - 2018-10-08 10:12:35 --> Security Class Initialized
DEBUG - 2018-10-08 10:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:12:35 --> Input Class Initialized
INFO - 2018-10-08 10:12:35 --> Language Class Initialized
ERROR - 2018-10-08 10:12:35 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:14:02 --> Config Class Initialized
INFO - 2018-10-08 10:14:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:14:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:14:02 --> Utf8 Class Initialized
INFO - 2018-10-08 10:14:02 --> URI Class Initialized
INFO - 2018-10-08 10:14:02 --> Router Class Initialized
INFO - 2018-10-08 10:14:02 --> Output Class Initialized
INFO - 2018-10-08 10:14:02 --> Security Class Initialized
DEBUG - 2018-10-08 10:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:14:02 --> Input Class Initialized
INFO - 2018-10-08 10:14:02 --> Language Class Initialized
ERROR - 2018-10-08 10:14:02 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:14:04 --> Config Class Initialized
INFO - 2018-10-08 10:14:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:14:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:14:05 --> Utf8 Class Initialized
INFO - 2018-10-08 10:14:05 --> URI Class Initialized
INFO - 2018-10-08 10:14:05 --> Router Class Initialized
INFO - 2018-10-08 10:14:05 --> Output Class Initialized
INFO - 2018-10-08 10:14:05 --> Security Class Initialized
DEBUG - 2018-10-08 10:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:14:05 --> Input Class Initialized
INFO - 2018-10-08 10:14:05 --> Language Class Initialized
ERROR - 2018-10-08 10:14:05 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:14:36 --> Config Class Initialized
INFO - 2018-10-08 10:14:36 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:14:36 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:14:36 --> Utf8 Class Initialized
INFO - 2018-10-08 10:14:36 --> URI Class Initialized
INFO - 2018-10-08 10:14:36 --> Router Class Initialized
INFO - 2018-10-08 10:14:36 --> Output Class Initialized
INFO - 2018-10-08 10:14:36 --> Security Class Initialized
DEBUG - 2018-10-08 10:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:14:36 --> Input Class Initialized
INFO - 2018-10-08 10:14:36 --> Language Class Initialized
ERROR - 2018-10-08 10:14:36 --> 404 Page Not Found: ../modules/Person/controllers//index
INFO - 2018-10-08 10:14:40 --> Config Class Initialized
INFO - 2018-10-08 10:14:40 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:14:40 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:14:40 --> Utf8 Class Initialized
INFO - 2018-10-08 10:14:40 --> URI Class Initialized
INFO - 2018-10-08 10:14:40 --> Router Class Initialized
INFO - 2018-10-08 10:14:40 --> Output Class Initialized
INFO - 2018-10-08 10:14:40 --> Security Class Initialized
DEBUG - 2018-10-08 10:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:14:40 --> Input Class Initialized
INFO - 2018-10-08 10:14:40 --> Language Class Initialized
ERROR - 2018-10-08 10:14:40 --> 404 Page Not Found: ../modules/person/controllers//index
INFO - 2018-10-08 10:14:44 --> Config Class Initialized
INFO - 2018-10-08 10:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:14:44 --> Utf8 Class Initialized
INFO - 2018-10-08 10:14:44 --> URI Class Initialized
INFO - 2018-10-08 10:14:44 --> Router Class Initialized
INFO - 2018-10-08 10:14:44 --> Output Class Initialized
INFO - 2018-10-08 10:14:44 --> Security Class Initialized
DEBUG - 2018-10-08 10:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:14:44 --> Input Class Initialized
INFO - 2018-10-08 10:14:45 --> Language Class Initialized
INFO - 2018-10-08 10:14:45 --> Language Class Initialized
INFO - 2018-10-08 10:14:45 --> Config Class Initialized
INFO - 2018-10-08 10:14:45 --> Loader Class Initialized
INFO - 2018-10-08 10:14:46 --> Helper loaded: url_helper
INFO - 2018-10-08 10:14:46 --> Helper loaded: form_helper
INFO - 2018-10-08 10:14:46 --> Database Driver Class Initialized
INFO - 2018-10-08 10:14:49 --> Email Class Initialized
INFO - 2018-10-08 10:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:14:50 --> Form Validation Class Initialized
INFO - 2018-10-08 10:14:50 --> Controller Class Initialized
DEBUG - 2018-10-08 10:14:50 --> Welcome MX_Controller Initialized
DEBUG - 2018-10-08 10:14:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/welcome/views/welcome_message.php
INFO - 2018-10-08 10:14:50 --> Final output sent to browser
DEBUG - 2018-10-08 10:14:50 --> Total execution time: 6.8094
INFO - 2018-10-08 10:16:47 --> Config Class Initialized
INFO - 2018-10-08 10:16:47 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:16:47 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:16:47 --> Utf8 Class Initialized
INFO - 2018-10-08 10:16:47 --> URI Class Initialized
DEBUG - 2018-10-08 10:16:47 --> No URI present. Default controller set.
INFO - 2018-10-08 10:16:47 --> Router Class Initialized
INFO - 2018-10-08 10:16:47 --> Output Class Initialized
INFO - 2018-10-08 10:16:47 --> Security Class Initialized
DEBUG - 2018-10-08 10:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:16:47 --> Input Class Initialized
INFO - 2018-10-08 10:16:47 --> Language Class Initialized
INFO - 2018-10-08 10:16:47 --> Language Class Initialized
INFO - 2018-10-08 10:16:47 --> Config Class Initialized
INFO - 2018-10-08 10:16:47 --> Loader Class Initialized
INFO - 2018-10-08 10:16:47 --> Helper loaded: url_helper
INFO - 2018-10-08 10:16:47 --> Helper loaded: form_helper
INFO - 2018-10-08 10:16:47 --> Database Driver Class Initialized
INFO - 2018-10-08 10:16:47 --> Email Class Initialized
INFO - 2018-10-08 10:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:16:47 --> Form Validation Class Initialized
INFO - 2018-10-08 10:16:47 --> Controller Class Initialized
DEBUG - 2018-10-08 10:16:47 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:16:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/welcome_message.php
INFO - 2018-10-08 10:16:47 --> Final output sent to browser
DEBUG - 2018-10-08 10:16:48 --> Total execution time: 0.9331
INFO - 2018-10-08 10:25:10 --> Config Class Initialized
INFO - 2018-10-08 10:25:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:25:13 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:25:13 --> Utf8 Class Initialized
INFO - 2018-10-08 10:25:14 --> URI Class Initialized
DEBUG - 2018-10-08 10:25:14 --> No URI present. Default controller set.
INFO - 2018-10-08 10:25:14 --> Router Class Initialized
INFO - 2018-10-08 10:25:14 --> Output Class Initialized
INFO - 2018-10-08 10:25:14 --> Security Class Initialized
DEBUG - 2018-10-08 10:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:25:14 --> Input Class Initialized
INFO - 2018-10-08 10:25:14 --> Language Class Initialized
INFO - 2018-10-08 10:25:15 --> Language Class Initialized
INFO - 2018-10-08 10:25:15 --> Config Class Initialized
INFO - 2018-10-08 10:25:15 --> Loader Class Initialized
INFO - 2018-10-08 10:25:15 --> Helper loaded: url_helper
INFO - 2018-10-08 10:25:15 --> Helper loaded: form_helper
INFO - 2018-10-08 10:25:15 --> Database Driver Class Initialized
INFO - 2018-10-08 10:25:18 --> Email Class Initialized
INFO - 2018-10-08 10:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:25:19 --> Form Validation Class Initialized
INFO - 2018-10-08 10:25:19 --> Controller Class Initialized
DEBUG - 2018-10-08 10:25:19 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:25:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:25:24 --> Final output sent to browser
DEBUG - 2018-10-08 10:25:24 --> Total execution time: 16.3709
INFO - 2018-10-08 10:29:44 --> Config Class Initialized
INFO - 2018-10-08 10:29:45 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:29:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:29:46 --> Utf8 Class Initialized
INFO - 2018-10-08 10:29:46 --> URI Class Initialized
DEBUG - 2018-10-08 10:29:46 --> No URI present. Default controller set.
INFO - 2018-10-08 10:29:46 --> Router Class Initialized
INFO - 2018-10-08 10:29:47 --> Output Class Initialized
INFO - 2018-10-08 10:29:47 --> Security Class Initialized
DEBUG - 2018-10-08 10:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:29:47 --> Input Class Initialized
INFO - 2018-10-08 10:29:47 --> Language Class Initialized
INFO - 2018-10-08 10:29:47 --> Language Class Initialized
INFO - 2018-10-08 10:29:47 --> Config Class Initialized
INFO - 2018-10-08 10:29:47 --> Loader Class Initialized
INFO - 2018-10-08 10:29:47 --> Helper loaded: url_helper
INFO - 2018-10-08 10:29:47 --> Helper loaded: form_helper
INFO - 2018-10-08 10:29:48 --> Database Driver Class Initialized
INFO - 2018-10-08 10:29:48 --> Email Class Initialized
INFO - 2018-10-08 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:29:48 --> Form Validation Class Initialized
INFO - 2018-10-08 10:29:48 --> Controller Class Initialized
DEBUG - 2018-10-08 10:29:48 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:29:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:29:48 --> Final output sent to browser
DEBUG - 2018-10-08 10:29:48 --> Total execution time: 4.3162
INFO - 2018-10-08 10:34:56 --> Config Class Initialized
INFO - 2018-10-08 10:34:56 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:34:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:34:57 --> Utf8 Class Initialized
INFO - 2018-10-08 10:34:58 --> URI Class Initialized
DEBUG - 2018-10-08 10:34:58 --> No URI present. Default controller set.
INFO - 2018-10-08 10:34:58 --> Router Class Initialized
INFO - 2018-10-08 10:34:58 --> Output Class Initialized
INFO - 2018-10-08 10:34:58 --> Security Class Initialized
DEBUG - 2018-10-08 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:34:58 --> Input Class Initialized
INFO - 2018-10-08 10:34:58 --> Language Class Initialized
INFO - 2018-10-08 10:34:59 --> Language Class Initialized
INFO - 2018-10-08 10:34:59 --> Config Class Initialized
INFO - 2018-10-08 10:34:59 --> Loader Class Initialized
INFO - 2018-10-08 10:34:59 --> Helper loaded: url_helper
INFO - 2018-10-08 10:34:59 --> Helper loaded: form_helper
INFO - 2018-10-08 10:34:59 --> Database Driver Class Initialized
INFO - 2018-10-08 10:34:59 --> Email Class Initialized
INFO - 2018-10-08 10:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:34:59 --> Form Validation Class Initialized
INFO - 2018-10-08 10:34:59 --> Controller Class Initialized
DEBUG - 2018-10-08 10:35:00 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:35:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:35:00 --> Final output sent to browser
DEBUG - 2018-10-08 10:35:00 --> Total execution time: 4.2842
INFO - 2018-10-08 10:47:01 --> Config Class Initialized
INFO - 2018-10-08 10:47:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:47:06 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:47:06 --> Utf8 Class Initialized
INFO - 2018-10-08 10:47:06 --> URI Class Initialized
DEBUG - 2018-10-08 10:47:06 --> No URI present. Default controller set.
INFO - 2018-10-08 10:47:06 --> Router Class Initialized
INFO - 2018-10-08 10:47:07 --> Output Class Initialized
INFO - 2018-10-08 10:47:07 --> Security Class Initialized
DEBUG - 2018-10-08 10:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:47:07 --> Input Class Initialized
INFO - 2018-10-08 10:47:07 --> Language Class Initialized
INFO - 2018-10-08 10:47:07 --> Language Class Initialized
INFO - 2018-10-08 10:47:07 --> Config Class Initialized
INFO - 2018-10-08 10:47:08 --> Loader Class Initialized
INFO - 2018-10-08 10:47:08 --> Helper loaded: url_helper
INFO - 2018-10-08 10:47:08 --> Helper loaded: form_helper
INFO - 2018-10-08 10:47:08 --> Database Driver Class Initialized
INFO - 2018-10-08 10:47:14 --> Email Class Initialized
INFO - 2018-10-08 10:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:47:15 --> Form Validation Class Initialized
INFO - 2018-10-08 10:47:15 --> Controller Class Initialized
DEBUG - 2018-10-08 10:47:15 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:47:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:47:15 --> Final output sent to browser
DEBUG - 2018-10-08 10:47:15 --> Total execution time: 14.5568
INFO - 2018-10-08 10:47:26 --> Config Class Initialized
INFO - 2018-10-08 10:47:26 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:47:26 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:47:26 --> Utf8 Class Initialized
INFO - 2018-10-08 10:47:26 --> URI Class Initialized
DEBUG - 2018-10-08 10:47:26 --> No URI present. Default controller set.
INFO - 2018-10-08 10:47:26 --> Router Class Initialized
INFO - 2018-10-08 10:47:26 --> Output Class Initialized
INFO - 2018-10-08 10:47:26 --> Security Class Initialized
DEBUG - 2018-10-08 10:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:47:26 --> Input Class Initialized
INFO - 2018-10-08 10:47:26 --> Language Class Initialized
INFO - 2018-10-08 10:47:26 --> Language Class Initialized
INFO - 2018-10-08 10:47:26 --> Config Class Initialized
INFO - 2018-10-08 10:47:26 --> Loader Class Initialized
INFO - 2018-10-08 10:47:26 --> Helper loaded: url_helper
INFO - 2018-10-08 10:47:26 --> Helper loaded: form_helper
INFO - 2018-10-08 10:47:27 --> Database Driver Class Initialized
INFO - 2018-10-08 10:47:27 --> Email Class Initialized
INFO - 2018-10-08 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:47:27 --> Form Validation Class Initialized
INFO - 2018-10-08 10:47:27 --> Controller Class Initialized
DEBUG - 2018-10-08 10:47:27 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:47:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:47:27 --> Final output sent to browser
DEBUG - 2018-10-08 10:47:27 --> Total execution time: 1.9171
INFO - 2018-10-08 10:47:51 --> Config Class Initialized
INFO - 2018-10-08 10:47:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:47:51 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:47:51 --> Utf8 Class Initialized
INFO - 2018-10-08 10:47:51 --> URI Class Initialized
DEBUG - 2018-10-08 10:47:52 --> No URI present. Default controller set.
INFO - 2018-10-08 10:47:52 --> Router Class Initialized
INFO - 2018-10-08 10:47:52 --> Output Class Initialized
INFO - 2018-10-08 10:47:52 --> Security Class Initialized
DEBUG - 2018-10-08 10:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:47:52 --> Input Class Initialized
INFO - 2018-10-08 10:47:52 --> Language Class Initialized
INFO - 2018-10-08 10:47:53 --> Language Class Initialized
INFO - 2018-10-08 10:47:53 --> Config Class Initialized
INFO - 2018-10-08 10:47:53 --> Loader Class Initialized
INFO - 2018-10-08 10:47:53 --> Helper loaded: url_helper
INFO - 2018-10-08 10:47:53 --> Helper loaded: form_helper
INFO - 2018-10-08 10:47:53 --> Database Driver Class Initialized
INFO - 2018-10-08 10:47:53 --> Email Class Initialized
INFO - 2018-10-08 10:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:47:54 --> Form Validation Class Initialized
INFO - 2018-10-08 10:47:54 --> Controller Class Initialized
DEBUG - 2018-10-08 10:47:54 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:47:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:47:54 --> Final output sent to browser
DEBUG - 2018-10-08 10:47:54 --> Total execution time: 3.0452
INFO - 2018-10-08 10:48:36 --> Config Class Initialized
INFO - 2018-10-08 10:48:36 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:48:37 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:48:37 --> Utf8 Class Initialized
INFO - 2018-10-08 10:48:37 --> URI Class Initialized
DEBUG - 2018-10-08 10:48:38 --> No URI present. Default controller set.
INFO - 2018-10-08 10:48:38 --> Router Class Initialized
INFO - 2018-10-08 10:48:39 --> Output Class Initialized
INFO - 2018-10-08 10:48:39 --> Security Class Initialized
DEBUG - 2018-10-08 10:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:48:39 --> Input Class Initialized
INFO - 2018-10-08 10:48:39 --> Language Class Initialized
INFO - 2018-10-08 10:48:40 --> Language Class Initialized
INFO - 2018-10-08 10:48:40 --> Config Class Initialized
INFO - 2018-10-08 10:48:41 --> Loader Class Initialized
INFO - 2018-10-08 10:48:51 --> Helper loaded: url_helper
INFO - 2018-10-08 10:48:51 --> Helper loaded: form_helper
INFO - 2018-10-08 10:49:03 --> Database Driver Class Initialized
INFO - 2018-10-08 10:49:04 --> Email Class Initialized
ERROR - 2018-10-08 10:49:09 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\User_Management\system\core\Log.php 222
INFO - 2018-10-08 10:49:38 --> Config Class Initialized
INFO - 2018-10-08 10:49:38 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:49:39 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:49:39 --> Utf8 Class Initialized
INFO - 2018-10-08 10:49:39 --> URI Class Initialized
DEBUG - 2018-10-08 10:49:41 --> No URI present. Default controller set.
INFO - 2018-10-08 10:49:41 --> Router Class Initialized
INFO - 2018-10-08 10:49:42 --> Output Class Initialized
INFO - 2018-10-08 10:49:42 --> Security Class Initialized
DEBUG - 2018-10-08 10:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:49:42 --> Input Class Initialized
INFO - 2018-10-08 10:49:42 --> Language Class Initialized
INFO - 2018-10-08 10:49:43 --> Language Class Initialized
INFO - 2018-10-08 10:49:43 --> Config Class Initialized
INFO - 2018-10-08 10:49:43 --> Loader Class Initialized
INFO - 2018-10-08 10:49:43 --> Helper loaded: url_helper
INFO - 2018-10-08 10:49:43 --> Helper loaded: form_helper
INFO - 2018-10-08 10:49:44 --> Database Driver Class Initialized
INFO - 2018-10-08 10:49:44 --> Email Class Initialized
INFO - 2018-10-08 10:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:49:45 --> Form Validation Class Initialized
INFO - 2018-10-08 10:49:45 --> Controller Class Initialized
DEBUG - 2018-10-08 10:49:45 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:49:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:49:45 --> Final output sent to browser
DEBUG - 2018-10-08 10:49:46 --> Total execution time: 8.1695
INFO - 2018-10-08 10:50:31 --> Config Class Initialized
INFO - 2018-10-08 10:50:31 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:50:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:50:33 --> Utf8 Class Initialized
INFO - 2018-10-08 10:50:33 --> URI Class Initialized
DEBUG - 2018-10-08 10:50:33 --> No URI present. Default controller set.
INFO - 2018-10-08 10:50:33 --> Router Class Initialized
INFO - 2018-10-08 10:50:34 --> Output Class Initialized
INFO - 2018-10-08 10:50:34 --> Security Class Initialized
DEBUG - 2018-10-08 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:50:34 --> Input Class Initialized
INFO - 2018-10-08 10:50:34 --> Language Class Initialized
INFO - 2018-10-08 10:50:34 --> Language Class Initialized
INFO - 2018-10-08 10:50:34 --> Config Class Initialized
INFO - 2018-10-08 10:50:35 --> Loader Class Initialized
INFO - 2018-10-08 10:50:35 --> Helper loaded: url_helper
INFO - 2018-10-08 10:50:35 --> Helper loaded: form_helper
INFO - 2018-10-08 10:50:35 --> Database Driver Class Initialized
INFO - 2018-10-08 10:50:35 --> Email Class Initialized
INFO - 2018-10-08 10:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:50:36 --> Form Validation Class Initialized
INFO - 2018-10-08 10:50:36 --> Controller Class Initialized
DEBUG - 2018-10-08 10:50:36 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:50:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:50:36 --> Final output sent to browser
DEBUG - 2018-10-08 10:50:37 --> Total execution time: 5.2813
INFO - 2018-10-08 10:51:47 --> Config Class Initialized
INFO - 2018-10-08 10:51:47 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:51:48 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:51:48 --> Utf8 Class Initialized
INFO - 2018-10-08 10:51:49 --> URI Class Initialized
DEBUG - 2018-10-08 10:51:49 --> No URI present. Default controller set.
INFO - 2018-10-08 10:51:49 --> Router Class Initialized
INFO - 2018-10-08 10:51:49 --> Output Class Initialized
INFO - 2018-10-08 10:51:49 --> Security Class Initialized
DEBUG - 2018-10-08 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:51:50 --> Input Class Initialized
INFO - 2018-10-08 10:51:50 --> Language Class Initialized
INFO - 2018-10-08 10:51:50 --> Language Class Initialized
INFO - 2018-10-08 10:51:50 --> Config Class Initialized
INFO - 2018-10-08 10:51:50 --> Loader Class Initialized
INFO - 2018-10-08 10:51:50 --> Helper loaded: url_helper
INFO - 2018-10-08 10:51:50 --> Helper loaded: form_helper
INFO - 2018-10-08 10:51:51 --> Database Driver Class Initialized
INFO - 2018-10-08 10:51:51 --> Email Class Initialized
INFO - 2018-10-08 10:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:51:51 --> Form Validation Class Initialized
INFO - 2018-10-08 10:51:51 --> Controller Class Initialized
DEBUG - 2018-10-08 10:51:51 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:51:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:51:51 --> Final output sent to browser
DEBUG - 2018-10-08 10:51:51 --> Total execution time: 4.0432
INFO - 2018-10-08 10:52:57 --> Config Class Initialized
INFO - 2018-10-08 10:52:57 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:52:58 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:52:58 --> Utf8 Class Initialized
INFO - 2018-10-08 10:52:58 --> URI Class Initialized
DEBUG - 2018-10-08 10:52:59 --> No URI present. Default controller set.
INFO - 2018-10-08 10:52:59 --> Router Class Initialized
INFO - 2018-10-08 10:52:59 --> Output Class Initialized
INFO - 2018-10-08 10:52:59 --> Security Class Initialized
DEBUG - 2018-10-08 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:52:59 --> Input Class Initialized
INFO - 2018-10-08 10:53:00 --> Language Class Initialized
INFO - 2018-10-08 10:53:00 --> Language Class Initialized
INFO - 2018-10-08 10:53:00 --> Config Class Initialized
INFO - 2018-10-08 10:53:00 --> Loader Class Initialized
INFO - 2018-10-08 10:53:01 --> Helper loaded: url_helper
INFO - 2018-10-08 10:53:01 --> Helper loaded: form_helper
INFO - 2018-10-08 10:53:01 --> Database Driver Class Initialized
INFO - 2018-10-08 10:53:02 --> Email Class Initialized
INFO - 2018-10-08 10:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:53:03 --> Form Validation Class Initialized
INFO - 2018-10-08 10:53:03 --> Controller Class Initialized
DEBUG - 2018-10-08 10:53:03 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:53:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:53:03 --> Final output sent to browser
DEBUG - 2018-10-08 10:53:03 --> Total execution time: 6.0673
INFO - 2018-10-08 10:58:35 --> Config Class Initialized
INFO - 2018-10-08 10:58:35 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:58:39 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:58:39 --> Utf8 Class Initialized
INFO - 2018-10-08 10:58:40 --> URI Class Initialized
DEBUG - 2018-10-08 10:58:41 --> No URI present. Default controller set.
INFO - 2018-10-08 10:58:41 --> Router Class Initialized
INFO - 2018-10-08 10:58:42 --> Output Class Initialized
INFO - 2018-10-08 10:58:42 --> Security Class Initialized
DEBUG - 2018-10-08 10:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:58:42 --> Input Class Initialized
INFO - 2018-10-08 10:58:43 --> Language Class Initialized
INFO - 2018-10-08 10:58:43 --> Language Class Initialized
INFO - 2018-10-08 10:58:43 --> Config Class Initialized
INFO - 2018-10-08 10:58:43 --> Loader Class Initialized
INFO - 2018-10-08 10:58:44 --> Helper loaded: url_helper
INFO - 2018-10-08 10:58:44 --> Helper loaded: form_helper
INFO - 2018-10-08 10:58:46 --> Database Driver Class Initialized
INFO - 2018-10-08 10:58:52 --> Email Class Initialized
INFO - 2018-10-08 10:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:58:53 --> Form Validation Class Initialized
INFO - 2018-10-08 10:58:53 --> Controller Class Initialized
DEBUG - 2018-10-08 10:58:53 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:58:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:58:53 --> Final output sent to browser
DEBUG - 2018-10-08 10:58:53 --> Total execution time: 21.4132
INFO - 2018-10-08 10:59:10 --> Config Class Initialized
INFO - 2018-10-08 10:59:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:59:10 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:59:10 --> Utf8 Class Initialized
INFO - 2018-10-08 10:59:11 --> URI Class Initialized
INFO - 2018-10-08 10:59:11 --> Router Class Initialized
INFO - 2018-10-08 10:59:11 --> Output Class Initialized
INFO - 2018-10-08 10:59:11 --> Security Class Initialized
DEBUG - 2018-10-08 10:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:59:11 --> Input Class Initialized
INFO - 2018-10-08 10:59:11 --> Language Class Initialized
INFO - 2018-10-08 10:59:11 --> Language Class Initialized
INFO - 2018-10-08 10:59:11 --> Config Class Initialized
INFO - 2018-10-08 10:59:11 --> Loader Class Initialized
INFO - 2018-10-08 10:59:11 --> Helper loaded: url_helper
INFO - 2018-10-08 10:59:11 --> Helper loaded: form_helper
INFO - 2018-10-08 10:59:11 --> Database Driver Class Initialized
INFO - 2018-10-08 10:59:11 --> Email Class Initialized
INFO - 2018-10-08 10:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:59:11 --> Form Validation Class Initialized
INFO - 2018-10-08 10:59:11 --> Controller Class Initialized
DEBUG - 2018-10-08 10:59:11 --> Person MX_Controller Initialized
INFO - 2018-10-08 10:59:11 --> Final output sent to browser
DEBUG - 2018-10-08 10:59:11 --> Total execution time: 1.3884
INFO - 2018-10-08 10:59:45 --> Config Class Initialized
INFO - 2018-10-08 10:59:45 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:59:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:59:46 --> Utf8 Class Initialized
INFO - 2018-10-08 10:59:46 --> URI Class Initialized
DEBUG - 2018-10-08 10:59:46 --> No URI present. Default controller set.
INFO - 2018-10-08 10:59:46 --> Router Class Initialized
INFO - 2018-10-08 10:59:46 --> Output Class Initialized
INFO - 2018-10-08 10:59:46 --> Security Class Initialized
DEBUG - 2018-10-08 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:59:46 --> Input Class Initialized
INFO - 2018-10-08 10:59:46 --> Language Class Initialized
INFO - 2018-10-08 10:59:46 --> Language Class Initialized
INFO - 2018-10-08 10:59:46 --> Config Class Initialized
INFO - 2018-10-08 10:59:46 --> Loader Class Initialized
INFO - 2018-10-08 10:59:46 --> Helper loaded: url_helper
INFO - 2018-10-08 10:59:46 --> Helper loaded: form_helper
INFO - 2018-10-08 10:59:46 --> Database Driver Class Initialized
INFO - 2018-10-08 10:59:46 --> Email Class Initialized
INFO - 2018-10-08 10:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:59:46 --> Form Validation Class Initialized
INFO - 2018-10-08 10:59:46 --> Controller Class Initialized
DEBUG - 2018-10-08 10:59:46 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:59:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:59:47 --> Final output sent to browser
DEBUG - 2018-10-08 10:59:47 --> Total execution time: 1.1331
INFO - 2018-10-08 10:59:52 --> Config Class Initialized
INFO - 2018-10-08 10:59:52 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:59:52 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:59:52 --> Utf8 Class Initialized
INFO - 2018-10-08 10:59:52 --> URI Class Initialized
INFO - 2018-10-08 10:59:52 --> Router Class Initialized
INFO - 2018-10-08 10:59:52 --> Output Class Initialized
INFO - 2018-10-08 10:59:53 --> Security Class Initialized
DEBUG - 2018-10-08 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:59:53 --> Input Class Initialized
INFO - 2018-10-08 10:59:53 --> Language Class Initialized
INFO - 2018-10-08 10:59:53 --> Language Class Initialized
INFO - 2018-10-08 10:59:53 --> Config Class Initialized
INFO - 2018-10-08 10:59:53 --> Loader Class Initialized
INFO - 2018-10-08 10:59:53 --> Helper loaded: url_helper
INFO - 2018-10-08 10:59:53 --> Helper loaded: form_helper
INFO - 2018-10-08 10:59:53 --> Database Driver Class Initialized
INFO - 2018-10-08 10:59:53 --> Email Class Initialized
INFO - 2018-10-08 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:59:53 --> Form Validation Class Initialized
INFO - 2018-10-08 10:59:53 --> Controller Class Initialized
DEBUG - 2018-10-08 10:59:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 10:59:53 --> Final output sent to browser
DEBUG - 2018-10-08 10:59:53 --> Total execution time: 1.3261
INFO - 2018-10-08 10:59:54 --> Config Class Initialized
INFO - 2018-10-08 10:59:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 10:59:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 10:59:54 --> Utf8 Class Initialized
INFO - 2018-10-08 10:59:54 --> URI Class Initialized
DEBUG - 2018-10-08 10:59:54 --> No URI present. Default controller set.
INFO - 2018-10-08 10:59:55 --> Router Class Initialized
INFO - 2018-10-08 10:59:55 --> Output Class Initialized
INFO - 2018-10-08 10:59:55 --> Security Class Initialized
DEBUG - 2018-10-08 10:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 10:59:55 --> Input Class Initialized
INFO - 2018-10-08 10:59:55 --> Language Class Initialized
INFO - 2018-10-08 10:59:55 --> Language Class Initialized
INFO - 2018-10-08 10:59:55 --> Config Class Initialized
INFO - 2018-10-08 10:59:55 --> Loader Class Initialized
INFO - 2018-10-08 10:59:55 --> Helper loaded: url_helper
INFO - 2018-10-08 10:59:55 --> Helper loaded: form_helper
INFO - 2018-10-08 10:59:56 --> Database Driver Class Initialized
INFO - 2018-10-08 10:59:56 --> Email Class Initialized
INFO - 2018-10-08 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 10:59:56 --> Form Validation Class Initialized
INFO - 2018-10-08 10:59:56 --> Controller Class Initialized
DEBUG - 2018-10-08 10:59:56 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 10:59:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 10:59:56 --> Final output sent to browser
DEBUG - 2018-10-08 10:59:56 --> Total execution time: 2.6021
INFO - 2018-10-08 11:09:04 --> Config Class Initialized
INFO - 2018-10-08 11:09:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:09:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:09:05 --> Utf8 Class Initialized
INFO - 2018-10-08 11:09:05 --> URI Class Initialized
DEBUG - 2018-10-08 11:09:06 --> No URI present. Default controller set.
INFO - 2018-10-08 11:09:06 --> Router Class Initialized
INFO - 2018-10-08 11:09:06 --> Output Class Initialized
INFO - 2018-10-08 11:09:06 --> Security Class Initialized
DEBUG - 2018-10-08 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:09:06 --> Input Class Initialized
INFO - 2018-10-08 11:09:06 --> Language Class Initialized
INFO - 2018-10-08 11:09:06 --> Language Class Initialized
INFO - 2018-10-08 11:09:06 --> Config Class Initialized
INFO - 2018-10-08 11:09:07 --> Loader Class Initialized
INFO - 2018-10-08 11:09:07 --> Helper loaded: url_helper
INFO - 2018-10-08 11:09:07 --> Helper loaded: form_helper
INFO - 2018-10-08 11:09:07 --> Database Driver Class Initialized
INFO - 2018-10-08 11:09:07 --> Email Class Initialized
INFO - 2018-10-08 11:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:09:08 --> Form Validation Class Initialized
INFO - 2018-10-08 11:09:08 --> Controller Class Initialized
DEBUG - 2018-10-08 11:09:08 --> Person MX_Controller Initialized
ERROR - 2018-10-08 11:09:08 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 32
ERROR - 2018-10-08 11:09:08 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:11:27 --> Config Class Initialized
INFO - 2018-10-08 11:11:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:11:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:11:27 --> Utf8 Class Initialized
INFO - 2018-10-08 11:11:28 --> URI Class Initialized
DEBUG - 2018-10-08 11:11:28 --> No URI present. Default controller set.
INFO - 2018-10-08 11:11:28 --> Router Class Initialized
INFO - 2018-10-08 11:11:28 --> Output Class Initialized
INFO - 2018-10-08 11:11:28 --> Security Class Initialized
DEBUG - 2018-10-08 11:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:11:28 --> Input Class Initialized
INFO - 2018-10-08 11:11:28 --> Language Class Initialized
INFO - 2018-10-08 11:11:28 --> Language Class Initialized
INFO - 2018-10-08 11:11:28 --> Config Class Initialized
INFO - 2018-10-08 11:11:28 --> Loader Class Initialized
INFO - 2018-10-08 11:11:28 --> Helper loaded: url_helper
INFO - 2018-10-08 11:11:28 --> Helper loaded: form_helper
INFO - 2018-10-08 11:11:28 --> Database Driver Class Initialized
INFO - 2018-10-08 11:11:28 --> Email Class Initialized
INFO - 2018-10-08 11:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:11:28 --> Form Validation Class Initialized
INFO - 2018-10-08 11:11:28 --> Controller Class Initialized
DEBUG - 2018-10-08 11:11:28 --> Person MX_Controller Initialized
ERROR - 2018-10-08 11:11:28 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 32
ERROR - 2018-10-08 11:11:28 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:12:06 --> Config Class Initialized
INFO - 2018-10-08 11:12:06 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:12:06 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:12:06 --> Utf8 Class Initialized
INFO - 2018-10-08 11:12:06 --> URI Class Initialized
DEBUG - 2018-10-08 11:12:06 --> No URI present. Default controller set.
INFO - 2018-10-08 11:12:06 --> Router Class Initialized
INFO - 2018-10-08 11:12:06 --> Output Class Initialized
INFO - 2018-10-08 11:12:06 --> Security Class Initialized
DEBUG - 2018-10-08 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:12:07 --> Input Class Initialized
INFO - 2018-10-08 11:12:07 --> Language Class Initialized
INFO - 2018-10-08 11:12:07 --> Language Class Initialized
INFO - 2018-10-08 11:12:07 --> Config Class Initialized
INFO - 2018-10-08 11:12:07 --> Loader Class Initialized
INFO - 2018-10-08 11:12:07 --> Helper loaded: url_helper
INFO - 2018-10-08 11:12:07 --> Helper loaded: form_helper
INFO - 2018-10-08 11:12:07 --> Database Driver Class Initialized
INFO - 2018-10-08 11:12:07 --> Email Class Initialized
INFO - 2018-10-08 11:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:12:07 --> Form Validation Class Initialized
INFO - 2018-10-08 11:12:07 --> Controller Class Initialized
DEBUG - 2018-10-08 11:12:07 --> Person MX_Controller Initialized
ERROR - 2018-10-08 11:12:07 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 32
ERROR - 2018-10-08 11:12:07 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:15:45 --> Config Class Initialized
INFO - 2018-10-08 11:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:15:46 --> Utf8 Class Initialized
INFO - 2018-10-08 11:15:46 --> URI Class Initialized
DEBUG - 2018-10-08 11:15:47 --> No URI present. Default controller set.
INFO - 2018-10-08 11:15:47 --> Router Class Initialized
INFO - 2018-10-08 11:15:47 --> Output Class Initialized
INFO - 2018-10-08 11:15:47 --> Security Class Initialized
DEBUG - 2018-10-08 11:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:15:48 --> Input Class Initialized
INFO - 2018-10-08 11:15:48 --> Language Class Initialized
INFO - 2018-10-08 11:15:48 --> Language Class Initialized
INFO - 2018-10-08 11:15:48 --> Config Class Initialized
INFO - 2018-10-08 11:15:48 --> Loader Class Initialized
INFO - 2018-10-08 11:15:48 --> Helper loaded: url_helper
INFO - 2018-10-08 11:15:48 --> Helper loaded: form_helper
INFO - 2018-10-08 11:15:49 --> Database Driver Class Initialized
INFO - 2018-10-08 11:15:49 --> Email Class Initialized
INFO - 2018-10-08 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:15:49 --> Form Validation Class Initialized
INFO - 2018-10-08 11:15:49 --> Controller Class Initialized
DEBUG - 2018-10-08 11:15:49 --> Person MX_Controller Initialized
ERROR - 2018-10-08 11:15:50 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 32
ERROR - 2018-10-08 11:15:50 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:16:20 --> Config Class Initialized
INFO - 2018-10-08 11:16:20 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:16:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:16:21 --> Utf8 Class Initialized
INFO - 2018-10-08 11:16:21 --> URI Class Initialized
DEBUG - 2018-10-08 11:16:22 --> No URI present. Default controller set.
INFO - 2018-10-08 11:16:22 --> Router Class Initialized
INFO - 2018-10-08 11:16:22 --> Output Class Initialized
INFO - 2018-10-08 11:16:22 --> Security Class Initialized
DEBUG - 2018-10-08 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:16:22 --> Input Class Initialized
INFO - 2018-10-08 11:16:22 --> Language Class Initialized
INFO - 2018-10-08 11:16:23 --> Language Class Initialized
INFO - 2018-10-08 11:16:23 --> Config Class Initialized
INFO - 2018-10-08 11:16:24 --> Loader Class Initialized
INFO - 2018-10-08 11:16:24 --> Helper loaded: url_helper
INFO - 2018-10-08 11:16:24 --> Helper loaded: form_helper
INFO - 2018-10-08 11:16:24 --> Database Driver Class Initialized
INFO - 2018-10-08 11:16:25 --> Email Class Initialized
INFO - 2018-10-08 11:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:16:25 --> Form Validation Class Initialized
INFO - 2018-10-08 11:16:25 --> Controller Class Initialized
DEBUG - 2018-10-08 11:16:25 --> Person MX_Controller Initialized
ERROR - 2018-10-08 11:16:25 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 32
ERROR - 2018-10-08 11:16:25 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:16:42 --> Config Class Initialized
INFO - 2018-10-08 11:16:42 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:16:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:16:43 --> Utf8 Class Initialized
INFO - 2018-10-08 11:16:43 --> URI Class Initialized
DEBUG - 2018-10-08 11:16:43 --> No URI present. Default controller set.
INFO - 2018-10-08 11:16:43 --> Router Class Initialized
INFO - 2018-10-08 11:16:43 --> Output Class Initialized
INFO - 2018-10-08 11:16:43 --> Security Class Initialized
DEBUG - 2018-10-08 11:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:16:43 --> Input Class Initialized
INFO - 2018-10-08 11:16:43 --> Language Class Initialized
INFO - 2018-10-08 11:16:43 --> Language Class Initialized
INFO - 2018-10-08 11:16:43 --> Config Class Initialized
INFO - 2018-10-08 11:16:43 --> Loader Class Initialized
INFO - 2018-10-08 11:16:43 --> Helper loaded: url_helper
INFO - 2018-10-08 11:16:44 --> Helper loaded: form_helper
INFO - 2018-10-08 11:16:44 --> Database Driver Class Initialized
INFO - 2018-10-08 11:16:44 --> Email Class Initialized
INFO - 2018-10-08 11:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:16:44 --> Form Validation Class Initialized
INFO - 2018-10-08 11:16:44 --> Controller Class Initialized
DEBUG - 2018-10-08 11:16:44 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:16:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:16:44 --> Final output sent to browser
DEBUG - 2018-10-08 11:16:44 --> Total execution time: 1.9311
INFO - 2018-10-08 11:17:04 --> Config Class Initialized
INFO - 2018-10-08 11:17:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:17:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:17:05 --> Utf8 Class Initialized
INFO - 2018-10-08 11:17:05 --> URI Class Initialized
DEBUG - 2018-10-08 11:17:05 --> No URI present. Default controller set.
INFO - 2018-10-08 11:17:05 --> Router Class Initialized
INFO - 2018-10-08 11:17:05 --> Output Class Initialized
INFO - 2018-10-08 11:17:05 --> Security Class Initialized
DEBUG - 2018-10-08 11:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:17:05 --> Input Class Initialized
INFO - 2018-10-08 11:17:05 --> Language Class Initialized
INFO - 2018-10-08 11:17:05 --> Language Class Initialized
INFO - 2018-10-08 11:17:05 --> Config Class Initialized
INFO - 2018-10-08 11:17:05 --> Loader Class Initialized
INFO - 2018-10-08 11:17:05 --> Helper loaded: url_helper
INFO - 2018-10-08 11:17:05 --> Helper loaded: form_helper
INFO - 2018-10-08 11:17:05 --> Database Driver Class Initialized
INFO - 2018-10-08 11:17:05 --> Email Class Initialized
INFO - 2018-10-08 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:17:06 --> Form Validation Class Initialized
INFO - 2018-10-08 11:17:06 --> Controller Class Initialized
DEBUG - 2018-10-08 11:17:06 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:17:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:17:06 --> Final output sent to browser
DEBUG - 2018-10-08 11:17:06 --> Total execution time: 1.3871
INFO - 2018-10-08 11:17:32 --> Config Class Initialized
INFO - 2018-10-08 11:17:32 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:17:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:17:33 --> Utf8 Class Initialized
INFO - 2018-10-08 11:17:33 --> URI Class Initialized
INFO - 2018-10-08 11:17:33 --> Router Class Initialized
INFO - 2018-10-08 11:17:33 --> Output Class Initialized
INFO - 2018-10-08 11:17:33 --> Security Class Initialized
INFO - 2018-10-08 11:17:33 --> Config Class Initialized
DEBUG - 2018-10-08 11:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:17:33 --> Input Class Initialized
INFO - 2018-10-08 11:17:33 --> Hooks Class Initialized
INFO - 2018-10-08 11:17:34 --> Language Class Initialized
INFO - 2018-10-08 11:17:34 --> Language Class Initialized
DEBUG - 2018-10-08 11:17:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:17:34 --> Config Class Initialized
INFO - 2018-10-08 11:17:34 --> Loader Class Initialized
INFO - 2018-10-08 11:17:34 --> Helper loaded: url_helper
INFO - 2018-10-08 11:17:34 --> Helper loaded: form_helper
INFO - 2018-10-08 11:17:34 --> Utf8 Class Initialized
INFO - 2018-10-08 11:17:34 --> URI Class Initialized
INFO - 2018-10-08 11:17:34 --> Database Driver Class Initialized
DEBUG - 2018-10-08 11:17:34 --> No URI present. Default controller set.
INFO - 2018-10-08 11:17:34 --> Email Class Initialized
INFO - 2018-10-08 11:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:17:35 --> Router Class Initialized
INFO - 2018-10-08 11:17:35 --> Output Class Initialized
INFO - 2018-10-08 11:17:35 --> Form Validation Class Initialized
INFO - 2018-10-08 11:17:35 --> Controller Class Initialized
DEBUG - 2018-10-08 11:17:35 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:17:35 --> Security Class Initialized
DEBUG - 2018-10-08 11:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:17:35 --> Input Class Initialized
INFO - 2018-10-08 11:17:35 --> Language Class Initialized
INFO - 2018-10-08 11:17:35 --> Language Class Initialized
INFO - 2018-10-08 11:17:35 --> Config Class Initialized
INFO - 2018-10-08 11:17:35 --> Loader Class Initialized
INFO - 2018-10-08 11:17:35 --> Final output sent to browser
DEBUG - 2018-10-08 11:17:35 --> Total execution time: 3.0092
INFO - 2018-10-08 11:17:36 --> Helper loaded: url_helper
INFO - 2018-10-08 11:17:36 --> Helper loaded: form_helper
INFO - 2018-10-08 11:17:36 --> Database Driver Class Initialized
INFO - 2018-10-08 11:17:36 --> Email Class Initialized
INFO - 2018-10-08 11:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:17:36 --> Form Validation Class Initialized
INFO - 2018-10-08 11:17:36 --> Controller Class Initialized
DEBUG - 2018-10-08 11:17:36 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:17:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:17:36 --> Final output sent to browser
DEBUG - 2018-10-08 11:17:37 --> Total execution time: 3.4682
INFO - 2018-10-08 11:21:03 --> Config Class Initialized
INFO - 2018-10-08 11:21:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:21:04 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:21:04 --> Utf8 Class Initialized
INFO - 2018-10-08 11:21:04 --> URI Class Initialized
DEBUG - 2018-10-08 11:21:05 --> No URI present. Default controller set.
INFO - 2018-10-08 11:21:05 --> Router Class Initialized
INFO - 2018-10-08 11:21:05 --> Output Class Initialized
INFO - 2018-10-08 11:21:05 --> Security Class Initialized
DEBUG - 2018-10-08 11:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:21:05 --> Input Class Initialized
INFO - 2018-10-08 11:21:05 --> Language Class Initialized
INFO - 2018-10-08 11:21:06 --> Language Class Initialized
INFO - 2018-10-08 11:21:06 --> Config Class Initialized
INFO - 2018-10-08 11:21:06 --> Loader Class Initialized
INFO - 2018-10-08 11:21:06 --> Helper loaded: url_helper
INFO - 2018-10-08 11:21:06 --> Helper loaded: form_helper
INFO - 2018-10-08 11:21:06 --> Database Driver Class Initialized
INFO - 2018-10-08 11:21:06 --> Email Class Initialized
INFO - 2018-10-08 11:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:21:07 --> Form Validation Class Initialized
INFO - 2018-10-08 11:21:07 --> Controller Class Initialized
DEBUG - 2018-10-08 11:21:07 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:21:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:21:07 --> Final output sent to browser
DEBUG - 2018-10-08 11:21:07 --> Total execution time: 3.8162
INFO - 2018-10-08 11:21:26 --> Config Class Initialized
INFO - 2018-10-08 11:21:26 --> Hooks Class Initialized
INFO - 2018-10-08 11:21:26 --> Config Class Initialized
INFO - 2018-10-08 11:21:26 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 11:21:26 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:21:26 --> Utf8 Class Initialized
INFO - 2018-10-08 11:21:26 --> Utf8 Class Initialized
INFO - 2018-10-08 11:21:26 --> URI Class Initialized
INFO - 2018-10-08 11:21:26 --> URI Class Initialized
INFO - 2018-10-08 11:21:27 --> Router Class Initialized
DEBUG - 2018-10-08 11:21:27 --> No URI present. Default controller set.
INFO - 2018-10-08 11:21:27 --> Output Class Initialized
INFO - 2018-10-08 11:21:27 --> Security Class Initialized
INFO - 2018-10-08 11:21:27 --> Router Class Initialized
INFO - 2018-10-08 11:21:27 --> Output Class Initialized
INFO - 2018-10-08 11:21:27 --> Security Class Initialized
DEBUG - 2018-10-08 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:21:27 --> Input Class Initialized
DEBUG - 2018-10-08 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:21:27 --> Input Class Initialized
INFO - 2018-10-08 11:21:27 --> Language Class Initialized
INFO - 2018-10-08 11:21:27 --> Language Class Initialized
INFO - 2018-10-08 11:21:27 --> Config Class Initialized
INFO - 2018-10-08 11:21:28 --> Language Class Initialized
INFO - 2018-10-08 11:21:28 --> Language Class Initialized
INFO - 2018-10-08 11:21:28 --> Config Class Initialized
INFO - 2018-10-08 11:21:28 --> Loader Class Initialized
INFO - 2018-10-08 11:21:28 --> Helper loaded: url_helper
INFO - 2018-10-08 11:21:28 --> Helper loaded: form_helper
INFO - 2018-10-08 11:21:28 --> Database Driver Class Initialized
INFO - 2018-10-08 11:21:28 --> Loader Class Initialized
INFO - 2018-10-08 11:21:28 --> Email Class Initialized
INFO - 2018-10-08 11:21:31 --> Config Class Initialized
INFO - 2018-10-08 11:21:31 --> Config Class Initialized
INFO - 2018-10-08 11:21:38 --> Hooks Class Initialized
INFO - 2018-10-08 11:21:39 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:21:39 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:21:39 --> Utf8 Class Initialized
INFO - 2018-10-08 11:21:39 --> Helper loaded: url_helper
INFO - 2018-10-08 11:21:39 --> URI Class Initialized
INFO - 2018-10-08 11:21:39 --> Helper loaded: form_helper
INFO - 2018-10-08 11:21:39 --> Router Class Initialized
INFO - 2018-10-08 11:21:39 --> Output Class Initialized
INFO - 2018-10-08 11:21:40 --> Security Class Initialized
INFO - 2018-10-08 11:21:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-08 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:21:40 --> Input Class Initialized
INFO - 2018-10-08 11:21:40 --> Language Class Initialized
INFO - 2018-10-08 11:21:40 --> Form Validation Class Initialized
INFO - 2018-10-08 11:21:40 --> Language Class Initialized
INFO - 2018-10-08 11:21:40 --> Config Class Initialized
INFO - 2018-10-08 11:21:40 --> Controller Class Initialized
INFO - 2018-10-08 11:21:40 --> Loader Class Initialized
INFO - 2018-10-08 11:21:40 --> Helper loaded: url_helper
INFO - 2018-10-08 11:21:40 --> Helper loaded: form_helper
DEBUG - 2018-10-08 11:21:40 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:21:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:21:40 --> Final output sent to browser
DEBUG - 2018-10-08 11:21:40 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 11:21:40 --> Total execution time: 14.6448
INFO - 2018-10-08 11:21:41 --> Database Driver Class Initialized
INFO - 2018-10-08 11:21:41 --> Database Driver Class Initialized
INFO - 2018-10-08 11:21:41 --> Utf8 Class Initialized
INFO - 2018-10-08 11:21:41 --> Email Class Initialized
INFO - 2018-10-08 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:21:41 --> Form Validation Class Initialized
INFO - 2018-10-08 11:21:41 --> Controller Class Initialized
DEBUG - 2018-10-08 11:21:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:21:41 --> URI Class Initialized
INFO - 2018-10-08 11:21:41 --> Final output sent to browser
INFO - 2018-10-08 11:21:41 --> Email Class Initialized
INFO - 2018-10-08 11:21:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-08 11:21:41 --> No URI present. Default controller set.
INFO - 2018-10-08 11:21:41 --> Router Class Initialized
INFO - 2018-10-08 11:21:41 --> Form Validation Class Initialized
DEBUG - 2018-10-08 11:21:41 --> Total execution time: 15.4829
INFO - 2018-10-08 11:21:41 --> Controller Class Initialized
INFO - 2018-10-08 11:21:41 --> Output Class Initialized
DEBUG - 2018-10-08 11:21:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:21:42 --> Final output sent to browser
DEBUG - 2018-10-08 11:21:42 --> Total execution time: 10.1536
INFO - 2018-10-08 11:21:42 --> Security Class Initialized
DEBUG - 2018-10-08 11:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:21:42 --> Input Class Initialized
INFO - 2018-10-08 11:21:42 --> Language Class Initialized
INFO - 2018-10-08 11:21:42 --> Language Class Initialized
INFO - 2018-10-08 11:21:42 --> Config Class Initialized
INFO - 2018-10-08 11:21:42 --> Loader Class Initialized
INFO - 2018-10-08 11:21:42 --> Helper loaded: url_helper
INFO - 2018-10-08 11:21:43 --> Helper loaded: form_helper
INFO - 2018-10-08 11:21:43 --> Database Driver Class Initialized
INFO - 2018-10-08 11:21:43 --> Email Class Initialized
INFO - 2018-10-08 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:21:43 --> Form Validation Class Initialized
INFO - 2018-10-08 11:21:43 --> Controller Class Initialized
DEBUG - 2018-10-08 11:21:43 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:21:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:21:43 --> Final output sent to browser
DEBUG - 2018-10-08 11:21:43 --> Total execution time: 14.0318
INFO - 2018-10-08 11:23:27 --> Config Class Initialized
INFO - 2018-10-08 11:23:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:23:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:23:28 --> Utf8 Class Initialized
INFO - 2018-10-08 11:23:28 --> URI Class Initialized
DEBUG - 2018-10-08 11:23:29 --> No URI present. Default controller set.
INFO - 2018-10-08 11:23:29 --> Router Class Initialized
INFO - 2018-10-08 11:23:29 --> Output Class Initialized
INFO - 2018-10-08 11:23:29 --> Security Class Initialized
DEBUG - 2018-10-08 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:23:29 --> Input Class Initialized
INFO - 2018-10-08 11:23:29 --> Language Class Initialized
INFO - 2018-10-08 11:23:29 --> Language Class Initialized
INFO - 2018-10-08 11:23:29 --> Config Class Initialized
INFO - 2018-10-08 11:23:30 --> Loader Class Initialized
INFO - 2018-10-08 11:23:30 --> Helper loaded: url_helper
INFO - 2018-10-08 11:23:30 --> Helper loaded: form_helper
INFO - 2018-10-08 11:23:30 --> Database Driver Class Initialized
INFO - 2018-10-08 11:23:31 --> Email Class Initialized
INFO - 2018-10-08 11:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:23:31 --> Form Validation Class Initialized
INFO - 2018-10-08 11:23:31 --> Controller Class Initialized
DEBUG - 2018-10-08 11:23:32 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:23:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:23:32 --> Final output sent to browser
DEBUG - 2018-10-08 11:23:32 --> Total execution time: 4.5543
INFO - 2018-10-08 11:23:49 --> Config Class Initialized
INFO - 2018-10-08 11:23:49 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:23:49 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:23:49 --> Utf8 Class Initialized
INFO - 2018-10-08 11:23:49 --> Config Class Initialized
INFO - 2018-10-08 11:23:49 --> Hooks Class Initialized
INFO - 2018-10-08 11:23:50 --> URI Class Initialized
INFO - 2018-10-08 11:23:50 --> Router Class Initialized
INFO - 2018-10-08 11:23:50 --> Output Class Initialized
DEBUG - 2018-10-08 11:23:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:23:50 --> Utf8 Class Initialized
INFO - 2018-10-08 11:23:50 --> Security Class Initialized
DEBUG - 2018-10-08 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:23:50 --> Input Class Initialized
INFO - 2018-10-08 11:23:50 --> Language Class Initialized
INFO - 2018-10-08 11:23:50 --> Language Class Initialized
INFO - 2018-10-08 11:23:50 --> Config Class Initialized
INFO - 2018-10-08 11:23:50 --> Loader Class Initialized
INFO - 2018-10-08 11:23:50 --> URI Class Initialized
INFO - 2018-10-08 11:23:50 --> Helper loaded: url_helper
INFO - 2018-10-08 11:23:50 --> Helper loaded: form_helper
INFO - 2018-10-08 11:23:51 --> Database Driver Class Initialized
INFO - 2018-10-08 11:23:51 --> Router Class Initialized
INFO - 2018-10-08 11:23:51 --> Email Class Initialized
INFO - 2018-10-08 11:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:23:51 --> Output Class Initialized
INFO - 2018-10-08 11:23:51 --> Form Validation Class Initialized
INFO - 2018-10-08 11:23:51 --> Controller Class Initialized
DEBUG - 2018-10-08 11:23:51 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:23:51 --> Security Class Initialized
DEBUG - 2018-10-08 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:23:51 --> Input Class Initialized
INFO - 2018-10-08 11:23:51 --> Language Class Initialized
INFO - 2018-10-08 11:23:51 --> Language Class Initialized
INFO - 2018-10-08 11:23:51 --> Config Class Initialized
INFO - 2018-10-08 11:23:52 --> Loader Class Initialized
INFO - 2018-10-08 11:23:52 --> Helper loaded: url_helper
INFO - 2018-10-08 11:23:52 --> Helper loaded: form_helper
INFO - 2018-10-08 11:23:52 --> Model Class Initialized
INFO - 2018-10-08 11:23:52 --> Database Driver Class Initialized
DEBUG - 2018-10-08 11:23:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:23:52 --> Email Class Initialized
INFO - 2018-10-08 11:23:52 --> Model Class Initialized
INFO - 2018-10-08 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:23:52 --> Form Validation Class Initialized
INFO - 2018-10-08 11:23:52 --> Controller Class Initialized
DEBUG - 2018-10-08 11:23:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:23:53 --> Model Class Initialized
DEBUG - 2018-10-08 11:23:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:23:53 --> Model Class Initialized
INFO - 2018-10-08 11:23:53 --> Final output sent to browser
DEBUG - 2018-10-08 11:23:53 --> Total execution time: 4.5743
INFO - 2018-10-08 11:23:54 --> Final output sent to browser
DEBUG - 2018-10-08 11:23:54 --> Total execution time: 4.3152
INFO - 2018-10-08 11:25:19 --> Config Class Initialized
INFO - 2018-10-08 11:25:19 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:25:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:25:20 --> Utf8 Class Initialized
INFO - 2018-10-08 11:25:20 --> URI Class Initialized
DEBUG - 2018-10-08 11:25:20 --> No URI present. Default controller set.
INFO - 2018-10-08 11:25:20 --> Router Class Initialized
INFO - 2018-10-08 11:25:20 --> Output Class Initialized
INFO - 2018-10-08 11:25:20 --> Security Class Initialized
DEBUG - 2018-10-08 11:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:25:21 --> Input Class Initialized
INFO - 2018-10-08 11:25:21 --> Language Class Initialized
INFO - 2018-10-08 11:25:21 --> Language Class Initialized
INFO - 2018-10-08 11:25:21 --> Config Class Initialized
INFO - 2018-10-08 11:25:21 --> Loader Class Initialized
INFO - 2018-10-08 11:25:21 --> Helper loaded: url_helper
INFO - 2018-10-08 11:25:21 --> Helper loaded: form_helper
INFO - 2018-10-08 11:25:21 --> Database Driver Class Initialized
INFO - 2018-10-08 11:25:21 --> Email Class Initialized
INFO - 2018-10-08 11:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:25:22 --> Form Validation Class Initialized
INFO - 2018-10-08 11:25:22 --> Controller Class Initialized
DEBUG - 2018-10-08 11:25:22 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:25:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:25:22 --> Final output sent to browser
DEBUG - 2018-10-08 11:25:22 --> Total execution time: 3.1792
INFO - 2018-10-08 11:25:47 --> Config Class Initialized
INFO - 2018-10-08 11:25:47 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:25:47 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:25:47 --> Utf8 Class Initialized
INFO - 2018-10-08 11:25:47 --> Config Class Initialized
INFO - 2018-10-08 11:25:47 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:25:47 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:25:47 --> Utf8 Class Initialized
INFO - 2018-10-08 11:25:47 --> URI Class Initialized
INFO - 2018-10-08 11:25:47 --> URI Class Initialized
INFO - 2018-10-08 11:25:47 --> Router Class Initialized
INFO - 2018-10-08 11:25:48 --> Router Class Initialized
INFO - 2018-10-08 11:25:48 --> Output Class Initialized
INFO - 2018-10-08 11:25:48 --> Security Class Initialized
INFO - 2018-10-08 11:25:48 --> Output Class Initialized
DEBUG - 2018-10-08 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:25:48 --> Input Class Initialized
INFO - 2018-10-08 11:25:48 --> Language Class Initialized
INFO - 2018-10-08 11:25:48 --> Language Class Initialized
INFO - 2018-10-08 11:25:48 --> Config Class Initialized
INFO - 2018-10-08 11:25:48 --> Security Class Initialized
DEBUG - 2018-10-08 11:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:25:48 --> Input Class Initialized
INFO - 2018-10-08 11:25:48 --> Loader Class Initialized
INFO - 2018-10-08 11:25:48 --> Helper loaded: url_helper
INFO - 2018-10-08 11:25:48 --> Helper loaded: form_helper
INFO - 2018-10-08 11:25:48 --> Database Driver Class Initialized
INFO - 2018-10-08 11:25:48 --> Email Class Initialized
INFO - 2018-10-08 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:25:49 --> Form Validation Class Initialized
INFO - 2018-10-08 11:25:49 --> Controller Class Initialized
INFO - 2018-10-08 11:25:49 --> Language Class Initialized
DEBUG - 2018-10-08 11:25:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:25:49 --> Final output sent to browser
DEBUG - 2018-10-08 11:25:49 --> Total execution time: 2.1421
INFO - 2018-10-08 11:25:49 --> Language Class Initialized
INFO - 2018-10-08 11:25:49 --> Config Class Initialized
INFO - 2018-10-08 11:25:49 --> Loader Class Initialized
INFO - 2018-10-08 11:25:49 --> Helper loaded: url_helper
INFO - 2018-10-08 11:25:49 --> Helper loaded: form_helper
INFO - 2018-10-08 11:25:49 --> Database Driver Class Initialized
INFO - 2018-10-08 11:25:49 --> Email Class Initialized
INFO - 2018-10-08 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:25:50 --> Form Validation Class Initialized
INFO - 2018-10-08 11:25:50 --> Controller Class Initialized
DEBUG - 2018-10-08 11:25:50 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:25:50 --> Model Class Initialized
DEBUG - 2018-10-08 11:25:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:25:50 --> Model Class Initialized
INFO - 2018-10-08 11:25:50 --> Final output sent to browser
DEBUG - 2018-10-08 11:25:50 --> Total execution time: 3.0552
INFO - 2018-10-08 11:26:44 --> Config Class Initialized
INFO - 2018-10-08 11:26:44 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:26:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:26:44 --> Utf8 Class Initialized
INFO - 2018-10-08 11:26:44 --> URI Class Initialized
DEBUG - 2018-10-08 11:26:44 --> No URI present. Default controller set.
INFO - 2018-10-08 11:26:44 --> Router Class Initialized
INFO - 2018-10-08 11:26:44 --> Output Class Initialized
INFO - 2018-10-08 11:26:44 --> Security Class Initialized
DEBUG - 2018-10-08 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:26:45 --> Input Class Initialized
INFO - 2018-10-08 11:26:45 --> Language Class Initialized
INFO - 2018-10-08 11:26:45 --> Language Class Initialized
INFO - 2018-10-08 11:26:45 --> Config Class Initialized
INFO - 2018-10-08 11:26:45 --> Loader Class Initialized
INFO - 2018-10-08 11:26:45 --> Helper loaded: url_helper
INFO - 2018-10-08 11:26:45 --> Helper loaded: form_helper
INFO - 2018-10-08 11:26:45 --> Database Driver Class Initialized
INFO - 2018-10-08 11:26:45 --> Email Class Initialized
INFO - 2018-10-08 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:26:45 --> Form Validation Class Initialized
INFO - 2018-10-08 11:26:45 --> Controller Class Initialized
DEBUG - 2018-10-08 11:26:46 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:26:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:26:46 --> Final output sent to browser
DEBUG - 2018-10-08 11:26:46 --> Total execution time: 1.9621
INFO - 2018-10-08 11:27:14 --> Config Class Initialized
INFO - 2018-10-08 11:27:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:27:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:27:14 --> Utf8 Class Initialized
INFO - 2018-10-08 11:27:14 --> Config Class Initialized
INFO - 2018-10-08 11:27:14 --> URI Class Initialized
DEBUG - 2018-10-08 11:27:14 --> No URI present. Default controller set.
INFO - 2018-10-08 11:27:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:27:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:27:14 --> Utf8 Class Initialized
INFO - 2018-10-08 11:27:14 --> Router Class Initialized
INFO - 2018-10-08 11:27:14 --> Output Class Initialized
INFO - 2018-10-08 11:27:14 --> Security Class Initialized
DEBUG - 2018-10-08 11:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:27:14 --> Input Class Initialized
INFO - 2018-10-08 11:27:15 --> Language Class Initialized
INFO - 2018-10-08 11:27:15 --> Language Class Initialized
INFO - 2018-10-08 11:27:15 --> Config Class Initialized
INFO - 2018-10-08 11:27:15 --> Loader Class Initialized
INFO - 2018-10-08 11:27:15 --> Helper loaded: url_helper
INFO - 2018-10-08 11:27:15 --> Helper loaded: form_helper
INFO - 2018-10-08 11:27:15 --> URI Class Initialized
INFO - 2018-10-08 11:27:15 --> Router Class Initialized
INFO - 2018-10-08 11:27:15 --> Database Driver Class Initialized
INFO - 2018-10-08 11:27:15 --> Email Class Initialized
INFO - 2018-10-08 11:27:15 --> Output Class Initialized
INFO - 2018-10-08 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:27:16 --> Form Validation Class Initialized
INFO - 2018-10-08 11:27:16 --> Controller Class Initialized
DEBUG - 2018-10-08 11:27:16 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:27:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:27:16 --> Final output sent to browser
DEBUG - 2018-10-08 11:27:16 --> Total execution time: 2.2991
INFO - 2018-10-08 11:27:16 --> Security Class Initialized
DEBUG - 2018-10-08 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:27:16 --> Input Class Initialized
INFO - 2018-10-08 11:27:17 --> Language Class Initialized
INFO - 2018-10-08 11:27:17 --> Language Class Initialized
INFO - 2018-10-08 11:27:17 --> Config Class Initialized
INFO - 2018-10-08 11:27:17 --> Loader Class Initialized
INFO - 2018-10-08 11:27:17 --> Helper loaded: url_helper
INFO - 2018-10-08 11:27:17 --> Helper loaded: form_helper
INFO - 2018-10-08 11:27:17 --> Database Driver Class Initialized
INFO - 2018-10-08 11:27:17 --> Email Class Initialized
INFO - 2018-10-08 11:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:27:18 --> Form Validation Class Initialized
INFO - 2018-10-08 11:27:18 --> Controller Class Initialized
DEBUG - 2018-10-08 11:27:18 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:27:18 --> Final output sent to browser
DEBUG - 2018-10-08 11:27:18 --> Total execution time: 3.9748
INFO - 2018-10-08 11:31:15 --> Config Class Initialized
INFO - 2018-10-08 11:31:15 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:31:15 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:31:15 --> Utf8 Class Initialized
INFO - 2018-10-08 11:31:15 --> URI Class Initialized
DEBUG - 2018-10-08 11:31:15 --> No URI present. Default controller set.
INFO - 2018-10-08 11:31:15 --> Router Class Initialized
INFO - 2018-10-08 11:31:15 --> Output Class Initialized
INFO - 2018-10-08 11:31:15 --> Security Class Initialized
DEBUG - 2018-10-08 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:31:15 --> Input Class Initialized
INFO - 2018-10-08 11:31:15 --> Language Class Initialized
INFO - 2018-10-08 11:31:15 --> Language Class Initialized
INFO - 2018-10-08 11:31:16 --> Config Class Initialized
INFO - 2018-10-08 11:31:16 --> Loader Class Initialized
INFO - 2018-10-08 11:31:16 --> Helper loaded: url_helper
INFO - 2018-10-08 11:31:16 --> Helper loaded: form_helper
INFO - 2018-10-08 11:31:16 --> Database Driver Class Initialized
INFO - 2018-10-08 11:31:16 --> Email Class Initialized
INFO - 2018-10-08 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:31:16 --> Form Validation Class Initialized
INFO - 2018-10-08 11:31:16 --> Controller Class Initialized
DEBUG - 2018-10-08 11:31:16 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:31:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:31:16 --> Final output sent to browser
DEBUG - 2018-10-08 11:31:16 --> Total execution time: 1.7941
INFO - 2018-10-08 11:31:33 --> Config Class Initialized
INFO - 2018-10-08 11:31:33 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:31:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:31:33 --> Config Class Initialized
INFO - 2018-10-08 11:31:33 --> Utf8 Class Initialized
INFO - 2018-10-08 11:31:34 --> Hooks Class Initialized
INFO - 2018-10-08 11:31:34 --> URI Class Initialized
INFO - 2018-10-08 11:31:34 --> Router Class Initialized
INFO - 2018-10-08 11:31:34 --> Output Class Initialized
INFO - 2018-10-08 11:31:34 --> Security Class Initialized
DEBUG - 2018-10-08 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:31:34 --> Input Class Initialized
INFO - 2018-10-08 11:31:34 --> Language Class Initialized
INFO - 2018-10-08 11:31:34 --> Language Class Initialized
INFO - 2018-10-08 11:31:34 --> Config Class Initialized
DEBUG - 2018-10-08 11:31:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:31:34 --> Utf8 Class Initialized
INFO - 2018-10-08 11:31:34 --> Loader Class Initialized
INFO - 2018-10-08 11:31:34 --> Helper loaded: url_helper
INFO - 2018-10-08 11:31:34 --> Helper loaded: form_helper
INFO - 2018-10-08 11:31:35 --> URI Class Initialized
INFO - 2018-10-08 11:31:35 --> Database Driver Class Initialized
INFO - 2018-10-08 11:31:35 --> Email Class Initialized
INFO - 2018-10-08 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:31:35 --> Form Validation Class Initialized
INFO - 2018-10-08 11:31:35 --> Controller Class Initialized
DEBUG - 2018-10-08 11:31:35 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:31:35 --> Final output sent to browser
DEBUG - 2018-10-08 11:31:35 --> Total execution time: 1.8481
DEBUG - 2018-10-08 11:31:35 --> No URI present. Default controller set.
INFO - 2018-10-08 11:31:35 --> Router Class Initialized
INFO - 2018-10-08 11:31:35 --> Output Class Initialized
INFO - 2018-10-08 11:31:35 --> Security Class Initialized
DEBUG - 2018-10-08 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:31:35 --> Input Class Initialized
INFO - 2018-10-08 11:31:36 --> Language Class Initialized
INFO - 2018-10-08 11:31:36 --> Language Class Initialized
INFO - 2018-10-08 11:31:36 --> Config Class Initialized
INFO - 2018-10-08 11:31:36 --> Loader Class Initialized
INFO - 2018-10-08 11:31:36 --> Helper loaded: url_helper
INFO - 2018-10-08 11:31:36 --> Helper loaded: form_helper
INFO - 2018-10-08 11:31:36 --> Database Driver Class Initialized
INFO - 2018-10-08 11:31:36 --> Email Class Initialized
INFO - 2018-10-08 11:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:31:36 --> Form Validation Class Initialized
INFO - 2018-10-08 11:31:36 --> Controller Class Initialized
DEBUG - 2018-10-08 11:31:36 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:31:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:31:36 --> Final output sent to browser
DEBUG - 2018-10-08 11:31:36 --> Total execution time: 3.1242
INFO - 2018-10-08 11:32:17 --> Config Class Initialized
INFO - 2018-10-08 11:32:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:32:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:32:17 --> Utf8 Class Initialized
INFO - 2018-10-08 11:32:17 --> URI Class Initialized
DEBUG - 2018-10-08 11:32:17 --> No URI present. Default controller set.
INFO - 2018-10-08 11:32:17 --> Router Class Initialized
INFO - 2018-10-08 11:32:18 --> Output Class Initialized
INFO - 2018-10-08 11:32:18 --> Security Class Initialized
DEBUG - 2018-10-08 11:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:32:18 --> Input Class Initialized
INFO - 2018-10-08 11:32:18 --> Language Class Initialized
INFO - 2018-10-08 11:32:18 --> Language Class Initialized
INFO - 2018-10-08 11:32:18 --> Config Class Initialized
INFO - 2018-10-08 11:32:18 --> Loader Class Initialized
INFO - 2018-10-08 11:32:18 --> Helper loaded: url_helper
INFO - 2018-10-08 11:32:18 --> Helper loaded: form_helper
INFO - 2018-10-08 11:32:18 --> Database Driver Class Initialized
INFO - 2018-10-08 11:32:18 --> Email Class Initialized
INFO - 2018-10-08 11:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:32:19 --> Form Validation Class Initialized
INFO - 2018-10-08 11:32:19 --> Controller Class Initialized
DEBUG - 2018-10-08 11:32:19 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:32:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:32:19 --> Final output sent to browser
DEBUG - 2018-10-08 11:32:19 --> Total execution time: 2.0171
INFO - 2018-10-08 11:32:35 --> Config Class Initialized
INFO - 2018-10-08 11:32:35 --> Hooks Class Initialized
INFO - 2018-10-08 11:32:35 --> Config Class Initialized
DEBUG - 2018-10-08 11:32:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:32:35 --> Hooks Class Initialized
INFO - 2018-10-08 11:32:35 --> Utf8 Class Initialized
DEBUG - 2018-10-08 11:32:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:32:36 --> Utf8 Class Initialized
INFO - 2018-10-08 11:32:36 --> URI Class Initialized
INFO - 2018-10-08 11:32:36 --> Router Class Initialized
INFO - 2018-10-08 11:32:36 --> Output Class Initialized
INFO - 2018-10-08 11:32:36 --> URI Class Initialized
INFO - 2018-10-08 11:32:36 --> Security Class Initialized
DEBUG - 2018-10-08 11:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:32:36 --> Input Class Initialized
INFO - 2018-10-08 11:32:37 --> Language Class Initialized
INFO - 2018-10-08 11:32:37 --> Language Class Initialized
INFO - 2018-10-08 11:32:37 --> Config Class Initialized
INFO - 2018-10-08 11:32:37 --> Loader Class Initialized
INFO - 2018-10-08 11:32:37 --> Helper loaded: url_helper
INFO - 2018-10-08 11:32:37 --> Helper loaded: form_helper
INFO - 2018-10-08 11:32:37 --> Database Driver Class Initialized
INFO - 2018-10-08 11:32:37 --> Email Class Initialized
DEBUG - 2018-10-08 11:32:37 --> No URI present. Default controller set.
INFO - 2018-10-08 11:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:32:37 --> Form Validation Class Initialized
INFO - 2018-10-08 11:32:37 --> Controller Class Initialized
DEBUG - 2018-10-08 11:32:37 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:32:38 --> Final output sent to browser
DEBUG - 2018-10-08 11:32:38 --> Total execution time: 2.5191
INFO - 2018-10-08 11:32:38 --> Router Class Initialized
INFO - 2018-10-08 11:32:38 --> Output Class Initialized
INFO - 2018-10-08 11:32:38 --> Security Class Initialized
DEBUG - 2018-10-08 11:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:32:38 --> Input Class Initialized
INFO - 2018-10-08 11:32:38 --> Language Class Initialized
INFO - 2018-10-08 11:32:38 --> Language Class Initialized
INFO - 2018-10-08 11:32:38 --> Config Class Initialized
INFO - 2018-10-08 11:32:38 --> Loader Class Initialized
INFO - 2018-10-08 11:32:38 --> Helper loaded: url_helper
INFO - 2018-10-08 11:32:38 --> Helper loaded: form_helper
INFO - 2018-10-08 11:32:38 --> Database Driver Class Initialized
INFO - 2018-10-08 11:32:39 --> Email Class Initialized
INFO - 2018-10-08 11:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:32:39 --> Form Validation Class Initialized
INFO - 2018-10-08 11:32:39 --> Controller Class Initialized
DEBUG - 2018-10-08 11:32:39 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:32:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:32:39 --> Final output sent to browser
DEBUG - 2018-10-08 11:32:39 --> Total execution time: 3.8252
INFO - 2018-10-08 11:35:14 --> Config Class Initialized
INFO - 2018-10-08 11:35:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:35:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:35:15 --> Utf8 Class Initialized
INFO - 2018-10-08 11:35:15 --> URI Class Initialized
DEBUG - 2018-10-08 11:35:15 --> No URI present. Default controller set.
INFO - 2018-10-08 11:35:15 --> Router Class Initialized
INFO - 2018-10-08 11:35:15 --> Output Class Initialized
INFO - 2018-10-08 11:35:15 --> Security Class Initialized
DEBUG - 2018-10-08 11:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:35:15 --> Input Class Initialized
INFO - 2018-10-08 11:35:15 --> Language Class Initialized
INFO - 2018-10-08 11:35:15 --> Language Class Initialized
INFO - 2018-10-08 11:35:15 --> Config Class Initialized
INFO - 2018-10-08 11:35:15 --> Loader Class Initialized
INFO - 2018-10-08 11:35:16 --> Helper loaded: url_helper
INFO - 2018-10-08 11:35:16 --> Helper loaded: form_helper
INFO - 2018-10-08 11:35:16 --> Database Driver Class Initialized
INFO - 2018-10-08 11:35:16 --> Email Class Initialized
INFO - 2018-10-08 11:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:35:16 --> Form Validation Class Initialized
INFO - 2018-10-08 11:35:16 --> Controller Class Initialized
DEBUG - 2018-10-08 11:35:16 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:35:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:35:16 --> Final output sent to browser
DEBUG - 2018-10-08 11:35:16 --> Total execution time: 2.2431
INFO - 2018-10-08 11:35:36 --> Config Class Initialized
INFO - 2018-10-08 11:35:36 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:35:36 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:35:36 --> Utf8 Class Initialized
INFO - 2018-10-08 11:35:36 --> Config Class Initialized
INFO - 2018-10-08 11:35:36 --> Hooks Class Initialized
INFO - 2018-10-08 11:35:36 --> URI Class Initialized
INFO - 2018-10-08 11:35:36 --> Router Class Initialized
DEBUG - 2018-10-08 11:35:36 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:35:36 --> Utf8 Class Initialized
INFO - 2018-10-08 11:35:36 --> Output Class Initialized
INFO - 2018-10-08 11:35:36 --> Security Class Initialized
DEBUG - 2018-10-08 11:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:35:37 --> Input Class Initialized
INFO - 2018-10-08 11:35:37 --> Language Class Initialized
INFO - 2018-10-08 11:35:37 --> URI Class Initialized
INFO - 2018-10-08 11:35:37 --> Language Class Initialized
DEBUG - 2018-10-08 11:35:37 --> No URI present. Default controller set.
INFO - 2018-10-08 11:35:37 --> Router Class Initialized
INFO - 2018-10-08 11:35:37 --> Output Class Initialized
INFO - 2018-10-08 11:35:37 --> Config Class Initialized
INFO - 2018-10-08 11:35:37 --> Security Class Initialized
DEBUG - 2018-10-08 11:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:35:37 --> Loader Class Initialized
INFO - 2018-10-08 11:35:37 --> Helper loaded: url_helper
INFO - 2018-10-08 11:35:38 --> Helper loaded: form_helper
INFO - 2018-10-08 11:35:38 --> Database Driver Class Initialized
INFO - 2018-10-08 11:35:38 --> Input Class Initialized
INFO - 2018-10-08 11:35:38 --> Language Class Initialized
INFO - 2018-10-08 11:35:38 --> Language Class Initialized
INFO - 2018-10-08 11:35:38 --> Email Class Initialized
INFO - 2018-10-08 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:35:38 --> Form Validation Class Initialized
INFO - 2018-10-08 11:35:38 --> Controller Class Initialized
DEBUG - 2018-10-08 11:35:38 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:35:38 --> Final output sent to browser
DEBUG - 2018-10-08 11:35:38 --> Total execution time: 2.7632
INFO - 2018-10-08 11:35:38 --> Config Class Initialized
INFO - 2018-10-08 11:35:39 --> Loader Class Initialized
INFO - 2018-10-08 11:35:39 --> Helper loaded: url_helper
INFO - 2018-10-08 11:35:39 --> Helper loaded: form_helper
INFO - 2018-10-08 11:35:39 --> Database Driver Class Initialized
INFO - 2018-10-08 11:35:39 --> Email Class Initialized
INFO - 2018-10-08 11:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:35:39 --> Form Validation Class Initialized
INFO - 2018-10-08 11:35:39 --> Controller Class Initialized
DEBUG - 2018-10-08 11:35:39 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:35:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:35:39 --> Final output sent to browser
DEBUG - 2018-10-08 11:35:39 --> Total execution time: 3.4852
INFO - 2018-10-08 11:38:33 --> Config Class Initialized
INFO - 2018-10-08 11:38:33 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:38:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:38:34 --> Utf8 Class Initialized
INFO - 2018-10-08 11:38:34 --> URI Class Initialized
DEBUG - 2018-10-08 11:38:34 --> No URI present. Default controller set.
INFO - 2018-10-08 11:38:34 --> Router Class Initialized
INFO - 2018-10-08 11:38:34 --> Output Class Initialized
INFO - 2018-10-08 11:38:34 --> Security Class Initialized
DEBUG - 2018-10-08 11:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:38:34 --> Input Class Initialized
INFO - 2018-10-08 11:38:34 --> Language Class Initialized
INFO - 2018-10-08 11:38:34 --> Language Class Initialized
INFO - 2018-10-08 11:38:35 --> Config Class Initialized
INFO - 2018-10-08 11:38:35 --> Loader Class Initialized
INFO - 2018-10-08 11:38:35 --> Helper loaded: url_helper
INFO - 2018-10-08 11:38:35 --> Helper loaded: form_helper
INFO - 2018-10-08 11:38:35 --> Database Driver Class Initialized
INFO - 2018-10-08 11:38:35 --> Email Class Initialized
INFO - 2018-10-08 11:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:38:35 --> Form Validation Class Initialized
INFO - 2018-10-08 11:38:35 --> Controller Class Initialized
DEBUG - 2018-10-08 11:38:35 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:38:35 --> Model Class Initialized
DEBUG - 2018-10-08 11:38:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:38:35 --> Model Class Initialized
DEBUG - 2018-10-08 11:38:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:38:35 --> Final output sent to browser
DEBUG - 2018-10-08 11:38:35 --> Total execution time: 2.0861
INFO - 2018-10-08 11:38:46 --> Config Class Initialized
INFO - 2018-10-08 11:38:46 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:38:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:38:46 --> Config Class Initialized
INFO - 2018-10-08 11:38:46 --> Utf8 Class Initialized
INFO - 2018-10-08 11:38:46 --> Hooks Class Initialized
INFO - 2018-10-08 11:38:46 --> URI Class Initialized
DEBUG - 2018-10-08 11:38:46 --> No URI present. Default controller set.
INFO - 2018-10-08 11:38:46 --> Router Class Initialized
INFO - 2018-10-08 11:38:46 --> Output Class Initialized
DEBUG - 2018-10-08 11:38:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:38:46 --> Security Class Initialized
INFO - 2018-10-08 11:38:47 --> Utf8 Class Initialized
DEBUG - 2018-10-08 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:38:47 --> Input Class Initialized
INFO - 2018-10-08 11:38:47 --> Language Class Initialized
INFO - 2018-10-08 11:38:47 --> Language Class Initialized
INFO - 2018-10-08 11:38:47 --> Config Class Initialized
INFO - 2018-10-08 11:38:47 --> Loader Class Initialized
INFO - 2018-10-08 11:38:47 --> Helper loaded: url_helper
INFO - 2018-10-08 11:38:47 --> Helper loaded: form_helper
INFO - 2018-10-08 11:38:47 --> Database Driver Class Initialized
INFO - 2018-10-08 11:38:47 --> Email Class Initialized
INFO - 2018-10-08 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:38:48 --> Form Validation Class Initialized
INFO - 2018-10-08 11:38:48 --> Controller Class Initialized
DEBUG - 2018-10-08 11:38:48 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:38:48 --> Model Class Initialized
DEBUG - 2018-10-08 11:38:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:38:48 --> Model Class Initialized
INFO - 2018-10-08 11:38:48 --> URI Class Initialized
INFO - 2018-10-08 11:38:48 --> Router Class Initialized
INFO - 2018-10-08 11:38:48 --> Output Class Initialized
INFO - 2018-10-08 11:38:48 --> Security Class Initialized
DEBUG - 2018-10-08 11:38:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:38:48 --> Final output sent to browser
DEBUG - 2018-10-08 11:38:48 --> Total execution time: 2.8102
DEBUG - 2018-10-08 11:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:38:49 --> Input Class Initialized
INFO - 2018-10-08 11:38:49 --> Language Class Initialized
INFO - 2018-10-08 11:38:50 --> Language Class Initialized
INFO - 2018-10-08 11:38:50 --> Config Class Initialized
INFO - 2018-10-08 11:38:50 --> Loader Class Initialized
INFO - 2018-10-08 11:38:50 --> Helper loaded: url_helper
INFO - 2018-10-08 11:38:50 --> Helper loaded: form_helper
INFO - 2018-10-08 11:38:50 --> Database Driver Class Initialized
INFO - 2018-10-08 11:38:50 --> Email Class Initialized
INFO - 2018-10-08 11:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:38:50 --> Form Validation Class Initialized
INFO - 2018-10-08 11:38:51 --> Controller Class Initialized
DEBUG - 2018-10-08 11:38:51 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:38:51 --> Model Class Initialized
DEBUG - 2018-10-08 11:38:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:38:51 --> Model Class Initialized
INFO - 2018-10-08 11:40:13 --> Config Class Initialized
INFO - 2018-10-08 11:40:14 --> Config Class Initialized
INFO - 2018-10-08 11:40:14 --> Hooks Class Initialized
INFO - 2018-10-08 11:40:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:40:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:40:14 --> Utf8 Class Initialized
DEBUG - 2018-10-08 11:40:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:40:14 --> Utf8 Class Initialized
INFO - 2018-10-08 11:40:14 --> URI Class Initialized
INFO - 2018-10-08 11:40:14 --> URI Class Initialized
INFO - 2018-10-08 11:40:15 --> Router Class Initialized
DEBUG - 2018-10-08 11:40:15 --> No URI present. Default controller set.
INFO - 2018-10-08 11:40:15 --> Router Class Initialized
INFO - 2018-10-08 11:40:15 --> Output Class Initialized
INFO - 2018-10-08 11:40:15 --> Security Class Initialized
INFO - 2018-10-08 11:40:15 --> Output Class Initialized
INFO - 2018-10-08 11:40:15 --> Security Class Initialized
DEBUG - 2018-10-08 11:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-08 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:40:15 --> Input Class Initialized
INFO - 2018-10-08 11:40:15 --> Input Class Initialized
INFO - 2018-10-08 11:40:15 --> Language Class Initialized
INFO - 2018-10-08 11:40:16 --> Language Class Initialized
INFO - 2018-10-08 11:40:16 --> Language Class Initialized
INFO - 2018-10-08 11:40:16 --> Language Class Initialized
INFO - 2018-10-08 11:40:16 --> Config Class Initialized
INFO - 2018-10-08 11:40:17 --> Loader Class Initialized
INFO - 2018-10-08 11:40:17 --> Config Class Initialized
INFO - 2018-10-08 11:40:17 --> Loader Class Initialized
INFO - 2018-10-08 11:40:17 --> Helper loaded: url_helper
INFO - 2018-10-08 11:40:17 --> Helper loaded: url_helper
INFO - 2018-10-08 11:40:17 --> Helper loaded: form_helper
INFO - 2018-10-08 11:40:17 --> Helper loaded: form_helper
INFO - 2018-10-08 11:40:17 --> Database Driver Class Initialized
INFO - 2018-10-08 11:40:17 --> Database Driver Class Initialized
INFO - 2018-10-08 11:40:17 --> Email Class Initialized
INFO - 2018-10-08 11:40:17 --> Email Class Initialized
INFO - 2018-10-08 11:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:40:18 --> Form Validation Class Initialized
INFO - 2018-10-08 11:40:18 --> Controller Class Initialized
DEBUG - 2018-10-08 11:40:18 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:40:18 --> Model Class Initialized
DEBUG - 2018-10-08 11:40:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:40:18 --> Model Class Initialized
INFO - 2018-10-08 11:40:18 --> Form Validation Class Initialized
INFO - 2018-10-08 11:40:19 --> Controller Class Initialized
DEBUG - 2018-10-08 11:40:19 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:40:19 --> Model Class Initialized
DEBUG - 2018-10-08 11:40:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:40:19 --> Model Class Initialized
DEBUG - 2018-10-08 11:40:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:40:19 --> Final output sent to browser
DEBUG - 2018-10-08 11:40:19 --> Total execution time: 6.2704
INFO - 2018-10-08 11:43:31 --> Config Class Initialized
INFO - 2018-10-08 11:43:31 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:43:31 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:43:31 --> Utf8 Class Initialized
INFO - 2018-10-08 11:43:32 --> URI Class Initialized
DEBUG - 2018-10-08 11:43:32 --> No URI present. Default controller set.
INFO - 2018-10-08 11:43:32 --> Router Class Initialized
INFO - 2018-10-08 11:43:32 --> Output Class Initialized
INFO - 2018-10-08 11:43:32 --> Security Class Initialized
DEBUG - 2018-10-08 11:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:43:32 --> Input Class Initialized
INFO - 2018-10-08 11:43:32 --> Language Class Initialized
INFO - 2018-10-08 11:43:32 --> Language Class Initialized
INFO - 2018-10-08 11:43:32 --> Config Class Initialized
INFO - 2018-10-08 11:43:33 --> Loader Class Initialized
INFO - 2018-10-08 11:43:33 --> Helper loaded: url_helper
INFO - 2018-10-08 11:43:33 --> Helper loaded: form_helper
INFO - 2018-10-08 11:43:33 --> Database Driver Class Initialized
INFO - 2018-10-08 11:43:33 --> Email Class Initialized
INFO - 2018-10-08 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:43:33 --> Form Validation Class Initialized
INFO - 2018-10-08 11:43:33 --> Controller Class Initialized
DEBUG - 2018-10-08 11:43:33 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:43:34 --> Model Class Initialized
DEBUG - 2018-10-08 11:43:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:43:34 --> Model Class Initialized
DEBUG - 2018-10-08 11:43:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:43:34 --> Final output sent to browser
DEBUG - 2018-10-08 11:43:34 --> Total execution time: 3.2702
INFO - 2018-10-08 11:43:45 --> Config Class Initialized
INFO - 2018-10-08 11:43:45 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:43:45 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:43:45 --> Utf8 Class Initialized
INFO - 2018-10-08 11:43:45 --> Config Class Initialized
INFO - 2018-10-08 11:43:46 --> URI Class Initialized
INFO - 2018-10-08 11:43:46 --> Router Class Initialized
INFO - 2018-10-08 11:43:46 --> Output Class Initialized
INFO - 2018-10-08 11:43:46 --> Security Class Initialized
DEBUG - 2018-10-08 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:43:47 --> Input Class Initialized
INFO - 2018-10-08 11:43:47 --> Hooks Class Initialized
INFO - 2018-10-08 11:43:47 --> Language Class Initialized
DEBUG - 2018-10-08 11:43:47 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:43:47 --> Language Class Initialized
INFO - 2018-10-08 11:43:47 --> Utf8 Class Initialized
INFO - 2018-10-08 11:43:47 --> Config Class Initialized
INFO - 2018-10-08 11:43:47 --> URI Class Initialized
INFO - 2018-10-08 11:43:47 --> Loader Class Initialized
DEBUG - 2018-10-08 11:43:47 --> No URI present. Default controller set.
INFO - 2018-10-08 11:43:47 --> Router Class Initialized
INFO - 2018-10-08 11:43:48 --> Helper loaded: url_helper
INFO - 2018-10-08 11:43:48 --> Helper loaded: form_helper
INFO - 2018-10-08 11:43:48 --> Database Driver Class Initialized
INFO - 2018-10-08 11:43:48 --> Output Class Initialized
INFO - 2018-10-08 11:43:48 --> Email Class Initialized
INFO - 2018-10-08 11:43:48 --> Security Class Initialized
INFO - 2018-10-08 11:43:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-08 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:43:48 --> Input Class Initialized
INFO - 2018-10-08 11:43:48 --> Form Validation Class Initialized
INFO - 2018-10-08 11:43:49 --> Language Class Initialized
INFO - 2018-10-08 11:43:49 --> Controller Class Initialized
DEBUG - 2018-10-08 11:43:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:43:49 --> Model Class Initialized
DEBUG - 2018-10-08 11:43:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:43:49 --> Model Class Initialized
INFO - 2018-10-08 11:43:49 --> Language Class Initialized
INFO - 2018-10-08 11:43:49 --> Config Class Initialized
ERROR - 2018-10-08 11:43:49 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
INFO - 2018-10-08 11:43:50 --> Loader Class Initialized
INFO - 2018-10-08 11:43:50 --> Helper loaded: url_helper
ERROR - 2018-10-08 11:43:50 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 29
INFO - 2018-10-08 11:43:50 --> Helper loaded: form_helper
ERROR - 2018-10-08 11:43:50 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:43:51 --> Database Driver Class Initialized
INFO - 2018-10-08 11:43:51 --> Email Class Initialized
INFO - 2018-10-08 11:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:43:51 --> Form Validation Class Initialized
INFO - 2018-10-08 11:43:51 --> Controller Class Initialized
DEBUG - 2018-10-08 11:43:51 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:43:51 --> Model Class Initialized
DEBUG - 2018-10-08 11:43:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:43:52 --> Model Class Initialized
DEBUG - 2018-10-08 11:43:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:43:52 --> Final output sent to browser
DEBUG - 2018-10-08 11:43:52 --> Total execution time: 6.4374
INFO - 2018-10-08 11:44:57 --> Config Class Initialized
INFO - 2018-10-08 11:44:57 --> Hooks Class Initialized
INFO - 2018-10-08 11:44:57 --> Config Class Initialized
DEBUG - 2018-10-08 11:44:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:44:57 --> Utf8 Class Initialized
INFO - 2018-10-08 11:44:57 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:44:58 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:44:58 --> Utf8 Class Initialized
INFO - 2018-10-08 11:44:58 --> URI Class Initialized
INFO - 2018-10-08 11:44:58 --> Router Class Initialized
INFO - 2018-10-08 11:44:58 --> Output Class Initialized
INFO - 2018-10-08 11:44:58 --> Security Class Initialized
DEBUG - 2018-10-08 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:44:58 --> Input Class Initialized
INFO - 2018-10-08 11:44:58 --> URI Class Initialized
INFO - 2018-10-08 11:44:59 --> Language Class Initialized
INFO - 2018-10-08 11:44:59 --> Language Class Initialized
INFO - 2018-10-08 11:44:59 --> Config Class Initialized
INFO - 2018-10-08 11:44:59 --> Loader Class Initialized
INFO - 2018-10-08 11:44:59 --> Helper loaded: url_helper
INFO - 2018-10-08 11:44:59 --> Helper loaded: form_helper
INFO - 2018-10-08 11:44:59 --> Database Driver Class Initialized
INFO - 2018-10-08 11:44:59 --> Email Class Initialized
INFO - 2018-10-08 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:44:59 --> Form Validation Class Initialized
INFO - 2018-10-08 11:45:00 --> Controller Class Initialized
DEBUG - 2018-10-08 11:45:00 --> No URI present. Default controller set.
DEBUG - 2018-10-08 11:45:00 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:45:00 --> Router Class Initialized
INFO - 2018-10-08 11:45:00 --> Model Class Initialized
DEBUG - 2018-10-08 11:45:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:45:00 --> Model Class Initialized
ERROR - 2018-10-08 11:45:00 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:45:00 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 29
INFO - 2018-10-08 11:45:00 --> Output Class Initialized
ERROR - 2018-10-08 11:45:00 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:45:01 --> Security Class Initialized
DEBUG - 2018-10-08 11:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:45:01 --> Input Class Initialized
INFO - 2018-10-08 11:45:01 --> Language Class Initialized
INFO - 2018-10-08 11:45:01 --> Language Class Initialized
INFO - 2018-10-08 11:45:01 --> Config Class Initialized
INFO - 2018-10-08 11:45:01 --> Loader Class Initialized
INFO - 2018-10-08 11:45:01 --> Helper loaded: url_helper
INFO - 2018-10-08 11:45:01 --> Helper loaded: form_helper
INFO - 2018-10-08 11:45:01 --> Database Driver Class Initialized
INFO - 2018-10-08 11:45:01 --> Email Class Initialized
INFO - 2018-10-08 11:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:45:02 --> Form Validation Class Initialized
INFO - 2018-10-08 11:45:02 --> Controller Class Initialized
DEBUG - 2018-10-08 11:45:02 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:45:02 --> Model Class Initialized
DEBUG - 2018-10-08 11:45:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:45:02 --> Model Class Initialized
DEBUG - 2018-10-08 11:45:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:45:02 --> Final output sent to browser
DEBUG - 2018-10-08 11:45:02 --> Total execution time: 5.5073
INFO - 2018-10-08 11:46:27 --> Config Class Initialized
INFO - 2018-10-08 11:46:27 --> Hooks Class Initialized
INFO - 2018-10-08 11:46:27 --> Config Class Initialized
INFO - 2018-10-08 11:46:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:46:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:46:28 --> Utf8 Class Initialized
INFO - 2018-10-08 11:46:28 --> URI Class Initialized
DEBUG - 2018-10-08 11:46:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:46:28 --> Utf8 Class Initialized
INFO - 2018-10-08 11:46:28 --> URI Class Initialized
INFO - 2018-10-08 11:46:28 --> Router Class Initialized
INFO - 2018-10-08 11:46:29 --> Output Class Initialized
DEBUG - 2018-10-08 11:46:29 --> No URI present. Default controller set.
INFO - 2018-10-08 11:46:29 --> Router Class Initialized
INFO - 2018-10-08 11:46:29 --> Security Class Initialized
INFO - 2018-10-08 11:46:29 --> Output Class Initialized
DEBUG - 2018-10-08 11:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:46:30 --> Input Class Initialized
INFO - 2018-10-08 11:46:30 --> Language Class Initialized
INFO - 2018-10-08 11:46:30 --> Language Class Initialized
INFO - 2018-10-08 11:46:30 --> Security Class Initialized
DEBUG - 2018-10-08 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:46:30 --> Input Class Initialized
INFO - 2018-10-08 11:46:30 --> Config Class Initialized
INFO - 2018-10-08 11:46:30 --> Loader Class Initialized
INFO - 2018-10-08 11:46:30 --> Language Class Initialized
INFO - 2018-10-08 11:46:30 --> Language Class Initialized
INFO - 2018-10-08 11:46:31 --> Config Class Initialized
INFO - 2018-10-08 11:46:31 --> Loader Class Initialized
INFO - 2018-10-08 11:46:31 --> Helper loaded: url_helper
INFO - 2018-10-08 11:46:31 --> Helper loaded: url_helper
INFO - 2018-10-08 11:46:31 --> Helper loaded: form_helper
INFO - 2018-10-08 11:46:31 --> Database Driver Class Initialized
INFO - 2018-10-08 11:46:31 --> Email Class Initialized
INFO - 2018-10-08 11:46:31 --> Helper loaded: form_helper
INFO - 2018-10-08 11:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:46:31 --> Form Validation Class Initialized
INFO - 2018-10-08 11:46:31 --> Database Driver Class Initialized
INFO - 2018-10-08 11:46:32 --> Email Class Initialized
INFO - 2018-10-08 11:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:46:32 --> Controller Class Initialized
DEBUG - 2018-10-08 11:46:32 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:46:32 --> Model Class Initialized
DEBUG - 2018-10-08 11:46:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:46:32 --> Model Class Initialized
DEBUG - 2018-10-08 11:46:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:46:32 --> Final output sent to browser
DEBUG - 2018-10-08 11:46:32 --> Total execution time: 5.1123
INFO - 2018-10-08 11:46:33 --> Form Validation Class Initialized
INFO - 2018-10-08 11:46:33 --> Controller Class Initialized
DEBUG - 2018-10-08 11:46:33 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:46:33 --> Model Class Initialized
DEBUG - 2018-10-08 11:46:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:46:33 --> Model Class Initialized
INFO - 2018-10-08 11:51:21 --> Config Class Initialized
INFO - 2018-10-08 11:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:51:21 --> Utf8 Class Initialized
INFO - 2018-10-08 11:51:21 --> URI Class Initialized
DEBUG - 2018-10-08 11:51:21 --> No URI present. Default controller set.
INFO - 2018-10-08 11:51:21 --> Router Class Initialized
INFO - 2018-10-08 11:51:21 --> Output Class Initialized
INFO - 2018-10-08 11:51:21 --> Security Class Initialized
DEBUG - 2018-10-08 11:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:51:22 --> Input Class Initialized
INFO - 2018-10-08 11:51:22 --> Language Class Initialized
INFO - 2018-10-08 11:51:22 --> Language Class Initialized
INFO - 2018-10-08 11:51:22 --> Config Class Initialized
INFO - 2018-10-08 11:51:22 --> Loader Class Initialized
INFO - 2018-10-08 11:51:22 --> Helper loaded: url_helper
INFO - 2018-10-08 11:51:23 --> Helper loaded: form_helper
INFO - 2018-10-08 11:51:23 --> Database Driver Class Initialized
INFO - 2018-10-08 11:51:23 --> Email Class Initialized
INFO - 2018-10-08 11:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:51:23 --> Form Validation Class Initialized
INFO - 2018-10-08 11:51:23 --> Controller Class Initialized
DEBUG - 2018-10-08 11:51:23 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:51:23 --> Model Class Initialized
DEBUG - 2018-10-08 11:51:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:51:23 --> Model Class Initialized
DEBUG - 2018-10-08 11:51:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:51:23 --> Final output sent to browser
DEBUG - 2018-10-08 11:51:24 --> Total execution time: 2.9332
INFO - 2018-10-08 11:52:03 --> Config Class Initialized
INFO - 2018-10-08 11:52:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:52:04 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:52:04 --> Utf8 Class Initialized
INFO - 2018-10-08 11:52:04 --> URI Class Initialized
INFO - 2018-10-08 11:52:04 --> Router Class Initialized
INFO - 2018-10-08 11:52:05 --> Output Class Initialized
INFO - 2018-10-08 11:52:05 --> Security Class Initialized
DEBUG - 2018-10-08 11:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:52:05 --> Input Class Initialized
INFO - 2018-10-08 11:52:05 --> Language Class Initialized
INFO - 2018-10-08 11:52:05 --> Language Class Initialized
INFO - 2018-10-08 11:52:05 --> Config Class Initialized
INFO - 2018-10-08 11:52:05 --> Loader Class Initialized
INFO - 2018-10-08 11:52:05 --> Helper loaded: url_helper
INFO - 2018-10-08 11:52:05 --> Helper loaded: form_helper
INFO - 2018-10-08 11:52:06 --> Database Driver Class Initialized
INFO - 2018-10-08 11:52:06 --> Email Class Initialized
INFO - 2018-10-08 11:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:52:06 --> Form Validation Class Initialized
INFO - 2018-10-08 11:52:06 --> Controller Class Initialized
DEBUG - 2018-10-08 11:52:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:52:06 --> Model Class Initialized
DEBUG - 2018-10-08 11:52:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:52:06 --> Model Class Initialized
ERROR - 2018-10-08 11:52:06 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:52:06 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
ERROR - 2018-10-08 11:52:07 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:52:16 --> Config Class Initialized
INFO - 2018-10-08 11:52:16 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:52:17 --> Utf8 Class Initialized
INFO - 2018-10-08 11:52:17 --> URI Class Initialized
INFO - 2018-10-08 11:52:17 --> Router Class Initialized
INFO - 2018-10-08 11:52:17 --> Output Class Initialized
INFO - 2018-10-08 11:52:17 --> Security Class Initialized
DEBUG - 2018-10-08 11:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:52:17 --> Input Class Initialized
INFO - 2018-10-08 11:52:17 --> Language Class Initialized
INFO - 2018-10-08 11:52:17 --> Language Class Initialized
INFO - 2018-10-08 11:52:17 --> Config Class Initialized
INFO - 2018-10-08 11:52:18 --> Loader Class Initialized
INFO - 2018-10-08 11:52:18 --> Helper loaded: url_helper
INFO - 2018-10-08 11:52:18 --> Helper loaded: form_helper
INFO - 2018-10-08 11:52:18 --> Database Driver Class Initialized
INFO - 2018-10-08 11:52:18 --> Email Class Initialized
INFO - 2018-10-08 11:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:52:18 --> Form Validation Class Initialized
INFO - 2018-10-08 11:52:18 --> Controller Class Initialized
DEBUG - 2018-10-08 11:52:18 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:52:18 --> Model Class Initialized
INFO - 2018-10-08 11:52:18 --> Config Class Initialized
INFO - 2018-10-08 11:52:18 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:52:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:52:19 --> Utf8 Class Initialized
INFO - 2018-10-08 11:52:19 --> URI Class Initialized
INFO - 2018-10-08 11:52:19 --> Router Class Initialized
DEBUG - 2018-10-08 11:52:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:52:19 --> Output Class Initialized
INFO - 2018-10-08 11:52:19 --> Model Class Initialized
INFO - 2018-10-08 11:52:19 --> Security Class Initialized
DEBUG - 2018-10-08 11:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:52:20 --> Input Class Initialized
ERROR - 2018-10-08 11:52:20 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:52:20 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
INFO - 2018-10-08 11:52:20 --> Language Class Initialized
ERROR - 2018-10-08 11:52:20 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:52:20 --> Language Class Initialized
INFO - 2018-10-08 11:52:20 --> Config Class Initialized
INFO - 2018-10-08 11:52:20 --> Loader Class Initialized
INFO - 2018-10-08 11:52:20 --> Config Class Initialized
INFO - 2018-10-08 11:52:20 --> Helper loaded: url_helper
INFO - 2018-10-08 11:52:20 --> Helper loaded: form_helper
INFO - 2018-10-08 11:52:21 --> Hooks Class Initialized
INFO - 2018-10-08 11:52:21 --> Database Driver Class Initialized
INFO - 2018-10-08 11:52:21 --> Email Class Initialized
INFO - 2018-10-08 11:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:52:21 --> Form Validation Class Initialized
DEBUG - 2018-10-08 11:52:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:52:21 --> Utf8 Class Initialized
INFO - 2018-10-08 11:52:21 --> Controller Class Initialized
DEBUG - 2018-10-08 11:52:22 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:52:22 --> Model Class Initialized
DEBUG - 2018-10-08 11:52:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:52:22 --> Model Class Initialized
ERROR - 2018-10-08 11:52:22 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:52:22 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
ERROR - 2018-10-08 11:52:22 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:52:23 --> URI Class Initialized
INFO - 2018-10-08 11:52:23 --> Router Class Initialized
INFO - 2018-10-08 11:52:23 --> Output Class Initialized
INFO - 2018-10-08 11:52:23 --> Security Class Initialized
DEBUG - 2018-10-08 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:52:23 --> Input Class Initialized
INFO - 2018-10-08 11:52:23 --> Language Class Initialized
INFO - 2018-10-08 11:52:24 --> Language Class Initialized
INFO - 2018-10-08 11:52:24 --> Config Class Initialized
INFO - 2018-10-08 11:52:24 --> Loader Class Initialized
INFO - 2018-10-08 11:52:24 --> Helper loaded: url_helper
INFO - 2018-10-08 11:52:24 --> Helper loaded: form_helper
INFO - 2018-10-08 11:52:25 --> Database Driver Class Initialized
INFO - 2018-10-08 11:52:25 --> Email Class Initialized
INFO - 2018-10-08 11:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:52:25 --> Form Validation Class Initialized
INFO - 2018-10-08 11:52:25 --> Controller Class Initialized
DEBUG - 2018-10-08 11:52:25 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:52:25 --> Model Class Initialized
DEBUG - 2018-10-08 11:52:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:52:25 --> Model Class Initialized
ERROR - 2018-10-08 11:52:26 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:52:26 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
ERROR - 2018-10-08 11:52:26 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:53:21 --> Config Class Initialized
INFO - 2018-10-08 11:53:21 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:53:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:53:21 --> Utf8 Class Initialized
INFO - 2018-10-08 11:53:22 --> URI Class Initialized
INFO - 2018-10-08 11:53:22 --> Router Class Initialized
INFO - 2018-10-08 11:53:22 --> Output Class Initialized
INFO - 2018-10-08 11:53:22 --> Security Class Initialized
DEBUG - 2018-10-08 11:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:53:22 --> Input Class Initialized
INFO - 2018-10-08 11:53:22 --> Language Class Initialized
INFO - 2018-10-08 11:53:22 --> Language Class Initialized
INFO - 2018-10-08 11:53:22 --> Config Class Initialized
INFO - 2018-10-08 11:53:23 --> Loader Class Initialized
INFO - 2018-10-08 11:53:23 --> Helper loaded: url_helper
INFO - 2018-10-08 11:53:23 --> Helper loaded: form_helper
INFO - 2018-10-08 11:53:23 --> Database Driver Class Initialized
INFO - 2018-10-08 11:53:23 --> Email Class Initialized
INFO - 2018-10-08 11:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:53:23 --> Form Validation Class Initialized
INFO - 2018-10-08 11:53:23 --> Controller Class Initialized
DEBUG - 2018-10-08 11:53:23 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:53:23 --> Model Class Initialized
DEBUG - 2018-10-08 11:53:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:53:23 --> Model Class Initialized
ERROR - 2018-10-08 11:53:24 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:53:24 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
ERROR - 2018-10-08 11:53:24 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:53:52 --> Config Class Initialized
INFO - 2018-10-08 11:53:52 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:53:53 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:53:53 --> Utf8 Class Initialized
INFO - 2018-10-08 11:53:53 --> URI Class Initialized
DEBUG - 2018-10-08 11:53:53 --> No URI present. Default controller set.
INFO - 2018-10-08 11:53:53 --> Router Class Initialized
INFO - 2018-10-08 11:53:53 --> Output Class Initialized
INFO - 2018-10-08 11:53:53 --> Security Class Initialized
DEBUG - 2018-10-08 11:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:53:53 --> Input Class Initialized
INFO - 2018-10-08 11:53:53 --> Language Class Initialized
INFO - 2018-10-08 11:53:53 --> Language Class Initialized
INFO - 2018-10-08 11:53:54 --> Config Class Initialized
INFO - 2018-10-08 11:53:54 --> Loader Class Initialized
INFO - 2018-10-08 11:53:54 --> Helper loaded: url_helper
INFO - 2018-10-08 11:53:54 --> Helper loaded: form_helper
INFO - 2018-10-08 11:53:54 --> Database Driver Class Initialized
INFO - 2018-10-08 11:53:54 --> Email Class Initialized
INFO - 2018-10-08 11:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:53:55 --> Form Validation Class Initialized
INFO - 2018-10-08 11:53:55 --> Controller Class Initialized
DEBUG - 2018-10-08 11:53:55 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:53:55 --> Model Class Initialized
DEBUG - 2018-10-08 11:53:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:53:56 --> Model Class Initialized
DEBUG - 2018-10-08 11:53:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:53:57 --> Final output sent to browser
DEBUG - 2018-10-08 11:53:57 --> Total execution time: 4.4823
INFO - 2018-10-08 11:54:17 --> Config Class Initialized
INFO - 2018-10-08 11:54:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:54:18 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:54:18 --> Utf8 Class Initialized
INFO - 2018-10-08 11:54:18 --> URI Class Initialized
INFO - 2018-10-08 11:54:18 --> Router Class Initialized
INFO - 2018-10-08 11:54:18 --> Output Class Initialized
INFO - 2018-10-08 11:54:18 --> Security Class Initialized
DEBUG - 2018-10-08 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:54:18 --> Input Class Initialized
INFO - 2018-10-08 11:54:18 --> Language Class Initialized
INFO - 2018-10-08 11:54:18 --> Language Class Initialized
INFO - 2018-10-08 11:54:19 --> Config Class Initialized
INFO - 2018-10-08 11:54:19 --> Loader Class Initialized
INFO - 2018-10-08 11:54:19 --> Helper loaded: url_helper
INFO - 2018-10-08 11:54:19 --> Helper loaded: form_helper
INFO - 2018-10-08 11:54:19 --> Database Driver Class Initialized
INFO - 2018-10-08 11:54:19 --> Email Class Initialized
INFO - 2018-10-08 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:54:19 --> Form Validation Class Initialized
INFO - 2018-10-08 11:54:19 --> Controller Class Initialized
DEBUG - 2018-10-08 11:54:19 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:54:20 --> Model Class Initialized
DEBUG - 2018-10-08 11:54:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:54:20 --> Model Class Initialized
ERROR - 2018-10-08 11:54:20 --> Severity: Notice --> Undefined property: CI::$mdl_person C:\xampp\htdocs\User_Management\application\third_party\MX\Controller.php 59
ERROR - 2018-10-08 11:54:20 --> Severity: error --> Exception: Call to a member function _insert() on null C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 30
ERROR - 2018-10-08 11:54:20 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 11:56:18 --> Config Class Initialized
INFO - 2018-10-08 11:56:18 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:56:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:56:19 --> Utf8 Class Initialized
INFO - 2018-10-08 11:56:20 --> URI Class Initialized
INFO - 2018-10-08 11:56:20 --> Router Class Initialized
INFO - 2018-10-08 11:56:20 --> Config Class Initialized
INFO - 2018-10-08 11:56:20 --> Output Class Initialized
INFO - 2018-10-08 11:56:20 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:56:20 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:56:20 --> Security Class Initialized
INFO - 2018-10-08 11:56:20 --> Utf8 Class Initialized
INFO - 2018-10-08 11:56:21 --> URI Class Initialized
DEBUG - 2018-10-08 11:56:21 --> No URI present. Default controller set.
INFO - 2018-10-08 11:56:21 --> Router Class Initialized
INFO - 2018-10-08 11:56:21 --> Output Class Initialized
INFO - 2018-10-08 11:56:21 --> Security Class Initialized
DEBUG - 2018-10-08 11:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:56:21 --> Input Class Initialized
INFO - 2018-10-08 11:56:21 --> Language Class Initialized
INFO - 2018-10-08 11:56:21 --> Language Class Initialized
INFO - 2018-10-08 11:56:21 --> Config Class Initialized
DEBUG - 2018-10-08 11:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:56:22 --> Loader Class Initialized
INFO - 2018-10-08 11:56:22 --> Helper loaded: url_helper
INFO - 2018-10-08 11:56:22 --> Helper loaded: form_helper
INFO - 2018-10-08 11:56:22 --> Input Class Initialized
INFO - 2018-10-08 11:56:22 --> Language Class Initialized
INFO - 2018-10-08 11:56:22 --> Language Class Initialized
INFO - 2018-10-08 11:56:22 --> Database Driver Class Initialized
INFO - 2018-10-08 11:56:22 --> Config Class Initialized
INFO - 2018-10-08 11:56:22 --> Loader Class Initialized
INFO - 2018-10-08 11:56:23 --> Helper loaded: url_helper
INFO - 2018-10-08 11:56:23 --> Helper loaded: form_helper
INFO - 2018-10-08 11:56:23 --> Database Driver Class Initialized
INFO - 2018-10-08 11:56:23 --> Email Class Initialized
INFO - 2018-10-08 11:56:23 --> Email Class Initialized
INFO - 2018-10-08 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:56:23 --> Form Validation Class Initialized
INFO - 2018-10-08 11:56:23 --> Controller Class Initialized
DEBUG - 2018-10-08 11:56:23 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:56:24 --> Model Class Initialized
DEBUG - 2018-10-08 11:56:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 11:56:24 --> Model Class Initialized
DEBUG - 2018-10-08 11:56:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:56:24 --> Final output sent to browser
INFO - 2018-10-08 11:56:24 --> Form Validation Class Initialized
DEBUG - 2018-10-08 11:56:24 --> Total execution time: 3.9852
INFO - 2018-10-08 11:56:24 --> Controller Class Initialized
DEBUG - 2018-10-08 11:56:24 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:56:25 --> Model Class Initialized
DEBUG - 2018-10-08 11:56:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:56:26 --> Model Class Initialized
INFO - 2018-10-08 11:56:28 --> Final output sent to browser
DEBUG - 2018-10-08 11:56:28 --> Total execution time: 9.4685
INFO - 2018-10-08 11:57:43 --> Config Class Initialized
INFO - 2018-10-08 11:57:43 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:57:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:57:44 --> Utf8 Class Initialized
INFO - 2018-10-08 11:57:44 --> URI Class Initialized
DEBUG - 2018-10-08 11:57:44 --> No URI present. Default controller set.
INFO - 2018-10-08 11:57:44 --> Router Class Initialized
INFO - 2018-10-08 11:57:44 --> Output Class Initialized
INFO - 2018-10-08 11:57:45 --> Security Class Initialized
DEBUG - 2018-10-08 11:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:57:45 --> Input Class Initialized
INFO - 2018-10-08 11:57:45 --> Language Class Initialized
INFO - 2018-10-08 11:57:45 --> Language Class Initialized
INFO - 2018-10-08 11:57:46 --> Config Class Initialized
INFO - 2018-10-08 11:57:46 --> Loader Class Initialized
INFO - 2018-10-08 11:57:46 --> Helper loaded: url_helper
INFO - 2018-10-08 11:57:46 --> Helper loaded: form_helper
INFO - 2018-10-08 11:57:46 --> Database Driver Class Initialized
INFO - 2018-10-08 11:57:46 --> Email Class Initialized
INFO - 2018-10-08 11:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:57:47 --> Form Validation Class Initialized
INFO - 2018-10-08 11:57:47 --> Controller Class Initialized
DEBUG - 2018-10-08 11:57:47 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:57:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:57:47 --> Final output sent to browser
DEBUG - 2018-10-08 11:57:47 --> Total execution time: 3.9982
INFO - 2018-10-08 11:58:15 --> Config Class Initialized
INFO - 2018-10-08 11:58:15 --> Hooks Class Initialized
INFO - 2018-10-08 11:58:15 --> Config Class Initialized
INFO - 2018-10-08 11:58:15 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:58:15 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:58:15 --> Utf8 Class Initialized
INFO - 2018-10-08 11:58:16 --> URI Class Initialized
DEBUG - 2018-10-08 11:58:16 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 11:58:16 --> No URI present. Default controller set.
INFO - 2018-10-08 11:58:16 --> Utf8 Class Initialized
INFO - 2018-10-08 11:58:16 --> Router Class Initialized
INFO - 2018-10-08 11:58:16 --> Output Class Initialized
INFO - 2018-10-08 11:58:16 --> Security Class Initialized
DEBUG - 2018-10-08 11:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:58:16 --> URI Class Initialized
INFO - 2018-10-08 11:58:17 --> Router Class Initialized
INFO - 2018-10-08 11:58:17 --> Input Class Initialized
INFO - 2018-10-08 11:58:17 --> Language Class Initialized
INFO - 2018-10-08 11:58:17 --> Language Class Initialized
INFO - 2018-10-08 11:58:17 --> Output Class Initialized
INFO - 2018-10-08 11:58:17 --> Config Class Initialized
INFO - 2018-10-08 11:58:17 --> Loader Class Initialized
INFO - 2018-10-08 11:58:17 --> Helper loaded: url_helper
INFO - 2018-10-08 11:58:17 --> Helper loaded: form_helper
INFO - 2018-10-08 11:58:17 --> Database Driver Class Initialized
INFO - 2018-10-08 11:58:18 --> Email Class Initialized
INFO - 2018-10-08 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:58:18 --> Security Class Initialized
INFO - 2018-10-08 11:58:18 --> Form Validation Class Initialized
INFO - 2018-10-08 11:58:18 --> Controller Class Initialized
DEBUG - 2018-10-08 11:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-08 11:58:18 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:58:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:58:18 --> Final output sent to browser
DEBUG - 2018-10-08 11:58:18 --> Total execution time: 3.3392
INFO - 2018-10-08 11:58:19 --> Input Class Initialized
INFO - 2018-10-08 11:58:19 --> Language Class Initialized
INFO - 2018-10-08 11:58:20 --> Language Class Initialized
INFO - 2018-10-08 11:58:20 --> Config Class Initialized
INFO - 2018-10-08 11:58:20 --> Loader Class Initialized
INFO - 2018-10-08 11:58:20 --> Helper loaded: url_helper
INFO - 2018-10-08 11:58:20 --> Helper loaded: form_helper
INFO - 2018-10-08 11:58:20 --> Database Driver Class Initialized
INFO - 2018-10-08 11:58:20 --> Email Class Initialized
INFO - 2018-10-08 11:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:58:21 --> Form Validation Class Initialized
INFO - 2018-10-08 11:58:21 --> Controller Class Initialized
DEBUG - 2018-10-08 11:58:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:58:21 --> Final output sent to browser
DEBUG - 2018-10-08 11:58:21 --> Total execution time: 6.0587
INFO - 2018-10-08 11:59:13 --> Config Class Initialized
INFO - 2018-10-08 11:59:13 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:59:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:59:14 --> Utf8 Class Initialized
INFO - 2018-10-08 11:59:14 --> URI Class Initialized
DEBUG - 2018-10-08 11:59:14 --> No URI present. Default controller set.
INFO - 2018-10-08 11:59:14 --> Router Class Initialized
INFO - 2018-10-08 11:59:14 --> Output Class Initialized
INFO - 2018-10-08 11:59:14 --> Security Class Initialized
DEBUG - 2018-10-08 11:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:59:15 --> Input Class Initialized
INFO - 2018-10-08 11:59:15 --> Language Class Initialized
INFO - 2018-10-08 11:59:15 --> Language Class Initialized
INFO - 2018-10-08 11:59:15 --> Config Class Initialized
INFO - 2018-10-08 11:59:15 --> Loader Class Initialized
INFO - 2018-10-08 11:59:15 --> Helper loaded: url_helper
INFO - 2018-10-08 11:59:15 --> Helper loaded: form_helper
INFO - 2018-10-08 11:59:15 --> Database Driver Class Initialized
INFO - 2018-10-08 11:59:15 --> Email Class Initialized
INFO - 2018-10-08 11:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:59:16 --> Form Validation Class Initialized
INFO - 2018-10-08 11:59:16 --> Controller Class Initialized
DEBUG - 2018-10-08 11:59:16 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:59:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:59:16 --> Final output sent to browser
DEBUG - 2018-10-08 11:59:16 --> Total execution time: 2.7222
INFO - 2018-10-08 11:59:41 --> Config Class Initialized
INFO - 2018-10-08 11:59:41 --> Hooks Class Initialized
INFO - 2018-10-08 11:59:41 --> Config Class Initialized
DEBUG - 2018-10-08 11:59:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:59:42 --> Hooks Class Initialized
DEBUG - 2018-10-08 11:59:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 11:59:42 --> Utf8 Class Initialized
INFO - 2018-10-08 11:59:42 --> Utf8 Class Initialized
INFO - 2018-10-08 11:59:42 --> URI Class Initialized
DEBUG - 2018-10-08 11:59:42 --> No URI present. Default controller set.
INFO - 2018-10-08 11:59:42 --> URI Class Initialized
INFO - 2018-10-08 11:59:42 --> Router Class Initialized
INFO - 2018-10-08 11:59:43 --> Output Class Initialized
INFO - 2018-10-08 11:59:43 --> Security Class Initialized
DEBUG - 2018-10-08 11:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:59:43 --> Router Class Initialized
INFO - 2018-10-08 11:59:43 --> Input Class Initialized
INFO - 2018-10-08 11:59:43 --> Language Class Initialized
INFO - 2018-10-08 11:59:43 --> Language Class Initialized
INFO - 2018-10-08 11:59:43 --> Config Class Initialized
INFO - 2018-10-08 11:59:43 --> Loader Class Initialized
INFO - 2018-10-08 11:59:43 --> Helper loaded: url_helper
INFO - 2018-10-08 11:59:44 --> Output Class Initialized
INFO - 2018-10-08 11:59:44 --> Helper loaded: form_helper
INFO - 2018-10-08 11:59:44 --> Database Driver Class Initialized
INFO - 2018-10-08 11:59:44 --> Email Class Initialized
INFO - 2018-10-08 11:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:59:44 --> Form Validation Class Initialized
INFO - 2018-10-08 11:59:44 --> Controller Class Initialized
DEBUG - 2018-10-08 11:59:44 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 11:59:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 11:59:45 --> Final output sent to browser
DEBUG - 2018-10-08 11:59:45 --> Total execution time: 3.3452
INFO - 2018-10-08 11:59:45 --> Security Class Initialized
DEBUG - 2018-10-08 11:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 11:59:46 --> Input Class Initialized
INFO - 2018-10-08 11:59:46 --> Language Class Initialized
INFO - 2018-10-08 11:59:46 --> Language Class Initialized
INFO - 2018-10-08 11:59:46 --> Config Class Initialized
INFO - 2018-10-08 11:59:46 --> Loader Class Initialized
INFO - 2018-10-08 11:59:47 --> Helper loaded: url_helper
INFO - 2018-10-08 11:59:47 --> Helper loaded: form_helper
INFO - 2018-10-08 11:59:47 --> Database Driver Class Initialized
INFO - 2018-10-08 11:59:47 --> Email Class Initialized
INFO - 2018-10-08 11:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 11:59:47 --> Form Validation Class Initialized
INFO - 2018-10-08 11:59:48 --> Controller Class Initialized
DEBUG - 2018-10-08 11:59:48 --> Person MX_Controller Initialized
INFO - 2018-10-08 11:59:48 --> Model Class Initialized
DEBUG - 2018-10-08 11:59:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 11:59:48 --> Model Class Initialized
INFO - 2018-10-08 11:59:48 --> Final output sent to browser
DEBUG - 2018-10-08 11:59:48 --> Total execution time: 7.1048
INFO - 2018-10-08 12:01:01 --> Config Class Initialized
INFO - 2018-10-08 12:01:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:01:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:01:01 --> Utf8 Class Initialized
INFO - 2018-10-08 12:01:01 --> Config Class Initialized
INFO - 2018-10-08 12:01:02 --> Hooks Class Initialized
INFO - 2018-10-08 12:01:02 --> Config Class Initialized
INFO - 2018-10-08 12:01:02 --> URI Class Initialized
INFO - 2018-10-08 12:01:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:01:02 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 12:01:02 --> No URI present. Default controller set.
INFO - 2018-10-08 12:01:02 --> Router Class Initialized
INFO - 2018-10-08 12:01:02 --> Output Class Initialized
INFO - 2018-10-08 12:01:02 --> Security Class Initialized
INFO - 2018-10-08 12:01:03 --> Config Class Initialized
INFO - 2018-10-08 12:01:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-08 12:01:03 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:01:03 --> Input Class Initialized
INFO - 2018-10-08 12:01:03 --> Language Class Initialized
INFO - 2018-10-08 12:01:03 --> Utf8 Class Initialized
INFO - 2018-10-08 12:01:03 --> Language Class Initialized
INFO - 2018-10-08 12:01:03 --> Config Class Initialized
INFO - 2018-10-08 12:01:03 --> Loader Class Initialized
INFO - 2018-10-08 12:01:04 --> Helper loaded: url_helper
INFO - 2018-10-08 12:01:04 --> Helper loaded: form_helper
INFO - 2018-10-08 12:01:04 --> Database Driver Class Initialized
INFO - 2018-10-08 12:01:04 --> Email Class Initialized
DEBUG - 2018-10-08 12:01:04 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:01:04 --> Form Validation Class Initialized
INFO - 2018-10-08 12:01:04 --> Controller Class Initialized
INFO - 2018-10-08 12:01:05 --> Utf8 Class Initialized
DEBUG - 2018-10-08 12:01:05 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 12:01:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:01:05 --> Final output sent to browser
DEBUG - 2018-10-08 12:01:05 --> Total execution time: 4.1232
INFO - 2018-10-08 12:01:05 --> URI Class Initialized
INFO - 2018-10-08 12:01:06 --> Router Class Initialized
INFO - 2018-10-08 12:01:06 --> Utf8 Class Initialized
INFO - 2018-10-08 12:01:06 --> URI Class Initialized
INFO - 2018-10-08 12:01:06 --> Router Class Initialized
INFO - 2018-10-08 12:01:06 --> Output Class Initialized
INFO - 2018-10-08 12:01:06 --> Security Class Initialized
DEBUG - 2018-10-08 12:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:01:07 --> Output Class Initialized
INFO - 2018-10-08 12:01:09 --> Security Class Initialized
INFO - 2018-10-08 12:01:10 --> Input Class Initialized
INFO - 2018-10-08 12:01:10 --> URI Class Initialized
INFO - 2018-10-08 12:01:10 --> Language Class Initialized
DEBUG - 2018-10-08 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:01:10 --> Input Class Initialized
INFO - 2018-10-08 12:01:10 --> Language Class Initialized
DEBUG - 2018-10-08 12:01:10 --> No URI present. Default controller set.
INFO - 2018-10-08 12:01:10 --> Language Class Initialized
INFO - 2018-10-08 12:01:10 --> Language Class Initialized
INFO - 2018-10-08 12:01:11 --> Router Class Initialized
INFO - 2018-10-08 12:01:11 --> Output Class Initialized
INFO - 2018-10-08 12:01:11 --> Security Class Initialized
DEBUG - 2018-10-08 12:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:01:11 --> Input Class Initialized
INFO - 2018-10-08 12:01:11 --> Language Class Initialized
INFO - 2018-10-08 12:01:11 --> Language Class Initialized
INFO - 2018-10-08 12:01:11 --> Config Class Initialized
INFO - 2018-10-08 12:01:11 --> Loader Class Initialized
INFO - 2018-10-08 12:01:11 --> Config Class Initialized
INFO - 2018-10-08 12:01:12 --> Loader Class Initialized
INFO - 2018-10-08 12:01:12 --> Helper loaded: url_helper
INFO - 2018-10-08 12:01:12 --> Helper loaded: form_helper
INFO - 2018-10-08 12:01:12 --> Helper loaded: url_helper
INFO - 2018-10-08 12:01:12 --> Database Driver Class Initialized
INFO - 2018-10-08 12:01:12 --> Email Class Initialized
INFO - 2018-10-08 12:01:12 --> Config Class Initialized
INFO - 2018-10-08 12:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:01:12 --> Helper loaded: form_helper
INFO - 2018-10-08 12:01:13 --> Database Driver Class Initialized
INFO - 2018-10-08 12:01:13 --> Email Class Initialized
INFO - 2018-10-08 12:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:01:13 --> Form Validation Class Initialized
INFO - 2018-10-08 12:01:13 --> Loader Class Initialized
INFO - 2018-10-08 12:01:13 --> Helper loaded: url_helper
INFO - 2018-10-08 12:01:13 --> Helper loaded: form_helper
INFO - 2018-10-08 12:01:13 --> Database Driver Class Initialized
INFO - 2018-10-08 12:01:13 --> Email Class Initialized
INFO - 2018-10-08 12:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:01:14 --> Form Validation Class Initialized
INFO - 2018-10-08 12:01:14 --> Controller Class Initialized
DEBUG - 2018-10-08 12:01:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:01:14 --> Model Class Initialized
DEBUG - 2018-10-08 12:01:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 12:01:14 --> Model Class Initialized
INFO - 2018-10-08 12:01:14 --> Controller Class Initialized
DEBUG - 2018-10-08 12:01:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:01:14 --> Model Class Initialized
DEBUG - 2018-10-08 12:01:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 12:01:15 --> Model Class Initialized
INFO - 2018-10-08 12:01:15 --> Form Validation Class Initialized
INFO - 2018-10-08 12:01:15 --> Controller Class Initialized
DEBUG - 2018-10-08 12:01:15 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:01:15 --> Final output sent to browser
DEBUG - 2018-10-08 12:01:15 --> Total execution time: 13.6998
DEBUG - 2018-10-08 12:01:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:01:15 --> Final output sent to browser
DEBUG - 2018-10-08 12:01:16 --> Total execution time: 12.9167
INFO - 2018-10-08 12:01:16 --> Final output sent to browser
DEBUG - 2018-10-08 12:01:16 --> Total execution time: 14.5808
INFO - 2018-10-08 12:02:15 --> Config Class Initialized
INFO - 2018-10-08 12:02:15 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:02:15 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:02:15 --> Utf8 Class Initialized
INFO - 2018-10-08 12:02:15 --> URI Class Initialized
DEBUG - 2018-10-08 12:02:15 --> No URI present. Default controller set.
INFO - 2018-10-08 12:02:15 --> Router Class Initialized
INFO - 2018-10-08 12:02:15 --> Output Class Initialized
INFO - 2018-10-08 12:02:16 --> Security Class Initialized
DEBUG - 2018-10-08 12:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:02:16 --> Input Class Initialized
INFO - 2018-10-08 12:02:16 --> Language Class Initialized
INFO - 2018-10-08 12:02:16 --> Language Class Initialized
INFO - 2018-10-08 12:02:16 --> Config Class Initialized
INFO - 2018-10-08 12:02:16 --> Loader Class Initialized
INFO - 2018-10-08 12:02:16 --> Helper loaded: url_helper
INFO - 2018-10-08 12:02:16 --> Helper loaded: form_helper
INFO - 2018-10-08 12:02:16 --> Database Driver Class Initialized
INFO - 2018-10-08 12:02:17 --> Email Class Initialized
INFO - 2018-10-08 12:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:02:17 --> Form Validation Class Initialized
INFO - 2018-10-08 12:02:17 --> Controller Class Initialized
DEBUG - 2018-10-08 12:02:17 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 12:02:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:02:17 --> Final output sent to browser
DEBUG - 2018-10-08 12:02:17 --> Total execution time: 2.6652
INFO - 2018-10-08 12:02:53 --> Config Class Initialized
INFO - 2018-10-08 12:02:53 --> Hooks Class Initialized
INFO - 2018-10-08 12:02:54 --> Config Class Initialized
INFO - 2018-10-08 12:02:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:02:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:02:54 --> Config Class Initialized
INFO - 2018-10-08 12:02:54 --> Config Class Initialized
INFO - 2018-10-08 12:02:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 12:02:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:02:54 --> Utf8 Class Initialized
INFO - 2018-10-08 12:02:54 --> URI Class Initialized
INFO - 2018-10-08 12:02:55 --> Utf8 Class Initialized
DEBUG - 2018-10-08 12:02:55 --> No URI present. Default controller set.
INFO - 2018-10-08 12:02:55 --> Router Class Initialized
INFO - 2018-10-08 12:02:55 --> Output Class Initialized
INFO - 2018-10-08 12:02:55 --> Security Class Initialized
DEBUG - 2018-10-08 12:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:02:55 --> Input Class Initialized
INFO - 2018-10-08 12:02:55 --> Language Class Initialized
INFO - 2018-10-08 12:02:55 --> Language Class Initialized
INFO - 2018-10-08 12:02:56 --> Config Class Initialized
INFO - 2018-10-08 12:02:56 --> Loader Class Initialized
INFO - 2018-10-08 12:02:56 --> Helper loaded: url_helper
INFO - 2018-10-08 12:02:56 --> Helper loaded: form_helper
INFO - 2018-10-08 12:02:56 --> URI Class Initialized
INFO - 2018-10-08 12:02:56 --> Database Driver Class Initialized
DEBUG - 2018-10-08 12:02:56 --> No URI present. Default controller set.
INFO - 2018-10-08 12:02:56 --> Email Class Initialized
INFO - 2018-10-08 12:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:02:57 --> Form Validation Class Initialized
INFO - 2018-10-08 12:02:57 --> Controller Class Initialized
DEBUG - 2018-10-08 12:02:57 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 12:02:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:02:57 --> Final output sent to browser
DEBUG - 2018-10-08 12:02:57 --> Total execution time: 3.5152
INFO - 2018-10-08 12:02:58 --> Router Class Initialized
INFO - 2018-10-08 12:02:58 --> Utf8 Class Initialized
INFO - 2018-10-08 12:02:58 --> Output Class Initialized
INFO - 2018-10-08 12:02:59 --> URI Class Initialized
INFO - 2018-10-08 12:02:59 --> Security Class Initialized
INFO - 2018-10-08 12:02:59 --> Router Class Initialized
INFO - 2018-10-08 12:02:59 --> Output Class Initialized
INFO - 2018-10-08 12:02:59 --> Security Class Initialized
DEBUG - 2018-10-08 12:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:03:00 --> Hooks Class Initialized
INFO - 2018-10-08 12:03:00 --> Input Class Initialized
DEBUG - 2018-10-08 12:03:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:03:00 --> Utf8 Class Initialized
INFO - 2018-10-08 12:03:00 --> URI Class Initialized
INFO - 2018-10-08 12:03:00 --> Language Class Initialized
INFO - 2018-10-08 12:03:00 --> Router Class Initialized
INFO - 2018-10-08 12:03:01 --> Output Class Initialized
INFO - 2018-10-08 12:03:01 --> Language Class Initialized
INFO - 2018-10-08 12:03:01 --> Security Class Initialized
DEBUG - 2018-10-08 12:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:03:01 --> Input Class Initialized
INFO - 2018-10-08 12:03:01 --> Language Class Initialized
INFO - 2018-10-08 12:03:01 --> Config Class Initialized
INFO - 2018-10-08 12:03:01 --> Language Class Initialized
INFO - 2018-10-08 12:03:02 --> Loader Class Initialized
INFO - 2018-10-08 12:03:02 --> Helper loaded: url_helper
DEBUG - 2018-10-08 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:03:02 --> Helper loaded: form_helper
INFO - 2018-10-08 12:03:02 --> Database Driver Class Initialized
INFO - 2018-10-08 12:03:02 --> Config Class Initialized
INFO - 2018-10-08 12:03:02 --> Email Class Initialized
INFO - 2018-10-08 12:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:03:03 --> Input Class Initialized
INFO - 2018-10-08 12:03:03 --> Language Class Initialized
INFO - 2018-10-08 12:03:03 --> Loader Class Initialized
INFO - 2018-10-08 12:03:03 --> Helper loaded: url_helper
INFO - 2018-10-08 12:03:04 --> Helper loaded: form_helper
INFO - 2018-10-08 12:03:04 --> Database Driver Class Initialized
INFO - 2018-10-08 12:03:04 --> Email Class Initialized
INFO - 2018-10-08 12:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:03:04 --> Form Validation Class Initialized
INFO - 2018-10-08 12:03:05 --> Language Class Initialized
INFO - 2018-10-08 12:03:05 --> Config Class Initialized
INFO - 2018-10-08 12:03:05 --> Loader Class Initialized
INFO - 2018-10-08 12:03:05 --> Helper loaded: url_helper
INFO - 2018-10-08 12:03:05 --> Helper loaded: form_helper
INFO - 2018-10-08 12:03:06 --> Database Driver Class Initialized
INFO - 2018-10-08 12:03:06 --> Email Class Initialized
INFO - 2018-10-08 12:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:03:06 --> Form Validation Class Initialized
INFO - 2018-10-08 12:03:06 --> Controller Class Initialized
INFO - 2018-10-08 12:03:06 --> Form Validation Class Initialized
INFO - 2018-10-08 12:03:06 --> Controller Class Initialized
DEBUG - 2018-10-08 12:03:07 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:03:07 --> Model Class Initialized
DEBUG - 2018-10-08 12:03:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
DEBUG - 2018-10-08 12:03:07 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 12:03:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:03:07 --> Final output sent to browser
DEBUG - 2018-10-08 12:03:07 --> Total execution time: 13.6894
INFO - 2018-10-08 12:03:07 --> Controller Class Initialized
INFO - 2018-10-08 12:03:07 --> Model Class Initialized
DEBUG - 2018-10-08 12:03:08 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:03:08 --> Model Class Initialized
INFO - 2018-10-08 12:03:08 --> Final output sent to browser
DEBUG - 2018-10-08 12:03:08 --> Total execution time: 15.2919
DEBUG - 2018-10-08 12:03:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 12:03:08 --> Model Class Initialized
INFO - 2018-10-08 12:03:09 --> Final output sent to browser
DEBUG - 2018-10-08 12:03:09 --> Total execution time: 15.0973
INFO - 2018-10-08 12:04:17 --> Config Class Initialized
INFO - 2018-10-08 12:04:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:04:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:04:17 --> Utf8 Class Initialized
INFO - 2018-10-08 12:04:17 --> URI Class Initialized
DEBUG - 2018-10-08 12:04:18 --> No URI present. Default controller set.
INFO - 2018-10-08 12:04:18 --> Router Class Initialized
INFO - 2018-10-08 12:04:19 --> Output Class Initialized
INFO - 2018-10-08 12:04:19 --> Security Class Initialized
DEBUG - 2018-10-08 12:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:04:19 --> Input Class Initialized
INFO - 2018-10-08 12:04:19 --> Language Class Initialized
INFO - 2018-10-08 12:04:20 --> Language Class Initialized
INFO - 2018-10-08 12:04:20 --> Config Class Initialized
INFO - 2018-10-08 12:04:20 --> Loader Class Initialized
INFO - 2018-10-08 12:04:20 --> Helper loaded: url_helper
INFO - 2018-10-08 12:04:20 --> Helper loaded: form_helper
INFO - 2018-10-08 12:04:21 --> Database Driver Class Initialized
INFO - 2018-10-08 12:04:21 --> Email Class Initialized
INFO - 2018-10-08 12:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:04:22 --> Form Validation Class Initialized
INFO - 2018-10-08 12:04:22 --> Controller Class Initialized
DEBUG - 2018-10-08 12:04:22 --> Person MX_Controller Initialized
ERROR - 2018-10-08 12:04:22 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 27
ERROR - 2018-10-08 12:04:22 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:08:41 --> Config Class Initialized
INFO - 2018-10-08 12:08:41 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:08:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:08:42 --> Utf8 Class Initialized
INFO - 2018-10-08 12:08:43 --> URI Class Initialized
DEBUG - 2018-10-08 12:08:43 --> No URI present. Default controller set.
INFO - 2018-10-08 12:08:43 --> Router Class Initialized
INFO - 2018-10-08 12:08:43 --> Output Class Initialized
INFO - 2018-10-08 12:08:43 --> Security Class Initialized
DEBUG - 2018-10-08 12:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:08:44 --> Input Class Initialized
INFO - 2018-10-08 12:08:44 --> Language Class Initialized
INFO - 2018-10-08 12:08:44 --> Language Class Initialized
INFO - 2018-10-08 12:08:44 --> Config Class Initialized
INFO - 2018-10-08 12:08:44 --> Loader Class Initialized
INFO - 2018-10-08 12:08:44 --> Helper loaded: url_helper
INFO - 2018-10-08 12:08:45 --> Helper loaded: form_helper
INFO - 2018-10-08 12:08:45 --> Database Driver Class Initialized
INFO - 2018-10-08 12:08:45 --> Email Class Initialized
INFO - 2018-10-08 12:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:08:45 --> Form Validation Class Initialized
INFO - 2018-10-08 12:08:45 --> Controller Class Initialized
DEBUG - 2018-10-08 12:08:45 --> Person MX_Controller Initialized
ERROR - 2018-10-08 12:08:46 --> Severity: error --> Exception: Too few arguments to function Person::get(), 0 passed in C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php on line 10 and exactly 1 expected C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 27
ERROR - 2018-10-08 12:08:46 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ArgumentCountError given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ArgumentCountError))
#1 [internal function]: _exception_handler(Object(ArgumentCountError))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:08:59 --> Config Class Initialized
INFO - 2018-10-08 12:08:59 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:08:59 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:08:59 --> Utf8 Class Initialized
INFO - 2018-10-08 12:09:00 --> URI Class Initialized
DEBUG - 2018-10-08 12:09:00 --> No URI present. Default controller set.
INFO - 2018-10-08 12:09:00 --> Router Class Initialized
INFO - 2018-10-08 12:09:00 --> Output Class Initialized
INFO - 2018-10-08 12:09:00 --> Security Class Initialized
DEBUG - 2018-10-08 12:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:09:00 --> Input Class Initialized
INFO - 2018-10-08 12:09:00 --> Language Class Initialized
INFO - 2018-10-08 12:09:01 --> Language Class Initialized
INFO - 2018-10-08 12:09:01 --> Config Class Initialized
INFO - 2018-10-08 12:09:01 --> Loader Class Initialized
INFO - 2018-10-08 12:09:01 --> Helper loaded: url_helper
INFO - 2018-10-08 12:09:01 --> Helper loaded: form_helper
INFO - 2018-10-08 12:09:01 --> Database Driver Class Initialized
INFO - 2018-10-08 12:09:01 --> Email Class Initialized
INFO - 2018-10-08 12:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:09:02 --> Form Validation Class Initialized
INFO - 2018-10-08 12:09:02 --> Controller Class Initialized
DEBUG - 2018-10-08 12:09:02 --> Person MX_Controller Initialized
ERROR - 2018-10-08 12:09:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 99
ERROR - 2018-10-08 12:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 99
DEBUG - 2018-10-08 12:09:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:09:02 --> Final output sent to browser
DEBUG - 2018-10-08 12:09:02 --> Total execution time: 3.1966
INFO - 2018-10-08 12:11:01 --> Config Class Initialized
INFO - 2018-10-08 12:11:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:11:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:11:02 --> Utf8 Class Initialized
INFO - 2018-10-08 12:11:02 --> URI Class Initialized
DEBUG - 2018-10-08 12:11:02 --> No URI present. Default controller set.
INFO - 2018-10-08 12:11:02 --> Router Class Initialized
INFO - 2018-10-08 12:11:02 --> Output Class Initialized
INFO - 2018-10-08 12:11:02 --> Security Class Initialized
DEBUG - 2018-10-08 12:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:11:03 --> Input Class Initialized
INFO - 2018-10-08 12:11:03 --> Language Class Initialized
INFO - 2018-10-08 12:11:03 --> Language Class Initialized
INFO - 2018-10-08 12:11:03 --> Config Class Initialized
INFO - 2018-10-08 12:11:03 --> Loader Class Initialized
INFO - 2018-10-08 12:11:03 --> Helper loaded: url_helper
INFO - 2018-10-08 12:11:03 --> Helper loaded: form_helper
INFO - 2018-10-08 12:11:03 --> Database Driver Class Initialized
INFO - 2018-10-08 12:11:03 --> Email Class Initialized
INFO - 2018-10-08 12:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:11:04 --> Form Validation Class Initialized
INFO - 2018-10-08 12:11:04 --> Controller Class Initialized
DEBUG - 2018-10-08 12:11:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:11:04 --> Model Class Initialized
DEBUG - 2018-10-08 12:11:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:11:04 --> Model Class Initialized
ERROR - 2018-10-08 12:11:06 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 99
ERROR - 2018-10-08 12:11:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 99
DEBUG - 2018-10-08 12:11:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:11:07 --> Final output sent to browser
DEBUG - 2018-10-08 12:11:07 --> Total execution time: 5.5533
INFO - 2018-10-08 12:13:10 --> Config Class Initialized
INFO - 2018-10-08 12:13:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:13:11 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:13:11 --> Utf8 Class Initialized
INFO - 2018-10-08 12:13:11 --> URI Class Initialized
DEBUG - 2018-10-08 12:13:11 --> No URI present. Default controller set.
INFO - 2018-10-08 12:13:11 --> Router Class Initialized
INFO - 2018-10-08 12:13:11 --> Output Class Initialized
INFO - 2018-10-08 12:13:11 --> Security Class Initialized
DEBUG - 2018-10-08 12:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:13:12 --> Input Class Initialized
INFO - 2018-10-08 12:13:12 --> Language Class Initialized
INFO - 2018-10-08 12:13:12 --> Language Class Initialized
INFO - 2018-10-08 12:13:12 --> Config Class Initialized
INFO - 2018-10-08 12:13:12 --> Loader Class Initialized
INFO - 2018-10-08 12:13:12 --> Helper loaded: url_helper
INFO - 2018-10-08 12:13:12 --> Helper loaded: form_helper
INFO - 2018-10-08 12:13:12 --> Database Driver Class Initialized
INFO - 2018-10-08 12:13:13 --> Email Class Initialized
INFO - 2018-10-08 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:13:13 --> Form Validation Class Initialized
INFO - 2018-10-08 12:13:13 --> Controller Class Initialized
DEBUG - 2018-10-08 12:13:13 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:13:13 --> Model Class Initialized
DEBUG - 2018-10-08 12:13:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:13:13 --> Model Class Initialized
ERROR - 2018-10-08 12:13:13 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:13:14 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:13:53 --> Config Class Initialized
INFO - 2018-10-08 12:13:53 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:13:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:13:54 --> Utf8 Class Initialized
INFO - 2018-10-08 12:13:54 --> URI Class Initialized
DEBUG - 2018-10-08 12:13:54 --> No URI present. Default controller set.
INFO - 2018-10-08 12:13:54 --> Router Class Initialized
INFO - 2018-10-08 12:13:54 --> Output Class Initialized
INFO - 2018-10-08 12:13:54 --> Security Class Initialized
DEBUG - 2018-10-08 12:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:13:55 --> Input Class Initialized
INFO - 2018-10-08 12:13:55 --> Language Class Initialized
INFO - 2018-10-08 12:13:55 --> Language Class Initialized
INFO - 2018-10-08 12:13:55 --> Config Class Initialized
INFO - 2018-10-08 12:13:55 --> Loader Class Initialized
INFO - 2018-10-08 12:13:55 --> Helper loaded: url_helper
INFO - 2018-10-08 12:13:55 --> Helper loaded: form_helper
INFO - 2018-10-08 12:13:56 --> Database Driver Class Initialized
INFO - 2018-10-08 12:13:56 --> Email Class Initialized
INFO - 2018-10-08 12:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:13:56 --> Form Validation Class Initialized
INFO - 2018-10-08 12:13:56 --> Controller Class Initialized
DEBUG - 2018-10-08 12:13:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:13:56 --> Model Class Initialized
DEBUG - 2018-10-08 12:13:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:13:57 --> Model Class Initialized
DEBUG - 2018-10-08 12:13:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:13:57 --> Final output sent to browser
DEBUG - 2018-10-08 12:13:57 --> Total execution time: 3.4432
INFO - 2018-10-08 12:14:50 --> Config Class Initialized
INFO - 2018-10-08 12:14:50 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:14:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:14:50 --> Utf8 Class Initialized
INFO - 2018-10-08 12:14:50 --> URI Class Initialized
DEBUG - 2018-10-08 12:14:50 --> No URI present. Default controller set.
INFO - 2018-10-08 12:14:50 --> Router Class Initialized
INFO - 2018-10-08 12:14:51 --> Output Class Initialized
INFO - 2018-10-08 12:14:51 --> Security Class Initialized
DEBUG - 2018-10-08 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:14:51 --> Input Class Initialized
INFO - 2018-10-08 12:14:51 --> Language Class Initialized
INFO - 2018-10-08 12:14:51 --> Language Class Initialized
INFO - 2018-10-08 12:14:51 --> Config Class Initialized
INFO - 2018-10-08 12:14:52 --> Loader Class Initialized
INFO - 2018-10-08 12:14:52 --> Helper loaded: url_helper
INFO - 2018-10-08 12:14:52 --> Helper loaded: form_helper
INFO - 2018-10-08 12:14:52 --> Database Driver Class Initialized
INFO - 2018-10-08 12:14:52 --> Email Class Initialized
INFO - 2018-10-08 12:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:14:52 --> Form Validation Class Initialized
INFO - 2018-10-08 12:14:52 --> Controller Class Initialized
DEBUG - 2018-10-08 12:14:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:14:53 --> Model Class Initialized
DEBUG - 2018-10-08 12:14:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:14:53 --> Model Class Initialized
ERROR - 2018-10-08 12:14:53 --> Severity: 4096 --> Object of class mysqli could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:14:53 --> Severity: 4096 --> Object of class mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:14:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:14:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:14:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
DEBUG - 2018-10-08 12:14:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:14:54 --> Final output sent to browser
DEBUG - 2018-10-08 12:14:54 --> Total execution time: 4.1632
INFO - 2018-10-08 12:15:18 --> Config Class Initialized
INFO - 2018-10-08 12:15:18 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:15:18 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:15:18 --> Utf8 Class Initialized
INFO - 2018-10-08 12:15:18 --> URI Class Initialized
DEBUG - 2018-10-08 12:15:18 --> No URI present. Default controller set.
INFO - 2018-10-08 12:15:18 --> Router Class Initialized
INFO - 2018-10-08 12:15:19 --> Output Class Initialized
INFO - 2018-10-08 12:15:19 --> Security Class Initialized
DEBUG - 2018-10-08 12:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:15:19 --> Input Class Initialized
INFO - 2018-10-08 12:15:19 --> Language Class Initialized
INFO - 2018-10-08 12:15:19 --> Language Class Initialized
INFO - 2018-10-08 12:15:19 --> Config Class Initialized
INFO - 2018-10-08 12:15:19 --> Loader Class Initialized
INFO - 2018-10-08 12:15:19 --> Helper loaded: url_helper
INFO - 2018-10-08 12:15:20 --> Helper loaded: form_helper
INFO - 2018-10-08 12:15:20 --> Database Driver Class Initialized
INFO - 2018-10-08 12:15:20 --> Email Class Initialized
INFO - 2018-10-08 12:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:15:20 --> Form Validation Class Initialized
INFO - 2018-10-08 12:15:20 --> Controller Class Initialized
DEBUG - 2018-10-08 12:15:20 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:15:20 --> Model Class Initialized
DEBUG - 2018-10-08 12:15:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:15:21 --> Model Class Initialized
ERROR - 2018-10-08 12:15:21 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:21 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:15:46 --> Config Class Initialized
INFO - 2018-10-08 12:15:46 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:15:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:15:46 --> Utf8 Class Initialized
INFO - 2018-10-08 12:15:46 --> URI Class Initialized
DEBUG - 2018-10-08 12:15:46 --> No URI present. Default controller set.
INFO - 2018-10-08 12:15:46 --> Router Class Initialized
INFO - 2018-10-08 12:15:47 --> Output Class Initialized
INFO - 2018-10-08 12:15:47 --> Security Class Initialized
DEBUG - 2018-10-08 12:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:15:47 --> Input Class Initialized
INFO - 2018-10-08 12:15:47 --> Language Class Initialized
INFO - 2018-10-08 12:15:47 --> Language Class Initialized
INFO - 2018-10-08 12:15:47 --> Config Class Initialized
INFO - 2018-10-08 12:15:47 --> Loader Class Initialized
INFO - 2018-10-08 12:15:48 --> Helper loaded: url_helper
INFO - 2018-10-08 12:15:48 --> Helper loaded: form_helper
INFO - 2018-10-08 12:15:48 --> Database Driver Class Initialized
INFO - 2018-10-08 12:15:48 --> Email Class Initialized
INFO - 2018-10-08 12:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:15:48 --> Form Validation Class Initialized
INFO - 2018-10-08 12:15:48 --> Controller Class Initialized
DEBUG - 2018-10-08 12:15:48 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:15:49 --> Model Class Initialized
DEBUG - 2018-10-08 12:15:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:15:49 --> Model Class Initialized
ERROR - 2018-10-08 12:15:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
ERROR - 2018-10-08 12:15:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\User_Management\application\modules\Person\views\home.php 102
DEBUG - 2018-10-08 12:15:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:15:50 --> Final output sent to browser
DEBUG - 2018-10-08 12:15:50 --> Total execution time: 4.5533
INFO - 2018-10-08 12:16:18 --> Config Class Initialized
INFO - 2018-10-08 12:16:18 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:16:18 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:16:18 --> Utf8 Class Initialized
INFO - 2018-10-08 12:16:18 --> URI Class Initialized
DEBUG - 2018-10-08 12:16:19 --> No URI present. Default controller set.
INFO - 2018-10-08 12:16:19 --> Router Class Initialized
INFO - 2018-10-08 12:16:19 --> Output Class Initialized
INFO - 2018-10-08 12:16:19 --> Security Class Initialized
DEBUG - 2018-10-08 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:16:19 --> Input Class Initialized
INFO - 2018-10-08 12:16:19 --> Language Class Initialized
INFO - 2018-10-08 12:16:19 --> Language Class Initialized
INFO - 2018-10-08 12:16:20 --> Config Class Initialized
INFO - 2018-10-08 12:16:20 --> Loader Class Initialized
INFO - 2018-10-08 12:16:20 --> Helper loaded: url_helper
INFO - 2018-10-08 12:16:20 --> Helper loaded: form_helper
INFO - 2018-10-08 12:16:20 --> Database Driver Class Initialized
INFO - 2018-10-08 12:16:20 --> Email Class Initialized
INFO - 2018-10-08 12:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:16:20 --> Form Validation Class Initialized
INFO - 2018-10-08 12:16:21 --> Controller Class Initialized
DEBUG - 2018-10-08 12:16:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:16:21 --> Model Class Initialized
DEBUG - 2018-10-08 12:16:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:16:21 --> Model Class Initialized
INFO - 2018-10-08 12:17:17 --> Config Class Initialized
INFO - 2018-10-08 12:17:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:17:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:17:17 --> Utf8 Class Initialized
INFO - 2018-10-08 12:17:18 --> URI Class Initialized
DEBUG - 2018-10-08 12:17:18 --> No URI present. Default controller set.
INFO - 2018-10-08 12:17:18 --> Router Class Initialized
INFO - 2018-10-08 12:17:18 --> Output Class Initialized
INFO - 2018-10-08 12:17:18 --> Security Class Initialized
DEBUG - 2018-10-08 12:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:17:18 --> Input Class Initialized
INFO - 2018-10-08 12:17:18 --> Language Class Initialized
INFO - 2018-10-08 12:17:19 --> Language Class Initialized
INFO - 2018-10-08 12:17:19 --> Config Class Initialized
INFO - 2018-10-08 12:17:19 --> Loader Class Initialized
INFO - 2018-10-08 12:17:19 --> Helper loaded: url_helper
INFO - 2018-10-08 12:17:19 --> Helper loaded: form_helper
INFO - 2018-10-08 12:17:19 --> Database Driver Class Initialized
INFO - 2018-10-08 12:17:19 --> Email Class Initialized
INFO - 2018-10-08 12:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:17:20 --> Form Validation Class Initialized
INFO - 2018-10-08 12:17:20 --> Controller Class Initialized
DEBUG - 2018-10-08 12:17:20 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:17:20 --> Model Class Initialized
DEBUG - 2018-10-08 12:17:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:17:20 --> Model Class Initialized
INFO - 2018-10-08 12:19:04 --> Config Class Initialized
INFO - 2018-10-08 12:19:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:19:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:19:05 --> Utf8 Class Initialized
INFO - 2018-10-08 12:19:05 --> URI Class Initialized
DEBUG - 2018-10-08 12:19:05 --> No URI present. Default controller set.
INFO - 2018-10-08 12:19:05 --> Router Class Initialized
INFO - 2018-10-08 12:19:05 --> Output Class Initialized
INFO - 2018-10-08 12:19:05 --> Security Class Initialized
DEBUG - 2018-10-08 12:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:19:06 --> Input Class Initialized
INFO - 2018-10-08 12:19:06 --> Language Class Initialized
INFO - 2018-10-08 12:19:06 --> Language Class Initialized
INFO - 2018-10-08 12:19:06 --> Config Class Initialized
INFO - 2018-10-08 12:19:06 --> Loader Class Initialized
INFO - 2018-10-08 12:19:06 --> Helper loaded: url_helper
INFO - 2018-10-08 12:19:06 --> Helper loaded: form_helper
INFO - 2018-10-08 12:19:07 --> Database Driver Class Initialized
INFO - 2018-10-08 12:19:07 --> Email Class Initialized
INFO - 2018-10-08 12:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:19:07 --> Form Validation Class Initialized
INFO - 2018-10-08 12:19:07 --> Controller Class Initialized
DEBUG - 2018-10-08 12:19:07 --> Person MX_Controller Initialized
ERROR - 2018-10-08 12:19:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 13
DEBUG - 2018-10-08 12:19:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:19:08 --> Final output sent to browser
DEBUG - 2018-10-08 12:19:08 --> Total execution time: 3.4632
INFO - 2018-10-08 12:19:29 --> Config Class Initialized
INFO - 2018-10-08 12:19:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:19:29 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:19:29 --> Utf8 Class Initialized
INFO - 2018-10-08 12:19:30 --> URI Class Initialized
DEBUG - 2018-10-08 12:19:30 --> No URI present. Default controller set.
INFO - 2018-10-08 12:19:30 --> Router Class Initialized
INFO - 2018-10-08 12:19:30 --> Output Class Initialized
INFO - 2018-10-08 12:19:30 --> Security Class Initialized
DEBUG - 2018-10-08 12:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:19:30 --> Input Class Initialized
INFO - 2018-10-08 12:19:30 --> Language Class Initialized
INFO - 2018-10-08 12:19:31 --> Language Class Initialized
INFO - 2018-10-08 12:19:31 --> Config Class Initialized
INFO - 2018-10-08 12:19:31 --> Loader Class Initialized
INFO - 2018-10-08 12:19:31 --> Helper loaded: url_helper
INFO - 2018-10-08 12:19:31 --> Helper loaded: form_helper
INFO - 2018-10-08 12:19:31 --> Database Driver Class Initialized
INFO - 2018-10-08 12:19:31 --> Email Class Initialized
INFO - 2018-10-08 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:19:32 --> Form Validation Class Initialized
INFO - 2018-10-08 12:19:32 --> Controller Class Initialized
DEBUG - 2018-10-08 12:19:32 --> Person MX_Controller Initialized
DEBUG - 2018-10-08 12:19:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:19:32 --> Final output sent to browser
DEBUG - 2018-10-08 12:19:32 --> Total execution time: 3.3192
INFO - 2018-10-08 12:21:39 --> Config Class Initialized
INFO - 2018-10-08 12:21:39 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:21:40 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:21:40 --> Utf8 Class Initialized
INFO - 2018-10-08 12:21:41 --> URI Class Initialized
DEBUG - 2018-10-08 12:21:41 --> No URI present. Default controller set.
INFO - 2018-10-08 12:21:41 --> Router Class Initialized
INFO - 2018-10-08 12:21:42 --> Output Class Initialized
INFO - 2018-10-08 12:21:42 --> Security Class Initialized
DEBUG - 2018-10-08 12:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:21:42 --> Input Class Initialized
INFO - 2018-10-08 12:21:43 --> Language Class Initialized
INFO - 2018-10-08 12:21:43 --> Language Class Initialized
INFO - 2018-10-08 12:21:43 --> Config Class Initialized
INFO - 2018-10-08 12:21:43 --> Loader Class Initialized
INFO - 2018-10-08 12:21:43 --> Helper loaded: url_helper
INFO - 2018-10-08 12:21:43 --> Helper loaded: form_helper
INFO - 2018-10-08 12:21:44 --> Database Driver Class Initialized
INFO - 2018-10-08 12:21:44 --> Email Class Initialized
INFO - 2018-10-08 12:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:21:44 --> Form Validation Class Initialized
INFO - 2018-10-08 12:21:44 --> Controller Class Initialized
DEBUG - 2018-10-08 12:21:45 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:21:45 --> Model Class Initialized
DEBUG - 2018-10-08 12:21:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:21:45 --> Model Class Initialized
INFO - 2018-10-08 12:22:12 --> Config Class Initialized
INFO - 2018-10-08 12:22:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:22:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:22:12 --> Utf8 Class Initialized
INFO - 2018-10-08 12:22:13 --> URI Class Initialized
DEBUG - 2018-10-08 12:22:13 --> No URI present. Default controller set.
INFO - 2018-10-08 12:22:13 --> Router Class Initialized
INFO - 2018-10-08 12:22:13 --> Output Class Initialized
INFO - 2018-10-08 12:22:13 --> Security Class Initialized
DEBUG - 2018-10-08 12:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:22:14 --> Input Class Initialized
INFO - 2018-10-08 12:22:14 --> Language Class Initialized
INFO - 2018-10-08 12:22:14 --> Language Class Initialized
INFO - 2018-10-08 12:22:14 --> Config Class Initialized
INFO - 2018-10-08 12:22:14 --> Loader Class Initialized
INFO - 2018-10-08 12:22:14 --> Helper loaded: url_helper
INFO - 2018-10-08 12:22:15 --> Helper loaded: form_helper
INFO - 2018-10-08 12:22:15 --> Database Driver Class Initialized
INFO - 2018-10-08 12:22:15 --> Email Class Initialized
INFO - 2018-10-08 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:22:15 --> Form Validation Class Initialized
INFO - 2018-10-08 12:22:15 --> Controller Class Initialized
DEBUG - 2018-10-08 12:22:15 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:22:16 --> Model Class Initialized
DEBUG - 2018-10-08 12:22:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:22:16 --> Model Class Initialized
ERROR - 2018-10-08 12:22:16 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 12
ERROR - 2018-10-08 12:22:16 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:23:14 --> Config Class Initialized
INFO - 2018-10-08 12:23:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:23:15 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:23:15 --> Utf8 Class Initialized
INFO - 2018-10-08 12:23:15 --> URI Class Initialized
DEBUG - 2018-10-08 12:23:15 --> No URI present. Default controller set.
INFO - 2018-10-08 12:23:15 --> Router Class Initialized
INFO - 2018-10-08 12:23:16 --> Output Class Initialized
INFO - 2018-10-08 12:23:16 --> Security Class Initialized
DEBUG - 2018-10-08 12:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:23:16 --> Input Class Initialized
INFO - 2018-10-08 12:23:16 --> Language Class Initialized
INFO - 2018-10-08 12:23:16 --> Language Class Initialized
INFO - 2018-10-08 12:23:16 --> Config Class Initialized
INFO - 2018-10-08 12:23:17 --> Loader Class Initialized
INFO - 2018-10-08 12:23:17 --> Helper loaded: url_helper
INFO - 2018-10-08 12:23:17 --> Helper loaded: form_helper
INFO - 2018-10-08 12:23:17 --> Database Driver Class Initialized
INFO - 2018-10-08 12:23:17 --> Email Class Initialized
INFO - 2018-10-08 12:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:23:18 --> Form Validation Class Initialized
INFO - 2018-10-08 12:23:18 --> Controller Class Initialized
DEBUG - 2018-10-08 12:23:18 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:23:18 --> Model Class Initialized
DEBUG - 2018-10-08 12:23:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:23:18 --> Model Class Initialized
ERROR - 2018-10-08 12:23:18 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp\htdocs\User_Management\application\modules\Person\controllers\Person.php 12
ERROR - 2018-10-08 12:23:18 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of Error given, called in C:\xampp\htdocs\User_Management\system\core\Common.php on line 658 and defined in C:\xampp\htdocs\User_Management\system\core\Exceptions.php:190
Stack trace:
#0 C:\xampp\htdocs\User_Management\system\core\Common.php(658): CI_Exceptions->show_exception(Object(Error))
#1 [internal function]: _exception_handler(Object(Error))
#2 {main}
  thrown C:\xampp\htdocs\User_Management\system\core\Exceptions.php 190
INFO - 2018-10-08 12:24:27 --> Config Class Initialized
INFO - 2018-10-08 12:24:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:24:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:24:27 --> Utf8 Class Initialized
INFO - 2018-10-08 12:24:27 --> URI Class Initialized
DEBUG - 2018-10-08 12:24:27 --> No URI present. Default controller set.
INFO - 2018-10-08 12:24:28 --> Router Class Initialized
INFO - 2018-10-08 12:24:28 --> Output Class Initialized
INFO - 2018-10-08 12:24:28 --> Security Class Initialized
DEBUG - 2018-10-08 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:24:28 --> Input Class Initialized
INFO - 2018-10-08 12:24:28 --> Language Class Initialized
INFO - 2018-10-08 12:24:28 --> Language Class Initialized
INFO - 2018-10-08 12:24:29 --> Config Class Initialized
INFO - 2018-10-08 12:24:29 --> Loader Class Initialized
INFO - 2018-10-08 12:24:29 --> Helper loaded: url_helper
INFO - 2018-10-08 12:24:29 --> Helper loaded: form_helper
INFO - 2018-10-08 12:24:29 --> Database Driver Class Initialized
INFO - 2018-10-08 12:24:29 --> Email Class Initialized
INFO - 2018-10-08 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:24:30 --> Form Validation Class Initialized
INFO - 2018-10-08 12:24:30 --> Controller Class Initialized
DEBUG - 2018-10-08 12:24:30 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:24:30 --> Model Class Initialized
DEBUG - 2018-10-08 12:24:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:24:30 --> Model Class Initialized
DEBUG - 2018-10-08 12:24:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:24:31 --> Final output sent to browser
DEBUG - 2018-10-08 12:24:31 --> Total execution time: 4.3362
INFO - 2018-10-08 12:29:16 --> Config Class Initialized
INFO - 2018-10-08 12:29:16 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:29:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:29:17 --> Utf8 Class Initialized
INFO - 2018-10-08 12:29:18 --> URI Class Initialized
DEBUG - 2018-10-08 12:29:18 --> No URI present. Default controller set.
INFO - 2018-10-08 12:29:18 --> Router Class Initialized
INFO - 2018-10-08 12:29:18 --> Output Class Initialized
INFO - 2018-10-08 12:29:18 --> Security Class Initialized
DEBUG - 2018-10-08 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:29:18 --> Input Class Initialized
INFO - 2018-10-08 12:29:19 --> Language Class Initialized
INFO - 2018-10-08 12:29:19 --> Language Class Initialized
INFO - 2018-10-08 12:29:19 --> Config Class Initialized
INFO - 2018-10-08 12:29:19 --> Loader Class Initialized
INFO - 2018-10-08 12:29:19 --> Helper loaded: url_helper
INFO - 2018-10-08 12:29:19 --> Helper loaded: form_helper
INFO - 2018-10-08 12:29:20 --> Database Driver Class Initialized
INFO - 2018-10-08 12:29:20 --> Email Class Initialized
INFO - 2018-10-08 12:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:29:20 --> Form Validation Class Initialized
INFO - 2018-10-08 12:29:20 --> Controller Class Initialized
DEBUG - 2018-10-08 12:29:20 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:29:20 --> Model Class Initialized
DEBUG - 2018-10-08 12:29:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:29:21 --> Model Class Initialized
DEBUG - 2018-10-08 12:29:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:29:21 --> Final output sent to browser
DEBUG - 2018-10-08 12:29:21 --> Total execution time: 4.4213
INFO - 2018-10-08 12:32:55 --> Config Class Initialized
INFO - 2018-10-08 12:32:55 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:32:56 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:32:56 --> Utf8 Class Initialized
INFO - 2018-10-08 12:32:56 --> URI Class Initialized
DEBUG - 2018-10-08 12:32:56 --> No URI present. Default controller set.
INFO - 2018-10-08 12:32:56 --> Router Class Initialized
INFO - 2018-10-08 12:32:57 --> Output Class Initialized
INFO - 2018-10-08 12:32:57 --> Security Class Initialized
DEBUG - 2018-10-08 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:32:58 --> Input Class Initialized
INFO - 2018-10-08 12:32:58 --> Language Class Initialized
INFO - 2018-10-08 12:32:58 --> Language Class Initialized
INFO - 2018-10-08 12:32:58 --> Config Class Initialized
INFO - 2018-10-08 12:32:59 --> Loader Class Initialized
INFO - 2018-10-08 12:32:59 --> Helper loaded: url_helper
INFO - 2018-10-08 12:32:59 --> Helper loaded: form_helper
INFO - 2018-10-08 12:33:00 --> Database Driver Class Initialized
INFO - 2018-10-08 12:33:00 --> Email Class Initialized
INFO - 2018-10-08 12:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:33:00 --> Form Validation Class Initialized
INFO - 2018-10-08 12:33:01 --> Controller Class Initialized
DEBUG - 2018-10-08 12:33:01 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:33:01 --> Model Class Initialized
DEBUG - 2018-10-08 12:33:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:33:01 --> Model Class Initialized
DEBUG - 2018-10-08 12:33:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:33:02 --> Final output sent to browser
DEBUG - 2018-10-08 12:33:02 --> Total execution time: 7.1734
INFO - 2018-10-08 12:33:43 --> Config Class Initialized
INFO - 2018-10-08 12:33:43 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:33:43 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:33:43 --> Utf8 Class Initialized
INFO - 2018-10-08 12:33:44 --> URI Class Initialized
DEBUG - 2018-10-08 12:33:44 --> No URI present. Default controller set.
INFO - 2018-10-08 12:33:44 --> Router Class Initialized
INFO - 2018-10-08 12:33:44 --> Output Class Initialized
INFO - 2018-10-08 12:33:44 --> Security Class Initialized
DEBUG - 2018-10-08 12:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:33:45 --> Input Class Initialized
INFO - 2018-10-08 12:33:45 --> Language Class Initialized
INFO - 2018-10-08 12:33:45 --> Language Class Initialized
INFO - 2018-10-08 12:33:45 --> Config Class Initialized
INFO - 2018-10-08 12:33:45 --> Loader Class Initialized
INFO - 2018-10-08 12:33:45 --> Helper loaded: url_helper
INFO - 2018-10-08 12:33:46 --> Helper loaded: form_helper
INFO - 2018-10-08 12:33:46 --> Database Driver Class Initialized
INFO - 2018-10-08 12:33:46 --> Email Class Initialized
INFO - 2018-10-08 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:33:46 --> Form Validation Class Initialized
INFO - 2018-10-08 12:33:46 --> Controller Class Initialized
DEBUG - 2018-10-08 12:33:47 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:33:47 --> Model Class Initialized
DEBUG - 2018-10-08 12:33:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:33:47 --> Model Class Initialized
DEBUG - 2018-10-08 12:33:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:33:47 --> Final output sent to browser
DEBUG - 2018-10-08 12:33:47 --> Total execution time: 4.4393
INFO - 2018-10-08 12:34:55 --> Config Class Initialized
INFO - 2018-10-08 12:34:55 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:34:55 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:34:55 --> Utf8 Class Initialized
INFO - 2018-10-08 12:34:55 --> URI Class Initialized
DEBUG - 2018-10-08 12:34:55 --> No URI present. Default controller set.
INFO - 2018-10-08 12:34:56 --> Router Class Initialized
INFO - 2018-10-08 12:34:56 --> Output Class Initialized
INFO - 2018-10-08 12:34:56 --> Security Class Initialized
DEBUG - 2018-10-08 12:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:34:56 --> Input Class Initialized
INFO - 2018-10-08 12:34:56 --> Language Class Initialized
INFO - 2018-10-08 12:34:56 --> Language Class Initialized
INFO - 2018-10-08 12:34:57 --> Config Class Initialized
INFO - 2018-10-08 12:34:57 --> Loader Class Initialized
INFO - 2018-10-08 12:34:57 --> Helper loaded: url_helper
INFO - 2018-10-08 12:34:57 --> Helper loaded: form_helper
INFO - 2018-10-08 12:34:57 --> Database Driver Class Initialized
INFO - 2018-10-08 12:34:57 --> Email Class Initialized
INFO - 2018-10-08 12:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:34:58 --> Form Validation Class Initialized
INFO - 2018-10-08 12:34:58 --> Controller Class Initialized
DEBUG - 2018-10-08 12:34:58 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:34:58 --> Model Class Initialized
DEBUG - 2018-10-08 12:34:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:34:58 --> Model Class Initialized
DEBUG - 2018-10-08 12:34:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:34:59 --> Final output sent to browser
DEBUG - 2018-10-08 12:34:59 --> Total execution time: 4.0002
INFO - 2018-10-08 12:36:12 --> Config Class Initialized
INFO - 2018-10-08 12:36:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:36:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:36:12 --> Utf8 Class Initialized
INFO - 2018-10-08 12:36:12 --> URI Class Initialized
DEBUG - 2018-10-08 12:36:13 --> No URI present. Default controller set.
INFO - 2018-10-08 12:36:13 --> Router Class Initialized
INFO - 2018-10-08 12:36:13 --> Output Class Initialized
INFO - 2018-10-08 12:36:13 --> Security Class Initialized
DEBUG - 2018-10-08 12:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:36:13 --> Input Class Initialized
INFO - 2018-10-08 12:36:13 --> Language Class Initialized
INFO - 2018-10-08 12:36:14 --> Language Class Initialized
INFO - 2018-10-08 12:36:14 --> Config Class Initialized
INFO - 2018-10-08 12:36:14 --> Loader Class Initialized
INFO - 2018-10-08 12:36:14 --> Helper loaded: url_helper
INFO - 2018-10-08 12:36:14 --> Helper loaded: form_helper
INFO - 2018-10-08 12:36:14 --> Database Driver Class Initialized
INFO - 2018-10-08 12:36:14 --> Email Class Initialized
INFO - 2018-10-08 12:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:36:15 --> Form Validation Class Initialized
INFO - 2018-10-08 12:36:15 --> Controller Class Initialized
DEBUG - 2018-10-08 12:36:15 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:36:15 --> Model Class Initialized
DEBUG - 2018-10-08 12:36:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:36:15 --> Model Class Initialized
DEBUG - 2018-10-08 12:36:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:36:16 --> Final output sent to browser
DEBUG - 2018-10-08 12:36:16 --> Total execution time: 3.8512
INFO - 2018-10-08 12:37:01 --> Config Class Initialized
INFO - 2018-10-08 12:37:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:37:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:37:01 --> Utf8 Class Initialized
INFO - 2018-10-08 12:37:01 --> URI Class Initialized
DEBUG - 2018-10-08 12:37:02 --> No URI present. Default controller set.
INFO - 2018-10-08 12:37:02 --> Router Class Initialized
INFO - 2018-10-08 12:37:02 --> Output Class Initialized
INFO - 2018-10-08 12:37:02 --> Security Class Initialized
DEBUG - 2018-10-08 12:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:37:02 --> Input Class Initialized
INFO - 2018-10-08 12:37:03 --> Language Class Initialized
INFO - 2018-10-08 12:37:03 --> Language Class Initialized
INFO - 2018-10-08 12:37:03 --> Config Class Initialized
INFO - 2018-10-08 12:37:03 --> Loader Class Initialized
INFO - 2018-10-08 12:37:03 --> Helper loaded: url_helper
INFO - 2018-10-08 12:37:03 --> Helper loaded: form_helper
INFO - 2018-10-08 12:37:04 --> Database Driver Class Initialized
INFO - 2018-10-08 12:37:04 --> Email Class Initialized
INFO - 2018-10-08 12:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:37:04 --> Form Validation Class Initialized
INFO - 2018-10-08 12:37:04 --> Controller Class Initialized
DEBUG - 2018-10-08 12:37:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:37:04 --> Model Class Initialized
DEBUG - 2018-10-08 12:37:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:37:05 --> Model Class Initialized
DEBUG - 2018-10-08 12:37:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:37:05 --> Final output sent to browser
DEBUG - 2018-10-08 12:37:05 --> Total execution time: 4.4993
INFO - 2018-10-08 12:37:38 --> Config Class Initialized
INFO - 2018-10-08 12:37:38 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:37:38 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:37:38 --> Utf8 Class Initialized
INFO - 2018-10-08 12:37:38 --> URI Class Initialized
DEBUG - 2018-10-08 12:37:39 --> No URI present. Default controller set.
INFO - 2018-10-08 12:37:39 --> Router Class Initialized
INFO - 2018-10-08 12:37:39 --> Output Class Initialized
INFO - 2018-10-08 12:37:39 --> Security Class Initialized
DEBUG - 2018-10-08 12:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:37:39 --> Input Class Initialized
INFO - 2018-10-08 12:37:40 --> Language Class Initialized
INFO - 2018-10-08 12:37:40 --> Language Class Initialized
INFO - 2018-10-08 12:37:41 --> Config Class Initialized
INFO - 2018-10-08 12:37:41 --> Loader Class Initialized
INFO - 2018-10-08 12:37:41 --> Helper loaded: url_helper
INFO - 2018-10-08 12:37:41 --> Helper loaded: form_helper
INFO - 2018-10-08 12:37:41 --> Database Driver Class Initialized
INFO - 2018-10-08 12:37:41 --> Email Class Initialized
INFO - 2018-10-08 12:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:37:42 --> Form Validation Class Initialized
INFO - 2018-10-08 12:37:42 --> Controller Class Initialized
DEBUG - 2018-10-08 12:37:42 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:37:42 --> Model Class Initialized
DEBUG - 2018-10-08 12:37:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:37:43 --> Model Class Initialized
DEBUG - 2018-10-08 12:37:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:37:43 --> Final output sent to browser
DEBUG - 2018-10-08 12:37:43 --> Total execution time: 5.1373
INFO - 2018-10-08 12:39:35 --> Config Class Initialized
INFO - 2018-10-08 12:39:35 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:39:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:39:35 --> Utf8 Class Initialized
INFO - 2018-10-08 12:39:35 --> URI Class Initialized
DEBUG - 2018-10-08 12:39:36 --> No URI present. Default controller set.
INFO - 2018-10-08 12:39:36 --> Router Class Initialized
INFO - 2018-10-08 12:39:36 --> Output Class Initialized
INFO - 2018-10-08 12:39:36 --> Security Class Initialized
DEBUG - 2018-10-08 12:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:39:36 --> Input Class Initialized
INFO - 2018-10-08 12:39:36 --> Language Class Initialized
INFO - 2018-10-08 12:39:37 --> Language Class Initialized
INFO - 2018-10-08 12:39:37 --> Config Class Initialized
INFO - 2018-10-08 12:39:37 --> Loader Class Initialized
INFO - 2018-10-08 12:39:37 --> Helper loaded: url_helper
INFO - 2018-10-08 12:39:37 --> Helper loaded: form_helper
INFO - 2018-10-08 12:39:37 --> Database Driver Class Initialized
INFO - 2018-10-08 12:39:37 --> Email Class Initialized
INFO - 2018-10-08 12:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:39:38 --> Form Validation Class Initialized
INFO - 2018-10-08 12:39:38 --> Controller Class Initialized
DEBUG - 2018-10-08 12:39:38 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:39:38 --> Model Class Initialized
DEBUG - 2018-10-08 12:39:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:39:38 --> Model Class Initialized
DEBUG - 2018-10-08 12:39:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:39:39 --> Final output sent to browser
DEBUG - 2018-10-08 12:39:39 --> Total execution time: 3.9812
INFO - 2018-10-08 12:41:07 --> Config Class Initialized
INFO - 2018-10-08 12:41:07 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:41:07 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:41:08 --> Utf8 Class Initialized
INFO - 2018-10-08 12:41:08 --> URI Class Initialized
DEBUG - 2018-10-08 12:41:08 --> No URI present. Default controller set.
INFO - 2018-10-08 12:41:08 --> Router Class Initialized
INFO - 2018-10-08 12:41:08 --> Output Class Initialized
INFO - 2018-10-08 12:41:09 --> Security Class Initialized
DEBUG - 2018-10-08 12:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:41:09 --> Input Class Initialized
INFO - 2018-10-08 12:41:09 --> Language Class Initialized
INFO - 2018-10-08 12:41:10 --> Language Class Initialized
INFO - 2018-10-08 12:41:10 --> Config Class Initialized
INFO - 2018-10-08 12:41:11 --> Loader Class Initialized
INFO - 2018-10-08 12:41:11 --> Helper loaded: url_helper
INFO - 2018-10-08 12:41:11 --> Helper loaded: form_helper
INFO - 2018-10-08 12:41:11 --> Database Driver Class Initialized
INFO - 2018-10-08 12:41:11 --> Email Class Initialized
INFO - 2018-10-08 12:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:41:12 --> Form Validation Class Initialized
INFO - 2018-10-08 12:41:12 --> Controller Class Initialized
DEBUG - 2018-10-08 12:41:12 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:41:12 --> Model Class Initialized
DEBUG - 2018-10-08 12:41:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:41:13 --> Model Class Initialized
DEBUG - 2018-10-08 12:41:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:41:13 --> Final output sent to browser
DEBUG - 2018-10-08 12:41:13 --> Total execution time: 5.9738
INFO - 2018-10-08 12:45:05 --> Config Class Initialized
INFO - 2018-10-08 12:45:05 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:45:06 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:45:06 --> Utf8 Class Initialized
INFO - 2018-10-08 12:45:07 --> URI Class Initialized
DEBUG - 2018-10-08 12:45:07 --> No URI present. Default controller set.
INFO - 2018-10-08 12:45:07 --> Router Class Initialized
INFO - 2018-10-08 12:45:07 --> Output Class Initialized
INFO - 2018-10-08 12:45:08 --> Security Class Initialized
DEBUG - 2018-10-08 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:45:08 --> Input Class Initialized
INFO - 2018-10-08 12:45:08 --> Language Class Initialized
INFO - 2018-10-08 12:45:08 --> Language Class Initialized
INFO - 2018-10-08 12:45:08 --> Config Class Initialized
INFO - 2018-10-08 12:45:09 --> Loader Class Initialized
INFO - 2018-10-08 12:45:09 --> Helper loaded: url_helper
INFO - 2018-10-08 12:45:09 --> Helper loaded: form_helper
INFO - 2018-10-08 12:45:09 --> Database Driver Class Initialized
INFO - 2018-10-08 12:45:09 --> Email Class Initialized
INFO - 2018-10-08 12:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:45:09 --> Form Validation Class Initialized
INFO - 2018-10-08 12:45:10 --> Controller Class Initialized
DEBUG - 2018-10-08 12:45:10 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:45:10 --> Model Class Initialized
DEBUG - 2018-10-08 12:45:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:45:10 --> Model Class Initialized
DEBUG - 2018-10-08 12:45:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:45:10 --> Final output sent to browser
DEBUG - 2018-10-08 12:45:11 --> Total execution time: 5.2683
INFO - 2018-10-08 12:45:18 --> Config Class Initialized
INFO - 2018-10-08 12:45:18 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:45:18 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:45:19 --> Utf8 Class Initialized
INFO - 2018-10-08 12:45:19 --> URI Class Initialized
DEBUG - 2018-10-08 12:45:19 --> No URI present. Default controller set.
INFO - 2018-10-08 12:45:19 --> Router Class Initialized
INFO - 2018-10-08 12:45:19 --> Output Class Initialized
INFO - 2018-10-08 12:45:19 --> Security Class Initialized
DEBUG - 2018-10-08 12:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:45:20 --> Input Class Initialized
INFO - 2018-10-08 12:45:20 --> Language Class Initialized
INFO - 2018-10-08 12:45:20 --> Language Class Initialized
INFO - 2018-10-08 12:45:20 --> Config Class Initialized
INFO - 2018-10-08 12:45:20 --> Loader Class Initialized
INFO - 2018-10-08 12:45:20 --> Helper loaded: url_helper
INFO - 2018-10-08 12:45:21 --> Helper loaded: form_helper
INFO - 2018-10-08 12:45:21 --> Database Driver Class Initialized
INFO - 2018-10-08 12:45:21 --> Email Class Initialized
INFO - 2018-10-08 12:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:45:21 --> Form Validation Class Initialized
INFO - 2018-10-08 12:45:21 --> Controller Class Initialized
DEBUG - 2018-10-08 12:45:22 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:45:22 --> Model Class Initialized
DEBUG - 2018-10-08 12:45:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:45:22 --> Model Class Initialized
DEBUG - 2018-10-08 12:45:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:45:23 --> Final output sent to browser
DEBUG - 2018-10-08 12:45:23 --> Total execution time: 4.2662
INFO - 2018-10-08 12:46:10 --> Config Class Initialized
INFO - 2018-10-08 12:46:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:46:10 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:46:10 --> Utf8 Class Initialized
INFO - 2018-10-08 12:46:10 --> URI Class Initialized
DEBUG - 2018-10-08 12:46:11 --> No URI present. Default controller set.
INFO - 2018-10-08 12:46:11 --> Router Class Initialized
INFO - 2018-10-08 12:46:11 --> Output Class Initialized
INFO - 2018-10-08 12:46:11 --> Security Class Initialized
DEBUG - 2018-10-08 12:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:46:11 --> Input Class Initialized
INFO - 2018-10-08 12:46:12 --> Language Class Initialized
INFO - 2018-10-08 12:46:12 --> Language Class Initialized
INFO - 2018-10-08 12:46:12 --> Config Class Initialized
INFO - 2018-10-08 12:46:12 --> Loader Class Initialized
INFO - 2018-10-08 12:46:12 --> Helper loaded: url_helper
INFO - 2018-10-08 12:46:12 --> Helper loaded: form_helper
INFO - 2018-10-08 12:46:12 --> Database Driver Class Initialized
INFO - 2018-10-08 12:46:13 --> Email Class Initialized
INFO - 2018-10-08 12:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:46:13 --> Form Validation Class Initialized
INFO - 2018-10-08 12:46:13 --> Controller Class Initialized
DEBUG - 2018-10-08 12:46:13 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:46:13 --> Model Class Initialized
DEBUG - 2018-10-08 12:46:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:46:14 --> Model Class Initialized
DEBUG - 2018-10-08 12:46:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:46:14 --> Final output sent to browser
DEBUG - 2018-10-08 12:46:17 --> Total execution time: 4.1252
INFO - 2018-10-08 12:46:24 --> Config Class Initialized
INFO - 2018-10-08 12:46:24 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:46:25 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:46:25 --> Utf8 Class Initialized
INFO - 2018-10-08 12:46:25 --> URI Class Initialized
DEBUG - 2018-10-08 12:46:25 --> No URI present. Default controller set.
INFO - 2018-10-08 12:46:25 --> Router Class Initialized
INFO - 2018-10-08 12:46:25 --> Output Class Initialized
INFO - 2018-10-08 12:46:26 --> Security Class Initialized
DEBUG - 2018-10-08 12:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:46:26 --> Input Class Initialized
INFO - 2018-10-08 12:46:26 --> Language Class Initialized
INFO - 2018-10-08 12:46:26 --> Language Class Initialized
INFO - 2018-10-08 12:46:26 --> Config Class Initialized
INFO - 2018-10-08 12:46:27 --> Loader Class Initialized
INFO - 2018-10-08 12:46:27 --> Helper loaded: url_helper
INFO - 2018-10-08 12:46:27 --> Helper loaded: form_helper
INFO - 2018-10-08 12:46:27 --> Database Driver Class Initialized
INFO - 2018-10-08 12:46:27 --> Email Class Initialized
INFO - 2018-10-08 12:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:46:27 --> Form Validation Class Initialized
INFO - 2018-10-08 12:46:28 --> Controller Class Initialized
DEBUG - 2018-10-08 12:46:28 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:46:28 --> Model Class Initialized
DEBUG - 2018-10-08 12:46:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:46:28 --> Model Class Initialized
DEBUG - 2018-10-08 12:46:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:46:28 --> Final output sent to browser
DEBUG - 2018-10-08 12:46:29 --> Total execution time: 4.0102
INFO - 2018-10-08 12:48:19 --> Config Class Initialized
INFO - 2018-10-08 12:48:19 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:48:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:48:19 --> Utf8 Class Initialized
INFO - 2018-10-08 12:48:20 --> URI Class Initialized
DEBUG - 2018-10-08 12:48:20 --> No URI present. Default controller set.
INFO - 2018-10-08 12:48:20 --> Router Class Initialized
INFO - 2018-10-08 12:48:20 --> Output Class Initialized
INFO - 2018-10-08 12:48:20 --> Security Class Initialized
DEBUG - 2018-10-08 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:48:21 --> Input Class Initialized
INFO - 2018-10-08 12:48:21 --> Language Class Initialized
INFO - 2018-10-08 12:48:21 --> Language Class Initialized
INFO - 2018-10-08 12:48:21 --> Config Class Initialized
INFO - 2018-10-08 12:48:21 --> Loader Class Initialized
INFO - 2018-10-08 12:48:21 --> Helper loaded: url_helper
INFO - 2018-10-08 12:48:21 --> Helper loaded: form_helper
INFO - 2018-10-08 12:48:22 --> Database Driver Class Initialized
INFO - 2018-10-08 12:48:22 --> Email Class Initialized
INFO - 2018-10-08 12:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:48:22 --> Form Validation Class Initialized
INFO - 2018-10-08 12:48:22 --> Controller Class Initialized
DEBUG - 2018-10-08 12:48:22 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:48:23 --> Model Class Initialized
DEBUG - 2018-10-08 12:48:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:48:23 --> Model Class Initialized
DEBUG - 2018-10-08 12:48:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:48:23 --> Final output sent to browser
DEBUG - 2018-10-08 12:48:23 --> Total execution time: 4.3152
INFO - 2018-10-08 12:50:00 --> Config Class Initialized
INFO - 2018-10-08 12:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:50:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:50:01 --> Utf8 Class Initialized
INFO - 2018-10-08 12:50:01 --> URI Class Initialized
DEBUG - 2018-10-08 12:50:01 --> No URI present. Default controller set.
INFO - 2018-10-08 12:50:01 --> Router Class Initialized
INFO - 2018-10-08 12:50:01 --> Config Class Initialized
INFO - 2018-10-08 12:50:01 --> Output Class Initialized
INFO - 2018-10-08 12:50:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:50:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:50:02 --> Utf8 Class Initialized
INFO - 2018-10-08 12:50:02 --> URI Class Initialized
DEBUG - 2018-10-08 12:50:02 --> No URI present. Default controller set.
INFO - 2018-10-08 12:50:03 --> Router Class Initialized
INFO - 2018-10-08 12:50:03 --> Output Class Initialized
INFO - 2018-10-08 12:50:03 --> Security Class Initialized
DEBUG - 2018-10-08 12:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:50:03 --> Security Class Initialized
INFO - 2018-10-08 12:50:03 --> Input Class Initialized
DEBUG - 2018-10-08 12:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:50:04 --> Input Class Initialized
INFO - 2018-10-08 12:50:04 --> Language Class Initialized
INFO - 2018-10-08 12:50:04 --> Language Class Initialized
INFO - 2018-10-08 12:50:04 --> Language Class Initialized
INFO - 2018-10-08 12:50:04 --> Language Class Initialized
INFO - 2018-10-08 12:50:04 --> Config Class Initialized
INFO - 2018-10-08 12:50:05 --> Loader Class Initialized
INFO - 2018-10-08 12:50:05 --> Helper loaded: url_helper
INFO - 2018-10-08 12:50:05 --> Helper loaded: form_helper
INFO - 2018-10-08 12:50:05 --> Config Class Initialized
INFO - 2018-10-08 12:50:05 --> Database Driver Class Initialized
INFO - 2018-10-08 12:50:05 --> Email Class Initialized
INFO - 2018-10-08 12:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:50:06 --> Loader Class Initialized
INFO - 2018-10-08 12:50:06 --> Form Validation Class Initialized
INFO - 2018-10-08 12:50:06 --> Controller Class Initialized
DEBUG - 2018-10-08 12:50:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:50:06 --> Helper loaded: url_helper
INFO - 2018-10-08 12:50:06 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:50:07 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:50:07 --> Final output sent to browser
DEBUG - 2018-10-08 12:50:07 --> Total execution time: 5.5903
INFO - 2018-10-08 12:50:08 --> Helper loaded: form_helper
INFO - 2018-10-08 12:50:09 --> Database Driver Class Initialized
INFO - 2018-10-08 12:50:09 --> Email Class Initialized
INFO - 2018-10-08 12:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:50:09 --> Form Validation Class Initialized
INFO - 2018-10-08 12:50:09 --> Controller Class Initialized
DEBUG - 2018-10-08 12:50:09 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:50:09 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:50:10 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:50:10 --> Final output sent to browser
DEBUG - 2018-10-08 12:50:10 --> Total execution time: 9.8401
INFO - 2018-10-08 12:50:17 --> Config Class Initialized
INFO - 2018-10-08 12:50:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:50:18 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:50:18 --> Utf8 Class Initialized
INFO - 2018-10-08 12:50:18 --> URI Class Initialized
DEBUG - 2018-10-08 12:50:18 --> No URI present. Default controller set.
INFO - 2018-10-08 12:50:18 --> Router Class Initialized
INFO - 2018-10-08 12:50:19 --> Output Class Initialized
INFO - 2018-10-08 12:50:19 --> Security Class Initialized
DEBUG - 2018-10-08 12:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:50:19 --> Input Class Initialized
INFO - 2018-10-08 12:50:19 --> Language Class Initialized
INFO - 2018-10-08 12:50:19 --> Language Class Initialized
INFO - 2018-10-08 12:50:20 --> Config Class Initialized
INFO - 2018-10-08 12:50:20 --> Loader Class Initialized
INFO - 2018-10-08 12:50:20 --> Helper loaded: url_helper
INFO - 2018-10-08 12:50:20 --> Helper loaded: form_helper
INFO - 2018-10-08 12:50:20 --> Database Driver Class Initialized
INFO - 2018-10-08 12:50:20 --> Email Class Initialized
INFO - 2018-10-08 12:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:50:21 --> Form Validation Class Initialized
INFO - 2018-10-08 12:50:21 --> Controller Class Initialized
DEBUG - 2018-10-08 12:50:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:50:21 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:50:21 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:50:22 --> Final output sent to browser
DEBUG - 2018-10-08 12:50:22 --> Total execution time: 4.5813
INFO - 2018-10-08 12:50:37 --> Config Class Initialized
INFO - 2018-10-08 12:50:37 --> Hooks Class Initialized
INFO - 2018-10-08 12:50:37 --> Config Class Initialized
DEBUG - 2018-10-08 12:50:37 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:50:37 --> Utf8 Class Initialized
INFO - 2018-10-08 12:50:38 --> URI Class Initialized
INFO - 2018-10-08 12:50:38 --> Router Class Initialized
INFO - 2018-10-08 12:50:38 --> Output Class Initialized
INFO - 2018-10-08 12:50:38 --> Security Class Initialized
DEBUG - 2018-10-08 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:50:38 --> Hooks Class Initialized
INFO - 2018-10-08 12:50:39 --> Input Class Initialized
INFO - 2018-10-08 12:50:39 --> Language Class Initialized
INFO - 2018-10-08 12:50:39 --> Language Class Initialized
INFO - 2018-10-08 12:50:39 --> Config Class Initialized
DEBUG - 2018-10-08 12:50:39 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:50:39 --> Loader Class Initialized
INFO - 2018-10-08 12:50:40 --> Helper loaded: url_helper
INFO - 2018-10-08 12:50:40 --> Utf8 Class Initialized
INFO - 2018-10-08 12:50:40 --> Helper loaded: form_helper
INFO - 2018-10-08 12:50:40 --> Database Driver Class Initialized
INFO - 2018-10-08 12:50:40 --> Email Class Initialized
INFO - 2018-10-08 12:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:50:40 --> Form Validation Class Initialized
INFO - 2018-10-08 12:50:41 --> Controller Class Initialized
DEBUG - 2018-10-08 12:50:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:50:41 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 12:50:41 --> Model Class Initialized
INFO - 2018-10-08 12:50:41 --> URI Class Initialized
DEBUG - 2018-10-08 12:50:42 --> No URI present. Default controller set.
INFO - 2018-10-08 12:50:42 --> Router Class Initialized
INFO - 2018-10-08 12:50:42 --> Output Class Initialized
INFO - 2018-10-08 12:50:42 --> Security Class Initialized
DEBUG - 2018-10-08 12:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:50:42 --> Final output sent to browser
DEBUG - 2018-10-08 12:50:43 --> Total execution time: 5.6703
INFO - 2018-10-08 12:50:43 --> Input Class Initialized
INFO - 2018-10-08 12:50:43 --> Language Class Initialized
INFO - 2018-10-08 12:50:43 --> Language Class Initialized
INFO - 2018-10-08 12:50:44 --> Config Class Initialized
INFO - 2018-10-08 12:50:44 --> Loader Class Initialized
INFO - 2018-10-08 12:50:44 --> Helper loaded: url_helper
INFO - 2018-10-08 12:50:44 --> Helper loaded: form_helper
INFO - 2018-10-08 12:50:44 --> Database Driver Class Initialized
INFO - 2018-10-08 12:50:44 --> Email Class Initialized
INFO - 2018-10-08 12:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:50:45 --> Form Validation Class Initialized
INFO - 2018-10-08 12:50:45 --> Controller Class Initialized
DEBUG - 2018-10-08 12:50:45 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:50:45 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:50:45 --> Model Class Initialized
DEBUG - 2018-10-08 12:50:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:50:46 --> Final output sent to browser
DEBUG - 2018-10-08 12:50:46 --> Total execution time: 8.9305
INFO - 2018-10-08 12:51:55 --> Config Class Initialized
INFO - 2018-10-08 12:51:55 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:51:55 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:51:55 --> Utf8 Class Initialized
INFO - 2018-10-08 12:51:55 --> URI Class Initialized
DEBUG - 2018-10-08 12:51:56 --> No URI present. Default controller set.
INFO - 2018-10-08 12:51:56 --> Router Class Initialized
INFO - 2018-10-08 12:51:56 --> Output Class Initialized
INFO - 2018-10-08 12:51:57 --> Security Class Initialized
DEBUG - 2018-10-08 12:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:51:57 --> Input Class Initialized
INFO - 2018-10-08 12:51:57 --> Language Class Initialized
INFO - 2018-10-08 12:51:57 --> Language Class Initialized
INFO - 2018-10-08 12:51:58 --> Config Class Initialized
INFO - 2018-10-08 12:51:58 --> Loader Class Initialized
INFO - 2018-10-08 12:51:58 --> Helper loaded: url_helper
INFO - 2018-10-08 12:51:58 --> Helper loaded: form_helper
INFO - 2018-10-08 12:51:58 --> Database Driver Class Initialized
INFO - 2018-10-08 12:51:59 --> Email Class Initialized
INFO - 2018-10-08 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:51:59 --> Form Validation Class Initialized
INFO - 2018-10-08 12:51:59 --> Controller Class Initialized
DEBUG - 2018-10-08 12:51:59 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:52:00 --> Model Class Initialized
DEBUG - 2018-10-08 12:52:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:52:00 --> Model Class Initialized
DEBUG - 2018-10-08 12:52:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:52:00 --> Final output sent to browser
DEBUG - 2018-10-08 12:52:01 --> Total execution time: 5.9433
INFO - 2018-10-08 12:53:08 --> Config Class Initialized
INFO - 2018-10-08 12:53:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:53:08 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:53:08 --> Utf8 Class Initialized
INFO - 2018-10-08 12:53:09 --> URI Class Initialized
DEBUG - 2018-10-08 12:53:09 --> No URI present. Default controller set.
INFO - 2018-10-08 12:53:09 --> Router Class Initialized
INFO - 2018-10-08 12:53:09 --> Output Class Initialized
INFO - 2018-10-08 12:53:09 --> Security Class Initialized
DEBUG - 2018-10-08 12:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:53:10 --> Input Class Initialized
INFO - 2018-10-08 12:53:10 --> Language Class Initialized
INFO - 2018-10-08 12:53:10 --> Language Class Initialized
INFO - 2018-10-08 12:53:10 --> Config Class Initialized
INFO - 2018-10-08 12:53:10 --> Loader Class Initialized
INFO - 2018-10-08 12:53:10 --> Helper loaded: url_helper
INFO - 2018-10-08 12:53:10 --> Helper loaded: form_helper
INFO - 2018-10-08 12:53:11 --> Database Driver Class Initialized
INFO - 2018-10-08 12:53:11 --> Email Class Initialized
INFO - 2018-10-08 12:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:53:11 --> Form Validation Class Initialized
INFO - 2018-10-08 12:53:11 --> Controller Class Initialized
DEBUG - 2018-10-08 12:53:11 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:53:12 --> Model Class Initialized
DEBUG - 2018-10-08 12:53:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:53:12 --> Model Class Initialized
DEBUG - 2018-10-08 12:53:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:53:12 --> Final output sent to browser
DEBUG - 2018-10-08 12:53:12 --> Total execution time: 4.4703
INFO - 2018-10-08 12:54:02 --> Config Class Initialized
INFO - 2018-10-08 12:54:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:54:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:54:03 --> Utf8 Class Initialized
INFO - 2018-10-08 12:54:03 --> URI Class Initialized
DEBUG - 2018-10-08 12:54:03 --> No URI present. Default controller set.
INFO - 2018-10-08 12:54:03 --> Router Class Initialized
INFO - 2018-10-08 12:54:03 --> Output Class Initialized
INFO - 2018-10-08 12:54:04 --> Security Class Initialized
DEBUG - 2018-10-08 12:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:54:04 --> Input Class Initialized
INFO - 2018-10-08 12:54:04 --> Language Class Initialized
INFO - 2018-10-08 12:54:04 --> Language Class Initialized
INFO - 2018-10-08 12:54:04 --> Config Class Initialized
INFO - 2018-10-08 12:54:04 --> Loader Class Initialized
INFO - 2018-10-08 12:54:05 --> Helper loaded: url_helper
INFO - 2018-10-08 12:54:05 --> Helper loaded: form_helper
INFO - 2018-10-08 12:54:05 --> Database Driver Class Initialized
INFO - 2018-10-08 12:54:05 --> Email Class Initialized
INFO - 2018-10-08 12:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:54:05 --> Form Validation Class Initialized
INFO - 2018-10-08 12:54:06 --> Controller Class Initialized
DEBUG - 2018-10-08 12:54:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:54:06 --> Model Class Initialized
DEBUG - 2018-10-08 12:54:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:54:06 --> Model Class Initialized
DEBUG - 2018-10-08 12:54:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:54:07 --> Final output sent to browser
DEBUG - 2018-10-08 12:54:07 --> Total execution time: 4.7323
INFO - 2018-10-08 12:55:08 --> Config Class Initialized
INFO - 2018-10-08 12:55:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:55:09 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:55:09 --> Utf8 Class Initialized
INFO - 2018-10-08 12:55:09 --> URI Class Initialized
DEBUG - 2018-10-08 12:55:09 --> No URI present. Default controller set.
INFO - 2018-10-08 12:55:09 --> Router Class Initialized
INFO - 2018-10-08 12:55:10 --> Output Class Initialized
INFO - 2018-10-08 12:55:10 --> Security Class Initialized
DEBUG - 2018-10-08 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:55:10 --> Input Class Initialized
INFO - 2018-10-08 12:55:10 --> Language Class Initialized
INFO - 2018-10-08 12:55:10 --> Language Class Initialized
INFO - 2018-10-08 12:55:11 --> Config Class Initialized
INFO - 2018-10-08 12:55:11 --> Loader Class Initialized
INFO - 2018-10-08 12:55:11 --> Helper loaded: url_helper
INFO - 2018-10-08 12:55:11 --> Helper loaded: form_helper
INFO - 2018-10-08 12:55:11 --> Database Driver Class Initialized
INFO - 2018-10-08 12:55:12 --> Email Class Initialized
INFO - 2018-10-08 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:55:12 --> Form Validation Class Initialized
INFO - 2018-10-08 12:55:12 --> Controller Class Initialized
DEBUG - 2018-10-08 12:55:12 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:55:12 --> Model Class Initialized
DEBUG - 2018-10-08 12:55:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:55:13 --> Model Class Initialized
DEBUG - 2018-10-08 12:55:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:55:13 --> Final output sent to browser
DEBUG - 2018-10-08 12:55:13 --> Total execution time: 4.5119
INFO - 2018-10-08 12:56:59 --> Config Class Initialized
INFO - 2018-10-08 12:56:59 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:56:59 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:56:59 --> Utf8 Class Initialized
INFO - 2018-10-08 12:57:00 --> URI Class Initialized
DEBUG - 2018-10-08 12:57:00 --> No URI present. Default controller set.
INFO - 2018-10-08 12:57:00 --> Router Class Initialized
INFO - 2018-10-08 12:57:01 --> Output Class Initialized
INFO - 2018-10-08 12:57:01 --> Security Class Initialized
DEBUG - 2018-10-08 12:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:57:01 --> Input Class Initialized
INFO - 2018-10-08 12:57:01 --> Language Class Initialized
INFO - 2018-10-08 12:57:01 --> Language Class Initialized
INFO - 2018-10-08 12:57:02 --> Config Class Initialized
INFO - 2018-10-08 12:57:02 --> Loader Class Initialized
INFO - 2018-10-08 12:57:02 --> Helper loaded: url_helper
INFO - 2018-10-08 12:57:02 --> Helper loaded: form_helper
INFO - 2018-10-08 12:57:03 --> Database Driver Class Initialized
INFO - 2018-10-08 12:57:03 --> Email Class Initialized
INFO - 2018-10-08 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:57:03 --> Form Validation Class Initialized
INFO - 2018-10-08 12:57:03 --> Controller Class Initialized
DEBUG - 2018-10-08 12:57:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:57:04 --> Model Class Initialized
DEBUG - 2018-10-08 12:57:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:57:04 --> Model Class Initialized
DEBUG - 2018-10-08 12:57:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:57:05 --> Final output sent to browser
DEBUG - 2018-10-08 12:57:05 --> Total execution time: 5.9933
INFO - 2018-10-08 12:57:26 --> Config Class Initialized
INFO - 2018-10-08 12:57:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:57:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:57:27 --> Utf8 Class Initialized
INFO - 2018-10-08 12:57:27 --> URI Class Initialized
DEBUG - 2018-10-08 12:57:27 --> No URI present. Default controller set.
INFO - 2018-10-08 12:57:28 --> Router Class Initialized
INFO - 2018-10-08 12:57:28 --> Output Class Initialized
INFO - 2018-10-08 12:57:28 --> Security Class Initialized
DEBUG - 2018-10-08 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:57:28 --> Input Class Initialized
INFO - 2018-10-08 12:57:28 --> Language Class Initialized
INFO - 2018-10-08 12:57:29 --> Language Class Initialized
INFO - 2018-10-08 12:57:29 --> Config Class Initialized
INFO - 2018-10-08 12:57:29 --> Loader Class Initialized
INFO - 2018-10-08 12:57:29 --> Helper loaded: url_helper
INFO - 2018-10-08 12:57:29 --> Helper loaded: form_helper
INFO - 2018-10-08 12:57:30 --> Database Driver Class Initialized
INFO - 2018-10-08 12:57:30 --> Email Class Initialized
INFO - 2018-10-08 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:57:30 --> Form Validation Class Initialized
INFO - 2018-10-08 12:57:30 --> Controller Class Initialized
DEBUG - 2018-10-08 12:57:30 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:57:31 --> Model Class Initialized
DEBUG - 2018-10-08 12:57:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:57:31 --> Model Class Initialized
DEBUG - 2018-10-08 12:57:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:57:31 --> Final output sent to browser
DEBUG - 2018-10-08 12:57:31 --> Total execution time: 4.8213
INFO - 2018-10-08 12:58:22 --> Config Class Initialized
INFO - 2018-10-08 12:58:22 --> Hooks Class Initialized
DEBUG - 2018-10-08 12:58:23 --> UTF-8 Support Enabled
INFO - 2018-10-08 12:58:23 --> Utf8 Class Initialized
INFO - 2018-10-08 12:58:23 --> URI Class Initialized
DEBUG - 2018-10-08 12:58:23 --> No URI present. Default controller set.
INFO - 2018-10-08 12:58:23 --> Router Class Initialized
INFO - 2018-10-08 12:58:24 --> Output Class Initialized
INFO - 2018-10-08 12:58:24 --> Security Class Initialized
DEBUG - 2018-10-08 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 12:58:24 --> Input Class Initialized
INFO - 2018-10-08 12:58:24 --> Language Class Initialized
INFO - 2018-10-08 12:58:25 --> Language Class Initialized
INFO - 2018-10-08 12:58:25 --> Config Class Initialized
INFO - 2018-10-08 12:58:25 --> Loader Class Initialized
INFO - 2018-10-08 12:58:26 --> Helper loaded: url_helper
INFO - 2018-10-08 12:58:26 --> Helper loaded: form_helper
INFO - 2018-10-08 12:58:26 --> Database Driver Class Initialized
INFO - 2018-10-08 12:58:27 --> Email Class Initialized
INFO - 2018-10-08 12:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 12:58:27 --> Form Validation Class Initialized
INFO - 2018-10-08 12:58:27 --> Controller Class Initialized
DEBUG - 2018-10-08 12:58:28 --> Person MX_Controller Initialized
INFO - 2018-10-08 12:58:28 --> Model Class Initialized
DEBUG - 2018-10-08 12:58:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 12:58:28 --> Model Class Initialized
DEBUG - 2018-10-08 12:58:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 12:58:29 --> Final output sent to browser
DEBUG - 2018-10-08 12:58:29 --> Total execution time: 6.6924
INFO - 2018-10-08 13:03:29 --> Config Class Initialized
INFO - 2018-10-08 13:03:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:03:30 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:03:30 --> Utf8 Class Initialized
INFO - 2018-10-08 13:03:30 --> URI Class Initialized
DEBUG - 2018-10-08 13:03:31 --> No URI present. Default controller set.
INFO - 2018-10-08 13:03:31 --> Router Class Initialized
INFO - 2018-10-08 13:03:31 --> Output Class Initialized
INFO - 2018-10-08 13:03:31 --> Security Class Initialized
DEBUG - 2018-10-08 13:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:03:32 --> Input Class Initialized
INFO - 2018-10-08 13:03:32 --> Language Class Initialized
INFO - 2018-10-08 13:03:32 --> Language Class Initialized
INFO - 2018-10-08 13:03:32 --> Config Class Initialized
INFO - 2018-10-08 13:03:32 --> Loader Class Initialized
INFO - 2018-10-08 13:03:32 --> Helper loaded: url_helper
INFO - 2018-10-08 13:03:33 --> Helper loaded: form_helper
INFO - 2018-10-08 13:03:33 --> Database Driver Class Initialized
INFO - 2018-10-08 13:03:34 --> Email Class Initialized
INFO - 2018-10-08 13:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:03:34 --> Form Validation Class Initialized
INFO - 2018-10-08 13:03:34 --> Controller Class Initialized
DEBUG - 2018-10-08 13:03:34 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:03:34 --> Model Class Initialized
DEBUG - 2018-10-08 13:03:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:03:35 --> Model Class Initialized
DEBUG - 2018-10-08 13:03:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:03:35 --> Final output sent to browser
DEBUG - 2018-10-08 13:03:35 --> Total execution time: 6.1954
INFO - 2018-10-08 13:04:03 --> Config Class Initialized
INFO - 2018-10-08 13:04:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:04:03 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:04:03 --> Utf8 Class Initialized
INFO - 2018-10-08 13:04:03 --> URI Class Initialized
DEBUG - 2018-10-08 13:04:03 --> No URI present. Default controller set.
INFO - 2018-10-08 13:04:03 --> Router Class Initialized
INFO - 2018-10-08 13:04:04 --> Output Class Initialized
INFO - 2018-10-08 13:04:04 --> Security Class Initialized
DEBUG - 2018-10-08 13:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:04:04 --> Input Class Initialized
INFO - 2018-10-08 13:04:04 --> Language Class Initialized
INFO - 2018-10-08 13:04:04 --> Language Class Initialized
INFO - 2018-10-08 13:04:05 --> Config Class Initialized
INFO - 2018-10-08 13:04:05 --> Loader Class Initialized
INFO - 2018-10-08 13:04:05 --> Helper loaded: url_helper
INFO - 2018-10-08 13:04:05 --> Helper loaded: form_helper
INFO - 2018-10-08 13:04:05 --> Database Driver Class Initialized
INFO - 2018-10-08 13:04:05 --> Email Class Initialized
INFO - 2018-10-08 13:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:04:06 --> Form Validation Class Initialized
INFO - 2018-10-08 13:04:06 --> Controller Class Initialized
DEBUG - 2018-10-08 13:04:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:04:06 --> Model Class Initialized
DEBUG - 2018-10-08 13:04:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:04:07 --> Model Class Initialized
DEBUG - 2018-10-08 13:04:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:04:07 --> Final output sent to browser
DEBUG - 2018-10-08 13:04:07 --> Total execution time: 4.3702
INFO - 2018-10-08 13:05:21 --> Config Class Initialized
INFO - 2018-10-08 13:05:21 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:05:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:05:21 --> Utf8 Class Initialized
INFO - 2018-10-08 13:05:21 --> URI Class Initialized
DEBUG - 2018-10-08 13:05:21 --> No URI present. Default controller set.
INFO - 2018-10-08 13:05:22 --> Router Class Initialized
INFO - 2018-10-08 13:05:22 --> Output Class Initialized
INFO - 2018-10-08 13:05:22 --> Security Class Initialized
DEBUG - 2018-10-08 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:05:22 --> Input Class Initialized
INFO - 2018-10-08 13:05:23 --> Language Class Initialized
INFO - 2018-10-08 13:05:23 --> Language Class Initialized
INFO - 2018-10-08 13:05:23 --> Config Class Initialized
INFO - 2018-10-08 13:05:23 --> Loader Class Initialized
INFO - 2018-10-08 13:05:23 --> Helper loaded: url_helper
INFO - 2018-10-08 13:05:23 --> Helper loaded: form_helper
INFO - 2018-10-08 13:05:24 --> Database Driver Class Initialized
INFO - 2018-10-08 13:05:24 --> Email Class Initialized
INFO - 2018-10-08 13:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:05:24 --> Form Validation Class Initialized
INFO - 2018-10-08 13:05:24 --> Controller Class Initialized
DEBUG - 2018-10-08 13:05:24 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:05:25 --> Model Class Initialized
DEBUG - 2018-10-08 13:05:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:05:25 --> Model Class Initialized
DEBUG - 2018-10-08 13:05:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:05:25 --> Final output sent to browser
DEBUG - 2018-10-08 13:05:25 --> Total execution time: 4.6183
INFO - 2018-10-08 13:06:19 --> Config Class Initialized
INFO - 2018-10-08 13:06:19 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:06:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:06:20 --> Utf8 Class Initialized
INFO - 2018-10-08 13:06:20 --> URI Class Initialized
DEBUG - 2018-10-08 13:06:20 --> No URI present. Default controller set.
INFO - 2018-10-08 13:06:20 --> Router Class Initialized
INFO - 2018-10-08 13:06:21 --> Output Class Initialized
INFO - 2018-10-08 13:06:21 --> Security Class Initialized
DEBUG - 2018-10-08 13:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:06:21 --> Input Class Initialized
INFO - 2018-10-08 13:06:21 --> Language Class Initialized
INFO - 2018-10-08 13:06:21 --> Language Class Initialized
INFO - 2018-10-08 13:06:22 --> Config Class Initialized
INFO - 2018-10-08 13:06:22 --> Loader Class Initialized
INFO - 2018-10-08 13:06:22 --> Helper loaded: url_helper
INFO - 2018-10-08 13:06:22 --> Helper loaded: form_helper
INFO - 2018-10-08 13:06:22 --> Database Driver Class Initialized
INFO - 2018-10-08 13:06:22 --> Email Class Initialized
INFO - 2018-10-08 13:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:06:23 --> Form Validation Class Initialized
INFO - 2018-10-08 13:06:23 --> Controller Class Initialized
DEBUG - 2018-10-08 13:06:23 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:06:23 --> Model Class Initialized
DEBUG - 2018-10-08 13:06:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:06:24 --> Model Class Initialized
DEBUG - 2018-10-08 13:06:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:06:24 --> Final output sent to browser
DEBUG - 2018-10-08 13:06:24 --> Total execution time: 4.9833
INFO - 2018-10-08 13:12:28 --> Config Class Initialized
INFO - 2018-10-08 13:12:28 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:12:29 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:12:30 --> Utf8 Class Initialized
INFO - 2018-10-08 13:12:30 --> URI Class Initialized
DEBUG - 2018-10-08 13:12:30 --> No URI present. Default controller set.
INFO - 2018-10-08 13:12:30 --> Router Class Initialized
INFO - 2018-10-08 13:12:30 --> Output Class Initialized
INFO - 2018-10-08 13:12:31 --> Security Class Initialized
DEBUG - 2018-10-08 13:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:12:31 --> Input Class Initialized
INFO - 2018-10-08 13:12:31 --> Language Class Initialized
INFO - 2018-10-08 13:12:31 --> Language Class Initialized
INFO - 2018-10-08 13:12:31 --> Config Class Initialized
INFO - 2018-10-08 13:12:32 --> Loader Class Initialized
INFO - 2018-10-08 13:12:32 --> Helper loaded: url_helper
INFO - 2018-10-08 13:12:32 --> Helper loaded: form_helper
INFO - 2018-10-08 13:12:32 --> Database Driver Class Initialized
INFO - 2018-10-08 13:12:32 --> Email Class Initialized
INFO - 2018-10-08 13:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:12:33 --> Form Validation Class Initialized
INFO - 2018-10-08 13:12:33 --> Controller Class Initialized
DEBUG - 2018-10-08 13:12:33 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:12:33 --> Model Class Initialized
DEBUG - 2018-10-08 13:12:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:12:33 --> Model Class Initialized
DEBUG - 2018-10-08 13:12:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:12:34 --> Final output sent to browser
DEBUG - 2018-10-08 13:12:34 --> Total execution time: 5.3243
INFO - 2018-10-08 13:13:23 --> Config Class Initialized
INFO - 2018-10-08 13:13:23 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:13:23 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:13:23 --> Utf8 Class Initialized
INFO - 2018-10-08 13:13:23 --> URI Class Initialized
DEBUG - 2018-10-08 13:13:24 --> No URI present. Default controller set.
INFO - 2018-10-08 13:13:24 --> Router Class Initialized
INFO - 2018-10-08 13:13:24 --> Output Class Initialized
INFO - 2018-10-08 13:13:24 --> Security Class Initialized
DEBUG - 2018-10-08 13:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:13:24 --> Input Class Initialized
INFO - 2018-10-08 13:13:25 --> Language Class Initialized
INFO - 2018-10-08 13:13:25 --> Language Class Initialized
INFO - 2018-10-08 13:13:25 --> Config Class Initialized
INFO - 2018-10-08 13:13:25 --> Loader Class Initialized
INFO - 2018-10-08 13:13:25 --> Helper loaded: url_helper
INFO - 2018-10-08 13:13:26 --> Helper loaded: form_helper
INFO - 2018-10-08 13:13:26 --> Database Driver Class Initialized
INFO - 2018-10-08 13:13:26 --> Email Class Initialized
INFO - 2018-10-08 13:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:13:27 --> Form Validation Class Initialized
INFO - 2018-10-08 13:13:27 --> Controller Class Initialized
DEBUG - 2018-10-08 13:13:27 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:13:27 --> Model Class Initialized
DEBUG - 2018-10-08 13:13:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:13:27 --> Model Class Initialized
DEBUG - 2018-10-08 13:13:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:13:28 --> Final output sent to browser
DEBUG - 2018-10-08 13:13:28 --> Total execution time: 5.1663
INFO - 2018-10-08 13:13:56 --> Config Class Initialized
INFO - 2018-10-08 13:13:56 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:13:56 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:13:56 --> Utf8 Class Initialized
INFO - 2018-10-08 13:13:56 --> URI Class Initialized
DEBUG - 2018-10-08 13:13:57 --> No URI present. Default controller set.
INFO - 2018-10-08 13:13:57 --> Router Class Initialized
INFO - 2018-10-08 13:13:57 --> Output Class Initialized
INFO - 2018-10-08 13:13:57 --> Security Class Initialized
DEBUG - 2018-10-08 13:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:13:58 --> Input Class Initialized
INFO - 2018-10-08 13:13:58 --> Language Class Initialized
INFO - 2018-10-08 13:13:58 --> Language Class Initialized
INFO - 2018-10-08 13:13:58 --> Config Class Initialized
INFO - 2018-10-08 13:13:58 --> Loader Class Initialized
INFO - 2018-10-08 13:13:58 --> Helper loaded: url_helper
INFO - 2018-10-08 13:13:59 --> Helper loaded: form_helper
INFO - 2018-10-08 13:13:59 --> Database Driver Class Initialized
INFO - 2018-10-08 13:13:59 --> Email Class Initialized
INFO - 2018-10-08 13:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:13:59 --> Form Validation Class Initialized
INFO - 2018-10-08 13:13:59 --> Controller Class Initialized
DEBUG - 2018-10-08 13:14:00 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:14:00 --> Model Class Initialized
DEBUG - 2018-10-08 13:14:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:14:00 --> Model Class Initialized
DEBUG - 2018-10-08 13:14:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:14:00 --> Final output sent to browser
DEBUG - 2018-10-08 13:14:01 --> Total execution time: 4.6443
INFO - 2018-10-08 13:14:44 --> Config Class Initialized
INFO - 2018-10-08 13:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:14:44 --> Utf8 Class Initialized
INFO - 2018-10-08 13:14:44 --> URI Class Initialized
DEBUG - 2018-10-08 13:14:45 --> No URI present. Default controller set.
INFO - 2018-10-08 13:14:45 --> Router Class Initialized
INFO - 2018-10-08 13:14:45 --> Output Class Initialized
INFO - 2018-10-08 13:14:45 --> Security Class Initialized
DEBUG - 2018-10-08 13:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:14:45 --> Input Class Initialized
INFO - 2018-10-08 13:14:46 --> Language Class Initialized
INFO - 2018-10-08 13:14:46 --> Language Class Initialized
INFO - 2018-10-08 13:14:46 --> Config Class Initialized
INFO - 2018-10-08 13:14:46 --> Loader Class Initialized
INFO - 2018-10-08 13:14:46 --> Helper loaded: url_helper
INFO - 2018-10-08 13:14:47 --> Helper loaded: form_helper
INFO - 2018-10-08 13:14:47 --> Database Driver Class Initialized
INFO - 2018-10-08 13:14:47 --> Email Class Initialized
INFO - 2018-10-08 13:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:14:47 --> Form Validation Class Initialized
INFO - 2018-10-08 13:14:47 --> Controller Class Initialized
DEBUG - 2018-10-08 13:14:47 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:14:48 --> Model Class Initialized
DEBUG - 2018-10-08 13:14:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:14:48 --> Model Class Initialized
DEBUG - 2018-10-08 13:14:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:14:48 --> Final output sent to browser
DEBUG - 2018-10-08 13:14:48 --> Total execution time: 4.6693
INFO - 2018-10-08 13:14:59 --> Config Class Initialized
INFO - 2018-10-08 13:14:59 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:14:59 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:14:59 --> Utf8 Class Initialized
INFO - 2018-10-08 13:15:00 --> URI Class Initialized
DEBUG - 2018-10-08 13:15:00 --> No URI present. Default controller set.
INFO - 2018-10-08 13:15:00 --> Router Class Initialized
INFO - 2018-10-08 13:15:00 --> Output Class Initialized
INFO - 2018-10-08 13:15:00 --> Security Class Initialized
DEBUG - 2018-10-08 13:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:15:01 --> Input Class Initialized
INFO - 2018-10-08 13:15:01 --> Language Class Initialized
INFO - 2018-10-08 13:15:01 --> Language Class Initialized
INFO - 2018-10-08 13:15:01 --> Config Class Initialized
INFO - 2018-10-08 13:15:01 --> Loader Class Initialized
INFO - 2018-10-08 13:15:01 --> Helper loaded: url_helper
INFO - 2018-10-08 13:15:02 --> Helper loaded: form_helper
INFO - 2018-10-08 13:15:02 --> Database Driver Class Initialized
INFO - 2018-10-08 13:15:02 --> Email Class Initialized
INFO - 2018-10-08 13:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:15:02 --> Form Validation Class Initialized
INFO - 2018-10-08 13:15:02 --> Controller Class Initialized
DEBUG - 2018-10-08 13:15:03 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:15:03 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:15:03 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:15:03 --> Final output sent to browser
DEBUG - 2018-10-08 13:15:04 --> Total execution time: 4.7913
INFO - 2018-10-08 13:15:10 --> Config Class Initialized
INFO - 2018-10-08 13:15:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:15:11 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:15:11 --> Utf8 Class Initialized
INFO - 2018-10-08 13:15:11 --> URI Class Initialized
DEBUG - 2018-10-08 13:15:11 --> No URI present. Default controller set.
INFO - 2018-10-08 13:15:11 --> Router Class Initialized
INFO - 2018-10-08 13:15:12 --> Output Class Initialized
INFO - 2018-10-08 13:15:12 --> Security Class Initialized
DEBUG - 2018-10-08 13:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:15:12 --> Input Class Initialized
INFO - 2018-10-08 13:15:12 --> Language Class Initialized
INFO - 2018-10-08 13:15:12 --> Language Class Initialized
INFO - 2018-10-08 13:15:13 --> Config Class Initialized
INFO - 2018-10-08 13:15:13 --> Loader Class Initialized
INFO - 2018-10-08 13:15:13 --> Helper loaded: url_helper
INFO - 2018-10-08 13:15:13 --> Helper loaded: form_helper
INFO - 2018-10-08 13:15:13 --> Database Driver Class Initialized
INFO - 2018-10-08 13:15:13 --> Email Class Initialized
INFO - 2018-10-08 13:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:15:14 --> Form Validation Class Initialized
INFO - 2018-10-08 13:15:14 --> Controller Class Initialized
DEBUG - 2018-10-08 13:15:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:15:14 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:15:15 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:15:15 --> Final output sent to browser
DEBUG - 2018-10-08 13:15:15 --> Total execution time: 5.0853
INFO - 2018-10-08 13:15:35 --> Config Class Initialized
INFO - 2018-10-08 13:15:35 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:15:36 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:15:37 --> Utf8 Class Initialized
INFO - 2018-10-08 13:15:37 --> URI Class Initialized
DEBUG - 2018-10-08 13:15:37 --> No URI present. Default controller set.
INFO - 2018-10-08 13:15:38 --> Router Class Initialized
INFO - 2018-10-08 13:15:38 --> Output Class Initialized
INFO - 2018-10-08 13:15:38 --> Security Class Initialized
DEBUG - 2018-10-08 13:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:15:38 --> Input Class Initialized
INFO - 2018-10-08 13:15:39 --> Language Class Initialized
INFO - 2018-10-08 13:15:39 --> Language Class Initialized
INFO - 2018-10-08 13:15:39 --> Config Class Initialized
INFO - 2018-10-08 13:15:39 --> Loader Class Initialized
INFO - 2018-10-08 13:15:40 --> Helper loaded: url_helper
INFO - 2018-10-08 13:15:40 --> Helper loaded: form_helper
INFO - 2018-10-08 13:15:40 --> Database Driver Class Initialized
INFO - 2018-10-08 13:15:40 --> Email Class Initialized
INFO - 2018-10-08 13:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:15:41 --> Form Validation Class Initialized
INFO - 2018-10-08 13:15:41 --> Controller Class Initialized
DEBUG - 2018-10-08 13:15:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:15:42 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:15:43 --> Model Class Initialized
DEBUG - 2018-10-08 13:15:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:15:43 --> Final output sent to browser
DEBUG - 2018-10-08 13:15:43 --> Total execution time: 8.1175
INFO - 2018-10-08 13:16:12 --> Config Class Initialized
INFO - 2018-10-08 13:16:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:16:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:16:12 --> Utf8 Class Initialized
INFO - 2018-10-08 13:16:12 --> URI Class Initialized
DEBUG - 2018-10-08 13:16:13 --> No URI present. Default controller set.
INFO - 2018-10-08 13:16:13 --> Router Class Initialized
INFO - 2018-10-08 13:16:13 --> Output Class Initialized
INFO - 2018-10-08 13:16:13 --> Security Class Initialized
DEBUG - 2018-10-08 13:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:16:13 --> Input Class Initialized
INFO - 2018-10-08 13:16:14 --> Language Class Initialized
INFO - 2018-10-08 13:16:14 --> Language Class Initialized
INFO - 2018-10-08 13:16:14 --> Config Class Initialized
INFO - 2018-10-08 13:16:14 --> Loader Class Initialized
INFO - 2018-10-08 13:16:14 --> Helper loaded: url_helper
INFO - 2018-10-08 13:16:15 --> Helper loaded: form_helper
INFO - 2018-10-08 13:16:15 --> Database Driver Class Initialized
INFO - 2018-10-08 13:16:15 --> Email Class Initialized
INFO - 2018-10-08 13:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:16:15 --> Form Validation Class Initialized
INFO - 2018-10-08 13:16:15 --> Controller Class Initialized
DEBUG - 2018-10-08 13:16:16 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:16:16 --> Model Class Initialized
DEBUG - 2018-10-08 13:16:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:16:16 --> Model Class Initialized
DEBUG - 2018-10-08 13:16:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:16:16 --> Final output sent to browser
DEBUG - 2018-10-08 13:16:17 --> Total execution time: 4.6823
INFO - 2018-10-08 13:16:27 --> Config Class Initialized
INFO - 2018-10-08 13:16:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:16:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:16:28 --> Utf8 Class Initialized
INFO - 2018-10-08 13:16:28 --> URI Class Initialized
DEBUG - 2018-10-08 13:16:28 --> No URI present. Default controller set.
INFO - 2018-10-08 13:16:28 --> Router Class Initialized
INFO - 2018-10-08 13:16:29 --> Output Class Initialized
INFO - 2018-10-08 13:16:29 --> Security Class Initialized
DEBUG - 2018-10-08 13:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:16:29 --> Input Class Initialized
INFO - 2018-10-08 13:16:29 --> Language Class Initialized
INFO - 2018-10-08 13:16:30 --> Language Class Initialized
INFO - 2018-10-08 13:16:30 --> Config Class Initialized
INFO - 2018-10-08 13:16:30 --> Loader Class Initialized
INFO - 2018-10-08 13:16:30 --> Helper loaded: url_helper
INFO - 2018-10-08 13:16:30 --> Helper loaded: form_helper
INFO - 2018-10-08 13:16:31 --> Database Driver Class Initialized
INFO - 2018-10-08 13:16:31 --> Email Class Initialized
INFO - 2018-10-08 13:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:16:31 --> Form Validation Class Initialized
INFO - 2018-10-08 13:16:31 --> Controller Class Initialized
DEBUG - 2018-10-08 13:16:31 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:16:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:16:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:16:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:16:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:16:32 --> Final output sent to browser
DEBUG - 2018-10-08 13:16:32 --> Total execution time: 5.2383
INFO - 2018-10-08 13:16:54 --> Config Class Initialized
INFO - 2018-10-08 13:16:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:16:55 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:16:55 --> Utf8 Class Initialized
INFO - 2018-10-08 13:16:55 --> URI Class Initialized
DEBUG - 2018-10-08 13:16:56 --> No URI present. Default controller set.
INFO - 2018-10-08 13:16:56 --> Router Class Initialized
INFO - 2018-10-08 13:16:56 --> Output Class Initialized
INFO - 2018-10-08 13:16:56 --> Security Class Initialized
DEBUG - 2018-10-08 13:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:16:57 --> Input Class Initialized
INFO - 2018-10-08 13:16:57 --> Language Class Initialized
INFO - 2018-10-08 13:16:57 --> Language Class Initialized
INFO - 2018-10-08 13:16:58 --> Config Class Initialized
INFO - 2018-10-08 13:16:58 --> Loader Class Initialized
INFO - 2018-10-08 13:16:58 --> Helper loaded: url_helper
INFO - 2018-10-08 13:16:58 --> Helper loaded: form_helper
INFO - 2018-10-08 13:16:59 --> Database Driver Class Initialized
INFO - 2018-10-08 13:16:59 --> Email Class Initialized
INFO - 2018-10-08 13:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:17:00 --> Form Validation Class Initialized
INFO - 2018-10-08 13:17:00 --> Controller Class Initialized
DEBUG - 2018-10-08 13:17:00 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:17:00 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:17:01 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:17:01 --> Final output sent to browser
DEBUG - 2018-10-08 13:17:01 --> Total execution time: 7.0374
INFO - 2018-10-08 13:17:11 --> Config Class Initialized
INFO - 2018-10-08 13:17:11 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:17:11 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:17:11 --> Utf8 Class Initialized
INFO - 2018-10-08 13:17:11 --> URI Class Initialized
DEBUG - 2018-10-08 13:17:12 --> No URI present. Default controller set.
INFO - 2018-10-08 13:17:12 --> Router Class Initialized
INFO - 2018-10-08 13:17:12 --> Output Class Initialized
INFO - 2018-10-08 13:17:12 --> Security Class Initialized
DEBUG - 2018-10-08 13:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:17:13 --> Input Class Initialized
INFO - 2018-10-08 13:17:13 --> Language Class Initialized
INFO - 2018-10-08 13:17:13 --> Language Class Initialized
INFO - 2018-10-08 13:17:13 --> Config Class Initialized
INFO - 2018-10-08 13:17:13 --> Loader Class Initialized
INFO - 2018-10-08 13:17:13 --> Helper loaded: url_helper
INFO - 2018-10-08 13:17:14 --> Helper loaded: form_helper
INFO - 2018-10-08 13:17:14 --> Database Driver Class Initialized
INFO - 2018-10-08 13:17:14 --> Email Class Initialized
INFO - 2018-10-08 13:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:17:14 --> Form Validation Class Initialized
INFO - 2018-10-08 13:17:14 --> Controller Class Initialized
DEBUG - 2018-10-08 13:17:15 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:17:15 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:17:15 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:17:15 --> Final output sent to browser
DEBUG - 2018-10-08 13:17:16 --> Total execution time: 4.6583
INFO - 2018-10-08 13:17:29 --> Config Class Initialized
INFO - 2018-10-08 13:17:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:17:30 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:17:31 --> Utf8 Class Initialized
INFO - 2018-10-08 13:17:32 --> URI Class Initialized
DEBUG - 2018-10-08 13:17:33 --> No URI present. Default controller set.
INFO - 2018-10-08 13:17:33 --> Router Class Initialized
INFO - 2018-10-08 13:17:33 --> Output Class Initialized
INFO - 2018-10-08 13:17:33 --> Security Class Initialized
DEBUG - 2018-10-08 13:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:17:34 --> Input Class Initialized
INFO - 2018-10-08 13:17:34 --> Language Class Initialized
INFO - 2018-10-08 13:17:34 --> Language Class Initialized
INFO - 2018-10-08 13:17:34 --> Config Class Initialized
INFO - 2018-10-08 13:17:35 --> Loader Class Initialized
INFO - 2018-10-08 13:17:35 --> Helper loaded: url_helper
INFO - 2018-10-08 13:17:35 --> Helper loaded: form_helper
INFO - 2018-10-08 13:17:35 --> Database Driver Class Initialized
INFO - 2018-10-08 13:17:36 --> Email Class Initialized
INFO - 2018-10-08 13:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:17:36 --> Form Validation Class Initialized
INFO - 2018-10-08 13:17:36 --> Controller Class Initialized
DEBUG - 2018-10-08 13:17:36 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:17:37 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:17:37 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:17:37 --> Final output sent to browser
DEBUG - 2018-10-08 13:17:38 --> Total execution time: 7.8955
INFO - 2018-10-08 13:17:42 --> Config Class Initialized
INFO - 2018-10-08 13:17:42 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:17:43 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:17:43 --> Utf8 Class Initialized
INFO - 2018-10-08 13:17:43 --> URI Class Initialized
DEBUG - 2018-10-08 13:17:43 --> No URI present. Default controller set.
INFO - 2018-10-08 13:17:44 --> Router Class Initialized
INFO - 2018-10-08 13:17:44 --> Output Class Initialized
INFO - 2018-10-08 13:17:44 --> Security Class Initialized
DEBUG - 2018-10-08 13:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:17:44 --> Input Class Initialized
INFO - 2018-10-08 13:17:45 --> Language Class Initialized
INFO - 2018-10-08 13:17:45 --> Language Class Initialized
INFO - 2018-10-08 13:17:45 --> Config Class Initialized
INFO - 2018-10-08 13:17:45 --> Loader Class Initialized
INFO - 2018-10-08 13:17:45 --> Helper loaded: url_helper
INFO - 2018-10-08 13:17:45 --> Helper loaded: form_helper
INFO - 2018-10-08 13:17:46 --> Database Driver Class Initialized
INFO - 2018-10-08 13:17:46 --> Email Class Initialized
INFO - 2018-10-08 13:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:17:46 --> Form Validation Class Initialized
INFO - 2018-10-08 13:17:46 --> Controller Class Initialized
DEBUG - 2018-10-08 13:17:46 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:17:47 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:17:47 --> Model Class Initialized
DEBUG - 2018-10-08 13:17:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:17:47 --> Final output sent to browser
DEBUG - 2018-10-08 13:17:47 --> Total execution time: 5.0953
INFO - 2018-10-08 13:18:14 --> Config Class Initialized
INFO - 2018-10-08 13:18:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:18:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:18:14 --> Utf8 Class Initialized
INFO - 2018-10-08 13:18:15 --> URI Class Initialized
DEBUG - 2018-10-08 13:18:15 --> No URI present. Default controller set.
INFO - 2018-10-08 13:18:15 --> Router Class Initialized
INFO - 2018-10-08 13:18:15 --> Output Class Initialized
INFO - 2018-10-08 13:18:16 --> Security Class Initialized
DEBUG - 2018-10-08 13:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:18:16 --> Input Class Initialized
INFO - 2018-10-08 13:18:17 --> Language Class Initialized
INFO - 2018-10-08 13:18:17 --> Language Class Initialized
INFO - 2018-10-08 13:18:17 --> Config Class Initialized
INFO - 2018-10-08 13:18:17 --> Loader Class Initialized
INFO - 2018-10-08 13:18:18 --> Helper loaded: url_helper
INFO - 2018-10-08 13:18:18 --> Helper loaded: form_helper
INFO - 2018-10-08 13:18:18 --> Database Driver Class Initialized
INFO - 2018-10-08 13:18:19 --> Email Class Initialized
INFO - 2018-10-08 13:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:18:19 --> Form Validation Class Initialized
INFO - 2018-10-08 13:18:20 --> Controller Class Initialized
DEBUG - 2018-10-08 13:18:20 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:18:20 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:18:20 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:18:21 --> Final output sent to browser
DEBUG - 2018-10-08 13:18:21 --> Total execution time: 7.2104
INFO - 2018-10-08 13:18:29 --> Config Class Initialized
INFO - 2018-10-08 13:18:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:18:29 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:18:29 --> Utf8 Class Initialized
INFO - 2018-10-08 13:18:29 --> URI Class Initialized
DEBUG - 2018-10-08 13:18:30 --> No URI present. Default controller set.
INFO - 2018-10-08 13:18:30 --> Router Class Initialized
INFO - 2018-10-08 13:18:30 --> Output Class Initialized
INFO - 2018-10-08 13:18:30 --> Security Class Initialized
DEBUG - 2018-10-08 13:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:18:31 --> Input Class Initialized
INFO - 2018-10-08 13:18:31 --> Language Class Initialized
INFO - 2018-10-08 13:18:31 --> Language Class Initialized
INFO - 2018-10-08 13:18:31 --> Config Class Initialized
INFO - 2018-10-08 13:18:32 --> Loader Class Initialized
INFO - 2018-10-08 13:18:32 --> Helper loaded: url_helper
INFO - 2018-10-08 13:18:32 --> Helper loaded: form_helper
INFO - 2018-10-08 13:18:32 --> Database Driver Class Initialized
INFO - 2018-10-08 13:18:32 --> Email Class Initialized
INFO - 2018-10-08 13:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:18:33 --> Form Validation Class Initialized
INFO - 2018-10-08 13:18:33 --> Controller Class Initialized
DEBUG - 2018-10-08 13:18:33 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:18:33 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:18:34 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:18:34 --> Final output sent to browser
DEBUG - 2018-10-08 13:18:34 --> Total execution time: 5.4333
INFO - 2018-10-08 13:18:42 --> Config Class Initialized
INFO - 2018-10-08 13:18:43 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:18:43 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:18:43 --> Utf8 Class Initialized
INFO - 2018-10-08 13:18:43 --> URI Class Initialized
DEBUG - 2018-10-08 13:18:43 --> No URI present. Default controller set.
INFO - 2018-10-08 13:18:44 --> Router Class Initialized
INFO - 2018-10-08 13:18:44 --> Output Class Initialized
INFO - 2018-10-08 13:18:44 --> Security Class Initialized
DEBUG - 2018-10-08 13:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:18:45 --> Input Class Initialized
INFO - 2018-10-08 13:18:45 --> Language Class Initialized
INFO - 2018-10-08 13:18:45 --> Language Class Initialized
INFO - 2018-10-08 13:18:46 --> Config Class Initialized
INFO - 2018-10-08 13:18:46 --> Loader Class Initialized
INFO - 2018-10-08 13:18:47 --> Helper loaded: url_helper
INFO - 2018-10-08 13:18:50 --> Config Class Initialized
INFO - 2018-10-08 13:18:53 --> Helper loaded: form_helper
INFO - 2018-10-08 13:18:54 --> Database Driver Class Initialized
INFO - 2018-10-08 13:18:54 --> Email Class Initialized
INFO - 2018-10-08 13:18:54 --> Hooks Class Initialized
INFO - 2018-10-08 13:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:18:55 --> Form Validation Class Initialized
INFO - 2018-10-08 13:18:55 --> Controller Class Initialized
DEBUG - 2018-10-08 13:18:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:18:56 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:18:56 --> Model Class Initialized
DEBUG - 2018-10-08 13:18:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:18:57 --> Final output sent to browser
DEBUG - 2018-10-08 13:18:57 --> Total execution time: 14.2992
DEBUG - 2018-10-08 13:18:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:18:57 --> Utf8 Class Initialized
INFO - 2018-10-08 13:18:58 --> URI Class Initialized
DEBUG - 2018-10-08 13:18:58 --> No URI present. Default controller set.
INFO - 2018-10-08 13:18:58 --> Router Class Initialized
INFO - 2018-10-08 13:18:58 --> Output Class Initialized
INFO - 2018-10-08 13:18:58 --> Security Class Initialized
DEBUG - 2018-10-08 13:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:18:59 --> Input Class Initialized
INFO - 2018-10-08 13:18:59 --> Language Class Initialized
INFO - 2018-10-08 13:18:59 --> Language Class Initialized
INFO - 2018-10-08 13:18:59 --> Config Class Initialized
INFO - 2018-10-08 13:18:59 --> Loader Class Initialized
INFO - 2018-10-08 13:19:00 --> Helper loaded: url_helper
INFO - 2018-10-08 13:19:00 --> Helper loaded: form_helper
INFO - 2018-10-08 13:19:00 --> Database Driver Class Initialized
INFO - 2018-10-08 13:19:00 --> Email Class Initialized
INFO - 2018-10-08 13:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:19:01 --> Form Validation Class Initialized
INFO - 2018-10-08 13:19:01 --> Controller Class Initialized
DEBUG - 2018-10-08 13:19:01 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:19:01 --> Model Class Initialized
DEBUG - 2018-10-08 13:19:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:19:02 --> Model Class Initialized
DEBUG - 2018-10-08 13:19:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:19:02 --> Final output sent to browser
DEBUG - 2018-10-08 13:19:02 --> Total execution time: 12.1607
INFO - 2018-10-08 13:19:13 --> Config Class Initialized
INFO - 2018-10-08 13:19:13 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:19:13 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:19:14 --> Utf8 Class Initialized
INFO - 2018-10-08 13:19:14 --> URI Class Initialized
DEBUG - 2018-10-08 13:19:14 --> No URI present. Default controller set.
INFO - 2018-10-08 13:19:14 --> Router Class Initialized
INFO - 2018-10-08 13:19:15 --> Output Class Initialized
INFO - 2018-10-08 13:19:15 --> Security Class Initialized
DEBUG - 2018-10-08 13:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:19:15 --> Input Class Initialized
INFO - 2018-10-08 13:19:15 --> Language Class Initialized
INFO - 2018-10-08 13:19:16 --> Language Class Initialized
INFO - 2018-10-08 13:19:16 --> Config Class Initialized
INFO - 2018-10-08 13:19:16 --> Loader Class Initialized
INFO - 2018-10-08 13:19:16 --> Helper loaded: url_helper
INFO - 2018-10-08 13:19:16 --> Helper loaded: form_helper
INFO - 2018-10-08 13:19:16 --> Database Driver Class Initialized
INFO - 2018-10-08 13:19:17 --> Email Class Initialized
INFO - 2018-10-08 13:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:19:17 --> Form Validation Class Initialized
INFO - 2018-10-08 13:19:17 --> Controller Class Initialized
DEBUG - 2018-10-08 13:19:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:19:18 --> Model Class Initialized
DEBUG - 2018-10-08 13:19:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:19:18 --> Model Class Initialized
DEBUG - 2018-10-08 13:19:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:19:18 --> Final output sent to browser
DEBUG - 2018-10-08 13:19:18 --> Total execution time: 5.3453
INFO - 2018-10-08 13:24:58 --> Config Class Initialized
INFO - 2018-10-08 13:24:58 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:25:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:25:00 --> Utf8 Class Initialized
INFO - 2018-10-08 13:25:00 --> URI Class Initialized
DEBUG - 2018-10-08 13:25:01 --> No URI present. Default controller set.
INFO - 2018-10-08 13:25:01 --> Router Class Initialized
INFO - 2018-10-08 13:25:01 --> Output Class Initialized
INFO - 2018-10-08 13:25:01 --> Security Class Initialized
DEBUG - 2018-10-08 13:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:25:02 --> Input Class Initialized
INFO - 2018-10-08 13:25:02 --> Language Class Initialized
INFO - 2018-10-08 13:25:02 --> Language Class Initialized
INFO - 2018-10-08 13:25:02 --> Config Class Initialized
INFO - 2018-10-08 13:25:02 --> Loader Class Initialized
INFO - 2018-10-08 13:25:03 --> Helper loaded: url_helper
INFO - 2018-10-08 13:25:03 --> Helper loaded: form_helper
INFO - 2018-10-08 13:25:03 --> Database Driver Class Initialized
INFO - 2018-10-08 13:25:04 --> Email Class Initialized
INFO - 2018-10-08 13:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:25:04 --> Form Validation Class Initialized
INFO - 2018-10-08 13:25:04 --> Controller Class Initialized
DEBUG - 2018-10-08 13:25:05 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:25:05 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:25:05 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:25:06 --> Final output sent to browser
DEBUG - 2018-10-08 13:25:06 --> Total execution time: 8.1225
INFO - 2018-10-08 13:25:12 --> Config Class Initialized
INFO - 2018-10-08 13:25:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:25:13 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:25:13 --> Utf8 Class Initialized
INFO - 2018-10-08 13:25:13 --> URI Class Initialized
DEBUG - 2018-10-08 13:25:13 --> No URI present. Default controller set.
INFO - 2018-10-08 13:25:14 --> Router Class Initialized
INFO - 2018-10-08 13:25:14 --> Output Class Initialized
INFO - 2018-10-08 13:25:14 --> Security Class Initialized
DEBUG - 2018-10-08 13:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:25:14 --> Input Class Initialized
INFO - 2018-10-08 13:25:15 --> Language Class Initialized
INFO - 2018-10-08 13:25:15 --> Language Class Initialized
INFO - 2018-10-08 13:25:15 --> Config Class Initialized
INFO - 2018-10-08 13:25:15 --> Loader Class Initialized
INFO - 2018-10-08 13:25:15 --> Helper loaded: url_helper
INFO - 2018-10-08 13:25:16 --> Helper loaded: form_helper
INFO - 2018-10-08 13:25:16 --> Database Driver Class Initialized
INFO - 2018-10-08 13:25:16 --> Email Class Initialized
INFO - 2018-10-08 13:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:25:16 --> Form Validation Class Initialized
INFO - 2018-10-08 13:25:17 --> Controller Class Initialized
DEBUG - 2018-10-08 13:25:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:25:17 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:25:17 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:25:18 --> Final output sent to browser
DEBUG - 2018-10-08 13:25:18 --> Total execution time: 5.4573
INFO - 2018-10-08 13:25:26 --> Config Class Initialized
INFO - 2018-10-08 13:25:26 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:25:26 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:25:27 --> Utf8 Class Initialized
INFO - 2018-10-08 13:25:27 --> URI Class Initialized
DEBUG - 2018-10-08 13:25:27 --> No URI present. Default controller set.
INFO - 2018-10-08 13:25:27 --> Router Class Initialized
INFO - 2018-10-08 13:25:28 --> Output Class Initialized
INFO - 2018-10-08 13:25:28 --> Security Class Initialized
DEBUG - 2018-10-08 13:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:25:29 --> Input Class Initialized
INFO - 2018-10-08 13:25:29 --> Language Class Initialized
INFO - 2018-10-08 13:25:29 --> Language Class Initialized
INFO - 2018-10-08 13:25:29 --> Config Class Initialized
INFO - 2018-10-08 13:25:30 --> Loader Class Initialized
INFO - 2018-10-08 13:25:30 --> Helper loaded: url_helper
INFO - 2018-10-08 13:25:30 --> Helper loaded: form_helper
INFO - 2018-10-08 13:25:30 --> Database Driver Class Initialized
INFO - 2018-10-08 13:25:31 --> Email Class Initialized
INFO - 2018-10-08 13:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:25:31 --> Form Validation Class Initialized
INFO - 2018-10-08 13:25:31 --> Controller Class Initialized
DEBUG - 2018-10-08 13:25:31 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:25:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:25:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:25:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:25:32 --> Final output sent to browser
DEBUG - 2018-10-08 13:25:32 --> Total execution time: 6.2864
INFO - 2018-10-08 13:36:53 --> Config Class Initialized
INFO - 2018-10-08 13:36:53 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:36:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:36:54 --> Utf8 Class Initialized
INFO - 2018-10-08 13:36:54 --> URI Class Initialized
DEBUG - 2018-10-08 13:36:55 --> No URI present. Default controller set.
INFO - 2018-10-08 13:36:55 --> Router Class Initialized
INFO - 2018-10-08 13:36:55 --> Output Class Initialized
INFO - 2018-10-08 13:36:55 --> Security Class Initialized
DEBUG - 2018-10-08 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:36:56 --> Input Class Initialized
INFO - 2018-10-08 13:36:56 --> Language Class Initialized
INFO - 2018-10-08 13:36:56 --> Language Class Initialized
INFO - 2018-10-08 13:36:57 --> Config Class Initialized
INFO - 2018-10-08 13:36:57 --> Loader Class Initialized
INFO - 2018-10-08 13:36:57 --> Helper loaded: url_helper
INFO - 2018-10-08 13:36:58 --> Helper loaded: form_helper
INFO - 2018-10-08 13:36:58 --> Database Driver Class Initialized
INFO - 2018-10-08 13:36:58 --> Email Class Initialized
INFO - 2018-10-08 13:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:36:59 --> Form Validation Class Initialized
INFO - 2018-10-08 13:36:59 --> Controller Class Initialized
DEBUG - 2018-10-08 13:36:59 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:37:00 --> Model Class Initialized
DEBUG - 2018-10-08 13:37:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:37:00 --> Model Class Initialized
DEBUG - 2018-10-08 13:37:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:37:01 --> Final output sent to browser
DEBUG - 2018-10-08 13:37:01 --> Total execution time: 7.4354
INFO - 2018-10-08 13:44:43 --> Config Class Initialized
INFO - 2018-10-08 13:44:43 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:44:45 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:44:45 --> Utf8 Class Initialized
INFO - 2018-10-08 13:44:45 --> URI Class Initialized
DEBUG - 2018-10-08 13:44:46 --> No URI present. Default controller set.
INFO - 2018-10-08 13:44:46 --> Router Class Initialized
INFO - 2018-10-08 13:44:46 --> Output Class Initialized
INFO - 2018-10-08 13:44:46 --> Security Class Initialized
DEBUG - 2018-10-08 13:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:44:47 --> Input Class Initialized
INFO - 2018-10-08 13:44:47 --> Language Class Initialized
INFO - 2018-10-08 13:44:48 --> Language Class Initialized
INFO - 2018-10-08 13:44:48 --> Config Class Initialized
INFO - 2018-10-08 13:44:48 --> Loader Class Initialized
INFO - 2018-10-08 13:44:48 --> Helper loaded: url_helper
INFO - 2018-10-08 13:44:49 --> Helper loaded: form_helper
INFO - 2018-10-08 13:44:49 --> Database Driver Class Initialized
INFO - 2018-10-08 13:44:49 --> Email Class Initialized
INFO - 2018-10-08 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:44:50 --> Form Validation Class Initialized
INFO - 2018-10-08 13:44:50 --> Controller Class Initialized
DEBUG - 2018-10-08 13:44:50 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:44:50 --> Model Class Initialized
DEBUG - 2018-10-08 13:44:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:44:51 --> Model Class Initialized
DEBUG - 2018-10-08 13:44:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:44:51 --> Final output sent to browser
DEBUG - 2018-10-08 13:44:52 --> Total execution time: 8.9595
INFO - 2018-10-08 13:45:01 --> Config Class Initialized
INFO - 2018-10-08 13:45:01 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:45:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:45:02 --> Utf8 Class Initialized
INFO - 2018-10-08 13:45:02 --> URI Class Initialized
DEBUG - 2018-10-08 13:45:02 --> No URI present. Default controller set.
INFO - 2018-10-08 13:45:03 --> Router Class Initialized
INFO - 2018-10-08 13:45:03 --> Output Class Initialized
INFO - 2018-10-08 13:45:03 --> Security Class Initialized
DEBUG - 2018-10-08 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:45:03 --> Input Class Initialized
INFO - 2018-10-08 13:45:04 --> Language Class Initialized
INFO - 2018-10-08 13:45:04 --> Language Class Initialized
INFO - 2018-10-08 13:45:04 --> Config Class Initialized
INFO - 2018-10-08 13:45:04 --> Loader Class Initialized
INFO - 2018-10-08 13:45:04 --> Helper loaded: url_helper
INFO - 2018-10-08 13:45:05 --> Helper loaded: form_helper
INFO - 2018-10-08 13:45:05 --> Database Driver Class Initialized
INFO - 2018-10-08 13:45:05 --> Email Class Initialized
INFO - 2018-10-08 13:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:45:05 --> Form Validation Class Initialized
INFO - 2018-10-08 13:45:06 --> Controller Class Initialized
DEBUG - 2018-10-08 13:45:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:45:06 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:45:06 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:45:07 --> Final output sent to browser
DEBUG - 2018-10-08 13:45:07 --> Total execution time: 5.5393
INFO - 2018-10-08 13:45:16 --> Config Class Initialized
INFO - 2018-10-08 13:45:16 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:45:16 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:45:17 --> Utf8 Class Initialized
INFO - 2018-10-08 13:45:17 --> URI Class Initialized
DEBUG - 2018-10-08 13:45:17 --> No URI present. Default controller set.
INFO - 2018-10-08 13:45:18 --> Router Class Initialized
INFO - 2018-10-08 13:45:18 --> Output Class Initialized
INFO - 2018-10-08 13:45:18 --> Security Class Initialized
DEBUG - 2018-10-08 13:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:45:18 --> Input Class Initialized
INFO - 2018-10-08 13:45:19 --> Language Class Initialized
INFO - 2018-10-08 13:45:19 --> Language Class Initialized
INFO - 2018-10-08 13:45:19 --> Config Class Initialized
INFO - 2018-10-08 13:45:20 --> Loader Class Initialized
INFO - 2018-10-08 13:45:20 --> Helper loaded: url_helper
INFO - 2018-10-08 13:45:20 --> Helper loaded: form_helper
INFO - 2018-10-08 13:45:20 --> Database Driver Class Initialized
INFO - 2018-10-08 13:45:20 --> Email Class Initialized
INFO - 2018-10-08 13:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:45:21 --> Form Validation Class Initialized
INFO - 2018-10-08 13:45:21 --> Controller Class Initialized
DEBUG - 2018-10-08 13:45:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:45:21 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:45:22 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:45:22 --> Final output sent to browser
DEBUG - 2018-10-08 13:45:22 --> Total execution time: 6.0913
INFO - 2018-10-08 13:45:41 --> Config Class Initialized
INFO - 2018-10-08 13:45:41 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:45:41 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:45:41 --> Utf8 Class Initialized
INFO - 2018-10-08 13:45:41 --> URI Class Initialized
DEBUG - 2018-10-08 13:45:42 --> No URI present. Default controller set.
INFO - 2018-10-08 13:45:42 --> Router Class Initialized
INFO - 2018-10-08 13:45:42 --> Output Class Initialized
INFO - 2018-10-08 13:45:42 --> Security Class Initialized
DEBUG - 2018-10-08 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:45:43 --> Input Class Initialized
INFO - 2018-10-08 13:45:43 --> Language Class Initialized
INFO - 2018-10-08 13:45:43 --> Language Class Initialized
INFO - 2018-10-08 13:45:43 --> Config Class Initialized
INFO - 2018-10-08 13:45:44 --> Loader Class Initialized
INFO - 2018-10-08 13:45:44 --> Helper loaded: url_helper
INFO - 2018-10-08 13:45:44 --> Helper loaded: form_helper
INFO - 2018-10-08 13:45:44 --> Database Driver Class Initialized
INFO - 2018-10-08 13:45:44 --> Config Class Initialized
INFO - 2018-10-08 13:45:44 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:45:45 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:45:45 --> Utf8 Class Initialized
INFO - 2018-10-08 13:45:45 --> URI Class Initialized
DEBUG - 2018-10-08 13:45:45 --> No URI present. Default controller set.
INFO - 2018-10-08 13:45:45 --> Router Class Initialized
INFO - 2018-10-08 13:45:46 --> Email Class Initialized
INFO - 2018-10-08 13:45:46 --> Output Class Initialized
INFO - 2018-10-08 13:45:46 --> Security Class Initialized
DEBUG - 2018-10-08 13:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:45:46 --> Input Class Initialized
INFO - 2018-10-08 13:45:47 --> Language Class Initialized
INFO - 2018-10-08 13:45:47 --> Language Class Initialized
INFO - 2018-10-08 13:45:47 --> Config Class Initialized
INFO - 2018-10-08 13:45:47 --> Loader Class Initialized
INFO - 2018-10-08 13:45:47 --> Helper loaded: url_helper
INFO - 2018-10-08 13:45:48 --> Helper loaded: form_helper
INFO - 2018-10-08 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:45:48 --> Database Driver Class Initialized
INFO - 2018-10-08 13:45:48 --> Email Class Initialized
INFO - 2018-10-08 13:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:45:49 --> Form Validation Class Initialized
INFO - 2018-10-08 13:45:49 --> Form Validation Class Initialized
INFO - 2018-10-08 13:45:49 --> Controller Class Initialized
DEBUG - 2018-10-08 13:45:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:45:49 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:45:50 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:45:50 --> Final output sent to browser
DEBUG - 2018-10-08 13:45:50 --> Total execution time: 5.8493
INFO - 2018-10-08 13:45:50 --> Controller Class Initialized
DEBUG - 2018-10-08 13:45:52 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:45:52 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:45:53 --> Model Class Initialized
DEBUG - 2018-10-08 13:45:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:45:53 --> Final output sent to browser
DEBUG - 2018-10-08 13:45:53 --> Total execution time: 12.5487
INFO - 2018-10-08 13:46:00 --> Config Class Initialized
INFO - 2018-10-08 13:46:00 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:46:01 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:46:01 --> Utf8 Class Initialized
INFO - 2018-10-08 13:46:02 --> URI Class Initialized
DEBUG - 2018-10-08 13:46:02 --> No URI present. Default controller set.
INFO - 2018-10-08 13:46:02 --> Router Class Initialized
INFO - 2018-10-08 13:46:03 --> Output Class Initialized
INFO - 2018-10-08 13:46:03 --> Security Class Initialized
DEBUG - 2018-10-08 13:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:46:03 --> Input Class Initialized
INFO - 2018-10-08 13:46:03 --> Language Class Initialized
INFO - 2018-10-08 13:46:04 --> Language Class Initialized
INFO - 2018-10-08 13:46:04 --> Config Class Initialized
INFO - 2018-10-08 13:46:04 --> Loader Class Initialized
INFO - 2018-10-08 13:46:04 --> Helper loaded: url_helper
INFO - 2018-10-08 13:46:05 --> Helper loaded: form_helper
INFO - 2018-10-08 13:46:05 --> Database Driver Class Initialized
INFO - 2018-10-08 13:46:05 --> Email Class Initialized
INFO - 2018-10-08 13:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:46:06 --> Form Validation Class Initialized
INFO - 2018-10-08 13:46:06 --> Controller Class Initialized
DEBUG - 2018-10-08 13:46:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:46:06 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:46:07 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:46:07 --> Final output sent to browser
DEBUG - 2018-10-08 13:46:07 --> Total execution time: 6.8757
INFO - 2018-10-08 13:46:08 --> Config Class Initialized
INFO - 2018-10-08 13:46:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:46:09 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:46:09 --> Utf8 Class Initialized
INFO - 2018-10-08 13:46:09 --> URI Class Initialized
DEBUG - 2018-10-08 13:46:09 --> No URI present. Default controller set.
INFO - 2018-10-08 13:46:10 --> Router Class Initialized
INFO - 2018-10-08 13:46:10 --> Output Class Initialized
INFO - 2018-10-08 13:46:10 --> Security Class Initialized
DEBUG - 2018-10-08 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:46:11 --> Input Class Initialized
INFO - 2018-10-08 13:46:11 --> Language Class Initialized
INFO - 2018-10-08 13:46:11 --> Language Class Initialized
INFO - 2018-10-08 13:46:12 --> Config Class Initialized
INFO - 2018-10-08 13:46:12 --> Loader Class Initialized
INFO - 2018-10-08 13:46:12 --> Helper loaded: url_helper
INFO - 2018-10-08 13:46:13 --> Helper loaded: form_helper
INFO - 2018-10-08 13:46:13 --> Database Driver Class Initialized
INFO - 2018-10-08 13:46:13 --> Email Class Initialized
INFO - 2018-10-08 13:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:46:14 --> Form Validation Class Initialized
INFO - 2018-10-08 13:46:14 --> Controller Class Initialized
DEBUG - 2018-10-08 13:46:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:46:14 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:46:15 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:46:15 --> Final output sent to browser
DEBUG - 2018-10-08 13:46:15 --> Total execution time: 7.6884
INFO - 2018-10-08 13:46:25 --> Config Class Initialized
INFO - 2018-10-08 13:46:25 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:46:25 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:46:25 --> Utf8 Class Initialized
INFO - 2018-10-08 13:46:26 --> URI Class Initialized
DEBUG - 2018-10-08 13:46:26 --> No URI present. Default controller set.
INFO - 2018-10-08 13:46:26 --> Router Class Initialized
INFO - 2018-10-08 13:46:26 --> Output Class Initialized
INFO - 2018-10-08 13:46:27 --> Security Class Initialized
DEBUG - 2018-10-08 13:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:46:27 --> Input Class Initialized
INFO - 2018-10-08 13:46:27 --> Language Class Initialized
INFO - 2018-10-08 13:46:27 --> Language Class Initialized
INFO - 2018-10-08 13:46:28 --> Config Class Initialized
INFO - 2018-10-08 13:46:28 --> Loader Class Initialized
INFO - 2018-10-08 13:46:28 --> Helper loaded: url_helper
INFO - 2018-10-08 13:46:28 --> Helper loaded: form_helper
INFO - 2018-10-08 13:46:28 --> Database Driver Class Initialized
INFO - 2018-10-08 13:46:29 --> Email Class Initialized
INFO - 2018-10-08 13:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:46:29 --> Form Validation Class Initialized
INFO - 2018-10-08 13:46:29 --> Controller Class Initialized
DEBUG - 2018-10-08 13:46:30 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:46:30 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:46:30 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:46:31 --> Final output sent to browser
DEBUG - 2018-10-08 13:46:31 --> Total execution time: 5.8553
INFO - 2018-10-08 13:46:50 --> Config Class Initialized
INFO - 2018-10-08 13:46:50 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:46:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:46:51 --> Utf8 Class Initialized
INFO - 2018-10-08 13:46:51 --> URI Class Initialized
DEBUG - 2018-10-08 13:46:51 --> No URI present. Default controller set.
INFO - 2018-10-08 13:46:52 --> Router Class Initialized
INFO - 2018-10-08 13:46:52 --> Output Class Initialized
INFO - 2018-10-08 13:46:52 --> Security Class Initialized
DEBUG - 2018-10-08 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:46:53 --> Input Class Initialized
INFO - 2018-10-08 13:46:53 --> Language Class Initialized
INFO - 2018-10-08 13:46:53 --> Language Class Initialized
INFO - 2018-10-08 13:46:53 --> Config Class Initialized
INFO - 2018-10-08 13:46:54 --> Loader Class Initialized
INFO - 2018-10-08 13:46:54 --> Helper loaded: url_helper
INFO - 2018-10-08 13:46:54 --> Helper loaded: form_helper
INFO - 2018-10-08 13:46:54 --> Database Driver Class Initialized
INFO - 2018-10-08 13:46:55 --> Email Class Initialized
INFO - 2018-10-08 13:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:46:55 --> Form Validation Class Initialized
INFO - 2018-10-08 13:46:56 --> Controller Class Initialized
DEBUG - 2018-10-08 13:46:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:46:56 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:46:57 --> Model Class Initialized
DEBUG - 2018-10-08 13:46:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:46:57 --> Final output sent to browser
DEBUG - 2018-10-08 13:46:57 --> Total execution time: 7.5914
INFO - 2018-10-08 13:47:05 --> Config Class Initialized
INFO - 2018-10-08 13:47:05 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:47:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:47:06 --> Utf8 Class Initialized
INFO - 2018-10-08 13:47:06 --> URI Class Initialized
DEBUG - 2018-10-08 13:47:06 --> No URI present. Default controller set.
INFO - 2018-10-08 13:47:06 --> Router Class Initialized
INFO - 2018-10-08 13:47:07 --> Output Class Initialized
INFO - 2018-10-08 13:47:07 --> Security Class Initialized
DEBUG - 2018-10-08 13:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:47:07 --> Input Class Initialized
INFO - 2018-10-08 13:47:08 --> Language Class Initialized
INFO - 2018-10-08 13:47:08 --> Language Class Initialized
INFO - 2018-10-08 13:47:08 --> Config Class Initialized
INFO - 2018-10-08 13:47:08 --> Loader Class Initialized
INFO - 2018-10-08 13:47:08 --> Helper loaded: url_helper
INFO - 2018-10-08 13:47:09 --> Helper loaded: form_helper
INFO - 2018-10-08 13:47:09 --> Database Driver Class Initialized
INFO - 2018-10-08 13:47:09 --> Email Class Initialized
INFO - 2018-10-08 13:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:47:09 --> Form Validation Class Initialized
INFO - 2018-10-08 13:47:10 --> Controller Class Initialized
DEBUG - 2018-10-08 13:47:10 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:47:10 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:47:10 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:47:11 --> Final output sent to browser
DEBUG - 2018-10-08 13:47:11 --> Total execution time: 5.7613
INFO - 2018-10-08 13:47:17 --> Config Class Initialized
INFO - 2018-10-08 13:47:17 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:47:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:47:17 --> Utf8 Class Initialized
INFO - 2018-10-08 13:47:18 --> URI Class Initialized
DEBUG - 2018-10-08 13:47:18 --> No URI present. Default controller set.
INFO - 2018-10-08 13:47:18 --> Router Class Initialized
INFO - 2018-10-08 13:47:18 --> Output Class Initialized
INFO - 2018-10-08 13:47:18 --> Security Class Initialized
DEBUG - 2018-10-08 13:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:47:19 --> Input Class Initialized
INFO - 2018-10-08 13:47:19 --> Language Class Initialized
INFO - 2018-10-08 13:47:19 --> Language Class Initialized
INFO - 2018-10-08 13:47:19 --> Config Class Initialized
INFO - 2018-10-08 13:47:20 --> Loader Class Initialized
INFO - 2018-10-08 13:47:20 --> Helper loaded: url_helper
INFO - 2018-10-08 13:47:20 --> Helper loaded: form_helper
INFO - 2018-10-08 13:47:20 --> Database Driver Class Initialized
INFO - 2018-10-08 13:47:20 --> Email Class Initialized
INFO - 2018-10-08 13:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:47:21 --> Form Validation Class Initialized
INFO - 2018-10-08 13:47:21 --> Controller Class Initialized
DEBUG - 2018-10-08 13:47:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:47:22 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:47:22 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:47:22 --> Final output sent to browser
DEBUG - 2018-10-08 13:47:23 --> Total execution time: 5.8043
INFO - 2018-10-08 13:47:32 --> Config Class Initialized
INFO - 2018-10-08 13:47:32 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:47:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:47:33 --> Utf8 Class Initialized
INFO - 2018-10-08 13:47:33 --> URI Class Initialized
DEBUG - 2018-10-08 13:47:34 --> No URI present. Default controller set.
INFO - 2018-10-08 13:47:34 --> Router Class Initialized
INFO - 2018-10-08 13:47:34 --> Output Class Initialized
INFO - 2018-10-08 13:47:34 --> Security Class Initialized
DEBUG - 2018-10-08 13:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:47:35 --> Input Class Initialized
INFO - 2018-10-08 13:47:36 --> Language Class Initialized
INFO - 2018-10-08 13:47:36 --> Language Class Initialized
INFO - 2018-10-08 13:47:36 --> Config Class Initialized
INFO - 2018-10-08 13:47:36 --> Loader Class Initialized
INFO - 2018-10-08 13:47:37 --> Helper loaded: url_helper
INFO - 2018-10-08 13:47:37 --> Helper loaded: form_helper
INFO - 2018-10-08 13:47:37 --> Database Driver Class Initialized
INFO - 2018-10-08 13:47:39 --> Email Class Initialized
INFO - 2018-10-08 13:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:47:39 --> Form Validation Class Initialized
INFO - 2018-10-08 13:47:39 --> Controller Class Initialized
DEBUG - 2018-10-08 13:47:40 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:47:40 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:47:41 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:47:42 --> Final output sent to browser
DEBUG - 2018-10-08 13:47:42 --> Total execution time: 9.6486
INFO - 2018-10-08 13:47:48 --> Config Class Initialized
INFO - 2018-10-08 13:47:48 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:47:49 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:47:49 --> Utf8 Class Initialized
INFO - 2018-10-08 13:47:49 --> URI Class Initialized
DEBUG - 2018-10-08 13:47:49 --> No URI present. Default controller set.
INFO - 2018-10-08 13:47:49 --> Router Class Initialized
INFO - 2018-10-08 13:47:50 --> Output Class Initialized
INFO - 2018-10-08 13:47:50 --> Security Class Initialized
DEBUG - 2018-10-08 13:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:47:50 --> Input Class Initialized
INFO - 2018-10-08 13:47:50 --> Language Class Initialized
INFO - 2018-10-08 13:47:51 --> Language Class Initialized
INFO - 2018-10-08 13:47:51 --> Config Class Initialized
INFO - 2018-10-08 13:47:51 --> Loader Class Initialized
INFO - 2018-10-08 13:47:51 --> Helper loaded: url_helper
INFO - 2018-10-08 13:47:52 --> Helper loaded: form_helper
INFO - 2018-10-08 13:47:52 --> Database Driver Class Initialized
INFO - 2018-10-08 13:47:52 --> Email Class Initialized
INFO - 2018-10-08 13:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:47:52 --> Form Validation Class Initialized
INFO - 2018-10-08 13:47:53 --> Controller Class Initialized
DEBUG - 2018-10-08 13:47:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:47:53 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:47:53 --> Model Class Initialized
DEBUG - 2018-10-08 13:47:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:47:54 --> Final output sent to browser
DEBUG - 2018-10-08 13:47:54 --> Total execution time: 5.5633
INFO - 2018-10-08 13:49:04 --> Config Class Initialized
INFO - 2018-10-08 13:49:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:49:07 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:49:08 --> Utf8 Class Initialized
INFO - 2018-10-08 13:49:08 --> URI Class Initialized
DEBUG - 2018-10-08 13:49:08 --> No URI present. Default controller set.
INFO - 2018-10-08 13:49:09 --> Router Class Initialized
INFO - 2018-10-08 13:49:09 --> Output Class Initialized
INFO - 2018-10-08 13:49:10 --> Security Class Initialized
DEBUG - 2018-10-08 13:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:49:11 --> Input Class Initialized
INFO - 2018-10-08 13:49:11 --> Language Class Initialized
INFO - 2018-10-08 13:49:11 --> Language Class Initialized
INFO - 2018-10-08 13:49:11 --> Config Class Initialized
INFO - 2018-10-08 13:49:12 --> Loader Class Initialized
INFO - 2018-10-08 13:49:12 --> Helper loaded: url_helper
INFO - 2018-10-08 13:49:12 --> Helper loaded: form_helper
INFO - 2018-10-08 13:49:12 --> Database Driver Class Initialized
INFO - 2018-10-08 13:49:13 --> Email Class Initialized
INFO - 2018-10-08 13:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:49:13 --> Form Validation Class Initialized
INFO - 2018-10-08 13:49:13 --> Controller Class Initialized
DEBUG - 2018-10-08 13:49:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:49:14 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:49:14 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:49:15 --> Final output sent to browser
DEBUG - 2018-10-08 13:49:15 --> Total execution time: 10.8846
INFO - 2018-10-08 13:49:27 --> Config Class Initialized
INFO - 2018-10-08 13:49:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:49:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:49:27 --> Utf8 Class Initialized
INFO - 2018-10-08 13:49:27 --> URI Class Initialized
DEBUG - 2018-10-08 13:49:28 --> No URI present. Default controller set.
INFO - 2018-10-08 13:49:28 --> Router Class Initialized
INFO - 2018-10-08 13:49:28 --> Output Class Initialized
INFO - 2018-10-08 13:49:28 --> Security Class Initialized
DEBUG - 2018-10-08 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:49:29 --> Input Class Initialized
INFO - 2018-10-08 13:49:29 --> Language Class Initialized
INFO - 2018-10-08 13:49:29 --> Language Class Initialized
INFO - 2018-10-08 13:49:29 --> Config Class Initialized
INFO - 2018-10-08 13:49:30 --> Loader Class Initialized
INFO - 2018-10-08 13:49:30 --> Helper loaded: url_helper
INFO - 2018-10-08 13:49:30 --> Helper loaded: form_helper
INFO - 2018-10-08 13:49:30 --> Database Driver Class Initialized
INFO - 2018-10-08 13:49:30 --> Email Class Initialized
INFO - 2018-10-08 13:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:49:31 --> Form Validation Class Initialized
INFO - 2018-10-08 13:49:31 --> Controller Class Initialized
DEBUG - 2018-10-08 13:49:31 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:49:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:49:32 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:49:32 --> Final output sent to browser
DEBUG - 2018-10-08 13:49:33 --> Total execution time: 5.8003
INFO - 2018-10-08 13:49:41 --> Config Class Initialized
INFO - 2018-10-08 13:49:41 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:49:42 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:49:42 --> Utf8 Class Initialized
INFO - 2018-10-08 13:49:42 --> URI Class Initialized
DEBUG - 2018-10-08 13:49:43 --> No URI present. Default controller set.
INFO - 2018-10-08 13:49:43 --> Router Class Initialized
INFO - 2018-10-08 13:49:43 --> Output Class Initialized
INFO - 2018-10-08 13:49:44 --> Security Class Initialized
DEBUG - 2018-10-08 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:49:44 --> Input Class Initialized
INFO - 2018-10-08 13:49:44 --> Language Class Initialized
INFO - 2018-10-08 13:49:44 --> Language Class Initialized
INFO - 2018-10-08 13:49:45 --> Config Class Initialized
INFO - 2018-10-08 13:49:45 --> Loader Class Initialized
INFO - 2018-10-08 13:49:45 --> Helper loaded: url_helper
INFO - 2018-10-08 13:49:45 --> Helper loaded: form_helper
INFO - 2018-10-08 13:49:46 --> Database Driver Class Initialized
INFO - 2018-10-08 13:49:46 --> Email Class Initialized
INFO - 2018-10-08 13:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:49:46 --> Form Validation Class Initialized
INFO - 2018-10-08 13:49:46 --> Controller Class Initialized
DEBUG - 2018-10-08 13:49:47 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:49:47 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:49:47 --> Model Class Initialized
DEBUG - 2018-10-08 13:49:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:49:48 --> Final output sent to browser
DEBUG - 2018-10-08 13:49:48 --> Total execution time: 6.4374
INFO - 2018-10-08 13:53:02 --> Config Class Initialized
INFO - 2018-10-08 13:53:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:53:03 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:53:04 --> Utf8 Class Initialized
INFO - 2018-10-08 13:53:04 --> URI Class Initialized
DEBUG - 2018-10-08 13:53:04 --> No URI present. Default controller set.
INFO - 2018-10-08 13:53:05 --> Router Class Initialized
INFO - 2018-10-08 13:53:05 --> Output Class Initialized
INFO - 2018-10-08 13:53:05 --> Security Class Initialized
DEBUG - 2018-10-08 13:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:53:06 --> Input Class Initialized
INFO - 2018-10-08 13:53:06 --> Language Class Initialized
INFO - 2018-10-08 13:53:06 --> Language Class Initialized
INFO - 2018-10-08 13:53:07 --> Config Class Initialized
INFO - 2018-10-08 13:53:07 --> Loader Class Initialized
INFO - 2018-10-08 13:53:07 --> Helper loaded: url_helper
INFO - 2018-10-08 13:53:08 --> Helper loaded: form_helper
INFO - 2018-10-08 13:53:08 --> Database Driver Class Initialized
INFO - 2018-10-08 13:53:08 --> Email Class Initialized
INFO - 2018-10-08 13:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:53:09 --> Form Validation Class Initialized
INFO - 2018-10-08 13:53:09 --> Controller Class Initialized
DEBUG - 2018-10-08 13:53:09 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:53:10 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:53:10 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:53:11 --> Final output sent to browser
DEBUG - 2018-10-08 13:53:11 --> Total execution time: 8.2775
INFO - 2018-10-08 13:53:27 --> Config Class Initialized
INFO - 2018-10-08 13:53:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:53:27 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:53:27 --> Utf8 Class Initialized
INFO - 2018-10-08 13:53:28 --> URI Class Initialized
INFO - 2018-10-08 13:53:28 --> Router Class Initialized
INFO - 2018-10-08 13:53:29 --> Output Class Initialized
INFO - 2018-10-08 13:53:29 --> Config Class Initialized
INFO - 2018-10-08 13:53:29 --> Hooks Class Initialized
INFO - 2018-10-08 13:53:29 --> Security Class Initialized
DEBUG - 2018-10-08 13:53:29 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:53:29 --> Utf8 Class Initialized
INFO - 2018-10-08 13:53:30 --> URI Class Initialized
DEBUG - 2018-10-08 13:53:30 --> No URI present. Default controller set.
INFO - 2018-10-08 13:53:30 --> Router Class Initialized
INFO - 2018-10-08 13:53:30 --> Output Class Initialized
DEBUG - 2018-10-08 13:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:53:31 --> Input Class Initialized
INFO - 2018-10-08 13:53:31 --> Security Class Initialized
DEBUG - 2018-10-08 13:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:53:31 --> Input Class Initialized
INFO - 2018-10-08 13:53:32 --> Language Class Initialized
INFO - 2018-10-08 13:53:32 --> Language Class Initialized
INFO - 2018-10-08 13:53:32 --> Language Class Initialized
INFO - 2018-10-08 13:53:32 --> Config Class Initialized
INFO - 2018-10-08 13:53:32 --> Loader Class Initialized
INFO - 2018-10-08 13:53:33 --> Helper loaded: url_helper
INFO - 2018-10-08 13:53:33 --> Helper loaded: form_helper
INFO - 2018-10-08 13:53:33 --> Database Driver Class Initialized
INFO - 2018-10-08 13:53:33 --> Email Class Initialized
INFO - 2018-10-08 13:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:53:34 --> Form Validation Class Initialized
INFO - 2018-10-08 13:53:34 --> Controller Class Initialized
DEBUG - 2018-10-08 13:53:34 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:53:34 --> Model Class Initialized
INFO - 2018-10-08 13:53:34 --> Language Class Initialized
INFO - 2018-10-08 13:53:35 --> Config Class Initialized
DEBUG - 2018-10-08 13:53:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:53:35 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:53:35 --> Final output sent to browser
INFO - 2018-10-08 13:53:36 --> Loader Class Initialized
INFO - 2018-10-08 13:53:36 --> Helper loaded: url_helper
INFO - 2018-10-08 13:53:36 --> Helper loaded: form_helper
INFO - 2018-10-08 13:53:36 --> Database Driver Class Initialized
DEBUG - 2018-10-08 13:53:36 --> Total execution time: 7.0144
INFO - 2018-10-08 13:53:37 --> Email Class Initialized
INFO - 2018-10-08 13:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:53:39 --> Form Validation Class Initialized
INFO - 2018-10-08 13:53:39 --> Controller Class Initialized
DEBUG - 2018-10-08 13:53:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:53:39 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 13:53:40 --> Model Class Initialized
ERROR - 2018-10-08 13:53:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\system\database\DB_query_builder.php 662
ERROR - 2018-10-08 13:53:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '9 = ''
WHERE `id` = `Array`' at line 1 - Invalid query: UPDATE `person` SET 9 = ''
WHERE `id` = `Array`
INFO - 2018-10-08 13:53:42 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-08 13:53:45 --> Config Class Initialized
INFO - 2018-10-08 13:53:45 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:53:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:53:46 --> Utf8 Class Initialized
INFO - 2018-10-08 13:53:46 --> URI Class Initialized
DEBUG - 2018-10-08 13:53:47 --> No URI present. Default controller set.
INFO - 2018-10-08 13:53:47 --> Router Class Initialized
INFO - 2018-10-08 13:53:47 --> Output Class Initialized
INFO - 2018-10-08 13:53:48 --> Security Class Initialized
DEBUG - 2018-10-08 13:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:53:49 --> Input Class Initialized
INFO - 2018-10-08 13:53:49 --> Language Class Initialized
INFO - 2018-10-08 13:53:49 --> Language Class Initialized
INFO - 2018-10-08 13:53:50 --> Config Class Initialized
INFO - 2018-10-08 13:53:50 --> Loader Class Initialized
INFO - 2018-10-08 13:53:50 --> Helper loaded: url_helper
INFO - 2018-10-08 13:53:51 --> Helper loaded: form_helper
INFO - 2018-10-08 13:53:51 --> Database Driver Class Initialized
INFO - 2018-10-08 13:53:52 --> Email Class Initialized
INFO - 2018-10-08 13:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:53:52 --> Form Validation Class Initialized
INFO - 2018-10-08 13:53:53 --> Controller Class Initialized
DEBUG - 2018-10-08 13:53:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:53:53 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:53:54 --> Model Class Initialized
DEBUG - 2018-10-08 13:53:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:53:55 --> Final output sent to browser
DEBUG - 2018-10-08 13:53:55 --> Total execution time: 9.7596
INFO - 2018-10-08 13:54:35 --> Config Class Initialized
INFO - 2018-10-08 13:54:35 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:54:37 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:54:37 --> Utf8 Class Initialized
INFO - 2018-10-08 13:54:38 --> URI Class Initialized
DEBUG - 2018-10-08 13:54:38 --> No URI present. Default controller set.
INFO - 2018-10-08 13:54:39 --> Router Class Initialized
INFO - 2018-10-08 13:54:39 --> Output Class Initialized
INFO - 2018-10-08 13:54:39 --> Security Class Initialized
DEBUG - 2018-10-08 13:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:54:40 --> Input Class Initialized
INFO - 2018-10-08 13:54:41 --> Language Class Initialized
INFO - 2018-10-08 13:54:41 --> Language Class Initialized
INFO - 2018-10-08 13:54:41 --> Config Class Initialized
INFO - 2018-10-08 13:54:42 --> Loader Class Initialized
INFO - 2018-10-08 13:54:42 --> Helper loaded: url_helper
INFO - 2018-10-08 13:54:42 --> Helper loaded: form_helper
INFO - 2018-10-08 13:54:43 --> Database Driver Class Initialized
INFO - 2018-10-08 13:54:43 --> Email Class Initialized
INFO - 2018-10-08 13:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:54:43 --> Form Validation Class Initialized
INFO - 2018-10-08 13:54:44 --> Controller Class Initialized
DEBUG - 2018-10-08 13:54:44 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:54:44 --> Model Class Initialized
DEBUG - 2018-10-08 13:54:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:54:45 --> Model Class Initialized
DEBUG - 2018-10-08 13:54:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:54:46 --> Final output sent to browser
DEBUG - 2018-10-08 13:54:46 --> Total execution time: 10.6286
INFO - 2018-10-08 13:55:27 --> Config Class Initialized
INFO - 2018-10-08 13:55:27 --> Hooks Class Initialized
INFO - 2018-10-08 13:55:27 --> Config Class Initialized
INFO - 2018-10-08 13:55:27 --> Config Class Initialized
INFO - 2018-10-08 13:55:28 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:55:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:55:28 --> Utf8 Class Initialized
DEBUG - 2018-10-08 13:55:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:55:29 --> URI Class Initialized
INFO - 2018-10-08 13:55:29 --> Router Class Initialized
INFO - 2018-10-08 13:55:29 --> Output Class Initialized
INFO - 2018-10-08 13:55:29 --> Utf8 Class Initialized
INFO - 2018-10-08 13:55:29 --> Security Class Initialized
INFO - 2018-10-08 13:55:30 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:55:30 --> Input Class Initialized
INFO - 2018-10-08 13:55:30 --> Language Class Initialized
INFO - 2018-10-08 13:55:31 --> Language Class Initialized
INFO - 2018-10-08 13:55:31 --> Config Class Initialized
INFO - 2018-10-08 13:55:31 --> Loader Class Initialized
INFO - 2018-10-08 13:55:31 --> Helper loaded: url_helper
INFO - 2018-10-08 13:55:31 --> URI Class Initialized
INFO - 2018-10-08 13:55:32 --> Helper loaded: form_helper
INFO - 2018-10-08 13:55:32 --> Database Driver Class Initialized
INFO - 2018-10-08 13:55:33 --> Email Class Initialized
INFO - 2018-10-08 13:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:55:33 --> Router Class Initialized
INFO - 2018-10-08 13:55:33 --> Output Class Initialized
INFO - 2018-10-08 13:55:34 --> Form Validation Class Initialized
INFO - 2018-10-08 13:55:34 --> Controller Class Initialized
INFO - 2018-10-08 13:55:34 --> Config Class Initialized
DEBUG - 2018-10-08 13:55:34 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:55:35 --> Model Class Initialized
INFO - 2018-10-08 13:55:35 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:55:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 13:55:35 --> Model Class Initialized
ERROR - 2018-10-08 13:55:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\system\database\DB_query_builder.php 662
DEBUG - 2018-10-08 13:55:36 --> UTF-8 Support Enabled
ERROR - 2018-10-08 13:55:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '9 = ''
WHERE `id` = `Array`' at line 1 - Invalid query: UPDATE `person` SET 9 = ''
WHERE `id` = `Array`
INFO - 2018-10-08 13:55:37 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-08 13:55:37 --> Utf8 Class Initialized
DEBUG - 2018-10-08 13:55:37 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:55:37 --> URI Class Initialized
DEBUG - 2018-10-08 13:55:38 --> No URI present. Default controller set.
INFO - 2018-10-08 13:55:38 --> Router Class Initialized
INFO - 2018-10-08 13:55:38 --> Utf8 Class Initialized
INFO - 2018-10-08 13:55:38 --> Output Class Initialized
INFO - 2018-10-08 13:55:38 --> Security Class Initialized
DEBUG - 2018-10-08 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:55:39 --> Input Class Initialized
INFO - 2018-10-08 13:55:39 --> Security Class Initialized
DEBUG - 2018-10-08 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:55:39 --> URI Class Initialized
DEBUG - 2018-10-08 13:55:40 --> No URI present. Default controller set.
INFO - 2018-10-08 13:55:40 --> Router Class Initialized
INFO - 2018-10-08 13:55:40 --> Output Class Initialized
INFO - 2018-10-08 13:55:40 --> Security Class Initialized
INFO - 2018-10-08 13:55:40 --> Language Class Initialized
INFO - 2018-10-08 13:55:41 --> Language Class Initialized
INFO - 2018-10-08 13:55:41 --> Config Class Initialized
INFO - 2018-10-08 13:55:41 --> Input Class Initialized
INFO - 2018-10-08 13:55:42 --> Language Class Initialized
INFO - 2018-10-08 13:55:42 --> Loader Class Initialized
INFO - 2018-10-08 13:55:42 --> Helper loaded: url_helper
INFO - 2018-10-08 13:55:42 --> Helper loaded: form_helper
INFO - 2018-10-08 13:55:42 --> Language Class Initialized
INFO - 2018-10-08 13:55:43 --> Database Driver Class Initialized
INFO - 2018-10-08 13:55:43 --> Config Class Initialized
DEBUG - 2018-10-08 13:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:55:43 --> Email Class Initialized
INFO - 2018-10-08 13:55:43 --> Loader Class Initialized
INFO - 2018-10-08 13:55:44 --> Helper loaded: url_helper
INFO - 2018-10-08 13:55:44 --> Helper loaded: form_helper
INFO - 2018-10-08 13:55:44 --> Input Class Initialized
INFO - 2018-10-08 13:55:44 --> Language Class Initialized
INFO - 2018-10-08 13:55:44 --> Language Class Initialized
INFO - 2018-10-08 13:55:45 --> Database Driver Class Initialized
INFO - 2018-10-08 13:55:45 --> Email Class Initialized
INFO - 2018-10-08 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:55:45 --> Config Class Initialized
INFO - 2018-10-08 13:55:45 --> Loader Class Initialized
INFO - 2018-10-08 13:55:46 --> Helper loaded: url_helper
INFO - 2018-10-08 13:55:46 --> Helper loaded: form_helper
INFO - 2018-10-08 13:55:46 --> Database Driver Class Initialized
INFO - 2018-10-08 13:55:47 --> Email Class Initialized
INFO - 2018-10-08 13:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:55:47 --> Form Validation Class Initialized
INFO - 2018-10-08 13:55:48 --> Form Validation Class Initialized
INFO - 2018-10-08 13:55:48 --> Controller Class Initialized
INFO - 2018-10-08 13:55:48 --> Form Validation Class Initialized
DEBUG - 2018-10-08 13:55:48 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:55:49 --> Model Class Initialized
DEBUG - 2018-10-08 13:55:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:55:49 --> Model Class Initialized
INFO - 2018-10-08 13:55:49 --> Controller Class Initialized
INFO - 2018-10-08 13:55:49 --> Controller Class Initialized
DEBUG - 2018-10-08 13:55:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:55:50 --> Model Class Initialized
DEBUG - 2018-10-08 13:55:50 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:55:50 --> Model Class Initialized
DEBUG - 2018-10-08 13:55:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
DEBUG - 2018-10-08 13:55:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:55:51 --> Final output sent to browser
DEBUG - 2018-10-08 13:55:51 --> Total execution time: 16.9170
DEBUG - 2018-10-08 13:55:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 13:55:52 --> Model Class Initialized
INFO - 2018-10-08 13:55:52 --> Model Class Initialized
DEBUG - 2018-10-08 13:55:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
ERROR - 2018-10-08 13:55:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\User_Management\system\database\DB_query_builder.php 662
ERROR - 2018-10-08 13:55:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '9 = ''
WHERE `id` = `Array`' at line 1 - Invalid query: UPDATE `person` SET 9 = ''
WHERE `id` = `Array`
INFO - 2018-10-08 13:55:53 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-08 13:55:53 --> Final output sent to browser
DEBUG - 2018-10-08 13:55:54 --> Total execution time: 26.2295
INFO - 2018-10-08 13:57:03 --> Config Class Initialized
INFO - 2018-10-08 13:57:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:57:04 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:57:04 --> Utf8 Class Initialized
INFO - 2018-10-08 13:57:05 --> URI Class Initialized
DEBUG - 2018-10-08 13:57:06 --> No URI present. Default controller set.
INFO - 2018-10-08 13:57:06 --> Router Class Initialized
INFO - 2018-10-08 13:57:07 --> Output Class Initialized
INFO - 2018-10-08 13:57:07 --> Security Class Initialized
DEBUG - 2018-10-08 13:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:57:07 --> Input Class Initialized
INFO - 2018-10-08 13:57:08 --> Language Class Initialized
INFO - 2018-10-08 13:57:08 --> Language Class Initialized
INFO - 2018-10-08 13:57:08 --> Config Class Initialized
INFO - 2018-10-08 13:57:09 --> Loader Class Initialized
INFO - 2018-10-08 13:57:09 --> Helper loaded: url_helper
INFO - 2018-10-08 13:57:09 --> Helper loaded: form_helper
INFO - 2018-10-08 13:57:10 --> Database Driver Class Initialized
INFO - 2018-10-08 13:57:10 --> Email Class Initialized
INFO - 2018-10-08 13:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:57:10 --> Form Validation Class Initialized
INFO - 2018-10-08 13:57:11 --> Controller Class Initialized
DEBUG - 2018-10-08 13:57:11 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:57:11 --> Model Class Initialized
DEBUG - 2018-10-08 13:57:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:57:12 --> Model Class Initialized
DEBUG - 2018-10-08 13:57:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:57:12 --> Final output sent to browser
DEBUG - 2018-10-08 13:57:12 --> Total execution time: 9.8586
INFO - 2018-10-08 13:58:31 --> Config Class Initialized
INFO - 2018-10-08 13:58:31 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:58:32 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:58:32 --> Utf8 Class Initialized
INFO - 2018-10-08 13:58:32 --> URI Class Initialized
DEBUG - 2018-10-08 13:58:33 --> No URI present. Default controller set.
INFO - 2018-10-08 13:58:33 --> Router Class Initialized
INFO - 2018-10-08 13:58:34 --> Output Class Initialized
INFO - 2018-10-08 13:58:34 --> Security Class Initialized
DEBUG - 2018-10-08 13:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:58:35 --> Input Class Initialized
INFO - 2018-10-08 13:58:35 --> Language Class Initialized
INFO - 2018-10-08 13:58:36 --> Language Class Initialized
INFO - 2018-10-08 13:58:36 --> Config Class Initialized
INFO - 2018-10-08 13:58:36 --> Loader Class Initialized
INFO - 2018-10-08 13:58:37 --> Helper loaded: url_helper
INFO - 2018-10-08 13:58:38 --> Helper loaded: form_helper
INFO - 2018-10-08 13:58:38 --> Database Driver Class Initialized
INFO - 2018-10-08 13:58:39 --> Email Class Initialized
INFO - 2018-10-08 13:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:58:39 --> Form Validation Class Initialized
INFO - 2018-10-08 13:58:40 --> Controller Class Initialized
DEBUG - 2018-10-08 13:58:40 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:58:40 --> Model Class Initialized
DEBUG - 2018-10-08 13:58:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:58:41 --> Model Class Initialized
DEBUG - 2018-10-08 13:58:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:58:41 --> Final output sent to browser
DEBUG - 2018-10-08 13:58:41 --> Total execution time: 10.4146
INFO - 2018-10-08 13:59:06 --> Config Class Initialized
INFO - 2018-10-08 13:59:06 --> Hooks Class Initialized
INFO - 2018-10-08 13:59:07 --> Config Class Initialized
INFO - 2018-10-08 13:59:07 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 13:59:07 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:59:07 --> Utf8 Class Initialized
INFO - 2018-10-08 13:59:08 --> Utf8 Class Initialized
INFO - 2018-10-08 13:59:08 --> URI Class Initialized
DEBUG - 2018-10-08 13:59:08 --> No URI present. Default controller set.
INFO - 2018-10-08 13:59:08 --> Router Class Initialized
INFO - 2018-10-08 13:59:09 --> Output Class Initialized
INFO - 2018-10-08 13:59:09 --> Security Class Initialized
INFO - 2018-10-08 13:59:09 --> URI Class Initialized
INFO - 2018-10-08 13:59:09 --> Router Class Initialized
DEBUG - 2018-10-08 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:59:10 --> Input Class Initialized
INFO - 2018-10-08 13:59:10 --> Output Class Initialized
INFO - 2018-10-08 13:59:10 --> Security Class Initialized
DEBUG - 2018-10-08 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:59:10 --> Input Class Initialized
INFO - 2018-10-08 13:59:11 --> Language Class Initialized
INFO - 2018-10-08 13:59:11 --> Language Class Initialized
INFO - 2018-10-08 13:59:11 --> Language Class Initialized
INFO - 2018-10-08 13:59:11 --> Language Class Initialized
INFO - 2018-10-08 13:59:12 --> Config Class Initialized
INFO - 2018-10-08 13:59:12 --> Loader Class Initialized
INFO - 2018-10-08 13:59:12 --> Helper loaded: url_helper
INFO - 2018-10-08 13:59:12 --> Helper loaded: form_helper
INFO - 2018-10-08 13:59:12 --> Database Driver Class Initialized
INFO - 2018-10-08 13:59:13 --> Email Class Initialized
INFO - 2018-10-08 13:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:59:13 --> Config Class Initialized
INFO - 2018-10-08 13:59:13 --> Form Validation Class Initialized
INFO - 2018-10-08 13:59:14 --> Loader Class Initialized
INFO - 2018-10-08 13:59:14 --> Controller Class Initialized
INFO - 2018-10-08 13:59:14 --> Helper loaded: url_helper
DEBUG - 2018-10-08 13:59:14 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:59:14 --> Model Class Initialized
DEBUG - 2018-10-08 13:59:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 13:59:15 --> Helper loaded: form_helper
INFO - 2018-10-08 13:59:15 --> Database Driver Class Initialized
INFO - 2018-10-08 13:59:15 --> Model Class Initialized
INFO - 2018-10-08 13:59:16 --> Email Class Initialized
INFO - 2018-10-08 13:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:59:16 --> Form Validation Class Initialized
INFO - 2018-10-08 13:59:16 --> Controller Class Initialized
DEBUG - 2018-10-08 13:59:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:59:17 --> Model Class Initialized
DEBUG - 2018-10-08 13:59:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:59:17 --> Model Class Initialized
INFO - 2018-10-08 13:59:17 --> Final output sent to browser
DEBUG - 2018-10-08 13:59:17 --> Total execution time: 10.8686
DEBUG - 2018-10-08 13:59:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:59:18 --> Final output sent to browser
DEBUG - 2018-10-08 13:59:18 --> Total execution time: 11.3787
INFO - 2018-10-08 13:59:34 --> Config Class Initialized
INFO - 2018-10-08 13:59:34 --> Hooks Class Initialized
DEBUG - 2018-10-08 13:59:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 13:59:35 --> Utf8 Class Initialized
INFO - 2018-10-08 13:59:35 --> URI Class Initialized
DEBUG - 2018-10-08 13:59:36 --> No URI present. Default controller set.
INFO - 2018-10-08 13:59:36 --> Router Class Initialized
INFO - 2018-10-08 13:59:36 --> Output Class Initialized
INFO - 2018-10-08 13:59:36 --> Security Class Initialized
DEBUG - 2018-10-08 13:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 13:59:37 --> Input Class Initialized
INFO - 2018-10-08 13:59:37 --> Language Class Initialized
INFO - 2018-10-08 13:59:37 --> Language Class Initialized
INFO - 2018-10-08 13:59:37 --> Config Class Initialized
INFO - 2018-10-08 13:59:37 --> Loader Class Initialized
INFO - 2018-10-08 13:59:38 --> Helper loaded: url_helper
INFO - 2018-10-08 13:59:38 --> Helper loaded: form_helper
INFO - 2018-10-08 13:59:38 --> Database Driver Class Initialized
INFO - 2018-10-08 13:59:38 --> Email Class Initialized
INFO - 2018-10-08 13:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 13:59:39 --> Form Validation Class Initialized
INFO - 2018-10-08 13:59:39 --> Controller Class Initialized
DEBUG - 2018-10-08 13:59:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 13:59:39 --> Model Class Initialized
DEBUG - 2018-10-08 13:59:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 13:59:40 --> Model Class Initialized
DEBUG - 2018-10-08 13:59:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 13:59:40 --> Final output sent to browser
DEBUG - 2018-10-08 13:59:41 --> Total execution time: 6.0793
INFO - 2018-10-08 14:00:19 --> Config Class Initialized
INFO - 2018-10-08 14:00:19 --> Hooks Class Initialized
INFO - 2018-10-08 14:00:19 --> Config Class Initialized
INFO - 2018-10-08 14:00:19 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:00:19 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:00:19 --> Utf8 Class Initialized
INFO - 2018-10-08 14:00:20 --> URI Class Initialized
DEBUG - 2018-10-08 14:00:20 --> No URI present. Default controller set.
DEBUG - 2018-10-08 14:00:20 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:00:20 --> Utf8 Class Initialized
INFO - 2018-10-08 14:00:21 --> URI Class Initialized
INFO - 2018-10-08 14:00:21 --> Router Class Initialized
INFO - 2018-10-08 14:00:21 --> Output Class Initialized
INFO - 2018-10-08 14:00:21 --> Security Class Initialized
INFO - 2018-10-08 14:00:21 --> Router Class Initialized
INFO - 2018-10-08 14:00:22 --> Output Class Initialized
INFO - 2018-10-08 14:00:22 --> Security Class Initialized
DEBUG - 2018-10-08 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-08 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:00:22 --> Input Class Initialized
INFO - 2018-10-08 14:00:23 --> Language Class Initialized
INFO - 2018-10-08 14:00:23 --> Language Class Initialized
INFO - 2018-10-08 14:00:23 --> Config Class Initialized
INFO - 2018-10-08 14:00:23 --> Loader Class Initialized
INFO - 2018-10-08 14:00:23 --> Helper loaded: url_helper
INFO - 2018-10-08 14:00:24 --> Helper loaded: form_helper
INFO - 2018-10-08 14:00:24 --> Input Class Initialized
INFO - 2018-10-08 14:00:24 --> Language Class Initialized
INFO - 2018-10-08 14:00:24 --> Language Class Initialized
INFO - 2018-10-08 14:00:25 --> Database Driver Class Initialized
INFO - 2018-10-08 14:00:25 --> Email Class Initialized
INFO - 2018-10-08 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:00:25 --> Config Class Initialized
INFO - 2018-10-08 14:00:25 --> Form Validation Class Initialized
INFO - 2018-10-08 14:00:26 --> Controller Class Initialized
DEBUG - 2018-10-08 14:00:26 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:00:26 --> Model Class Initialized
DEBUG - 2018-10-08 14:00:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-08 14:00:26 --> Model Class Initialized
INFO - 2018-10-08 14:00:27 --> Loader Class Initialized
INFO - 2018-10-08 14:00:27 --> Final output sent to browser
DEBUG - 2018-10-08 14:00:27 --> Total execution time: 8.3585
INFO - 2018-10-08 14:00:28 --> Helper loaded: url_helper
INFO - 2018-10-08 14:00:28 --> Helper loaded: form_helper
INFO - 2018-10-08 14:00:28 --> Database Driver Class Initialized
INFO - 2018-10-08 14:00:28 --> Email Class Initialized
INFO - 2018-10-08 14:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:00:29 --> Form Validation Class Initialized
INFO - 2018-10-08 14:00:29 --> Controller Class Initialized
DEBUG - 2018-10-08 14:00:29 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:00:29 --> Model Class Initialized
DEBUG - 2018-10-08 14:00:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:00:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:00:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:00:30 --> Final output sent to browser
DEBUG - 2018-10-08 14:00:30 --> Total execution time: 11.6847
INFO - 2018-10-08 14:00:57 --> Config Class Initialized
INFO - 2018-10-08 14:00:57 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:00:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:00:58 --> Utf8 Class Initialized
INFO - 2018-10-08 14:00:58 --> URI Class Initialized
DEBUG - 2018-10-08 14:00:59 --> No URI present. Default controller set.
INFO - 2018-10-08 14:00:59 --> Router Class Initialized
INFO - 2018-10-08 14:00:59 --> Output Class Initialized
INFO - 2018-10-08 14:01:00 --> Security Class Initialized
DEBUG - 2018-10-08 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:01:00 --> Input Class Initialized
INFO - 2018-10-08 14:01:01 --> Language Class Initialized
INFO - 2018-10-08 14:01:01 --> Language Class Initialized
INFO - 2018-10-08 14:01:02 --> Config Class Initialized
INFO - 2018-10-08 14:01:02 --> Loader Class Initialized
INFO - 2018-10-08 14:01:02 --> Helper loaded: url_helper
INFO - 2018-10-08 14:01:03 --> Helper loaded: form_helper
INFO - 2018-10-08 14:01:03 --> Database Driver Class Initialized
INFO - 2018-10-08 14:01:03 --> Email Class Initialized
INFO - 2018-10-08 14:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:01:04 --> Form Validation Class Initialized
INFO - 2018-10-08 14:01:04 --> Controller Class Initialized
DEBUG - 2018-10-08 14:01:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:01:04 --> Model Class Initialized
DEBUG - 2018-10-08 14:01:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:01:05 --> Model Class Initialized
DEBUG - 2018-10-08 14:01:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:01:05 --> Final output sent to browser
DEBUG - 2018-10-08 14:01:06 --> Total execution time: 8.4365
INFO - 2018-10-08 14:02:14 --> Config Class Initialized
INFO - 2018-10-08 14:02:14 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:02:14 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:02:15 --> Utf8 Class Initialized
INFO - 2018-10-08 14:02:15 --> URI Class Initialized
DEBUG - 2018-10-08 14:02:16 --> No URI present. Default controller set.
INFO - 2018-10-08 14:02:16 --> Router Class Initialized
INFO - 2018-10-08 14:02:16 --> Output Class Initialized
INFO - 2018-10-08 14:02:17 --> Security Class Initialized
DEBUG - 2018-10-08 14:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:02:17 --> Input Class Initialized
INFO - 2018-10-08 14:02:18 --> Language Class Initialized
INFO - 2018-10-08 14:02:18 --> Language Class Initialized
INFO - 2018-10-08 14:02:19 --> Config Class Initialized
INFO - 2018-10-08 14:02:19 --> Loader Class Initialized
INFO - 2018-10-08 14:02:19 --> Helper loaded: url_helper
INFO - 2018-10-08 14:02:19 --> Helper loaded: form_helper
INFO - 2018-10-08 14:02:20 --> Database Driver Class Initialized
INFO - 2018-10-08 14:02:21 --> Email Class Initialized
INFO - 2018-10-08 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:02:21 --> Form Validation Class Initialized
INFO - 2018-10-08 14:02:22 --> Controller Class Initialized
DEBUG - 2018-10-08 14:02:22 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:02:22 --> Model Class Initialized
DEBUG - 2018-10-08 14:02:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:02:23 --> Model Class Initialized
DEBUG - 2018-10-08 14:02:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:02:24 --> Final output sent to browser
DEBUG - 2018-10-08 14:02:24 --> Total execution time: 9.6336
INFO - 2018-10-08 14:03:24 --> Config Class Initialized
INFO - 2018-10-08 14:03:24 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:03:25 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:03:25 --> Utf8 Class Initialized
INFO - 2018-10-08 14:03:25 --> URI Class Initialized
DEBUG - 2018-10-08 14:03:26 --> No URI present. Default controller set.
INFO - 2018-10-08 14:03:26 --> Router Class Initialized
INFO - 2018-10-08 14:03:26 --> Output Class Initialized
INFO - 2018-10-08 14:03:26 --> Security Class Initialized
DEBUG - 2018-10-08 14:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:03:27 --> Input Class Initialized
INFO - 2018-10-08 14:03:27 --> Language Class Initialized
INFO - 2018-10-08 14:03:28 --> Language Class Initialized
INFO - 2018-10-08 14:03:28 --> Config Class Initialized
INFO - 2018-10-08 14:03:28 --> Loader Class Initialized
INFO - 2018-10-08 14:03:28 --> Helper loaded: url_helper
INFO - 2018-10-08 14:03:29 --> Helper loaded: form_helper
INFO - 2018-10-08 14:03:29 --> Database Driver Class Initialized
INFO - 2018-10-08 14:03:29 --> Email Class Initialized
INFO - 2018-10-08 14:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:03:30 --> Form Validation Class Initialized
INFO - 2018-10-08 14:03:30 --> Controller Class Initialized
DEBUG - 2018-10-08 14:03:30 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:03:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:03:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:03:31 --> Model Class Initialized
DEBUG - 2018-10-08 14:03:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:03:31 --> Final output sent to browser
DEBUG - 2018-10-08 14:03:31 --> Total execution time: 7.1034
INFO - 2018-10-08 14:04:51 --> Config Class Initialized
INFO - 2018-10-08 14:04:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:04:52 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:04:52 --> Utf8 Class Initialized
INFO - 2018-10-08 14:04:52 --> URI Class Initialized
DEBUG - 2018-10-08 14:04:52 --> No URI present. Default controller set.
INFO - 2018-10-08 14:04:53 --> Router Class Initialized
INFO - 2018-10-08 14:04:53 --> Output Class Initialized
INFO - 2018-10-08 14:04:53 --> Security Class Initialized
DEBUG - 2018-10-08 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:04:53 --> Input Class Initialized
INFO - 2018-10-08 14:04:54 --> Language Class Initialized
INFO - 2018-10-08 14:04:54 --> Language Class Initialized
INFO - 2018-10-08 14:04:54 --> Config Class Initialized
INFO - 2018-10-08 14:04:54 --> Loader Class Initialized
INFO - 2018-10-08 14:04:55 --> Helper loaded: url_helper
INFO - 2018-10-08 14:04:55 --> Helper loaded: form_helper
INFO - 2018-10-08 14:04:55 --> Database Driver Class Initialized
INFO - 2018-10-08 14:04:55 --> Email Class Initialized
INFO - 2018-10-08 14:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:04:56 --> Form Validation Class Initialized
INFO - 2018-10-08 14:04:56 --> Controller Class Initialized
DEBUG - 2018-10-08 14:04:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:04:56 --> Model Class Initialized
DEBUG - 2018-10-08 14:04:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:04:57 --> Model Class Initialized
DEBUG - 2018-10-08 14:04:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:04:57 --> Final output sent to browser
DEBUG - 2018-10-08 14:04:57 --> Total execution time: 5.7843
INFO - 2018-10-08 14:05:08 --> Config Class Initialized
INFO - 2018-10-08 14:05:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:05:09 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:05:09 --> Utf8 Class Initialized
INFO - 2018-10-08 14:05:09 --> URI Class Initialized
DEBUG - 2018-10-08 14:05:10 --> No URI present. Default controller set.
INFO - 2018-10-08 14:05:10 --> Router Class Initialized
INFO - 2018-10-08 14:05:10 --> Output Class Initialized
INFO - 2018-10-08 14:05:10 --> Security Class Initialized
DEBUG - 2018-10-08 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:05:11 --> Input Class Initialized
INFO - 2018-10-08 14:05:11 --> Language Class Initialized
INFO - 2018-10-08 14:05:11 --> Language Class Initialized
INFO - 2018-10-08 14:05:11 --> Config Class Initialized
INFO - 2018-10-08 14:05:12 --> Loader Class Initialized
INFO - 2018-10-08 14:05:12 --> Helper loaded: url_helper
INFO - 2018-10-08 14:05:12 --> Helper loaded: form_helper
INFO - 2018-10-08 14:05:12 --> Database Driver Class Initialized
INFO - 2018-10-08 14:05:13 --> Email Class Initialized
INFO - 2018-10-08 14:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:05:13 --> Form Validation Class Initialized
INFO - 2018-10-08 14:05:13 --> Controller Class Initialized
DEBUG - 2018-10-08 14:05:13 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:05:14 --> Model Class Initialized
DEBUG - 2018-10-08 14:05:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:05:14 --> Model Class Initialized
DEBUG - 2018-10-08 14:05:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:05:14 --> Final output sent to browser
DEBUG - 2018-10-08 14:05:15 --> Total execution time: 6.4874
INFO - 2018-10-08 14:05:59 --> Config Class Initialized
INFO - 2018-10-08 14:05:59 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:06:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:06:00 --> Utf8 Class Initialized
INFO - 2018-10-08 14:06:01 --> URI Class Initialized
DEBUG - 2018-10-08 14:06:01 --> No URI present. Default controller set.
INFO - 2018-10-08 14:06:01 --> Router Class Initialized
INFO - 2018-10-08 14:06:02 --> Output Class Initialized
INFO - 2018-10-08 14:06:02 --> Security Class Initialized
DEBUG - 2018-10-08 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:06:02 --> Input Class Initialized
INFO - 2018-10-08 14:06:03 --> Language Class Initialized
INFO - 2018-10-08 14:06:03 --> Language Class Initialized
INFO - 2018-10-08 14:06:03 --> Config Class Initialized
INFO - 2018-10-08 14:06:03 --> Loader Class Initialized
INFO - 2018-10-08 14:06:04 --> Helper loaded: url_helper
INFO - 2018-10-08 14:06:04 --> Helper loaded: form_helper
INFO - 2018-10-08 14:06:04 --> Database Driver Class Initialized
INFO - 2018-10-08 14:06:04 --> Email Class Initialized
INFO - 2018-10-08 14:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:06:05 --> Form Validation Class Initialized
INFO - 2018-10-08 14:06:05 --> Controller Class Initialized
DEBUG - 2018-10-08 14:06:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:06:06 --> Model Class Initialized
DEBUG - 2018-10-08 14:06:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:06:07 --> Model Class Initialized
DEBUG - 2018-10-08 14:06:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:06:08 --> Final output sent to browser
DEBUG - 2018-10-08 14:06:08 --> Total execution time: 8.2855
INFO - 2018-10-08 14:06:28 --> Config Class Initialized
INFO - 2018-10-08 14:06:28 --> Hooks Class Initialized
INFO - 2018-10-08 14:06:29 --> Config Class Initialized
INFO - 2018-10-08 14:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:06:29 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 14:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:06:29 --> Utf8 Class Initialized
INFO - 2018-10-08 14:06:30 --> URI Class Initialized
INFO - 2018-10-08 14:06:30 --> Router Class Initialized
INFO - 2018-10-08 14:06:30 --> Output Class Initialized
INFO - 2018-10-08 14:06:30 --> Security Class Initialized
DEBUG - 2018-10-08 14:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:06:31 --> Utf8 Class Initialized
INFO - 2018-10-08 14:06:31 --> Input Class Initialized
INFO - 2018-10-08 14:06:31 --> Language Class Initialized
INFO - 2018-10-08 14:06:31 --> Language Class Initialized
INFO - 2018-10-08 14:06:32 --> Config Class Initialized
INFO - 2018-10-08 14:06:32 --> URI Class Initialized
DEBUG - 2018-10-08 14:06:32 --> No URI present. Default controller set.
INFO - 2018-10-08 14:06:32 --> Router Class Initialized
INFO - 2018-10-08 14:06:33 --> Loader Class Initialized
INFO - 2018-10-08 14:06:33 --> Helper loaded: url_helper
INFO - 2018-10-08 14:06:33 --> Output Class Initialized
INFO - 2018-10-08 14:06:33 --> Helper loaded: form_helper
INFO - 2018-10-08 14:06:34 --> Database Driver Class Initialized
INFO - 2018-10-08 14:06:34 --> Security Class Initialized
INFO - 2018-10-08 14:06:34 --> Email Class Initialized
INFO - 2018-10-08 14:06:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-08 14:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:06:35 --> Input Class Initialized
INFO - 2018-10-08 14:06:35 --> Form Validation Class Initialized
INFO - 2018-10-08 14:06:35 --> Controller Class Initialized
DEBUG - 2018-10-08 14:06:35 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:06:36 --> Language Class Initialized
INFO - 2018-10-08 14:06:36 --> Language Class Initialized
INFO - 2018-10-08 14:06:37 --> Config Class Initialized
INFO - 2018-10-08 14:06:37 --> Loader Class Initialized
INFO - 2018-10-08 14:06:37 --> Helper loaded: url_helper
INFO - 2018-10-08 14:06:37 --> Helper loaded: form_helper
INFO - 2018-10-08 14:06:38 --> Database Driver Class Initialized
INFO - 2018-10-08 14:06:38 --> Email Class Initialized
INFO - 2018-10-08 14:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:06:38 --> Form Validation Class Initialized
INFO - 2018-10-08 14:06:39 --> Controller Class Initialized
DEBUG - 2018-10-08 14:06:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:06:39 --> Model Class Initialized
DEBUG - 2018-10-08 14:06:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:06:39 --> Model Class Initialized
DEBUG - 2018-10-08 14:06:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:06:40 --> Final output sent to browser
DEBUG - 2018-10-08 14:06:40 --> Total execution time: 11.5647
INFO - 2018-10-08 14:06:53 --> Config Class Initialized
INFO - 2018-10-08 14:06:53 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:06:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:06:54 --> Utf8 Class Initialized
INFO - 2018-10-08 14:06:54 --> URI Class Initialized
DEBUG - 2018-10-08 14:06:54 --> No URI present. Default controller set.
INFO - 2018-10-08 14:06:55 --> Router Class Initialized
INFO - 2018-10-08 14:06:55 --> Output Class Initialized
INFO - 2018-10-08 14:06:55 --> Security Class Initialized
DEBUG - 2018-10-08 14:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:06:56 --> Input Class Initialized
INFO - 2018-10-08 14:06:56 --> Language Class Initialized
INFO - 2018-10-08 14:06:56 --> Language Class Initialized
INFO - 2018-10-08 14:06:56 --> Config Class Initialized
INFO - 2018-10-08 14:06:57 --> Loader Class Initialized
INFO - 2018-10-08 14:06:57 --> Helper loaded: url_helper
INFO - 2018-10-08 14:06:57 --> Helper loaded: form_helper
INFO - 2018-10-08 14:06:58 --> Database Driver Class Initialized
INFO - 2018-10-08 14:06:58 --> Email Class Initialized
INFO - 2018-10-08 14:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:06:58 --> Form Validation Class Initialized
INFO - 2018-10-08 14:06:59 --> Controller Class Initialized
DEBUG - 2018-10-08 14:06:59 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:06:59 --> Model Class Initialized
DEBUG - 2018-10-08 14:06:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:07:00 --> Model Class Initialized
DEBUG - 2018-10-08 14:07:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:07:00 --> Final output sent to browser
DEBUG - 2018-10-08 14:07:00 --> Total execution time: 6.9674
INFO - 2018-10-08 14:08:22 --> Config Class Initialized
INFO - 2018-10-08 14:08:22 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:08:24 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:08:24 --> Utf8 Class Initialized
INFO - 2018-10-08 14:08:24 --> URI Class Initialized
DEBUG - 2018-10-08 14:08:24 --> No URI present. Default controller set.
INFO - 2018-10-08 14:08:25 --> Router Class Initialized
INFO - 2018-10-08 14:08:25 --> Output Class Initialized
INFO - 2018-10-08 14:08:25 --> Security Class Initialized
DEBUG - 2018-10-08 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:08:26 --> Input Class Initialized
INFO - 2018-10-08 14:08:26 --> Language Class Initialized
INFO - 2018-10-08 14:08:26 --> Language Class Initialized
INFO - 2018-10-08 14:08:26 --> Config Class Initialized
INFO - 2018-10-08 14:08:27 --> Loader Class Initialized
INFO - 2018-10-08 14:08:27 --> Helper loaded: url_helper
INFO - 2018-10-08 14:08:27 --> Helper loaded: form_helper
INFO - 2018-10-08 14:08:28 --> Database Driver Class Initialized
INFO - 2018-10-08 14:08:28 --> Email Class Initialized
INFO - 2018-10-08 14:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:08:28 --> Form Validation Class Initialized
INFO - 2018-10-08 14:08:28 --> Controller Class Initialized
DEBUG - 2018-10-08 14:08:28 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:08:29 --> Model Class Initialized
DEBUG - 2018-10-08 14:08:29 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:08:29 --> Model Class Initialized
DEBUG - 2018-10-08 14:08:29 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:08:30 --> Final output sent to browser
DEBUG - 2018-10-08 14:08:30 --> Total execution time: 7.4894
INFO - 2018-10-08 14:09:27 --> Config Class Initialized
INFO - 2018-10-08 14:09:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:09:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:09:28 --> Utf8 Class Initialized
INFO - 2018-10-08 14:09:28 --> URI Class Initialized
DEBUG - 2018-10-08 14:09:29 --> No URI present. Default controller set.
INFO - 2018-10-08 14:09:29 --> Router Class Initialized
INFO - 2018-10-08 14:09:29 --> Output Class Initialized
INFO - 2018-10-08 14:09:29 --> Security Class Initialized
DEBUG - 2018-10-08 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:09:30 --> Input Class Initialized
INFO - 2018-10-08 14:09:30 --> Language Class Initialized
INFO - 2018-10-08 14:09:30 --> Language Class Initialized
INFO - 2018-10-08 14:09:31 --> Config Class Initialized
INFO - 2018-10-08 14:09:31 --> Loader Class Initialized
INFO - 2018-10-08 14:09:31 --> Helper loaded: url_helper
INFO - 2018-10-08 14:09:31 --> Helper loaded: form_helper
INFO - 2018-10-08 14:09:31 --> Database Driver Class Initialized
INFO - 2018-10-08 14:09:32 --> Email Class Initialized
INFO - 2018-10-08 14:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:09:32 --> Form Validation Class Initialized
INFO - 2018-10-08 14:09:32 --> Controller Class Initialized
DEBUG - 2018-10-08 14:09:33 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:09:33 --> Model Class Initialized
DEBUG - 2018-10-08 14:09:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:09:33 --> Model Class Initialized
DEBUG - 2018-10-08 14:09:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:09:34 --> Final output sent to browser
DEBUG - 2018-10-08 14:09:34 --> Total execution time: 6.5044
INFO - 2018-10-08 14:09:49 --> Config Class Initialized
INFO - 2018-10-08 14:09:49 --> Hooks Class Initialized
INFO - 2018-10-08 14:09:49 --> Config Class Initialized
INFO - 2018-10-08 14:09:49 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:09:49 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 14:09:49 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:09:50 --> Utf8 Class Initialized
INFO - 2018-10-08 14:09:50 --> URI Class Initialized
INFO - 2018-10-08 14:09:51 --> Router Class Initialized
INFO - 2018-10-08 14:09:51 --> Output Class Initialized
INFO - 2018-10-08 14:09:51 --> Utf8 Class Initialized
INFO - 2018-10-08 14:09:52 --> URI Class Initialized
DEBUG - 2018-10-08 14:09:52 --> No URI present. Default controller set.
INFO - 2018-10-08 14:09:52 --> Router Class Initialized
INFO - 2018-10-08 14:09:52 --> Output Class Initialized
INFO - 2018-10-08 14:09:52 --> Security Class Initialized
INFO - 2018-10-08 14:09:53 --> Security Class Initialized
DEBUG - 2018-10-08 14:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:09:53 --> Input Class Initialized
INFO - 2018-10-08 14:09:53 --> Language Class Initialized
INFO - 2018-10-08 14:09:54 --> Language Class Initialized
DEBUG - 2018-10-08 14:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:09:54 --> Input Class Initialized
INFO - 2018-10-08 14:09:54 --> Language Class Initialized
INFO - 2018-10-08 14:09:55 --> Language Class Initialized
INFO - 2018-10-08 14:09:55 --> Config Class Initialized
INFO - 2018-10-08 14:09:55 --> Loader Class Initialized
INFO - 2018-10-08 14:09:55 --> Helper loaded: url_helper
INFO - 2018-10-08 14:09:55 --> Helper loaded: form_helper
INFO - 2018-10-08 14:09:56 --> Database Driver Class Initialized
INFO - 2018-10-08 14:09:56 --> Config Class Initialized
INFO - 2018-10-08 14:09:56 --> Email Class Initialized
INFO - 2018-10-08 14:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:09:57 --> Loader Class Initialized
INFO - 2018-10-08 14:09:57 --> Helper loaded: url_helper
INFO - 2018-10-08 14:09:57 --> Form Validation Class Initialized
INFO - 2018-10-08 14:09:57 --> Helper loaded: form_helper
INFO - 2018-10-08 14:09:57 --> Controller Class Initialized
DEBUG - 2018-10-08 14:09:58 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:09:58 --> Database Driver Class Initialized
INFO - 2018-10-08 14:09:58 --> Email Class Initialized
INFO - 2018-10-08 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:09:59 --> Form Validation Class Initialized
INFO - 2018-10-08 14:09:59 --> Controller Class Initialized
DEBUG - 2018-10-08 14:09:59 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:10:00 --> Model Class Initialized
DEBUG - 2018-10-08 14:10:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:10:00 --> Model Class Initialized
DEBUG - 2018-10-08 14:10:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:10:01 --> Final output sent to browser
DEBUG - 2018-10-08 14:10:01 --> Total execution time: 11.7797
INFO - 2018-10-08 14:10:10 --> Config Class Initialized
INFO - 2018-10-08 14:10:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:10:11 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:10:12 --> Utf8 Class Initialized
INFO - 2018-10-08 14:10:12 --> URI Class Initialized
DEBUG - 2018-10-08 14:10:12 --> No URI present. Default controller set.
INFO - 2018-10-08 14:10:13 --> Router Class Initialized
INFO - 2018-10-08 14:10:13 --> Output Class Initialized
INFO - 2018-10-08 14:10:13 --> Security Class Initialized
DEBUG - 2018-10-08 14:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:10:14 --> Input Class Initialized
INFO - 2018-10-08 14:10:14 --> Language Class Initialized
INFO - 2018-10-08 14:10:14 --> Language Class Initialized
INFO - 2018-10-08 14:10:14 --> Config Class Initialized
INFO - 2018-10-08 14:10:15 --> Loader Class Initialized
INFO - 2018-10-08 14:10:15 --> Helper loaded: url_helper
INFO - 2018-10-08 14:10:15 --> Helper loaded: form_helper
INFO - 2018-10-08 14:10:15 --> Database Driver Class Initialized
INFO - 2018-10-08 14:10:16 --> Email Class Initialized
INFO - 2018-10-08 14:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:10:16 --> Form Validation Class Initialized
INFO - 2018-10-08 14:10:16 --> Controller Class Initialized
DEBUG - 2018-10-08 14:10:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:10:17 --> Model Class Initialized
DEBUG - 2018-10-08 14:10:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:10:17 --> Model Class Initialized
DEBUG - 2018-10-08 14:10:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:10:18 --> Final output sent to browser
DEBUG - 2018-10-08 14:10:18 --> Total execution time: 7.5494
INFO - 2018-10-08 14:11:47 --> Config Class Initialized
INFO - 2018-10-08 14:11:47 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:11:47 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:11:47 --> Utf8 Class Initialized
INFO - 2018-10-08 14:11:48 --> URI Class Initialized
DEBUG - 2018-10-08 14:11:48 --> No URI present. Default controller set.
INFO - 2018-10-08 14:11:48 --> Router Class Initialized
INFO - 2018-10-08 14:11:48 --> Output Class Initialized
INFO - 2018-10-08 14:11:48 --> Security Class Initialized
DEBUG - 2018-10-08 14:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:11:49 --> Input Class Initialized
INFO - 2018-10-08 14:11:49 --> Language Class Initialized
INFO - 2018-10-08 14:11:50 --> Language Class Initialized
INFO - 2018-10-08 14:11:50 --> Config Class Initialized
INFO - 2018-10-08 14:11:50 --> Loader Class Initialized
INFO - 2018-10-08 14:11:50 --> Helper loaded: url_helper
INFO - 2018-10-08 14:11:50 --> Helper loaded: form_helper
INFO - 2018-10-08 14:11:51 --> Database Driver Class Initialized
INFO - 2018-10-08 14:11:51 --> Email Class Initialized
INFO - 2018-10-08 14:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:11:51 --> Form Validation Class Initialized
INFO - 2018-10-08 14:11:52 --> Controller Class Initialized
DEBUG - 2018-10-08 14:11:52 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:11:52 --> Model Class Initialized
DEBUG - 2018-10-08 14:11:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:11:53 --> Model Class Initialized
DEBUG - 2018-10-08 14:11:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:11:53 --> Final output sent to browser
DEBUG - 2018-10-08 14:11:53 --> Total execution time: 6.5924
INFO - 2018-10-08 14:12:12 --> Config Class Initialized
INFO - 2018-10-08 14:12:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:12:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:12:13 --> Utf8 Class Initialized
INFO - 2018-10-08 14:12:13 --> URI Class Initialized
DEBUG - 2018-10-08 14:12:13 --> No URI present. Default controller set.
INFO - 2018-10-08 14:12:13 --> Router Class Initialized
INFO - 2018-10-08 14:12:14 --> Output Class Initialized
INFO - 2018-10-08 14:12:14 --> Security Class Initialized
DEBUG - 2018-10-08 14:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:12:14 --> Input Class Initialized
INFO - 2018-10-08 14:12:14 --> Language Class Initialized
INFO - 2018-10-08 14:12:15 --> Language Class Initialized
INFO - 2018-10-08 14:12:15 --> Config Class Initialized
INFO - 2018-10-08 14:12:15 --> Loader Class Initialized
INFO - 2018-10-08 14:12:15 --> Helper loaded: url_helper
INFO - 2018-10-08 14:12:15 --> Helper loaded: form_helper
INFO - 2018-10-08 14:12:16 --> Database Driver Class Initialized
INFO - 2018-10-08 14:12:16 --> Email Class Initialized
INFO - 2018-10-08 14:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:12:16 --> Form Validation Class Initialized
INFO - 2018-10-08 14:12:16 --> Controller Class Initialized
DEBUG - 2018-10-08 14:12:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:12:17 --> Model Class Initialized
DEBUG - 2018-10-08 14:12:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:12:17 --> Model Class Initialized
DEBUG - 2018-10-08 14:12:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:12:18 --> Final output sent to browser
DEBUG - 2018-10-08 14:12:18 --> Total execution time: 5.8093
INFO - 2018-10-08 14:12:32 --> Config Class Initialized
INFO - 2018-10-08 14:12:32 --> Hooks Class Initialized
INFO - 2018-10-08 14:12:32 --> Config Class Initialized
INFO - 2018-10-08 14:12:33 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:12:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:12:33 --> Utf8 Class Initialized
DEBUG - 2018-10-08 14:12:34 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:12:34 --> Utf8 Class Initialized
INFO - 2018-10-08 14:12:34 --> URI Class Initialized
INFO - 2018-10-08 14:12:34 --> Router Class Initialized
INFO - 2018-10-08 14:12:35 --> Output Class Initialized
INFO - 2018-10-08 14:12:35 --> URI Class Initialized
DEBUG - 2018-10-08 14:12:35 --> No URI present. Default controller set.
INFO - 2018-10-08 14:12:36 --> Router Class Initialized
INFO - 2018-10-08 14:12:36 --> Security Class Initialized
DEBUG - 2018-10-08 14:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:12:37 --> Input Class Initialized
INFO - 2018-10-08 14:12:37 --> Language Class Initialized
INFO - 2018-10-08 14:12:37 --> Language Class Initialized
INFO - 2018-10-08 14:12:37 --> Config Class Initialized
INFO - 2018-10-08 14:12:38 --> Loader Class Initialized
INFO - 2018-10-08 14:12:38 --> Output Class Initialized
INFO - 2018-10-08 14:12:38 --> Helper loaded: url_helper
INFO - 2018-10-08 14:12:39 --> Helper loaded: form_helper
INFO - 2018-10-08 14:12:39 --> Database Driver Class Initialized
INFO - 2018-10-08 14:12:39 --> Security Class Initialized
INFO - 2018-10-08 14:12:39 --> Email Class Initialized
INFO - 2018-10-08 14:12:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-08 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:12:40 --> Input Class Initialized
INFO - 2018-10-08 14:12:40 --> Form Validation Class Initialized
INFO - 2018-10-08 14:12:40 --> Language Class Initialized
INFO - 2018-10-08 14:12:41 --> Controller Class Initialized
INFO - 2018-10-08 14:12:41 --> Language Class Initialized
INFO - 2018-10-08 14:12:41 --> Config Class Initialized
INFO - 2018-10-08 14:12:41 --> Loader Class Initialized
INFO - 2018-10-08 14:12:42 --> Helper loaded: url_helper
INFO - 2018-10-08 14:12:42 --> Helper loaded: form_helper
INFO - 2018-10-08 14:12:42 --> Database Driver Class Initialized
INFO - 2018-10-08 14:12:42 --> Email Class Initialized
INFO - 2018-10-08 14:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:12:43 --> Form Validation Class Initialized
DEBUG - 2018-10-08 14:12:43 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:12:43 --> Controller Class Initialized
DEBUG - 2018-10-08 14:12:44 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:12:45 --> Model Class Initialized
DEBUG - 2018-10-08 14:12:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:12:45 --> Model Class Initialized
DEBUG - 2018-10-08 14:12:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:12:45 --> Final output sent to browser
DEBUG - 2018-10-08 14:12:46 --> Total execution time: 13.3928
INFO - 2018-10-08 14:14:34 --> Config Class Initialized
INFO - 2018-10-08 14:14:34 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:14:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:14:35 --> Utf8 Class Initialized
INFO - 2018-10-08 14:14:35 --> URI Class Initialized
DEBUG - 2018-10-08 14:14:36 --> No URI present. Default controller set.
INFO - 2018-10-08 14:14:36 --> Router Class Initialized
INFO - 2018-10-08 14:14:36 --> Output Class Initialized
INFO - 2018-10-08 14:14:37 --> Security Class Initialized
DEBUG - 2018-10-08 14:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:14:37 --> Input Class Initialized
INFO - 2018-10-08 14:14:38 --> Language Class Initialized
INFO - 2018-10-08 14:14:38 --> Language Class Initialized
INFO - 2018-10-08 14:14:38 --> Config Class Initialized
INFO - 2018-10-08 14:14:39 --> Loader Class Initialized
INFO - 2018-10-08 14:14:39 --> Helper loaded: url_helper
INFO - 2018-10-08 14:14:39 --> Helper loaded: form_helper
INFO - 2018-10-08 14:14:40 --> Database Driver Class Initialized
INFO - 2018-10-08 14:14:40 --> Email Class Initialized
INFO - 2018-10-08 14:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:14:41 --> Form Validation Class Initialized
INFO - 2018-10-08 14:14:41 --> Controller Class Initialized
DEBUG - 2018-10-08 14:14:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:14:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:14:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:14:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:14:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:14:43 --> Final output sent to browser
DEBUG - 2018-10-08 14:14:43 --> Total execution time: 8.2795
INFO - 2018-10-08 14:15:27 --> Config Class Initialized
INFO - 2018-10-08 14:15:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:15:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:15:29 --> Utf8 Class Initialized
INFO - 2018-10-08 14:15:29 --> URI Class Initialized
DEBUG - 2018-10-08 14:15:29 --> No URI present. Default controller set.
INFO - 2018-10-08 14:15:29 --> Router Class Initialized
INFO - 2018-10-08 14:15:30 --> Output Class Initialized
INFO - 2018-10-08 14:15:30 --> Security Class Initialized
DEBUG - 2018-10-08 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:15:37 --> Input Class Initialized
INFO - 2018-10-08 14:15:38 --> Language Class Initialized
INFO - 2018-10-08 14:15:38 --> Language Class Initialized
INFO - 2018-10-08 14:15:38 --> Config Class Initialized
INFO - 2018-10-08 14:15:39 --> Loader Class Initialized
INFO - 2018-10-08 14:15:40 --> Helper loaded: url_helper
INFO - 2018-10-08 14:15:40 --> Helper loaded: form_helper
INFO - 2018-10-08 14:15:40 --> Database Driver Class Initialized
INFO - 2018-10-08 14:15:41 --> Email Class Initialized
INFO - 2018-10-08 14:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:15:41 --> Form Validation Class Initialized
INFO - 2018-10-08 14:15:42 --> Controller Class Initialized
DEBUG - 2018-10-08 14:15:42 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:15:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:15:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:15:43 --> Model Class Initialized
DEBUG - 2018-10-08 14:15:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:15:44 --> Final output sent to browser
DEBUG - 2018-10-08 14:15:44 --> Total execution time: 17.0220
INFO - 2018-10-08 14:15:51 --> Config Class Initialized
INFO - 2018-10-08 14:15:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:15:52 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:15:52 --> Utf8 Class Initialized
INFO - 2018-10-08 14:15:52 --> URI Class Initialized
DEBUG - 2018-10-08 14:15:53 --> No URI present. Default controller set.
INFO - 2018-10-08 14:15:53 --> Router Class Initialized
INFO - 2018-10-08 14:15:53 --> Output Class Initialized
INFO - 2018-10-08 14:15:53 --> Security Class Initialized
DEBUG - 2018-10-08 14:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:15:54 --> Input Class Initialized
INFO - 2018-10-08 14:15:54 --> Language Class Initialized
INFO - 2018-10-08 14:15:54 --> Language Class Initialized
INFO - 2018-10-08 14:15:54 --> Config Class Initialized
INFO - 2018-10-08 14:15:55 --> Loader Class Initialized
INFO - 2018-10-08 14:15:55 --> Helper loaded: url_helper
INFO - 2018-10-08 14:15:55 --> Helper loaded: form_helper
INFO - 2018-10-08 14:15:56 --> Database Driver Class Initialized
INFO - 2018-10-08 14:15:56 --> Email Class Initialized
INFO - 2018-10-08 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:15:56 --> Form Validation Class Initialized
INFO - 2018-10-08 14:15:56 --> Controller Class Initialized
DEBUG - 2018-10-08 14:15:57 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:15:57 --> Model Class Initialized
DEBUG - 2018-10-08 14:15:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:15:57 --> Model Class Initialized
DEBUG - 2018-10-08 14:15:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:15:58 --> Final output sent to browser
DEBUG - 2018-10-08 14:15:58 --> Total execution time: 6.5694
INFO - 2018-10-08 14:18:40 --> Config Class Initialized
INFO - 2018-10-08 14:18:40 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:18:41 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:18:42 --> Utf8 Class Initialized
INFO - 2018-10-08 14:18:42 --> URI Class Initialized
DEBUG - 2018-10-08 14:18:43 --> No URI present. Default controller set.
INFO - 2018-10-08 14:18:43 --> Router Class Initialized
INFO - 2018-10-08 14:18:44 --> Output Class Initialized
INFO - 2018-10-08 14:18:44 --> Security Class Initialized
DEBUG - 2018-10-08 14:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:18:44 --> Input Class Initialized
INFO - 2018-10-08 14:18:45 --> Language Class Initialized
INFO - 2018-10-08 14:18:45 --> Language Class Initialized
INFO - 2018-10-08 14:18:45 --> Config Class Initialized
INFO - 2018-10-08 14:18:45 --> Loader Class Initialized
INFO - 2018-10-08 14:18:45 --> Helper loaded: url_helper
INFO - 2018-10-08 14:18:46 --> Helper loaded: form_helper
INFO - 2018-10-08 14:18:46 --> Database Driver Class Initialized
INFO - 2018-10-08 14:18:46 --> Email Class Initialized
INFO - 2018-10-08 14:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:18:47 --> Form Validation Class Initialized
INFO - 2018-10-08 14:18:47 --> Controller Class Initialized
DEBUG - 2018-10-08 14:18:47 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:18:47 --> Model Class Initialized
DEBUG - 2018-10-08 14:18:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:18:48 --> Model Class Initialized
DEBUG - 2018-10-08 14:18:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:18:48 --> Final output sent to browser
DEBUG - 2018-10-08 14:18:48 --> Total execution time: 8.5365
INFO - 2018-10-08 14:19:02 --> Config Class Initialized
INFO - 2018-10-08 14:19:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:19:02 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:19:03 --> Utf8 Class Initialized
INFO - 2018-10-08 14:19:03 --> URI Class Initialized
DEBUG - 2018-10-08 14:19:04 --> No URI present. Default controller set.
INFO - 2018-10-08 14:19:04 --> Router Class Initialized
INFO - 2018-10-08 14:19:04 --> Output Class Initialized
INFO - 2018-10-08 14:19:04 --> Security Class Initialized
DEBUG - 2018-10-08 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:19:05 --> Input Class Initialized
INFO - 2018-10-08 14:19:05 --> Language Class Initialized
INFO - 2018-10-08 14:19:05 --> Language Class Initialized
INFO - 2018-10-08 14:19:06 --> Config Class Initialized
INFO - 2018-10-08 14:19:06 --> Loader Class Initialized
INFO - 2018-10-08 14:19:06 --> Helper loaded: url_helper
INFO - 2018-10-08 14:19:07 --> Helper loaded: form_helper
INFO - 2018-10-08 14:19:07 --> Database Driver Class Initialized
INFO - 2018-10-08 14:19:07 --> Email Class Initialized
INFO - 2018-10-08 14:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:19:08 --> Form Validation Class Initialized
INFO - 2018-10-08 14:19:08 --> Controller Class Initialized
DEBUG - 2018-10-08 14:19:08 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:19:08 --> Model Class Initialized
DEBUG - 2018-10-08 14:19:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:19:09 --> Model Class Initialized
DEBUG - 2018-10-08 14:19:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:19:09 --> Final output sent to browser
DEBUG - 2018-10-08 14:19:10 --> Total execution time: 7.4374
INFO - 2018-10-08 14:20:33 --> Config Class Initialized
INFO - 2018-10-08 14:20:33 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:20:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:20:34 --> Utf8 Class Initialized
INFO - 2018-10-08 14:20:34 --> URI Class Initialized
DEBUG - 2018-10-08 14:20:35 --> No URI present. Default controller set.
INFO - 2018-10-08 14:20:35 --> Router Class Initialized
INFO - 2018-10-08 14:20:35 --> Output Class Initialized
INFO - 2018-10-08 14:20:35 --> Security Class Initialized
DEBUG - 2018-10-08 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:20:36 --> Input Class Initialized
INFO - 2018-10-08 14:20:37 --> Language Class Initialized
INFO - 2018-10-08 14:20:37 --> Language Class Initialized
INFO - 2018-10-08 14:20:37 --> Config Class Initialized
INFO - 2018-10-08 14:20:38 --> Loader Class Initialized
INFO - 2018-10-08 14:20:38 --> Helper loaded: url_helper
INFO - 2018-10-08 14:20:39 --> Helper loaded: form_helper
INFO - 2018-10-08 14:20:39 --> Database Driver Class Initialized
INFO - 2018-10-08 14:20:39 --> Email Class Initialized
INFO - 2018-10-08 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:20:40 --> Form Validation Class Initialized
INFO - 2018-10-08 14:20:40 --> Controller Class Initialized
DEBUG - 2018-10-08 14:20:40 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:20:41 --> Model Class Initialized
DEBUG - 2018-10-08 14:20:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:20:41 --> Model Class Initialized
DEBUG - 2018-10-08 14:20:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:20:42 --> Final output sent to browser
DEBUG - 2018-10-08 14:20:42 --> Total execution time: 9.9566
INFO - 2018-10-08 14:20:55 --> Config Class Initialized
INFO - 2018-10-08 14:20:55 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:20:55 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:20:55 --> Config Class Initialized
INFO - 2018-10-08 14:20:55 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:20:56 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:20:56 --> Utf8 Class Initialized
INFO - 2018-10-08 14:20:57 --> Utf8 Class Initialized
INFO - 2018-10-08 14:20:57 --> URI Class Initialized
DEBUG - 2018-10-08 14:20:57 --> No URI present. Default controller set.
INFO - 2018-10-08 14:20:57 --> Router Class Initialized
INFO - 2018-10-08 14:20:58 --> URI Class Initialized
INFO - 2018-10-08 14:20:58 --> Router Class Initialized
INFO - 2018-10-08 14:20:58 --> Output Class Initialized
INFO - 2018-10-08 14:20:59 --> Security Class Initialized
DEBUG - 2018-10-08 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:20:59 --> Output Class Initialized
INFO - 2018-10-08 14:20:59 --> Security Class Initialized
DEBUG - 2018-10-08 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:21:00 --> Input Class Initialized
INFO - 2018-10-08 14:21:00 --> Input Class Initialized
INFO - 2018-10-08 14:21:00 --> Language Class Initialized
INFO - 2018-10-08 14:21:01 --> Language Class Initialized
INFO - 2018-10-08 14:21:01 --> Language Class Initialized
INFO - 2018-10-08 14:21:01 --> Config Class Initialized
INFO - 2018-10-08 14:21:01 --> Loader Class Initialized
INFO - 2018-10-08 14:21:02 --> Language Class Initialized
INFO - 2018-10-08 14:21:02 --> Config Class Initialized
INFO - 2018-10-08 14:21:02 --> Loader Class Initialized
INFO - 2018-10-08 14:21:02 --> Helper loaded: url_helper
INFO - 2018-10-08 14:21:03 --> Helper loaded: form_helper
INFO - 2018-10-08 14:21:03 --> Database Driver Class Initialized
INFO - 2018-10-08 14:21:03 --> Email Class Initialized
INFO - 2018-10-08 14:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:21:03 --> Form Validation Class Initialized
INFO - 2018-10-08 14:21:04 --> Helper loaded: url_helper
INFO - 2018-10-08 14:21:04 --> Controller Class Initialized
DEBUG - 2018-10-08 14:21:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:21:04 --> Helper loaded: form_helper
INFO - 2018-10-08 14:21:05 --> Database Driver Class Initialized
INFO - 2018-10-08 14:21:05 --> Email Class Initialized
INFO - 2018-10-08 14:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:21:06 --> Form Validation Class Initialized
INFO - 2018-10-08 14:21:06 --> Controller Class Initialized
DEBUG - 2018-10-08 14:21:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:21:07 --> Model Class Initialized
DEBUG - 2018-10-08 14:21:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:21:07 --> Model Class Initialized
DEBUG - 2018-10-08 14:21:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:21:08 --> Final output sent to browser
DEBUG - 2018-10-08 14:21:08 --> Total execution time: 13.0877
INFO - 2018-10-08 14:21:15 --> Config Class Initialized
INFO - 2018-10-08 14:21:15 --> Hooks Class Initialized
INFO - 2018-10-08 14:21:15 --> Config Class Initialized
INFO - 2018-10-08 14:21:15 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:21:16 --> UTF-8 Support Enabled
DEBUG - 2018-10-08 14:21:17 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:21:17 --> Utf8 Class Initialized
INFO - 2018-10-08 14:21:17 --> Utf8 Class Initialized
INFO - 2018-10-08 14:21:18 --> URI Class Initialized
DEBUG - 2018-10-08 14:21:18 --> No URI present. Default controller set.
INFO - 2018-10-08 14:21:19 --> URI Class Initialized
INFO - 2018-10-08 14:21:20 --> Router Class Initialized
INFO - 2018-10-08 14:21:20 --> Router Class Initialized
INFO - 2018-10-08 14:21:20 --> Output Class Initialized
INFO - 2018-10-08 14:21:21 --> Security Class Initialized
DEBUG - 2018-10-08 14:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:21:21 --> Input Class Initialized
INFO - 2018-10-08 14:21:21 --> Language Class Initialized
INFO - 2018-10-08 14:21:22 --> Language Class Initialized
INFO - 2018-10-08 14:21:22 --> Config Class Initialized
INFO - 2018-10-08 14:21:22 --> Output Class Initialized
INFO - 2018-10-08 14:21:22 --> Security Class Initialized
DEBUG - 2018-10-08 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:21:23 --> Loader Class Initialized
INFO - 2018-10-08 14:21:23 --> Input Class Initialized
INFO - 2018-10-08 14:21:24 --> Language Class Initialized
INFO - 2018-10-08 14:21:24 --> Helper loaded: url_helper
INFO - 2018-10-08 14:21:24 --> Language Class Initialized
INFO - 2018-10-08 14:21:24 --> Config Class Initialized
INFO - 2018-10-08 14:21:24 --> Helper loaded: form_helper
INFO - 2018-10-08 14:21:25 --> Database Driver Class Initialized
INFO - 2018-10-08 14:21:25 --> Email Class Initialized
INFO - 2018-10-08 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:21:26 --> Form Validation Class Initialized
INFO - 2018-10-08 14:21:26 --> Controller Class Initialized
DEBUG - 2018-10-08 14:21:26 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:21:27 --> Loader Class Initialized
INFO - 2018-10-08 14:21:27 --> Helper loaded: url_helper
INFO - 2018-10-08 14:21:27 --> Helper loaded: form_helper
INFO - 2018-10-08 14:21:27 --> Database Driver Class Initialized
INFO - 2018-10-08 14:21:28 --> Email Class Initialized
INFO - 2018-10-08 14:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:21:28 --> Form Validation Class Initialized
INFO - 2018-10-08 14:21:29 --> Controller Class Initialized
DEBUG - 2018-10-08 14:21:29 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:21:29 --> Model Class Initialized
DEBUG - 2018-10-08 14:21:29 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:21:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:21:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:21:30 --> Final output sent to browser
DEBUG - 2018-10-08 14:21:30 --> Total execution time: 14.7988
INFO - 2018-10-08 14:26:29 --> Config Class Initialized
INFO - 2018-10-08 14:26:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:26:30 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:26:30 --> Utf8 Class Initialized
INFO - 2018-10-08 14:26:31 --> URI Class Initialized
DEBUG - 2018-10-08 14:26:33 --> No URI present. Default controller set.
INFO - 2018-10-08 14:26:33 --> Router Class Initialized
INFO - 2018-10-08 14:26:33 --> Output Class Initialized
INFO - 2018-10-08 14:26:34 --> Security Class Initialized
DEBUG - 2018-10-08 14:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:26:34 --> Input Class Initialized
INFO - 2018-10-08 14:26:34 --> Language Class Initialized
INFO - 2018-10-08 14:26:35 --> Language Class Initialized
INFO - 2018-10-08 14:26:35 --> Config Class Initialized
INFO - 2018-10-08 14:26:35 --> Loader Class Initialized
INFO - 2018-10-08 14:26:35 --> Helper loaded: url_helper
INFO - 2018-10-08 14:26:35 --> Helper loaded: form_helper
INFO - 2018-10-08 14:26:36 --> Database Driver Class Initialized
INFO - 2018-10-08 14:26:38 --> Email Class Initialized
INFO - 2018-10-08 14:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:26:38 --> Form Validation Class Initialized
INFO - 2018-10-08 14:26:39 --> Controller Class Initialized
DEBUG - 2018-10-08 14:26:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:26:39 --> Model Class Initialized
DEBUG - 2018-10-08 14:26:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:26:40 --> Model Class Initialized
DEBUG - 2018-10-08 14:26:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:26:40 --> Final output sent to browser
DEBUG - 2018-10-08 14:26:40 --> Total execution time: 11.9007
INFO - 2018-10-08 14:26:49 --> Config Class Initialized
INFO - 2018-10-08 14:26:49 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:26:49 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:26:49 --> Utf8 Class Initialized
INFO - 2018-10-08 14:26:50 --> URI Class Initialized
DEBUG - 2018-10-08 14:26:50 --> No URI present. Default controller set.
INFO - 2018-10-08 14:26:50 --> Router Class Initialized
INFO - 2018-10-08 14:26:51 --> Output Class Initialized
INFO - 2018-10-08 14:26:51 --> Security Class Initialized
DEBUG - 2018-10-08 14:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:26:51 --> Input Class Initialized
INFO - 2018-10-08 14:26:52 --> Language Class Initialized
INFO - 2018-10-08 14:26:52 --> Language Class Initialized
INFO - 2018-10-08 14:26:52 --> Config Class Initialized
INFO - 2018-10-08 14:26:53 --> Loader Class Initialized
INFO - 2018-10-08 14:26:53 --> Helper loaded: url_helper
INFO - 2018-10-08 14:26:53 --> Helper loaded: form_helper
INFO - 2018-10-08 14:26:53 --> Database Driver Class Initialized
INFO - 2018-10-08 14:26:54 --> Email Class Initialized
INFO - 2018-10-08 14:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:26:54 --> Form Validation Class Initialized
INFO - 2018-10-08 14:26:54 --> Controller Class Initialized
DEBUG - 2018-10-08 14:26:55 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:26:55 --> Model Class Initialized
DEBUG - 2018-10-08 14:26:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:26:56 --> Model Class Initialized
DEBUG - 2018-10-08 14:26:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:26:56 --> Final output sent to browser
DEBUG - 2018-10-08 14:26:56 --> Total execution time: 7.3994
INFO - 2018-10-08 14:27:04 --> Config Class Initialized
INFO - 2018-10-08 14:27:04 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:27:05 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:27:05 --> Utf8 Class Initialized
INFO - 2018-10-08 14:27:06 --> URI Class Initialized
DEBUG - 2018-10-08 14:27:06 --> No URI present. Default controller set.
INFO - 2018-10-08 14:27:06 --> Router Class Initialized
INFO - 2018-10-08 14:27:06 --> Output Class Initialized
INFO - 2018-10-08 14:27:07 --> Security Class Initialized
DEBUG - 2018-10-08 14:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:27:07 --> Input Class Initialized
INFO - 2018-10-08 14:27:08 --> Language Class Initialized
INFO - 2018-10-08 14:27:08 --> Language Class Initialized
INFO - 2018-10-08 14:27:08 --> Config Class Initialized
INFO - 2018-10-08 14:27:08 --> Loader Class Initialized
INFO - 2018-10-08 14:27:09 --> Helper loaded: url_helper
INFO - 2018-10-08 14:27:09 --> Helper loaded: form_helper
INFO - 2018-10-08 14:27:09 --> Database Driver Class Initialized
INFO - 2018-10-08 14:27:09 --> Email Class Initialized
INFO - 2018-10-08 14:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:27:10 --> Form Validation Class Initialized
INFO - 2018-10-08 14:27:10 --> Controller Class Initialized
DEBUG - 2018-10-08 14:27:10 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:27:11 --> Model Class Initialized
DEBUG - 2018-10-08 14:27:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:27:11 --> Model Class Initialized
DEBUG - 2018-10-08 14:27:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:27:11 --> Final output sent to browser
DEBUG - 2018-10-08 14:27:12 --> Total execution time: 7.1004
INFO - 2018-10-08 14:28:19 --> Config Class Initialized
INFO - 2018-10-08 14:28:20 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:28:22 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:28:22 --> Utf8 Class Initialized
INFO - 2018-10-08 14:28:23 --> URI Class Initialized
DEBUG - 2018-10-08 14:28:24 --> No URI present. Default controller set.
INFO - 2018-10-08 14:28:24 --> Router Class Initialized
INFO - 2018-10-08 14:28:25 --> Output Class Initialized
INFO - 2018-10-08 14:28:26 --> Security Class Initialized
DEBUG - 2018-10-08 14:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:28:26 --> Input Class Initialized
INFO - 2018-10-08 14:28:27 --> Language Class Initialized
INFO - 2018-10-08 14:28:27 --> Language Class Initialized
INFO - 2018-10-08 14:28:27 --> Config Class Initialized
INFO - 2018-10-08 14:28:28 --> Loader Class Initialized
INFO - 2018-10-08 14:28:28 --> Helper loaded: url_helper
INFO - 2018-10-08 14:28:28 --> Helper loaded: form_helper
INFO - 2018-10-08 14:28:28 --> Database Driver Class Initialized
INFO - 2018-10-08 14:28:29 --> Email Class Initialized
INFO - 2018-10-08 14:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:28:29 --> Form Validation Class Initialized
INFO - 2018-10-08 14:28:29 --> Controller Class Initialized
DEBUG - 2018-10-08 14:28:29 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:28:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:28:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:28:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:28:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:28:31 --> Final output sent to browser
DEBUG - 2018-10-08 14:28:31 --> Total execution time: 12.1687
INFO - 2018-10-08 14:28:40 --> Config Class Initialized
INFO - 2018-10-08 14:28:40 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:28:40 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:28:41 --> Utf8 Class Initialized
INFO - 2018-10-08 14:28:41 --> URI Class Initialized
DEBUG - 2018-10-08 14:28:41 --> No URI present. Default controller set.
INFO - 2018-10-08 14:28:41 --> Router Class Initialized
INFO - 2018-10-08 14:28:42 --> Output Class Initialized
INFO - 2018-10-08 14:28:42 --> Security Class Initialized
DEBUG - 2018-10-08 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:28:44 --> Input Class Initialized
INFO - 2018-10-08 14:28:44 --> Language Class Initialized
INFO - 2018-10-08 14:28:44 --> Language Class Initialized
INFO - 2018-10-08 14:28:45 --> Config Class Initialized
INFO - 2018-10-08 14:28:45 --> Loader Class Initialized
INFO - 2018-10-08 14:28:46 --> Helper loaded: url_helper
INFO - 2018-10-08 14:28:46 --> Helper loaded: form_helper
INFO - 2018-10-08 14:28:46 --> Database Driver Class Initialized
INFO - 2018-10-08 14:28:46 --> Email Class Initialized
INFO - 2018-10-08 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:28:47 --> Form Validation Class Initialized
INFO - 2018-10-08 14:28:47 --> Controller Class Initialized
DEBUG - 2018-10-08 14:28:48 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:28:48 --> Model Class Initialized
DEBUG - 2018-10-08 14:28:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:28:49 --> Model Class Initialized
DEBUG - 2018-10-08 14:28:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:28:50 --> Final output sent to browser
DEBUG - 2018-10-08 14:28:50 --> Total execution time: 10.0116
INFO - 2018-10-08 14:28:57 --> Config Class Initialized
INFO - 2018-10-08 14:28:57 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:28:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:28:58 --> Utf8 Class Initialized
INFO - 2018-10-08 14:28:59 --> URI Class Initialized
DEBUG - 2018-10-08 14:28:59 --> No URI present. Default controller set.
INFO - 2018-10-08 14:28:59 --> Router Class Initialized
INFO - 2018-10-08 14:29:00 --> Output Class Initialized
INFO - 2018-10-08 14:29:00 --> Security Class Initialized
DEBUG - 2018-10-08 14:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:29:01 --> Input Class Initialized
INFO - 2018-10-08 14:29:02 --> Language Class Initialized
INFO - 2018-10-08 14:29:02 --> Language Class Initialized
INFO - 2018-10-08 14:29:02 --> Config Class Initialized
INFO - 2018-10-08 14:29:03 --> Loader Class Initialized
INFO - 2018-10-08 14:29:03 --> Helper loaded: url_helper
INFO - 2018-10-08 14:29:04 --> Helper loaded: form_helper
INFO - 2018-10-08 14:29:04 --> Database Driver Class Initialized
INFO - 2018-10-08 14:29:05 --> Email Class Initialized
INFO - 2018-10-08 14:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:29:05 --> Form Validation Class Initialized
INFO - 2018-10-08 14:29:05 --> Controller Class Initialized
DEBUG - 2018-10-08 14:29:06 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:29:06 --> Model Class Initialized
DEBUG - 2018-10-08 14:29:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:29:07 --> Model Class Initialized
DEBUG - 2018-10-08 14:29:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:29:08 --> Final output sent to browser
DEBUG - 2018-10-08 14:29:08 --> Total execution time: 10.6146
INFO - 2018-10-08 14:31:39 --> Config Class Initialized
INFO - 2018-10-08 14:31:40 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:31:43 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:31:43 --> Utf8 Class Initialized
INFO - 2018-10-08 14:31:44 --> URI Class Initialized
DEBUG - 2018-10-08 14:31:45 --> No URI present. Default controller set.
INFO - 2018-10-08 14:31:46 --> Router Class Initialized
INFO - 2018-10-08 14:31:48 --> Output Class Initialized
INFO - 2018-10-08 14:31:48 --> Security Class Initialized
DEBUG - 2018-10-08 14:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:31:48 --> Input Class Initialized
INFO - 2018-10-08 14:31:49 --> Language Class Initialized
INFO - 2018-10-08 14:31:49 --> Language Class Initialized
INFO - 2018-10-08 14:31:49 --> Config Class Initialized
INFO - 2018-10-08 14:31:50 --> Loader Class Initialized
INFO - 2018-10-08 14:31:50 --> Helper loaded: url_helper
INFO - 2018-10-08 14:31:50 --> Helper loaded: form_helper
INFO - 2018-10-08 14:31:52 --> Database Driver Class Initialized
INFO - 2018-10-08 14:31:53 --> Email Class Initialized
INFO - 2018-10-08 14:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:31:55 --> Form Validation Class Initialized
INFO - 2018-10-08 14:31:55 --> Controller Class Initialized
DEBUG - 2018-10-08 14:31:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:31:56 --> Model Class Initialized
DEBUG - 2018-10-08 14:31:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:31:57 --> Model Class Initialized
DEBUG - 2018-10-08 14:31:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:31:57 --> Final output sent to browser
DEBUG - 2018-10-08 14:31:58 --> Total execution time: 19.0221
INFO - 2018-10-08 14:32:07 --> Config Class Initialized
INFO - 2018-10-08 14:32:07 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:32:07 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:32:08 --> Utf8 Class Initialized
INFO - 2018-10-08 14:32:08 --> URI Class Initialized
DEBUG - 2018-10-08 14:32:09 --> No URI present. Default controller set.
INFO - 2018-10-08 14:32:09 --> Router Class Initialized
INFO - 2018-10-08 14:32:10 --> Output Class Initialized
INFO - 2018-10-08 14:32:11 --> Security Class Initialized
DEBUG - 2018-10-08 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:32:11 --> Input Class Initialized
INFO - 2018-10-08 14:32:12 --> Language Class Initialized
INFO - 2018-10-08 14:32:12 --> Language Class Initialized
INFO - 2018-10-08 14:32:12 --> Config Class Initialized
INFO - 2018-10-08 14:32:13 --> Loader Class Initialized
INFO - 2018-10-08 14:32:13 --> Helper loaded: url_helper
INFO - 2018-10-08 14:32:13 --> Helper loaded: form_helper
INFO - 2018-10-08 14:32:14 --> Database Driver Class Initialized
INFO - 2018-10-08 14:32:14 --> Email Class Initialized
INFO - 2018-10-08 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:32:14 --> Form Validation Class Initialized
INFO - 2018-10-08 14:32:15 --> Controller Class Initialized
DEBUG - 2018-10-08 14:32:15 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:32:15 --> Model Class Initialized
DEBUG - 2018-10-08 14:32:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:32:16 --> Model Class Initialized
DEBUG - 2018-10-08 14:32:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:32:16 --> Final output sent to browser
DEBUG - 2018-10-08 14:32:17 --> Total execution time: 9.3385
INFO - 2018-10-08 14:34:34 --> Config Class Initialized
INFO - 2018-10-08 14:34:34 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:34:35 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:34:35 --> Utf8 Class Initialized
INFO - 2018-10-08 14:34:36 --> URI Class Initialized
DEBUG - 2018-10-08 14:34:37 --> No URI present. Default controller set.
INFO - 2018-10-08 14:34:37 --> Router Class Initialized
INFO - 2018-10-08 14:34:38 --> Output Class Initialized
INFO - 2018-10-08 14:34:38 --> Security Class Initialized
DEBUG - 2018-10-08 14:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:34:38 --> Input Class Initialized
INFO - 2018-10-08 14:34:39 --> Language Class Initialized
INFO - 2018-10-08 14:34:39 --> Language Class Initialized
INFO - 2018-10-08 14:34:39 --> Config Class Initialized
INFO - 2018-10-08 14:34:40 --> Loader Class Initialized
INFO - 2018-10-08 14:34:40 --> Helper loaded: url_helper
INFO - 2018-10-08 14:34:40 --> Helper loaded: form_helper
INFO - 2018-10-08 14:34:40 --> Database Driver Class Initialized
INFO - 2018-10-08 14:34:41 --> Email Class Initialized
INFO - 2018-10-08 14:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:34:41 --> Form Validation Class Initialized
INFO - 2018-10-08 14:34:41 --> Controller Class Initialized
DEBUG - 2018-10-08 14:34:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:34:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:34:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:34:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:34:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:34:43 --> Final output sent to browser
DEBUG - 2018-10-08 14:34:43 --> Total execution time: 9.1535
INFO - 2018-10-08 14:34:53 --> Config Class Initialized
INFO - 2018-10-08 14:34:53 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:34:54 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:34:54 --> Utf8 Class Initialized
INFO - 2018-10-08 14:34:54 --> URI Class Initialized
DEBUG - 2018-10-08 14:34:55 --> No URI present. Default controller set.
INFO - 2018-10-08 14:34:55 --> Router Class Initialized
INFO - 2018-10-08 14:34:55 --> Output Class Initialized
INFO - 2018-10-08 14:34:55 --> Security Class Initialized
DEBUG - 2018-10-08 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:34:56 --> Input Class Initialized
INFO - 2018-10-08 14:34:56 --> Language Class Initialized
INFO - 2018-10-08 14:34:57 --> Language Class Initialized
INFO - 2018-10-08 14:34:57 --> Config Class Initialized
INFO - 2018-10-08 14:34:57 --> Loader Class Initialized
INFO - 2018-10-08 14:34:58 --> Helper loaded: url_helper
INFO - 2018-10-08 14:34:58 --> Helper loaded: form_helper
INFO - 2018-10-08 14:34:59 --> Database Driver Class Initialized
INFO - 2018-10-08 14:34:59 --> Email Class Initialized
INFO - 2018-10-08 14:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:34:59 --> Form Validation Class Initialized
INFO - 2018-10-08 14:35:00 --> Controller Class Initialized
DEBUG - 2018-10-08 14:35:00 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:35:01 --> Model Class Initialized
DEBUG - 2018-10-08 14:35:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:35:01 --> Model Class Initialized
DEBUG - 2018-10-08 14:35:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:35:02 --> Final output sent to browser
DEBUG - 2018-10-08 14:35:02 --> Total execution time: 9.1175
INFO - 2018-10-08 14:35:45 --> Config Class Initialized
INFO - 2018-10-08 14:35:45 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:35:46 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:35:46 --> Utf8 Class Initialized
INFO - 2018-10-08 14:35:46 --> URI Class Initialized
DEBUG - 2018-10-08 14:35:47 --> No URI present. Default controller set.
INFO - 2018-10-08 14:35:48 --> Router Class Initialized
INFO - 2018-10-08 14:35:48 --> Output Class Initialized
INFO - 2018-10-08 14:35:48 --> Security Class Initialized
DEBUG - 2018-10-08 14:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:35:49 --> Input Class Initialized
INFO - 2018-10-08 14:35:50 --> Language Class Initialized
INFO - 2018-10-08 14:35:50 --> Language Class Initialized
INFO - 2018-10-08 14:35:51 --> Config Class Initialized
INFO - 2018-10-08 14:35:51 --> Loader Class Initialized
INFO - 2018-10-08 14:35:51 --> Helper loaded: url_helper
INFO - 2018-10-08 14:35:52 --> Helper loaded: form_helper
INFO - 2018-10-08 14:35:52 --> Database Driver Class Initialized
INFO - 2018-10-08 14:35:52 --> Email Class Initialized
INFO - 2018-10-08 14:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:35:53 --> Form Validation Class Initialized
INFO - 2018-10-08 14:35:53 --> Controller Class Initialized
DEBUG - 2018-10-08 14:35:53 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:35:54 --> Model Class Initialized
DEBUG - 2018-10-08 14:35:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:35:54 --> Model Class Initialized
DEBUG - 2018-10-08 14:35:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:35:55 --> Final output sent to browser
DEBUG - 2018-10-08 14:35:55 --> Total execution time: 10.0036
INFO - 2018-10-08 14:37:08 --> Config Class Initialized
INFO - 2018-10-08 14:37:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:37:10 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:37:10 --> Utf8 Class Initialized
INFO - 2018-10-08 14:37:11 --> URI Class Initialized
DEBUG - 2018-10-08 14:37:11 --> No URI present. Default controller set.
INFO - 2018-10-08 14:37:12 --> Router Class Initialized
INFO - 2018-10-08 14:37:12 --> Output Class Initialized
INFO - 2018-10-08 14:37:13 --> Security Class Initialized
DEBUG - 2018-10-08 14:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:37:13 --> Input Class Initialized
INFO - 2018-10-08 14:37:13 --> Language Class Initialized
INFO - 2018-10-08 14:37:14 --> Language Class Initialized
INFO - 2018-10-08 14:37:14 --> Config Class Initialized
INFO - 2018-10-08 14:37:15 --> Loader Class Initialized
INFO - 2018-10-08 14:37:15 --> Helper loaded: url_helper
INFO - 2018-10-08 14:37:15 --> Helper loaded: form_helper
INFO - 2018-10-08 14:37:16 --> Database Driver Class Initialized
INFO - 2018-10-08 14:37:16 --> Email Class Initialized
INFO - 2018-10-08 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:37:17 --> Form Validation Class Initialized
INFO - 2018-10-08 14:37:17 --> Controller Class Initialized
DEBUG - 2018-10-08 14:37:17 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:37:18 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:37:18 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:37:19 --> Final output sent to browser
DEBUG - 2018-10-08 14:37:19 --> Total execution time: 11.1226
INFO - 2018-10-08 14:37:32 --> Config Class Initialized
INFO - 2018-10-08 14:37:32 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:37:33 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:37:33 --> Utf8 Class Initialized
INFO - 2018-10-08 14:37:34 --> URI Class Initialized
DEBUG - 2018-10-08 14:37:36 --> No URI present. Default controller set.
INFO - 2018-10-08 14:37:36 --> Router Class Initialized
INFO - 2018-10-08 14:37:37 --> Output Class Initialized
INFO - 2018-10-08 14:37:38 --> Security Class Initialized
DEBUG - 2018-10-08 14:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:37:38 --> Input Class Initialized
INFO - 2018-10-08 14:37:38 --> Language Class Initialized
INFO - 2018-10-08 14:37:39 --> Language Class Initialized
INFO - 2018-10-08 14:37:39 --> Config Class Initialized
INFO - 2018-10-08 14:37:39 --> Loader Class Initialized
INFO - 2018-10-08 14:37:39 --> Helper loaded: url_helper
INFO - 2018-10-08 14:37:40 --> Helper loaded: form_helper
INFO - 2018-10-08 14:37:40 --> Database Driver Class Initialized
INFO - 2018-10-08 14:37:40 --> Email Class Initialized
INFO - 2018-10-08 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:37:41 --> Form Validation Class Initialized
INFO - 2018-10-08 14:37:41 --> Controller Class Initialized
DEBUG - 2018-10-08 14:37:41 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:37:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:37:42 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:37:43 --> Final output sent to browser
DEBUG - 2018-10-08 14:37:43 --> Total execution time: 10.1277
INFO - 2018-10-08 14:37:49 --> Config Class Initialized
INFO - 2018-10-08 14:37:50 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:37:50 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:37:50 --> Utf8 Class Initialized
INFO - 2018-10-08 14:37:50 --> URI Class Initialized
DEBUG - 2018-10-08 14:37:51 --> No URI present. Default controller set.
INFO - 2018-10-08 14:37:51 --> Router Class Initialized
INFO - 2018-10-08 14:37:51 --> Output Class Initialized
INFO - 2018-10-08 14:37:51 --> Security Class Initialized
DEBUG - 2018-10-08 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:37:52 --> Input Class Initialized
INFO - 2018-10-08 14:37:52 --> Language Class Initialized
INFO - 2018-10-08 14:37:53 --> Language Class Initialized
INFO - 2018-10-08 14:37:53 --> Config Class Initialized
INFO - 2018-10-08 14:37:53 --> Loader Class Initialized
INFO - 2018-10-08 14:37:54 --> Helper loaded: url_helper
INFO - 2018-10-08 14:37:54 --> Helper loaded: form_helper
INFO - 2018-10-08 14:37:54 --> Database Driver Class Initialized
INFO - 2018-10-08 14:37:55 --> Email Class Initialized
INFO - 2018-10-08 14:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:37:55 --> Form Validation Class Initialized
INFO - 2018-10-08 14:37:55 --> Controller Class Initialized
DEBUG - 2018-10-08 14:37:56 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:37:56 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:37:57 --> Model Class Initialized
DEBUG - 2018-10-08 14:37:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:37:57 --> Final output sent to browser
DEBUG - 2018-10-08 14:37:57 --> Total execution time: 7.7326
INFO - 2018-10-08 14:38:27 --> Config Class Initialized
INFO - 2018-10-08 14:38:27 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:38:28 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:38:28 --> Utf8 Class Initialized
INFO - 2018-10-08 14:38:29 --> URI Class Initialized
DEBUG - 2018-10-08 14:38:29 --> No URI present. Default controller set.
INFO - 2018-10-08 14:38:29 --> Router Class Initialized
INFO - 2018-10-08 14:38:30 --> Output Class Initialized
INFO - 2018-10-08 14:38:30 --> Security Class Initialized
DEBUG - 2018-10-08 14:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:38:31 --> Input Class Initialized
INFO - 2018-10-08 14:38:31 --> Language Class Initialized
INFO - 2018-10-08 14:38:31 --> Language Class Initialized
INFO - 2018-10-08 14:38:32 --> Config Class Initialized
INFO - 2018-10-08 14:38:32 --> Loader Class Initialized
INFO - 2018-10-08 14:38:32 --> Helper loaded: url_helper
INFO - 2018-10-08 14:38:33 --> Helper loaded: form_helper
INFO - 2018-10-08 14:38:33 --> Database Driver Class Initialized
INFO - 2018-10-08 14:38:34 --> Email Class Initialized
INFO - 2018-10-08 14:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:38:35 --> Form Validation Class Initialized
INFO - 2018-10-08 14:38:35 --> Controller Class Initialized
DEBUG - 2018-10-08 14:38:36 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:38:36 --> Model Class Initialized
DEBUG - 2018-10-08 14:38:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:38:37 --> Model Class Initialized
DEBUG - 2018-10-08 14:38:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:38:38 --> Final output sent to browser
DEBUG - 2018-10-08 14:38:39 --> Total execution time: 11.0127
INFO - 2018-10-08 14:38:51 --> Config Class Initialized
INFO - 2018-10-08 14:38:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:38:52 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:38:52 --> Utf8 Class Initialized
INFO - 2018-10-08 14:38:53 --> URI Class Initialized
DEBUG - 2018-10-08 14:38:53 --> No URI present. Default controller set.
INFO - 2018-10-08 14:38:53 --> Router Class Initialized
INFO - 2018-10-08 14:38:53 --> Output Class Initialized
INFO - 2018-10-08 14:38:54 --> Security Class Initialized
DEBUG - 2018-10-08 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:38:54 --> Input Class Initialized
INFO - 2018-10-08 14:38:54 --> Language Class Initialized
INFO - 2018-10-08 14:38:55 --> Language Class Initialized
INFO - 2018-10-08 14:38:55 --> Config Class Initialized
INFO - 2018-10-08 14:38:55 --> Loader Class Initialized
INFO - 2018-10-08 14:38:55 --> Helper loaded: url_helper
INFO - 2018-10-08 14:38:56 --> Helper loaded: form_helper
INFO - 2018-10-08 14:38:56 --> Database Driver Class Initialized
INFO - 2018-10-08 14:38:57 --> Email Class Initialized
INFO - 2018-10-08 14:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:38:57 --> Form Validation Class Initialized
INFO - 2018-10-08 14:38:58 --> Controller Class Initialized
DEBUG - 2018-10-08 14:38:58 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:38:58 --> Model Class Initialized
DEBUG - 2018-10-08 14:38:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:38:59 --> Model Class Initialized
DEBUG - 2018-10-08 14:38:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:38:59 --> Final output sent to browser
DEBUG - 2018-10-08 14:38:59 --> Total execution time: 8.5076
INFO - 2018-10-08 14:39:40 --> Config Class Initialized
INFO - 2018-10-08 14:39:40 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:39:41 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:39:41 --> Utf8 Class Initialized
INFO - 2018-10-08 14:39:42 --> URI Class Initialized
DEBUG - 2018-10-08 14:39:42 --> No URI present. Default controller set.
INFO - 2018-10-08 14:39:42 --> Router Class Initialized
INFO - 2018-10-08 14:39:43 --> Output Class Initialized
INFO - 2018-10-08 14:39:43 --> Security Class Initialized
DEBUG - 2018-10-08 14:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:39:43 --> Input Class Initialized
INFO - 2018-10-08 14:39:44 --> Language Class Initialized
INFO - 2018-10-08 14:39:44 --> Language Class Initialized
INFO - 2018-10-08 14:39:45 --> Config Class Initialized
INFO - 2018-10-08 14:39:46 --> Loader Class Initialized
INFO - 2018-10-08 14:39:47 --> Helper loaded: url_helper
INFO - 2018-10-08 14:39:47 --> Helper loaded: form_helper
INFO - 2018-10-08 14:39:47 --> Database Driver Class Initialized
INFO - 2018-10-08 14:39:48 --> Email Class Initialized
INFO - 2018-10-08 14:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:39:48 --> Form Validation Class Initialized
INFO - 2018-10-08 14:39:49 --> Controller Class Initialized
DEBUG - 2018-10-08 14:39:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:39:49 --> Model Class Initialized
DEBUG - 2018-10-08 14:39:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:39:50 --> Model Class Initialized
DEBUG - 2018-10-08 14:39:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:39:51 --> Final output sent to browser
DEBUG - 2018-10-08 14:39:51 --> Total execution time: 10.3052
INFO - 2018-10-08 14:40:02 --> Config Class Initialized
INFO - 2018-10-08 14:40:02 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:40:03 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:40:03 --> Utf8 Class Initialized
INFO - 2018-10-08 14:40:03 --> URI Class Initialized
DEBUG - 2018-10-08 14:40:04 --> No URI present. Default controller set.
INFO - 2018-10-08 14:40:04 --> Router Class Initialized
INFO - 2018-10-08 14:40:04 --> Output Class Initialized
INFO - 2018-10-08 14:40:04 --> Security Class Initialized
DEBUG - 2018-10-08 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:40:05 --> Input Class Initialized
INFO - 2018-10-08 14:40:05 --> Language Class Initialized
INFO - 2018-10-08 14:40:05 --> Language Class Initialized
INFO - 2018-10-08 14:40:06 --> Config Class Initialized
INFO - 2018-10-08 14:40:06 --> Loader Class Initialized
INFO - 2018-10-08 14:40:06 --> Helper loaded: url_helper
INFO - 2018-10-08 14:40:06 --> Helper loaded: form_helper
INFO - 2018-10-08 14:40:07 --> Database Driver Class Initialized
INFO - 2018-10-08 14:40:07 --> Email Class Initialized
INFO - 2018-10-08 14:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:40:07 --> Form Validation Class Initialized
INFO - 2018-10-08 14:40:08 --> Controller Class Initialized
DEBUG - 2018-10-08 14:40:08 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:40:08 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:40:09 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:40:09 --> Final output sent to browser
DEBUG - 2018-10-08 14:40:10 --> Total execution time: 7.3101
INFO - 2018-10-08 14:40:25 --> Config Class Initialized
INFO - 2018-10-08 14:40:25 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:40:25 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:40:25 --> Utf8 Class Initialized
INFO - 2018-10-08 14:40:26 --> URI Class Initialized
DEBUG - 2018-10-08 14:40:26 --> No URI present. Default controller set.
INFO - 2018-10-08 14:40:26 --> Router Class Initialized
INFO - 2018-10-08 14:40:27 --> Output Class Initialized
INFO - 2018-10-08 14:40:27 --> Security Class Initialized
DEBUG - 2018-10-08 14:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:40:28 --> Input Class Initialized
INFO - 2018-10-08 14:40:28 --> Language Class Initialized
INFO - 2018-10-08 14:40:29 --> Language Class Initialized
INFO - 2018-10-08 14:40:29 --> Config Class Initialized
INFO - 2018-10-08 14:40:30 --> Loader Class Initialized
INFO - 2018-10-08 14:40:30 --> Helper loaded: url_helper
INFO - 2018-10-08 14:40:30 --> Helper loaded: form_helper
INFO - 2018-10-08 14:40:31 --> Database Driver Class Initialized
INFO - 2018-10-08 14:40:31 --> Email Class Initialized
INFO - 2018-10-08 14:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:40:32 --> Form Validation Class Initialized
INFO - 2018-10-08 14:40:32 --> Controller Class Initialized
DEBUG - 2018-10-08 14:40:32 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:40:32 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:40:33 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:40:33 --> Final output sent to browser
DEBUG - 2018-10-08 14:40:34 --> Total execution time: 8.7851
INFO - 2018-10-08 14:40:43 --> Config Class Initialized
INFO - 2018-10-08 14:40:43 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:40:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:40:44 --> Utf8 Class Initialized
INFO - 2018-10-08 14:40:44 --> URI Class Initialized
DEBUG - 2018-10-08 14:40:45 --> No URI present. Default controller set.
INFO - 2018-10-08 14:40:45 --> Router Class Initialized
INFO - 2018-10-08 14:40:45 --> Output Class Initialized
INFO - 2018-10-08 14:40:46 --> Security Class Initialized
DEBUG - 2018-10-08 14:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:40:46 --> Input Class Initialized
INFO - 2018-10-08 14:40:47 --> Language Class Initialized
INFO - 2018-10-08 14:40:47 --> Language Class Initialized
INFO - 2018-10-08 14:40:47 --> Config Class Initialized
INFO - 2018-10-08 14:40:47 --> Loader Class Initialized
INFO - 2018-10-08 14:40:48 --> Helper loaded: url_helper
INFO - 2018-10-08 14:40:48 --> Helper loaded: form_helper
INFO - 2018-10-08 14:40:48 --> Database Driver Class Initialized
INFO - 2018-10-08 14:40:48 --> Email Class Initialized
INFO - 2018-10-08 14:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:40:49 --> Form Validation Class Initialized
INFO - 2018-10-08 14:40:49 --> Controller Class Initialized
DEBUG - 2018-10-08 14:40:49 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:40:50 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:40:50 --> Model Class Initialized
DEBUG - 2018-10-08 14:40:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:40:51 --> Final output sent to browser
DEBUG - 2018-10-08 14:40:51 --> Total execution time: 7.6926
INFO - 2018-10-08 14:40:57 --> Config Class Initialized
INFO - 2018-10-08 14:40:57 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:40:57 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:40:58 --> Utf8 Class Initialized
INFO - 2018-10-08 14:40:58 --> URI Class Initialized
DEBUG - 2018-10-08 14:40:59 --> No URI present. Default controller set.
INFO - 2018-10-08 14:40:59 --> Router Class Initialized
INFO - 2018-10-08 14:40:59 --> Output Class Initialized
INFO - 2018-10-08 14:41:00 --> Security Class Initialized
DEBUG - 2018-10-08 14:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:41:00 --> Input Class Initialized
INFO - 2018-10-08 14:41:00 --> Language Class Initialized
INFO - 2018-10-08 14:41:01 --> Language Class Initialized
INFO - 2018-10-08 14:41:01 --> Config Class Initialized
INFO - 2018-10-08 14:41:02 --> Loader Class Initialized
INFO - 2018-10-08 14:41:02 --> Helper loaded: url_helper
INFO - 2018-10-08 14:41:02 --> Helper loaded: form_helper
INFO - 2018-10-08 14:41:02 --> Database Driver Class Initialized
INFO - 2018-10-08 14:41:03 --> Email Class Initialized
INFO - 2018-10-08 14:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:41:03 --> Form Validation Class Initialized
INFO - 2018-10-08 14:41:03 --> Controller Class Initialized
DEBUG - 2018-10-08 14:41:04 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:41:04 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:41:05 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:41:05 --> Final output sent to browser
DEBUG - 2018-10-08 14:41:05 --> Total execution time: 8.1201
INFO - 2018-10-08 14:41:22 --> Config Class Initialized
INFO - 2018-10-08 14:41:22 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:41:23 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:41:23 --> Utf8 Class Initialized
INFO - 2018-10-08 14:41:24 --> URI Class Initialized
DEBUG - 2018-10-08 14:41:24 --> No URI present. Default controller set.
INFO - 2018-10-08 14:41:24 --> Router Class Initialized
INFO - 2018-10-08 14:41:25 --> Output Class Initialized
INFO - 2018-10-08 14:41:25 --> Security Class Initialized
DEBUG - 2018-10-08 14:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:41:26 --> Input Class Initialized
INFO - 2018-10-08 14:41:26 --> Language Class Initialized
INFO - 2018-10-08 14:41:26 --> Language Class Initialized
INFO - 2018-10-08 14:41:27 --> Config Class Initialized
INFO - 2018-10-08 14:41:27 --> Loader Class Initialized
INFO - 2018-10-08 14:41:27 --> Helper loaded: url_helper
INFO - 2018-10-08 14:41:28 --> Helper loaded: form_helper
INFO - 2018-10-08 14:41:28 --> Database Driver Class Initialized
INFO - 2018-10-08 14:41:28 --> Email Class Initialized
INFO - 2018-10-08 14:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:41:29 --> Form Validation Class Initialized
INFO - 2018-10-08 14:41:29 --> Controller Class Initialized
DEBUG - 2018-10-08 14:41:30 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:41:30 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:41:31 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:41:31 --> Final output sent to browser
DEBUG - 2018-10-08 14:41:32 --> Total execution time: 9.5901
INFO - 2018-10-08 14:41:39 --> Config Class Initialized
INFO - 2018-10-08 14:41:39 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:41:39 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:41:39 --> Utf8 Class Initialized
INFO - 2018-10-08 14:41:40 --> URI Class Initialized
DEBUG - 2018-10-08 14:41:40 --> No URI present. Default controller set.
INFO - 2018-10-08 14:41:40 --> Router Class Initialized
INFO - 2018-10-08 14:41:41 --> Output Class Initialized
INFO - 2018-10-08 14:41:41 --> Security Class Initialized
DEBUG - 2018-10-08 14:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:41:41 --> Input Class Initialized
INFO - 2018-10-08 14:41:42 --> Language Class Initialized
INFO - 2018-10-08 14:41:42 --> Language Class Initialized
INFO - 2018-10-08 14:41:42 --> Config Class Initialized
INFO - 2018-10-08 14:41:42 --> Loader Class Initialized
INFO - 2018-10-08 14:41:43 --> Helper loaded: url_helper
INFO - 2018-10-08 14:41:43 --> Helper loaded: form_helper
INFO - 2018-10-08 14:41:43 --> Database Driver Class Initialized
INFO - 2018-10-08 14:41:44 --> Email Class Initialized
INFO - 2018-10-08 14:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:41:44 --> Form Validation Class Initialized
INFO - 2018-10-08 14:41:45 --> Controller Class Initialized
DEBUG - 2018-10-08 14:41:45 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:41:45 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:41:46 --> Model Class Initialized
DEBUG - 2018-10-08 14:41:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:41:46 --> Final output sent to browser
DEBUG - 2018-10-08 14:41:46 --> Total execution time: 7.4076
INFO - 2018-10-08 14:42:03 --> Config Class Initialized
INFO - 2018-10-08 14:42:03 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:42:04 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:42:04 --> Utf8 Class Initialized
INFO - 2018-10-08 14:42:05 --> URI Class Initialized
DEBUG - 2018-10-08 14:42:05 --> No URI present. Default controller set.
INFO - 2018-10-08 14:42:06 --> Router Class Initialized
INFO - 2018-10-08 14:42:06 --> Output Class Initialized
INFO - 2018-10-08 14:42:06 --> Security Class Initialized
DEBUG - 2018-10-08 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:42:07 --> Input Class Initialized
INFO - 2018-10-08 14:42:08 --> Language Class Initialized
INFO - 2018-10-08 14:42:08 --> Language Class Initialized
INFO - 2018-10-08 14:42:09 --> Config Class Initialized
INFO - 2018-10-08 14:42:10 --> Loader Class Initialized
INFO - 2018-10-08 14:42:10 --> Helper loaded: url_helper
INFO - 2018-10-08 14:42:10 --> Helper loaded: form_helper
INFO - 2018-10-08 14:42:10 --> Database Driver Class Initialized
INFO - 2018-10-08 14:42:11 --> Email Class Initialized
INFO - 2018-10-08 14:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:42:11 --> Form Validation Class Initialized
INFO - 2018-10-08 14:42:11 --> Controller Class Initialized
DEBUG - 2018-10-08 14:42:12 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:42:12 --> Model Class Initialized
DEBUG - 2018-10-08 14:42:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:42:12 --> Model Class Initialized
DEBUG - 2018-10-08 14:42:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:42:13 --> Final output sent to browser
DEBUG - 2018-10-08 14:42:13 --> Total execution time: 9.8802
INFO - 2018-10-08 14:42:21 --> Config Class Initialized
INFO - 2018-10-08 14:42:21 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:42:21 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:42:21 --> Utf8 Class Initialized
INFO - 2018-10-08 14:42:22 --> URI Class Initialized
DEBUG - 2018-10-08 14:42:22 --> No URI present. Default controller set.
INFO - 2018-10-08 14:42:22 --> Router Class Initialized
INFO - 2018-10-08 14:42:23 --> Output Class Initialized
INFO - 2018-10-08 14:42:24 --> Security Class Initialized
DEBUG - 2018-10-08 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:42:24 --> Input Class Initialized
INFO - 2018-10-08 14:42:25 --> Language Class Initialized
INFO - 2018-10-08 14:42:25 --> Language Class Initialized
INFO - 2018-10-08 14:42:25 --> Config Class Initialized
INFO - 2018-10-08 14:42:25 --> Loader Class Initialized
INFO - 2018-10-08 14:42:26 --> Helper loaded: url_helper
INFO - 2018-10-08 14:42:26 --> Helper loaded: form_helper
INFO - 2018-10-08 14:42:26 --> Database Driver Class Initialized
INFO - 2018-10-08 14:42:26 --> Email Class Initialized
INFO - 2018-10-08 14:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:42:27 --> Form Validation Class Initialized
INFO - 2018-10-08 14:42:27 --> Controller Class Initialized
DEBUG - 2018-10-08 14:42:27 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:42:28 --> Model Class Initialized
DEBUG - 2018-10-08 14:42:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:42:28 --> Model Class Initialized
DEBUG - 2018-10-08 14:42:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:42:29 --> Final output sent to browser
DEBUG - 2018-10-08 14:42:29 --> Total execution time: 7.6501
INFO - 2018-10-08 14:44:29 --> Config Class Initialized
INFO - 2018-10-08 14:44:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:44:31 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:44:31 --> Utf8 Class Initialized
INFO - 2018-10-08 14:44:32 --> URI Class Initialized
DEBUG - 2018-10-08 14:44:33 --> No URI present. Default controller set.
INFO - 2018-10-08 14:44:33 --> Router Class Initialized
INFO - 2018-10-08 14:44:34 --> Output Class Initialized
INFO - 2018-10-08 14:44:34 --> Security Class Initialized
DEBUG - 2018-10-08 14:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:44:35 --> Input Class Initialized
INFO - 2018-10-08 14:44:35 --> Language Class Initialized
INFO - 2018-10-08 14:44:35 --> Language Class Initialized
INFO - 2018-10-08 14:44:36 --> Config Class Initialized
INFO - 2018-10-08 14:44:36 --> Loader Class Initialized
INFO - 2018-10-08 14:44:36 --> Helper loaded: url_helper
INFO - 2018-10-08 14:44:37 --> Helper loaded: form_helper
INFO - 2018-10-08 14:44:37 --> Database Driver Class Initialized
INFO - 2018-10-08 14:44:37 --> Email Class Initialized
INFO - 2018-10-08 14:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:44:38 --> Form Validation Class Initialized
INFO - 2018-10-08 14:44:38 --> Controller Class Initialized
DEBUG - 2018-10-08 14:44:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:44:39 --> Model Class Initialized
DEBUG - 2018-10-08 14:44:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:44:40 --> Model Class Initialized
DEBUG - 2018-10-08 14:44:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:44:40 --> Final output sent to browser
DEBUG - 2018-10-08 14:44:41 --> Total execution time: 11.8077
INFO - 2018-10-08 14:44:51 --> Config Class Initialized
INFO - 2018-10-08 14:44:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:44:51 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:44:51 --> Utf8 Class Initialized
INFO - 2018-10-08 14:44:52 --> URI Class Initialized
DEBUG - 2018-10-08 14:44:52 --> No URI present. Default controller set.
INFO - 2018-10-08 14:44:52 --> Router Class Initialized
INFO - 2018-10-08 14:44:53 --> Output Class Initialized
INFO - 2018-10-08 14:44:53 --> Security Class Initialized
DEBUG - 2018-10-08 14:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:44:53 --> Input Class Initialized
INFO - 2018-10-08 14:44:54 --> Language Class Initialized
INFO - 2018-10-08 14:44:54 --> Language Class Initialized
INFO - 2018-10-08 14:44:54 --> Config Class Initialized
INFO - 2018-10-08 14:44:54 --> Loader Class Initialized
INFO - 2018-10-08 14:44:55 --> Helper loaded: url_helper
INFO - 2018-10-08 14:44:55 --> Helper loaded: form_helper
INFO - 2018-10-08 14:44:55 --> Database Driver Class Initialized
INFO - 2018-10-08 14:44:56 --> Email Class Initialized
INFO - 2018-10-08 14:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:44:56 --> Form Validation Class Initialized
INFO - 2018-10-08 14:44:57 --> Controller Class Initialized
DEBUG - 2018-10-08 14:44:57 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:45:06 --> Model Class Initialized
DEBUG - 2018-10-08 14:45:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:45:07 --> Model Class Initialized
DEBUG - 2018-10-08 14:45:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:45:08 --> Final output sent to browser
DEBUG - 2018-10-08 14:45:08 --> Total execution time: 17.3528
INFO - 2018-10-08 14:46:08 --> Config Class Initialized
INFO - 2018-10-08 14:46:08 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:46:09 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:46:09 --> Utf8 Class Initialized
INFO - 2018-10-08 14:46:10 --> URI Class Initialized
DEBUG - 2018-10-08 14:46:10 --> No URI present. Default controller set.
INFO - 2018-10-08 14:46:10 --> Router Class Initialized
INFO - 2018-10-08 14:46:11 --> Output Class Initialized
INFO - 2018-10-08 14:46:11 --> Security Class Initialized
DEBUG - 2018-10-08 14:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:46:12 --> Input Class Initialized
INFO - 2018-10-08 14:46:12 --> Language Class Initialized
INFO - 2018-10-08 14:46:13 --> Language Class Initialized
INFO - 2018-10-08 14:46:13 --> Config Class Initialized
INFO - 2018-10-08 14:46:13 --> Loader Class Initialized
INFO - 2018-10-08 14:46:13 --> Helper loaded: url_helper
INFO - 2018-10-08 14:46:14 --> Helper loaded: form_helper
INFO - 2018-10-08 14:46:16 --> Database Driver Class Initialized
INFO - 2018-10-08 14:46:17 --> Email Class Initialized
INFO - 2018-10-08 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:46:18 --> Form Validation Class Initialized
INFO - 2018-10-08 14:46:18 --> Controller Class Initialized
DEBUG - 2018-10-08 14:46:18 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:46:19 --> Model Class Initialized
DEBUG - 2018-10-08 14:46:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:46:20 --> Model Class Initialized
DEBUG - 2018-10-08 14:46:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:46:20 --> Final output sent to browser
DEBUG - 2018-10-08 14:46:21 --> Total execution time: 12.3302
INFO - 2018-10-08 14:47:29 --> Config Class Initialized
INFO - 2018-10-08 14:47:29 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:47:30 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:47:31 --> Utf8 Class Initialized
INFO - 2018-10-08 14:47:31 --> URI Class Initialized
DEBUG - 2018-10-08 14:47:32 --> No URI present. Default controller set.
INFO - 2018-10-08 14:47:32 --> Router Class Initialized
INFO - 2018-10-08 14:47:32 --> Output Class Initialized
INFO - 2018-10-08 14:47:33 --> Security Class Initialized
DEBUG - 2018-10-08 14:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:47:35 --> Input Class Initialized
INFO - 2018-10-08 14:47:35 --> Language Class Initialized
INFO - 2018-10-08 14:47:36 --> Language Class Initialized
INFO - 2018-10-08 14:47:36 --> Config Class Initialized
INFO - 2018-10-08 14:47:37 --> Loader Class Initialized
INFO - 2018-10-08 14:47:37 --> Helper loaded: url_helper
INFO - 2018-10-08 14:47:37 --> Helper loaded: form_helper
INFO - 2018-10-08 14:47:38 --> Database Driver Class Initialized
INFO - 2018-10-08 14:47:38 --> Email Class Initialized
INFO - 2018-10-08 14:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:47:39 --> Form Validation Class Initialized
INFO - 2018-10-08 14:47:39 --> Controller Class Initialized
DEBUG - 2018-10-08 14:47:39 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:47:40 --> Model Class Initialized
DEBUG - 2018-10-08 14:47:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:47:40 --> Model Class Initialized
DEBUG - 2018-10-08 14:47:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:47:41 --> Final output sent to browser
DEBUG - 2018-10-08 14:47:41 --> Total execution time: 11.6502
INFO - 2018-10-08 14:49:12 --> Config Class Initialized
INFO - 2018-10-08 14:49:12 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:49:13 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:49:13 --> Utf8 Class Initialized
INFO - 2018-10-08 14:49:14 --> URI Class Initialized
DEBUG - 2018-10-08 14:49:14 --> No URI present. Default controller set.
INFO - 2018-10-08 14:49:15 --> Router Class Initialized
INFO - 2018-10-08 14:49:15 --> Output Class Initialized
INFO - 2018-10-08 14:49:16 --> Security Class Initialized
DEBUG - 2018-10-08 14:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:49:16 --> Input Class Initialized
INFO - 2018-10-08 14:49:17 --> Language Class Initialized
INFO - 2018-10-08 14:49:17 --> Language Class Initialized
INFO - 2018-10-08 14:49:18 --> Config Class Initialized
INFO - 2018-10-08 14:49:18 --> Loader Class Initialized
INFO - 2018-10-08 14:49:18 --> Helper loaded: url_helper
INFO - 2018-10-08 14:49:19 --> Helper loaded: form_helper
INFO - 2018-10-08 14:49:19 --> Database Driver Class Initialized
INFO - 2018-10-08 14:49:19 --> Email Class Initialized
INFO - 2018-10-08 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:49:20 --> Form Validation Class Initialized
INFO - 2018-10-08 14:49:20 --> Controller Class Initialized
DEBUG - 2018-10-08 14:49:21 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:49:21 --> Model Class Initialized
DEBUG - 2018-10-08 14:49:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:49:22 --> Model Class Initialized
DEBUG - 2018-10-08 14:49:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:49:23 --> Final output sent to browser
DEBUG - 2018-10-08 14:49:23 --> Total execution time: 10.5777
INFO - 2018-10-08 14:49:51 --> Config Class Initialized
INFO - 2018-10-08 14:49:51 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:49:52 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:49:52 --> Utf8 Class Initialized
INFO - 2018-10-08 14:49:53 --> URI Class Initialized
DEBUG - 2018-10-08 14:49:53 --> No URI present. Default controller set.
INFO - 2018-10-08 14:49:53 --> Router Class Initialized
INFO - 2018-10-08 14:49:54 --> Output Class Initialized
INFO - 2018-10-08 14:49:54 --> Security Class Initialized
DEBUG - 2018-10-08 14:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:49:55 --> Input Class Initialized
INFO - 2018-10-08 14:49:55 --> Language Class Initialized
INFO - 2018-10-08 14:49:55 --> Language Class Initialized
INFO - 2018-10-08 14:49:56 --> Config Class Initialized
INFO - 2018-10-08 14:49:56 --> Loader Class Initialized
INFO - 2018-10-08 14:49:56 --> Helper loaded: url_helper
INFO - 2018-10-08 14:49:57 --> Helper loaded: form_helper
INFO - 2018-10-08 14:49:57 --> Database Driver Class Initialized
INFO - 2018-10-08 14:49:58 --> Email Class Initialized
INFO - 2018-10-08 14:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:49:58 --> Form Validation Class Initialized
INFO - 2018-10-08 14:49:59 --> Controller Class Initialized
DEBUG - 2018-10-08 14:49:59 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:49:59 --> Model Class Initialized
DEBUG - 2018-10-08 14:50:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:50:00 --> Model Class Initialized
DEBUG - 2018-10-08 14:50:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:50:02 --> Final output sent to browser
DEBUG - 2018-10-08 14:50:02 --> Total execution time: 10.4877
INFO - 2018-10-08 14:50:52 --> Config Class Initialized
INFO - 2018-10-08 14:50:52 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:50:53 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:50:53 --> Utf8 Class Initialized
INFO - 2018-10-08 14:50:54 --> URI Class Initialized
DEBUG - 2018-10-08 14:50:55 --> No URI present. Default controller set.
INFO - 2018-10-08 14:50:55 --> Router Class Initialized
INFO - 2018-10-08 14:50:55 --> Output Class Initialized
INFO - 2018-10-08 14:50:56 --> Security Class Initialized
DEBUG - 2018-10-08 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:50:57 --> Input Class Initialized
INFO - 2018-10-08 14:50:57 --> Language Class Initialized
INFO - 2018-10-08 14:50:58 --> Language Class Initialized
INFO - 2018-10-08 14:50:58 --> Config Class Initialized
INFO - 2018-10-08 14:50:59 --> Loader Class Initialized
INFO - 2018-10-08 14:50:59 --> Helper loaded: url_helper
INFO - 2018-10-08 14:50:59 --> Helper loaded: form_helper
INFO - 2018-10-08 14:51:00 --> Database Driver Class Initialized
INFO - 2018-10-08 14:51:00 --> Email Class Initialized
INFO - 2018-10-08 14:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:51:01 --> Form Validation Class Initialized
INFO - 2018-10-08 14:51:01 --> Controller Class Initialized
DEBUG - 2018-10-08 14:51:01 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:51:02 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:51:03 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:51:04 --> Final output sent to browser
DEBUG - 2018-10-08 14:51:05 --> Total execution time: 11.5127
INFO - 2018-10-08 14:51:15 --> Config Class Initialized
INFO - 2018-10-08 14:51:15 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:51:16 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:51:16 --> Utf8 Class Initialized
INFO - 2018-10-08 14:51:16 --> URI Class Initialized
DEBUG - 2018-10-08 14:51:17 --> No URI present. Default controller set.
INFO - 2018-10-08 14:51:17 --> Router Class Initialized
INFO - 2018-10-08 14:51:18 --> Output Class Initialized
INFO - 2018-10-08 14:51:19 --> Security Class Initialized
DEBUG - 2018-10-08 14:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:51:20 --> Input Class Initialized
INFO - 2018-10-08 14:51:20 --> Language Class Initialized
INFO - 2018-10-08 14:51:21 --> Language Class Initialized
INFO - 2018-10-08 14:51:21 --> Config Class Initialized
INFO - 2018-10-08 14:51:22 --> Loader Class Initialized
INFO - 2018-10-08 14:51:22 --> Helper loaded: url_helper
INFO - 2018-10-08 14:51:23 --> Helper loaded: form_helper
INFO - 2018-10-08 14:51:23 --> Database Driver Class Initialized
INFO - 2018-10-08 14:51:23 --> Email Class Initialized
INFO - 2018-10-08 14:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:51:24 --> Form Validation Class Initialized
INFO - 2018-10-08 14:51:25 --> Controller Class Initialized
DEBUG - 2018-10-08 14:51:25 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:51:26 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:51:27 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:51:28 --> Final output sent to browser
DEBUG - 2018-10-08 14:51:28 --> Total execution time: 12.4877
INFO - 2018-10-08 14:51:39 --> Config Class Initialized
INFO - 2018-10-08 14:51:39 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:51:40 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:51:40 --> Utf8 Class Initialized
INFO - 2018-10-08 14:51:41 --> URI Class Initialized
DEBUG - 2018-10-08 14:51:41 --> No URI present. Default controller set.
INFO - 2018-10-08 14:51:41 --> Router Class Initialized
INFO - 2018-10-08 14:51:42 --> Output Class Initialized
INFO - 2018-10-08 14:51:42 --> Security Class Initialized
DEBUG - 2018-10-08 14:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:51:43 --> Input Class Initialized
INFO - 2018-10-08 14:51:43 --> Language Class Initialized
INFO - 2018-10-08 14:51:43 --> Language Class Initialized
INFO - 2018-10-08 14:51:43 --> Config Class Initialized
INFO - 2018-10-08 14:51:44 --> Loader Class Initialized
INFO - 2018-10-08 14:51:44 --> Helper loaded: url_helper
INFO - 2018-10-08 14:51:44 --> Helper loaded: form_helper
INFO - 2018-10-08 14:51:44 --> Database Driver Class Initialized
INFO - 2018-10-08 14:51:45 --> Email Class Initialized
INFO - 2018-10-08 14:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:51:45 --> Form Validation Class Initialized
INFO - 2018-10-08 14:51:45 --> Controller Class Initialized
DEBUG - 2018-10-08 14:51:46 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:51:46 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:51:46 --> Model Class Initialized
DEBUG - 2018-10-08 14:51:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:51:47 --> Final output sent to browser
DEBUG - 2018-10-08 14:51:47 --> Total execution time: 7.6401
INFO - 2018-10-08 14:55:54 --> Config Class Initialized
INFO - 2018-10-08 14:55:54 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:56:00 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:56:00 --> Utf8 Class Initialized
INFO - 2018-10-08 14:56:00 --> URI Class Initialized
DEBUG - 2018-10-08 14:56:01 --> No URI present. Default controller set.
INFO - 2018-10-08 14:56:01 --> Router Class Initialized
INFO - 2018-10-08 14:56:02 --> Output Class Initialized
INFO - 2018-10-08 14:56:02 --> Security Class Initialized
DEBUG - 2018-10-08 14:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:56:03 --> Input Class Initialized
INFO - 2018-10-08 14:56:03 --> Language Class Initialized
INFO - 2018-10-08 14:56:04 --> Language Class Initialized
INFO - 2018-10-08 14:56:04 --> Config Class Initialized
INFO - 2018-10-08 14:56:04 --> Loader Class Initialized
INFO - 2018-10-08 14:56:05 --> Helper loaded: url_helper
INFO - 2018-10-08 14:56:05 --> Helper loaded: form_helper
INFO - 2018-10-08 14:56:06 --> Database Driver Class Initialized
INFO - 2018-10-08 14:56:08 --> Email Class Initialized
INFO - 2018-10-08 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:56:12 --> Form Validation Class Initialized
INFO - 2018-10-08 14:56:13 --> Controller Class Initialized
DEBUG - 2018-10-08 14:56:13 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:56:14 --> Model Class Initialized
DEBUG - 2018-10-08 14:56:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:56:14 --> Model Class Initialized
DEBUG - 2018-10-08 14:56:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:56:16 --> Final output sent to browser
DEBUG - 2018-10-08 14:56:16 --> Total execution time: 21.8953
INFO - 2018-10-08 14:57:10 --> Config Class Initialized
INFO - 2018-10-08 14:57:10 --> Hooks Class Initialized
DEBUG - 2018-10-08 14:57:12 --> UTF-8 Support Enabled
INFO - 2018-10-08 14:57:12 --> Utf8 Class Initialized
INFO - 2018-10-08 14:57:13 --> URI Class Initialized
DEBUG - 2018-10-08 14:57:14 --> No URI present. Default controller set.
INFO - 2018-10-08 14:57:14 --> Router Class Initialized
INFO - 2018-10-08 14:57:14 --> Output Class Initialized
INFO - 2018-10-08 14:57:15 --> Security Class Initialized
DEBUG - 2018-10-08 14:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 14:57:16 --> Input Class Initialized
INFO - 2018-10-08 14:57:16 --> Language Class Initialized
INFO - 2018-10-08 14:57:17 --> Language Class Initialized
INFO - 2018-10-08 14:57:17 --> Config Class Initialized
INFO - 2018-10-08 14:57:18 --> Loader Class Initialized
INFO - 2018-10-08 14:57:19 --> Helper loaded: url_helper
INFO - 2018-10-08 14:57:19 --> Helper loaded: form_helper
INFO - 2018-10-08 14:57:22 --> Database Driver Class Initialized
INFO - 2018-10-08 14:57:23 --> Email Class Initialized
INFO - 2018-10-08 14:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 14:57:24 --> Form Validation Class Initialized
INFO - 2018-10-08 14:57:24 --> Controller Class Initialized
DEBUG - 2018-10-08 14:57:24 --> Person MX_Controller Initialized
INFO - 2018-10-08 14:57:25 --> Model Class Initialized
DEBUG - 2018-10-08 14:57:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 14:57:25 --> Model Class Initialized
DEBUG - 2018-10-08 14:57:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 14:57:26 --> Final output sent to browser
DEBUG - 2018-10-08 14:57:27 --> Total execution time: 16.9953
INFO - 2018-10-08 15:05:42 --> Config Class Initialized
INFO - 2018-10-08 15:05:42 --> Hooks Class Initialized
DEBUG - 2018-10-08 15:05:44 --> UTF-8 Support Enabled
INFO - 2018-10-08 15:05:44 --> Utf8 Class Initialized
INFO - 2018-10-08 15:05:45 --> URI Class Initialized
DEBUG - 2018-10-08 15:05:45 --> No URI present. Default controller set.
INFO - 2018-10-08 15:05:45 --> Router Class Initialized
INFO - 2018-10-08 15:05:46 --> Output Class Initialized
INFO - 2018-10-08 15:05:47 --> Security Class Initialized
DEBUG - 2018-10-08 15:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 15:05:47 --> Input Class Initialized
INFO - 2018-10-08 15:05:48 --> Language Class Initialized
INFO - 2018-10-08 15:05:48 --> Language Class Initialized
INFO - 2018-10-08 15:05:48 --> Config Class Initialized
INFO - 2018-10-08 15:05:49 --> Loader Class Initialized
INFO - 2018-10-08 15:05:49 --> Helper loaded: url_helper
INFO - 2018-10-08 15:05:50 --> Helper loaded: form_helper
INFO - 2018-10-08 15:05:50 --> Database Driver Class Initialized
INFO - 2018-10-08 15:05:51 --> Email Class Initialized
INFO - 2018-10-08 15:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 15:05:51 --> Form Validation Class Initialized
INFO - 2018-10-08 15:05:51 --> Controller Class Initialized
DEBUG - 2018-10-08 15:05:52 --> Person MX_Controller Initialized
INFO - 2018-10-08 15:05:52 --> Model Class Initialized
DEBUG - 2018-10-08 15:05:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 15:05:52 --> Model Class Initialized
DEBUG - 2018-10-08 15:05:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 15:05:53 --> Final output sent to browser
DEBUG - 2018-10-08 15:05:53 --> Total execution time: 11.3652
INFO - 2018-10-08 15:06:56 --> Config Class Initialized
INFO - 2018-10-08 15:06:56 --> Hooks Class Initialized
DEBUG - 2018-10-08 15:06:56 --> UTF-8 Support Enabled
INFO - 2018-10-08 15:06:56 --> Utf8 Class Initialized
INFO - 2018-10-08 15:06:57 --> URI Class Initialized
DEBUG - 2018-10-08 15:06:57 --> No URI present. Default controller set.
INFO - 2018-10-08 15:06:57 --> Router Class Initialized
INFO - 2018-10-08 15:06:58 --> Output Class Initialized
INFO - 2018-10-08 15:06:58 --> Security Class Initialized
DEBUG - 2018-10-08 15:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-08 15:06:59 --> Input Class Initialized
INFO - 2018-10-08 15:06:59 --> Language Class Initialized
INFO - 2018-10-08 15:06:59 --> Language Class Initialized
INFO - 2018-10-08 15:06:59 --> Config Class Initialized
INFO - 2018-10-08 15:07:00 --> Loader Class Initialized
INFO - 2018-10-08 15:07:00 --> Helper loaded: url_helper
INFO - 2018-10-08 15:07:00 --> Helper loaded: form_helper
INFO - 2018-10-08 15:07:00 --> Database Driver Class Initialized
INFO - 2018-10-08 15:07:01 --> Email Class Initialized
INFO - 2018-10-08 15:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-08 15:07:01 --> Form Validation Class Initialized
INFO - 2018-10-08 15:07:01 --> Controller Class Initialized
DEBUG - 2018-10-08 15:07:02 --> Person MX_Controller Initialized
INFO - 2018-10-08 15:07:02 --> Model Class Initialized
DEBUG - 2018-10-08 15:07:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-08 15:07:02 --> Model Class Initialized
DEBUG - 2018-10-08 15:07:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-08 15:07:03 --> Final output sent to browser
DEBUG - 2018-10-08 15:07:03 --> Total execution time: 7.2626
