<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-09 06:45:53 --> Config Class Initialized
INFO - 2018-10-09 06:45:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 06:45:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 06:45:56 --> Utf8 Class Initialized
INFO - 2018-10-09 06:45:57 --> URI Class Initialized
DEBUG - 2018-10-09 06:45:57 --> No URI present. Default controller set.
INFO - 2018-10-09 06:45:57 --> Router Class Initialized
INFO - 2018-10-09 06:45:57 --> Output Class Initialized
INFO - 2018-10-09 06:45:58 --> Security Class Initialized
DEBUG - 2018-10-09 06:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 06:45:58 --> Input Class Initialized
INFO - 2018-10-09 06:45:59 --> Language Class Initialized
INFO - 2018-10-09 06:46:00 --> Language Class Initialized
INFO - 2018-10-09 06:46:00 --> Config Class Initialized
INFO - 2018-10-09 06:46:01 --> Loader Class Initialized
INFO - 2018-10-09 06:46:02 --> Helper loaded: url_helper
INFO - 2018-10-09 06:46:02 --> Helper loaded: form_helper
INFO - 2018-10-09 06:46:04 --> Database Driver Class Initialized
INFO - 2018-10-09 06:46:21 --> Config Class Initialized
INFO - 2018-10-09 06:46:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 06:46:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 06:46:21 --> Utf8 Class Initialized
INFO - 2018-10-09 06:46:21 --> URI Class Initialized
DEBUG - 2018-10-09 06:46:21 --> No URI present. Default controller set.
INFO - 2018-10-09 06:46:21 --> Router Class Initialized
INFO - 2018-10-09 06:46:21 --> Output Class Initialized
INFO - 2018-10-09 06:46:21 --> Security Class Initialized
DEBUG - 2018-10-09 06:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 06:46:21 --> Input Class Initialized
INFO - 2018-10-09 06:46:21 --> Language Class Initialized
INFO - 2018-10-09 06:46:21 --> Language Class Initialized
INFO - 2018-10-09 06:46:21 --> Config Class Initialized
INFO - 2018-10-09 06:46:22 --> Loader Class Initialized
INFO - 2018-10-09 06:46:22 --> Helper loaded: url_helper
INFO - 2018-10-09 06:46:22 --> Helper loaded: form_helper
INFO - 2018-10-09 06:46:22 --> Database Driver Class Initialized
ERROR - 2018-10-09 06:46:28 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\User_Management\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-10-09 06:46:31 --> Email Class Initialized
INFO - 2018-10-09 06:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 06:46:34 --> Form Validation Class Initialized
INFO - 2018-10-09 06:46:34 --> Controller Class Initialized
DEBUG - 2018-10-09 06:46:34 --> Person MX_Controller Initialized
INFO - 2018-10-09 06:46:34 --> Model Class Initialized
DEBUG - 2018-10-09 06:46:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 06:46:34 --> Model Class Initialized
DEBUG - 2018-10-09 06:46:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 06:46:36 --> Final output sent to browser
DEBUG - 2018-10-09 06:46:36 --> Total execution time: 16.1502
INFO - 2018-10-09 06:59:13 --> Config Class Initialized
INFO - 2018-10-09 06:59:13 --> Hooks Class Initialized
INFO - 2018-10-09 06:59:14 --> Config Class Initialized
INFO - 2018-10-09 06:59:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 06:59:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 06:59:19 --> Utf8 Class Initialized
DEBUG - 2018-10-09 06:59:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 06:59:19 --> Utf8 Class Initialized
INFO - 2018-10-09 06:59:20 --> URI Class Initialized
INFO - 2018-10-09 06:59:20 --> URI Class Initialized
DEBUG - 2018-10-09 06:59:21 --> No URI present. Default controller set.
INFO - 2018-10-09 06:59:21 --> Router Class Initialized
DEBUG - 2018-10-09 06:59:21 --> No URI present. Default controller set.
INFO - 2018-10-09 06:59:21 --> Router Class Initialized
INFO - 2018-10-09 06:59:21 --> Output Class Initialized
INFO - 2018-10-09 06:59:21 --> Output Class Initialized
INFO - 2018-10-09 06:59:22 --> Security Class Initialized
INFO - 2018-10-09 06:59:22 --> Security Class Initialized
DEBUG - 2018-10-09 06:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 06:59:24 --> Input Class Initialized
DEBUG - 2018-10-09 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 06:59:24 --> Input Class Initialized
INFO - 2018-10-09 06:59:24 --> Language Class Initialized
INFO - 2018-10-09 06:59:24 --> Language Class Initialized
INFO - 2018-10-09 06:59:24 --> Language Class Initialized
INFO - 2018-10-09 06:59:24 --> Language Class Initialized
INFO - 2018-10-09 06:59:24 --> Config Class Initialized
INFO - 2018-10-09 06:59:25 --> Config Class Initialized
INFO - 2018-10-09 06:59:25 --> Loader Class Initialized
INFO - 2018-10-09 06:59:25 --> Loader Class Initialized
INFO - 2018-10-09 06:59:25 --> Helper loaded: url_helper
INFO - 2018-10-09 06:59:26 --> Helper loaded: url_helper
INFO - 2018-10-09 06:59:26 --> Helper loaded: form_helper
INFO - 2018-10-09 06:59:26 --> Helper loaded: form_helper
INFO - 2018-10-09 06:59:27 --> Database Driver Class Initialized
INFO - 2018-10-09 06:59:27 --> Database Driver Class Initialized
INFO - 2018-10-09 06:59:34 --> Email Class Initialized
INFO - 2018-10-09 06:59:34 --> Email Class Initialized
INFO - 2018-10-09 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 06:59:35 --> Form Validation Class Initialized
INFO - 2018-10-09 06:59:35 --> Form Validation Class Initialized
INFO - 2018-10-09 06:59:35 --> Controller Class Initialized
DEBUG - 2018-10-09 06:59:35 --> Person MX_Controller Initialized
INFO - 2018-10-09 06:59:35 --> Model Class Initialized
INFO - 2018-10-09 06:59:35 --> Controller Class Initialized
DEBUG - 2018-10-09 06:59:35 --> Person MX_Controller Initialized
INFO - 2018-10-09 06:59:35 --> Model Class Initialized
DEBUG - 2018-10-09 06:59:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 06:59:35 --> Model Class Initialized
DEBUG - 2018-10-09 06:59:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 06:59:35 --> Model Class Initialized
DEBUG - 2018-10-09 06:59:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 06:59:36 --> Final output sent to browser
DEBUG - 2018-10-09 06:59:36 --> Total execution time: 22.1803
DEBUG - 2018-10-09 06:59:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 06:59:36 --> Final output sent to browser
DEBUG - 2018-10-09 06:59:36 --> Total execution time: 24.9054
INFO - 2018-10-09 06:59:56 --> Config Class Initialized
INFO - 2018-10-09 06:59:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 06:59:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 06:59:56 --> Utf8 Class Initialized
INFO - 2018-10-09 06:59:56 --> URI Class Initialized
DEBUG - 2018-10-09 06:59:56 --> No URI present. Default controller set.
INFO - 2018-10-09 06:59:56 --> Router Class Initialized
INFO - 2018-10-09 06:59:56 --> Output Class Initialized
INFO - 2018-10-09 06:59:56 --> Security Class Initialized
DEBUG - 2018-10-09 06:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 06:59:56 --> Input Class Initialized
INFO - 2018-10-09 06:59:56 --> Language Class Initialized
INFO - 2018-10-09 06:59:56 --> Language Class Initialized
INFO - 2018-10-09 06:59:56 --> Config Class Initialized
INFO - 2018-10-09 06:59:56 --> Loader Class Initialized
INFO - 2018-10-09 06:59:57 --> Helper loaded: url_helper
INFO - 2018-10-09 06:59:57 --> Helper loaded: form_helper
INFO - 2018-10-09 06:59:57 --> Database Driver Class Initialized
INFO - 2018-10-09 06:59:57 --> Email Class Initialized
INFO - 2018-10-09 06:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 06:59:57 --> Form Validation Class Initialized
INFO - 2018-10-09 06:59:57 --> Controller Class Initialized
DEBUG - 2018-10-09 06:59:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 06:59:57 --> Model Class Initialized
DEBUG - 2018-10-09 06:59:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 06:59:57 --> Model Class Initialized
DEBUG - 2018-10-09 06:59:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 06:59:57 --> Final output sent to browser
DEBUG - 2018-10-09 06:59:57 --> Total execution time: 1.6325
INFO - 2018-10-09 07:00:32 --> Config Class Initialized
INFO - 2018-10-09 07:00:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:00:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:00:32 --> Utf8 Class Initialized
INFO - 2018-10-09 07:00:32 --> URI Class Initialized
DEBUG - 2018-10-09 07:00:32 --> No URI present. Default controller set.
INFO - 2018-10-09 07:00:32 --> Router Class Initialized
INFO - 2018-10-09 07:00:32 --> Output Class Initialized
INFO - 2018-10-09 07:00:32 --> Security Class Initialized
DEBUG - 2018-10-09 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:00:32 --> Input Class Initialized
INFO - 2018-10-09 07:00:32 --> Language Class Initialized
INFO - 2018-10-09 07:00:32 --> Language Class Initialized
INFO - 2018-10-09 07:00:32 --> Config Class Initialized
INFO - 2018-10-09 07:00:32 --> Loader Class Initialized
INFO - 2018-10-09 07:00:32 --> Helper loaded: url_helper
INFO - 2018-10-09 07:00:32 --> Helper loaded: form_helper
INFO - 2018-10-09 07:00:32 --> Database Driver Class Initialized
INFO - 2018-10-09 07:00:32 --> Email Class Initialized
INFO - 2018-10-09 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:00:32 --> Form Validation Class Initialized
INFO - 2018-10-09 07:00:32 --> Controller Class Initialized
DEBUG - 2018-10-09 07:00:32 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:00:32 --> Model Class Initialized
DEBUG - 2018-10-09 07:00:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:00:32 --> Model Class Initialized
DEBUG - 2018-10-09 07:00:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:00:33 --> Final output sent to browser
DEBUG - 2018-10-09 07:00:33 --> Total execution time: 1.1575
INFO - 2018-10-09 07:00:38 --> Config Class Initialized
INFO - 2018-10-09 07:00:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:00:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:00:38 --> Utf8 Class Initialized
INFO - 2018-10-09 07:00:38 --> URI Class Initialized
DEBUG - 2018-10-09 07:00:38 --> No URI present. Default controller set.
INFO - 2018-10-09 07:00:38 --> Router Class Initialized
INFO - 2018-10-09 07:00:38 --> Output Class Initialized
INFO - 2018-10-09 07:00:38 --> Security Class Initialized
DEBUG - 2018-10-09 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:00:39 --> Input Class Initialized
INFO - 2018-10-09 07:00:39 --> Language Class Initialized
INFO - 2018-10-09 07:00:39 --> Language Class Initialized
INFO - 2018-10-09 07:00:39 --> Config Class Initialized
INFO - 2018-10-09 07:00:39 --> Loader Class Initialized
INFO - 2018-10-09 07:00:39 --> Helper loaded: url_helper
INFO - 2018-10-09 07:00:39 --> Helper loaded: form_helper
INFO - 2018-10-09 07:00:39 --> Database Driver Class Initialized
INFO - 2018-10-09 07:00:39 --> Email Class Initialized
INFO - 2018-10-09 07:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:00:39 --> Form Validation Class Initialized
INFO - 2018-10-09 07:00:39 --> Controller Class Initialized
DEBUG - 2018-10-09 07:00:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:00:39 --> Model Class Initialized
DEBUG - 2018-10-09 07:00:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:00:39 --> Model Class Initialized
DEBUG - 2018-10-09 07:00:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:00:40 --> Final output sent to browser
DEBUG - 2018-10-09 07:00:40 --> Total execution time: 1.4750
INFO - 2018-10-09 07:01:15 --> Config Class Initialized
INFO - 2018-10-09 07:01:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:01:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:01:15 --> Utf8 Class Initialized
INFO - 2018-10-09 07:01:15 --> URI Class Initialized
DEBUG - 2018-10-09 07:01:16 --> No URI present. Default controller set.
INFO - 2018-10-09 07:01:16 --> Router Class Initialized
INFO - 2018-10-09 07:01:16 --> Output Class Initialized
INFO - 2018-10-09 07:01:16 --> Security Class Initialized
DEBUG - 2018-10-09 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:01:16 --> Input Class Initialized
INFO - 2018-10-09 07:01:16 --> Language Class Initialized
INFO - 2018-10-09 07:01:16 --> Language Class Initialized
INFO - 2018-10-09 07:01:16 --> Config Class Initialized
INFO - 2018-10-09 07:01:16 --> Loader Class Initialized
INFO - 2018-10-09 07:01:16 --> Helper loaded: url_helper
INFO - 2018-10-09 07:01:16 --> Helper loaded: form_helper
INFO - 2018-10-09 07:01:16 --> Database Driver Class Initialized
INFO - 2018-10-09 07:01:16 --> Email Class Initialized
INFO - 2018-10-09 07:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:01:16 --> Form Validation Class Initialized
INFO - 2018-10-09 07:01:16 --> Controller Class Initialized
DEBUG - 2018-10-09 07:01:16 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:01:16 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:01:16 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:01:16 --> Final output sent to browser
DEBUG - 2018-10-09 07:01:16 --> Total execution time: 0.9450
INFO - 2018-10-09 07:01:24 --> Config Class Initialized
INFO - 2018-10-09 07:01:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:01:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:01:24 --> Utf8 Class Initialized
INFO - 2018-10-09 07:01:24 --> URI Class Initialized
DEBUG - 2018-10-09 07:01:25 --> No URI present. Default controller set.
INFO - 2018-10-09 07:01:25 --> Router Class Initialized
INFO - 2018-10-09 07:01:25 --> Output Class Initialized
INFO - 2018-10-09 07:01:25 --> Security Class Initialized
DEBUG - 2018-10-09 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:01:25 --> Input Class Initialized
INFO - 2018-10-09 07:01:25 --> Language Class Initialized
INFO - 2018-10-09 07:01:25 --> Language Class Initialized
INFO - 2018-10-09 07:01:25 --> Config Class Initialized
INFO - 2018-10-09 07:01:25 --> Loader Class Initialized
INFO - 2018-10-09 07:01:25 --> Helper loaded: url_helper
INFO - 2018-10-09 07:01:25 --> Helper loaded: form_helper
INFO - 2018-10-09 07:01:25 --> Database Driver Class Initialized
INFO - 2018-10-09 07:01:25 --> Email Class Initialized
INFO - 2018-10-09 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:01:25 --> Form Validation Class Initialized
INFO - 2018-10-09 07:01:25 --> Controller Class Initialized
DEBUG - 2018-10-09 07:01:25 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:01:25 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:01:25 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:01:26 --> Final output sent to browser
DEBUG - 2018-10-09 07:01:26 --> Total execution time: 1.2875
INFO - 2018-10-09 07:01:42 --> Config Class Initialized
INFO - 2018-10-09 07:01:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:01:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:01:42 --> Utf8 Class Initialized
INFO - 2018-10-09 07:01:43 --> URI Class Initialized
DEBUG - 2018-10-09 07:01:43 --> No URI present. Default controller set.
INFO - 2018-10-09 07:01:43 --> Router Class Initialized
INFO - 2018-10-09 07:01:43 --> Output Class Initialized
INFO - 2018-10-09 07:01:43 --> Security Class Initialized
DEBUG - 2018-10-09 07:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:01:43 --> Input Class Initialized
INFO - 2018-10-09 07:01:43 --> Language Class Initialized
INFO - 2018-10-09 07:01:43 --> Language Class Initialized
INFO - 2018-10-09 07:01:43 --> Config Class Initialized
INFO - 2018-10-09 07:01:43 --> Loader Class Initialized
INFO - 2018-10-09 07:01:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:01:43 --> Helper loaded: form_helper
INFO - 2018-10-09 07:01:43 --> Database Driver Class Initialized
INFO - 2018-10-09 07:01:43 --> Email Class Initialized
INFO - 2018-10-09 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:01:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:01:43 --> Controller Class Initialized
DEBUG - 2018-10-09 07:01:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:01:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:01:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:01:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:01:44 --> Final output sent to browser
DEBUG - 2018-10-09 07:01:44 --> Total execution time: 1.4275
INFO - 2018-10-09 07:02:03 --> Config Class Initialized
INFO - 2018-10-09 07:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:02:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:02:04 --> Utf8 Class Initialized
INFO - 2018-10-09 07:02:04 --> URI Class Initialized
DEBUG - 2018-10-09 07:02:04 --> No URI present. Default controller set.
INFO - 2018-10-09 07:02:04 --> Router Class Initialized
INFO - 2018-10-09 07:02:04 --> Output Class Initialized
INFO - 2018-10-09 07:02:04 --> Security Class Initialized
DEBUG - 2018-10-09 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:02:04 --> Input Class Initialized
INFO - 2018-10-09 07:02:04 --> Language Class Initialized
INFO - 2018-10-09 07:02:04 --> Language Class Initialized
INFO - 2018-10-09 07:02:04 --> Config Class Initialized
INFO - 2018-10-09 07:02:04 --> Loader Class Initialized
INFO - 2018-10-09 07:02:04 --> Helper loaded: url_helper
INFO - 2018-10-09 07:02:04 --> Helper loaded: form_helper
INFO - 2018-10-09 07:02:04 --> Database Driver Class Initialized
INFO - 2018-10-09 07:02:04 --> Email Class Initialized
INFO - 2018-10-09 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:02:04 --> Form Validation Class Initialized
INFO - 2018-10-09 07:02:04 --> Controller Class Initialized
DEBUG - 2018-10-09 07:02:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:02:04 --> Model Class Initialized
DEBUG - 2018-10-09 07:02:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:02:04 --> Model Class Initialized
DEBUG - 2018-10-09 07:02:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:02:04 --> Final output sent to browser
DEBUG - 2018-10-09 07:02:04 --> Total execution time: 0.9450
INFO - 2018-10-09 07:02:58 --> Config Class Initialized
INFO - 2018-10-09 07:02:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:02:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:02:59 --> Utf8 Class Initialized
INFO - 2018-10-09 07:02:59 --> URI Class Initialized
DEBUG - 2018-10-09 07:02:59 --> No URI present. Default controller set.
INFO - 2018-10-09 07:02:59 --> Router Class Initialized
INFO - 2018-10-09 07:02:59 --> Output Class Initialized
INFO - 2018-10-09 07:02:59 --> Security Class Initialized
DEBUG - 2018-10-09 07:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:02:59 --> Input Class Initialized
INFO - 2018-10-09 07:02:59 --> Language Class Initialized
INFO - 2018-10-09 07:02:59 --> Language Class Initialized
INFO - 2018-10-09 07:02:59 --> Config Class Initialized
INFO - 2018-10-09 07:02:59 --> Loader Class Initialized
INFO - 2018-10-09 07:02:59 --> Helper loaded: url_helper
INFO - 2018-10-09 07:02:59 --> Helper loaded: form_helper
INFO - 2018-10-09 07:02:59 --> Database Driver Class Initialized
INFO - 2018-10-09 07:02:59 --> Email Class Initialized
INFO - 2018-10-09 07:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:02:59 --> Form Validation Class Initialized
INFO - 2018-10-09 07:02:59 --> Controller Class Initialized
DEBUG - 2018-10-09 07:02:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:02:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:02:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:02:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:02:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:02:59 --> Final output sent to browser
DEBUG - 2018-10-09 07:02:59 --> Total execution time: 1.0175
INFO - 2018-10-09 07:03:08 --> Config Class Initialized
INFO - 2018-10-09 07:03:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:03:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:03:08 --> Utf8 Class Initialized
INFO - 2018-10-09 07:03:08 --> URI Class Initialized
DEBUG - 2018-10-09 07:03:08 --> No URI present. Default controller set.
INFO - 2018-10-09 07:03:08 --> Router Class Initialized
INFO - 2018-10-09 07:03:08 --> Output Class Initialized
INFO - 2018-10-09 07:03:09 --> Security Class Initialized
DEBUG - 2018-10-09 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:03:09 --> Input Class Initialized
INFO - 2018-10-09 07:03:09 --> Language Class Initialized
INFO - 2018-10-09 07:03:09 --> Language Class Initialized
INFO - 2018-10-09 07:03:09 --> Config Class Initialized
INFO - 2018-10-09 07:03:09 --> Loader Class Initialized
INFO - 2018-10-09 07:03:09 --> Helper loaded: url_helper
INFO - 2018-10-09 07:03:09 --> Helper loaded: form_helper
INFO - 2018-10-09 07:03:09 --> Database Driver Class Initialized
INFO - 2018-10-09 07:03:09 --> Email Class Initialized
INFO - 2018-10-09 07:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:03:09 --> Form Validation Class Initialized
INFO - 2018-10-09 07:03:09 --> Controller Class Initialized
DEBUG - 2018-10-09 07:03:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:03:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:03:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:03:10 --> Final output sent to browser
DEBUG - 2018-10-09 07:03:10 --> Total execution time: 1.7150
INFO - 2018-10-09 07:03:11 --> Config Class Initialized
INFO - 2018-10-09 07:03:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:03:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:03:11 --> Utf8 Class Initialized
INFO - 2018-10-09 07:03:11 --> URI Class Initialized
DEBUG - 2018-10-09 07:03:11 --> No URI present. Default controller set.
INFO - 2018-10-09 07:03:11 --> Router Class Initialized
INFO - 2018-10-09 07:03:11 --> Output Class Initialized
INFO - 2018-10-09 07:03:11 --> Security Class Initialized
DEBUG - 2018-10-09 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:03:11 --> Input Class Initialized
INFO - 2018-10-09 07:03:11 --> Language Class Initialized
INFO - 2018-10-09 07:03:11 --> Language Class Initialized
INFO - 2018-10-09 07:03:11 --> Config Class Initialized
INFO - 2018-10-09 07:03:12 --> Loader Class Initialized
INFO - 2018-10-09 07:03:12 --> Helper loaded: url_helper
INFO - 2018-10-09 07:03:12 --> Helper loaded: form_helper
INFO - 2018-10-09 07:03:12 --> Database Driver Class Initialized
INFO - 2018-10-09 07:03:12 --> Email Class Initialized
INFO - 2018-10-09 07:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:03:12 --> Form Validation Class Initialized
INFO - 2018-10-09 07:03:12 --> Controller Class Initialized
DEBUG - 2018-10-09 07:03:12 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:03:12 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:03:12 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:03:12 --> Final output sent to browser
DEBUG - 2018-10-09 07:03:12 --> Total execution time: 1.7800
INFO - 2018-10-09 07:03:19 --> Config Class Initialized
INFO - 2018-10-09 07:03:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:03:20 --> Utf8 Class Initialized
INFO - 2018-10-09 07:03:20 --> URI Class Initialized
DEBUG - 2018-10-09 07:03:20 --> No URI present. Default controller set.
INFO - 2018-10-09 07:03:20 --> Router Class Initialized
INFO - 2018-10-09 07:03:20 --> Output Class Initialized
INFO - 2018-10-09 07:03:20 --> Security Class Initialized
DEBUG - 2018-10-09 07:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:03:20 --> Input Class Initialized
INFO - 2018-10-09 07:03:20 --> Language Class Initialized
INFO - 2018-10-09 07:03:20 --> Language Class Initialized
INFO - 2018-10-09 07:03:20 --> Config Class Initialized
INFO - 2018-10-09 07:03:20 --> Loader Class Initialized
INFO - 2018-10-09 07:03:20 --> Helper loaded: url_helper
INFO - 2018-10-09 07:03:20 --> Helper loaded: form_helper
INFO - 2018-10-09 07:03:20 --> Database Driver Class Initialized
INFO - 2018-10-09 07:03:20 --> Email Class Initialized
INFO - 2018-10-09 07:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:03:20 --> Form Validation Class Initialized
INFO - 2018-10-09 07:03:20 --> Controller Class Initialized
DEBUG - 2018-10-09 07:03:21 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:03:21 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:03:21 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:03:21 --> Final output sent to browser
DEBUG - 2018-10-09 07:03:21 --> Total execution time: 1.3475
INFO - 2018-10-09 07:03:50 --> Config Class Initialized
INFO - 2018-10-09 07:03:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:03:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:03:51 --> Utf8 Class Initialized
INFO - 2018-10-09 07:03:51 --> URI Class Initialized
DEBUG - 2018-10-09 07:03:51 --> No URI present. Default controller set.
INFO - 2018-10-09 07:03:51 --> Router Class Initialized
INFO - 2018-10-09 07:03:51 --> Output Class Initialized
INFO - 2018-10-09 07:03:51 --> Security Class Initialized
DEBUG - 2018-10-09 07:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:03:51 --> Input Class Initialized
INFO - 2018-10-09 07:03:51 --> Language Class Initialized
INFO - 2018-10-09 07:03:51 --> Language Class Initialized
INFO - 2018-10-09 07:03:51 --> Config Class Initialized
INFO - 2018-10-09 07:03:51 --> Loader Class Initialized
INFO - 2018-10-09 07:03:51 --> Helper loaded: url_helper
INFO - 2018-10-09 07:03:51 --> Helper loaded: form_helper
INFO - 2018-10-09 07:03:51 --> Database Driver Class Initialized
INFO - 2018-10-09 07:03:51 --> Email Class Initialized
INFO - 2018-10-09 07:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:03:51 --> Form Validation Class Initialized
INFO - 2018-10-09 07:03:51 --> Controller Class Initialized
DEBUG - 2018-10-09 07:03:51 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:03:51 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:03:51 --> Model Class Initialized
DEBUG - 2018-10-09 07:03:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:03:51 --> Final output sent to browser
DEBUG - 2018-10-09 07:03:51 --> Total execution time: 0.9825
INFO - 2018-10-09 07:04:15 --> Config Class Initialized
INFO - 2018-10-09 07:04:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:04:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:04:15 --> Utf8 Class Initialized
INFO - 2018-10-09 07:04:15 --> URI Class Initialized
DEBUG - 2018-10-09 07:04:15 --> No URI present. Default controller set.
INFO - 2018-10-09 07:04:15 --> Router Class Initialized
INFO - 2018-10-09 07:04:15 --> Output Class Initialized
INFO - 2018-10-09 07:04:15 --> Security Class Initialized
DEBUG - 2018-10-09 07:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:04:16 --> Input Class Initialized
INFO - 2018-10-09 07:04:16 --> Language Class Initialized
INFO - 2018-10-09 07:04:16 --> Language Class Initialized
INFO - 2018-10-09 07:04:16 --> Config Class Initialized
INFO - 2018-10-09 07:04:16 --> Loader Class Initialized
INFO - 2018-10-09 07:04:16 --> Helper loaded: url_helper
INFO - 2018-10-09 07:04:16 --> Helper loaded: form_helper
INFO - 2018-10-09 07:04:16 --> Database Driver Class Initialized
INFO - 2018-10-09 07:04:16 --> Email Class Initialized
INFO - 2018-10-09 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:04:16 --> Form Validation Class Initialized
INFO - 2018-10-09 07:04:16 --> Controller Class Initialized
DEBUG - 2018-10-09 07:04:16 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:04:16 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:04:16 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:04:16 --> Final output sent to browser
DEBUG - 2018-10-09 07:04:16 --> Total execution time: 1.2000
INFO - 2018-10-09 07:04:19 --> Config Class Initialized
INFO - 2018-10-09 07:04:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:04:19 --> Utf8 Class Initialized
INFO - 2018-10-09 07:04:19 --> URI Class Initialized
DEBUG - 2018-10-09 07:04:19 --> No URI present. Default controller set.
INFO - 2018-10-09 07:04:19 --> Router Class Initialized
INFO - 2018-10-09 07:04:19 --> Output Class Initialized
INFO - 2018-10-09 07:04:19 --> Security Class Initialized
DEBUG - 2018-10-09 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:04:19 --> Input Class Initialized
INFO - 2018-10-09 07:04:19 --> Language Class Initialized
INFO - 2018-10-09 07:04:19 --> Language Class Initialized
INFO - 2018-10-09 07:04:19 --> Config Class Initialized
INFO - 2018-10-09 07:04:19 --> Loader Class Initialized
INFO - 2018-10-09 07:04:19 --> Helper loaded: url_helper
INFO - 2018-10-09 07:04:19 --> Helper loaded: form_helper
INFO - 2018-10-09 07:04:19 --> Database Driver Class Initialized
INFO - 2018-10-09 07:04:19 --> Email Class Initialized
INFO - 2018-10-09 07:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:04:19 --> Form Validation Class Initialized
INFO - 2018-10-09 07:04:19 --> Controller Class Initialized
DEBUG - 2018-10-09 07:04:19 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:04:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:04:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:04:20 --> Final output sent to browser
DEBUG - 2018-10-09 07:04:20 --> Total execution time: 1.1525
INFO - 2018-10-09 07:04:25 --> Config Class Initialized
INFO - 2018-10-09 07:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:04:25 --> Utf8 Class Initialized
INFO - 2018-10-09 07:04:25 --> URI Class Initialized
DEBUG - 2018-10-09 07:04:25 --> No URI present. Default controller set.
INFO - 2018-10-09 07:04:25 --> Router Class Initialized
INFO - 2018-10-09 07:04:26 --> Output Class Initialized
INFO - 2018-10-09 07:04:26 --> Security Class Initialized
DEBUG - 2018-10-09 07:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:04:26 --> Input Class Initialized
INFO - 2018-10-09 07:04:26 --> Language Class Initialized
INFO - 2018-10-09 07:04:26 --> Language Class Initialized
INFO - 2018-10-09 07:04:26 --> Config Class Initialized
INFO - 2018-10-09 07:04:26 --> Loader Class Initialized
INFO - 2018-10-09 07:04:26 --> Helper loaded: url_helper
INFO - 2018-10-09 07:04:26 --> Helper loaded: form_helper
INFO - 2018-10-09 07:04:26 --> Database Driver Class Initialized
INFO - 2018-10-09 07:04:26 --> Email Class Initialized
INFO - 2018-10-09 07:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:04:26 --> Form Validation Class Initialized
INFO - 2018-10-09 07:04:26 --> Controller Class Initialized
DEBUG - 2018-10-09 07:04:26 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:04:26 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:04:26 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:04:26 --> Final output sent to browser
DEBUG - 2018-10-09 07:04:26 --> Total execution time: 1.3225
INFO - 2018-10-09 07:04:53 --> Config Class Initialized
INFO - 2018-10-09 07:04:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:04:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:04:53 --> Utf8 Class Initialized
INFO - 2018-10-09 07:04:53 --> URI Class Initialized
DEBUG - 2018-10-09 07:04:53 --> No URI present. Default controller set.
INFO - 2018-10-09 07:04:53 --> Router Class Initialized
INFO - 2018-10-09 07:04:53 --> Output Class Initialized
INFO - 2018-10-09 07:04:53 --> Security Class Initialized
DEBUG - 2018-10-09 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:04:53 --> Input Class Initialized
INFO - 2018-10-09 07:04:54 --> Language Class Initialized
INFO - 2018-10-09 07:04:54 --> Language Class Initialized
INFO - 2018-10-09 07:04:54 --> Config Class Initialized
INFO - 2018-10-09 07:04:54 --> Loader Class Initialized
INFO - 2018-10-09 07:04:54 --> Helper loaded: url_helper
INFO - 2018-10-09 07:04:54 --> Helper loaded: form_helper
INFO - 2018-10-09 07:04:54 --> Database Driver Class Initialized
INFO - 2018-10-09 07:04:54 --> Email Class Initialized
INFO - 2018-10-09 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:04:54 --> Form Validation Class Initialized
INFO - 2018-10-09 07:04:54 --> Controller Class Initialized
DEBUG - 2018-10-09 07:04:54 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:04:54 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:04:54 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:04:54 --> Final output sent to browser
DEBUG - 2018-10-09 07:04:54 --> Total execution time: 1.3250
INFO - 2018-10-09 07:04:55 --> Config Class Initialized
INFO - 2018-10-09 07:04:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:04:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:04:55 --> Utf8 Class Initialized
INFO - 2018-10-09 07:04:55 --> URI Class Initialized
DEBUG - 2018-10-09 07:04:56 --> No URI present. Default controller set.
INFO - 2018-10-09 07:04:56 --> Router Class Initialized
INFO - 2018-10-09 07:04:56 --> Output Class Initialized
INFO - 2018-10-09 07:04:56 --> Security Class Initialized
DEBUG - 2018-10-09 07:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:04:56 --> Input Class Initialized
INFO - 2018-10-09 07:04:56 --> Language Class Initialized
INFO - 2018-10-09 07:04:56 --> Language Class Initialized
INFO - 2018-10-09 07:04:56 --> Config Class Initialized
INFO - 2018-10-09 07:04:57 --> Loader Class Initialized
INFO - 2018-10-09 07:04:57 --> Helper loaded: url_helper
INFO - 2018-10-09 07:04:57 --> Helper loaded: form_helper
INFO - 2018-10-09 07:04:57 --> Database Driver Class Initialized
INFO - 2018-10-09 07:04:57 --> Email Class Initialized
INFO - 2018-10-09 07:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:04:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:04:57 --> Controller Class Initialized
DEBUG - 2018-10-09 07:04:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:04:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:04:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:04:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:04:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:04:58 --> Total execution time: 2.5775
INFO - 2018-10-09 07:05:10 --> Config Class Initialized
INFO - 2018-10-09 07:05:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:05:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:05:10 --> Utf8 Class Initialized
INFO - 2018-10-09 07:05:10 --> URI Class Initialized
DEBUG - 2018-10-09 07:05:10 --> No URI present. Default controller set.
INFO - 2018-10-09 07:05:10 --> Router Class Initialized
INFO - 2018-10-09 07:05:10 --> Output Class Initialized
INFO - 2018-10-09 07:05:10 --> Security Class Initialized
DEBUG - 2018-10-09 07:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:05:10 --> Input Class Initialized
INFO - 2018-10-09 07:05:10 --> Language Class Initialized
INFO - 2018-10-09 07:05:11 --> Language Class Initialized
INFO - 2018-10-09 07:05:11 --> Config Class Initialized
INFO - 2018-10-09 07:05:11 --> Loader Class Initialized
INFO - 2018-10-09 07:05:11 --> Helper loaded: url_helper
INFO - 2018-10-09 07:05:11 --> Helper loaded: form_helper
INFO - 2018-10-09 07:05:11 --> Database Driver Class Initialized
INFO - 2018-10-09 07:05:11 --> Email Class Initialized
INFO - 2018-10-09 07:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:05:11 --> Form Validation Class Initialized
INFO - 2018-10-09 07:05:11 --> Controller Class Initialized
DEBUG - 2018-10-09 07:05:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:05:11 --> Model Class Initialized
DEBUG - 2018-10-09 07:05:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:05:11 --> Model Class Initialized
DEBUG - 2018-10-09 07:05:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:05:11 --> Final output sent to browser
DEBUG - 2018-10-09 07:05:11 --> Total execution time: 1.4725
INFO - 2018-10-09 07:05:48 --> Config Class Initialized
INFO - 2018-10-09 07:05:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:05:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:05:48 --> Utf8 Class Initialized
INFO - 2018-10-09 07:05:48 --> URI Class Initialized
DEBUG - 2018-10-09 07:05:48 --> No URI present. Default controller set.
INFO - 2018-10-09 07:05:48 --> Router Class Initialized
INFO - 2018-10-09 07:05:48 --> Output Class Initialized
INFO - 2018-10-09 07:05:48 --> Security Class Initialized
DEBUG - 2018-10-09 07:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:05:48 --> Input Class Initialized
INFO - 2018-10-09 07:05:48 --> Language Class Initialized
INFO - 2018-10-09 07:05:48 --> Language Class Initialized
INFO - 2018-10-09 07:05:48 --> Config Class Initialized
INFO - 2018-10-09 07:05:49 --> Loader Class Initialized
INFO - 2018-10-09 07:05:49 --> Helper loaded: url_helper
INFO - 2018-10-09 07:05:49 --> Helper loaded: form_helper
INFO - 2018-10-09 07:05:49 --> Database Driver Class Initialized
INFO - 2018-10-09 07:05:49 --> Email Class Initialized
INFO - 2018-10-09 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:05:49 --> Form Validation Class Initialized
INFO - 2018-10-09 07:05:49 --> Controller Class Initialized
DEBUG - 2018-10-09 07:05:49 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:05:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:05:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:05:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:05:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:05:49 --> Final output sent to browser
DEBUG - 2018-10-09 07:05:49 --> Total execution time: 1.3150
INFO - 2018-10-09 07:05:58 --> Config Class Initialized
INFO - 2018-10-09 07:05:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:05:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:05:58 --> Utf8 Class Initialized
INFO - 2018-10-09 07:05:58 --> URI Class Initialized
DEBUG - 2018-10-09 07:05:59 --> No URI present. Default controller set.
INFO - 2018-10-09 07:05:59 --> Router Class Initialized
INFO - 2018-10-09 07:05:59 --> Output Class Initialized
INFO - 2018-10-09 07:05:59 --> Security Class Initialized
DEBUG - 2018-10-09 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:05:59 --> Input Class Initialized
INFO - 2018-10-09 07:05:59 --> Language Class Initialized
INFO - 2018-10-09 07:05:59 --> Language Class Initialized
INFO - 2018-10-09 07:05:59 --> Config Class Initialized
INFO - 2018-10-09 07:05:59 --> Loader Class Initialized
INFO - 2018-10-09 07:05:59 --> Helper loaded: url_helper
INFO - 2018-10-09 07:05:59 --> Helper loaded: form_helper
INFO - 2018-10-09 07:05:59 --> Database Driver Class Initialized
INFO - 2018-10-09 07:05:59 --> Email Class Initialized
INFO - 2018-10-09 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:05:59 --> Form Validation Class Initialized
INFO - 2018-10-09 07:05:59 --> Controller Class Initialized
DEBUG - 2018-10-09 07:05:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:05:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:05:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:06:00 --> Model Class Initialized
DEBUG - 2018-10-09 07:06:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:06:00 --> Final output sent to browser
DEBUG - 2018-10-09 07:06:00 --> Total execution time: 1.5075
INFO - 2018-10-09 07:06:14 --> Config Class Initialized
INFO - 2018-10-09 07:06:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:06:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:06:14 --> Utf8 Class Initialized
INFO - 2018-10-09 07:06:14 --> URI Class Initialized
DEBUG - 2018-10-09 07:06:14 --> No URI present. Default controller set.
INFO - 2018-10-09 07:06:14 --> Router Class Initialized
INFO - 2018-10-09 07:06:14 --> Output Class Initialized
INFO - 2018-10-09 07:06:14 --> Security Class Initialized
DEBUG - 2018-10-09 07:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:06:14 --> Input Class Initialized
INFO - 2018-10-09 07:06:14 --> Language Class Initialized
INFO - 2018-10-09 07:06:14 --> Language Class Initialized
INFO - 2018-10-09 07:06:14 --> Config Class Initialized
INFO - 2018-10-09 07:06:14 --> Loader Class Initialized
INFO - 2018-10-09 07:06:14 --> Helper loaded: url_helper
INFO - 2018-10-09 07:06:14 --> Helper loaded: form_helper
INFO - 2018-10-09 07:06:14 --> Database Driver Class Initialized
INFO - 2018-10-09 07:06:14 --> Email Class Initialized
INFO - 2018-10-09 07:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:06:14 --> Form Validation Class Initialized
INFO - 2018-10-09 07:06:15 --> Controller Class Initialized
DEBUG - 2018-10-09 07:06:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:06:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:06:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:06:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:06:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:06:15 --> Final output sent to browser
DEBUG - 2018-10-09 07:06:15 --> Total execution time: 1.4275
INFO - 2018-10-09 07:06:39 --> Config Class Initialized
INFO - 2018-10-09 07:06:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:06:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:06:39 --> Utf8 Class Initialized
INFO - 2018-10-09 07:06:39 --> URI Class Initialized
DEBUG - 2018-10-09 07:06:39 --> No URI present. Default controller set.
INFO - 2018-10-09 07:06:39 --> Router Class Initialized
INFO - 2018-10-09 07:06:39 --> Output Class Initialized
INFO - 2018-10-09 07:06:39 --> Security Class Initialized
DEBUG - 2018-10-09 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:06:39 --> Input Class Initialized
INFO - 2018-10-09 07:06:39 --> Language Class Initialized
INFO - 2018-10-09 07:06:40 --> Language Class Initialized
INFO - 2018-10-09 07:06:40 --> Config Class Initialized
INFO - 2018-10-09 07:06:40 --> Loader Class Initialized
INFO - 2018-10-09 07:06:40 --> Helper loaded: url_helper
INFO - 2018-10-09 07:06:40 --> Helper loaded: form_helper
INFO - 2018-10-09 07:06:40 --> Database Driver Class Initialized
INFO - 2018-10-09 07:06:40 --> Email Class Initialized
INFO - 2018-10-09 07:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:06:40 --> Form Validation Class Initialized
INFO - 2018-10-09 07:06:40 --> Controller Class Initialized
DEBUG - 2018-10-09 07:06:40 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:06:40 --> Model Class Initialized
DEBUG - 2018-10-09 07:06:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:06:40 --> Model Class Initialized
DEBUG - 2018-10-09 07:06:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:06:40 --> Final output sent to browser
DEBUG - 2018-10-09 07:06:40 --> Total execution time: 1.4675
INFO - 2018-10-09 07:07:03 --> Config Class Initialized
INFO - 2018-10-09 07:07:03 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:07:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:07:03 --> Utf8 Class Initialized
INFO - 2018-10-09 07:07:03 --> URI Class Initialized
DEBUG - 2018-10-09 07:07:03 --> No URI present. Default controller set.
INFO - 2018-10-09 07:07:03 --> Router Class Initialized
INFO - 2018-10-09 07:07:03 --> Output Class Initialized
INFO - 2018-10-09 07:07:03 --> Security Class Initialized
DEBUG - 2018-10-09 07:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:07:03 --> Input Class Initialized
INFO - 2018-10-09 07:07:03 --> Language Class Initialized
INFO - 2018-10-09 07:07:03 --> Language Class Initialized
INFO - 2018-10-09 07:07:03 --> Config Class Initialized
INFO - 2018-10-09 07:07:03 --> Loader Class Initialized
INFO - 2018-10-09 07:07:03 --> Helper loaded: url_helper
INFO - 2018-10-09 07:07:03 --> Helper loaded: form_helper
INFO - 2018-10-09 07:07:04 --> Database Driver Class Initialized
INFO - 2018-10-09 07:07:04 --> Email Class Initialized
INFO - 2018-10-09 07:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:07:04 --> Form Validation Class Initialized
INFO - 2018-10-09 07:07:04 --> Controller Class Initialized
DEBUG - 2018-10-09 07:07:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:07:04 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:07:04 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:07:04 --> Final output sent to browser
DEBUG - 2018-10-09 07:07:04 --> Total execution time: 1.4575
INFO - 2018-10-09 07:07:19 --> Config Class Initialized
INFO - 2018-10-09 07:07:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:07:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:07:19 --> Utf8 Class Initialized
INFO - 2018-10-09 07:07:19 --> URI Class Initialized
DEBUG - 2018-10-09 07:07:19 --> No URI present. Default controller set.
INFO - 2018-10-09 07:07:19 --> Router Class Initialized
INFO - 2018-10-09 07:07:19 --> Output Class Initialized
INFO - 2018-10-09 07:07:19 --> Security Class Initialized
DEBUG - 2018-10-09 07:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:07:19 --> Input Class Initialized
INFO - 2018-10-09 07:07:19 --> Language Class Initialized
INFO - 2018-10-09 07:07:19 --> Language Class Initialized
INFO - 2018-10-09 07:07:19 --> Config Class Initialized
INFO - 2018-10-09 07:07:19 --> Loader Class Initialized
INFO - 2018-10-09 07:07:19 --> Helper loaded: url_helper
INFO - 2018-10-09 07:07:19 --> Helper loaded: form_helper
INFO - 2018-10-09 07:07:20 --> Database Driver Class Initialized
INFO - 2018-10-09 07:07:20 --> Email Class Initialized
INFO - 2018-10-09 07:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:07:20 --> Form Validation Class Initialized
INFO - 2018-10-09 07:07:20 --> Controller Class Initialized
DEBUG - 2018-10-09 07:07:20 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:07:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:07:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:07:20 --> Final output sent to browser
DEBUG - 2018-10-09 07:07:20 --> Total execution time: 1.4150
INFO - 2018-10-09 07:07:43 --> Config Class Initialized
INFO - 2018-10-09 07:07:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:07:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:07:43 --> Utf8 Class Initialized
INFO - 2018-10-09 07:07:43 --> URI Class Initialized
DEBUG - 2018-10-09 07:07:43 --> No URI present. Default controller set.
INFO - 2018-10-09 07:07:43 --> Router Class Initialized
INFO - 2018-10-09 07:07:43 --> Output Class Initialized
INFO - 2018-10-09 07:07:43 --> Security Class Initialized
DEBUG - 2018-10-09 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:07:43 --> Input Class Initialized
INFO - 2018-10-09 07:07:43 --> Language Class Initialized
INFO - 2018-10-09 07:07:43 --> Language Class Initialized
INFO - 2018-10-09 07:07:44 --> Config Class Initialized
INFO - 2018-10-09 07:07:44 --> Loader Class Initialized
INFO - 2018-10-09 07:07:44 --> Helper loaded: url_helper
INFO - 2018-10-09 07:07:44 --> Helper loaded: form_helper
INFO - 2018-10-09 07:07:44 --> Database Driver Class Initialized
INFO - 2018-10-09 07:07:44 --> Email Class Initialized
INFO - 2018-10-09 07:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:07:44 --> Form Validation Class Initialized
INFO - 2018-10-09 07:07:44 --> Controller Class Initialized
DEBUG - 2018-10-09 07:07:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:07:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:07:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:07:44 --> Final output sent to browser
DEBUG - 2018-10-09 07:07:44 --> Total execution time: 1.4475
INFO - 2018-10-09 07:07:47 --> Config Class Initialized
INFO - 2018-10-09 07:07:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:07:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:07:48 --> Utf8 Class Initialized
INFO - 2018-10-09 07:07:48 --> URI Class Initialized
DEBUG - 2018-10-09 07:07:48 --> No URI present. Default controller set.
INFO - 2018-10-09 07:07:48 --> Router Class Initialized
INFO - 2018-10-09 07:07:48 --> Output Class Initialized
INFO - 2018-10-09 07:07:48 --> Security Class Initialized
DEBUG - 2018-10-09 07:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:07:48 --> Input Class Initialized
INFO - 2018-10-09 07:07:48 --> Language Class Initialized
INFO - 2018-10-09 07:07:48 --> Language Class Initialized
INFO - 2018-10-09 07:07:48 --> Config Class Initialized
INFO - 2018-10-09 07:07:48 --> Loader Class Initialized
INFO - 2018-10-09 07:07:48 --> Helper loaded: url_helper
INFO - 2018-10-09 07:07:48 --> Helper loaded: form_helper
INFO - 2018-10-09 07:07:48 --> Database Driver Class Initialized
INFO - 2018-10-09 07:07:48 --> Email Class Initialized
INFO - 2018-10-09 07:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:07:49 --> Form Validation Class Initialized
INFO - 2018-10-09 07:07:49 --> Controller Class Initialized
DEBUG - 2018-10-09 07:07:49 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:07:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:07:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:07:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:07:49 --> Final output sent to browser
DEBUG - 2018-10-09 07:07:49 --> Total execution time: 1.4200
INFO - 2018-10-09 07:08:05 --> Config Class Initialized
INFO - 2018-10-09 07:08:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:08:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:08:05 --> Utf8 Class Initialized
INFO - 2018-10-09 07:08:06 --> URI Class Initialized
DEBUG - 2018-10-09 07:08:06 --> No URI present. Default controller set.
INFO - 2018-10-09 07:08:06 --> Router Class Initialized
INFO - 2018-10-09 07:08:06 --> Output Class Initialized
INFO - 2018-10-09 07:08:06 --> Security Class Initialized
DEBUG - 2018-10-09 07:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:08:06 --> Input Class Initialized
INFO - 2018-10-09 07:08:06 --> Language Class Initialized
INFO - 2018-10-09 07:08:06 --> Language Class Initialized
INFO - 2018-10-09 07:08:06 --> Config Class Initialized
INFO - 2018-10-09 07:08:06 --> Loader Class Initialized
INFO - 2018-10-09 07:08:06 --> Helper loaded: url_helper
INFO - 2018-10-09 07:08:06 --> Helper loaded: form_helper
INFO - 2018-10-09 07:08:06 --> Database Driver Class Initialized
INFO - 2018-10-09 07:08:06 --> Email Class Initialized
INFO - 2018-10-09 07:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:08:07 --> Form Validation Class Initialized
INFO - 2018-10-09 07:08:07 --> Controller Class Initialized
DEBUG - 2018-10-09 07:08:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:08:07 --> Model Class Initialized
DEBUG - 2018-10-09 07:08:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:08:07 --> Model Class Initialized
DEBUG - 2018-10-09 07:08:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:08:07 --> Final output sent to browser
DEBUG - 2018-10-09 07:08:07 --> Total execution time: 1.5675
INFO - 2018-10-09 07:09:00 --> Config Class Initialized
INFO - 2018-10-09 07:09:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:09:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:09:00 --> Utf8 Class Initialized
INFO - 2018-10-09 07:09:00 --> URI Class Initialized
DEBUG - 2018-10-09 07:09:00 --> No URI present. Default controller set.
INFO - 2018-10-09 07:09:00 --> Router Class Initialized
INFO - 2018-10-09 07:09:00 --> Output Class Initialized
INFO - 2018-10-09 07:09:00 --> Security Class Initialized
DEBUG - 2018-10-09 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:09:00 --> Input Class Initialized
INFO - 2018-10-09 07:09:00 --> Language Class Initialized
INFO - 2018-10-09 07:09:00 --> Language Class Initialized
INFO - 2018-10-09 07:09:00 --> Config Class Initialized
INFO - 2018-10-09 07:09:00 --> Loader Class Initialized
INFO - 2018-10-09 07:09:01 --> Helper loaded: url_helper
INFO - 2018-10-09 07:09:01 --> Helper loaded: form_helper
INFO - 2018-10-09 07:09:01 --> Database Driver Class Initialized
INFO - 2018-10-09 07:09:01 --> Email Class Initialized
INFO - 2018-10-09 07:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:09:01 --> Form Validation Class Initialized
INFO - 2018-10-09 07:09:01 --> Controller Class Initialized
DEBUG - 2018-10-09 07:09:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:09:01 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:09:01 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:09:01 --> Final output sent to browser
DEBUG - 2018-10-09 07:09:01 --> Total execution time: 1.5150
INFO - 2018-10-09 07:09:13 --> Config Class Initialized
INFO - 2018-10-09 07:09:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:09:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:09:13 --> Utf8 Class Initialized
INFO - 2018-10-09 07:09:13 --> URI Class Initialized
DEBUG - 2018-10-09 07:09:14 --> No URI present. Default controller set.
INFO - 2018-10-09 07:09:14 --> Router Class Initialized
INFO - 2018-10-09 07:09:14 --> Output Class Initialized
INFO - 2018-10-09 07:09:14 --> Security Class Initialized
DEBUG - 2018-10-09 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:09:14 --> Input Class Initialized
INFO - 2018-10-09 07:09:14 --> Language Class Initialized
INFO - 2018-10-09 07:09:14 --> Language Class Initialized
INFO - 2018-10-09 07:09:14 --> Config Class Initialized
INFO - 2018-10-09 07:09:14 --> Loader Class Initialized
INFO - 2018-10-09 07:09:14 --> Helper loaded: url_helper
INFO - 2018-10-09 07:09:14 --> Helper loaded: form_helper
INFO - 2018-10-09 07:09:14 --> Database Driver Class Initialized
INFO - 2018-10-09 07:09:14 --> Email Class Initialized
INFO - 2018-10-09 07:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:09:15 --> Form Validation Class Initialized
INFO - 2018-10-09 07:09:15 --> Controller Class Initialized
DEBUG - 2018-10-09 07:09:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:09:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:09:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:09:15 --> Final output sent to browser
DEBUG - 2018-10-09 07:09:15 --> Total execution time: 1.8125
INFO - 2018-10-09 07:09:30 --> Config Class Initialized
INFO - 2018-10-09 07:09:30 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:09:30 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:09:30 --> Utf8 Class Initialized
INFO - 2018-10-09 07:09:30 --> URI Class Initialized
DEBUG - 2018-10-09 07:09:31 --> No URI present. Default controller set.
INFO - 2018-10-09 07:09:31 --> Router Class Initialized
INFO - 2018-10-09 07:09:31 --> Output Class Initialized
INFO - 2018-10-09 07:09:31 --> Security Class Initialized
DEBUG - 2018-10-09 07:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:09:31 --> Input Class Initialized
INFO - 2018-10-09 07:09:31 --> Language Class Initialized
INFO - 2018-10-09 07:09:31 --> Language Class Initialized
INFO - 2018-10-09 07:09:31 --> Config Class Initialized
INFO - 2018-10-09 07:09:31 --> Loader Class Initialized
INFO - 2018-10-09 07:09:31 --> Helper loaded: url_helper
INFO - 2018-10-09 07:09:31 --> Helper loaded: form_helper
INFO - 2018-10-09 07:09:31 --> Database Driver Class Initialized
INFO - 2018-10-09 07:09:31 --> Email Class Initialized
INFO - 2018-10-09 07:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:09:31 --> Form Validation Class Initialized
INFO - 2018-10-09 07:09:31 --> Controller Class Initialized
DEBUG - 2018-10-09 07:09:31 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:09:31 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:09:32 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:09:32 --> Final output sent to browser
DEBUG - 2018-10-09 07:09:32 --> Total execution time: 1.4175
INFO - 2018-10-09 07:09:41 --> Config Class Initialized
INFO - 2018-10-09 07:09:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:09:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:09:41 --> Utf8 Class Initialized
INFO - 2018-10-09 07:09:41 --> URI Class Initialized
DEBUG - 2018-10-09 07:09:42 --> No URI present. Default controller set.
INFO - 2018-10-09 07:09:42 --> Router Class Initialized
INFO - 2018-10-09 07:09:42 --> Config Class Initialized
INFO - 2018-10-09 07:09:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:09:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:09:42 --> Utf8 Class Initialized
INFO - 2018-10-09 07:09:42 --> Output Class Initialized
INFO - 2018-10-09 07:09:42 --> Security Class Initialized
DEBUG - 2018-10-09 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:09:42 --> Input Class Initialized
INFO - 2018-10-09 07:09:42 --> Language Class Initialized
INFO - 2018-10-09 07:09:42 --> Language Class Initialized
INFO - 2018-10-09 07:09:42 --> URI Class Initialized
DEBUG - 2018-10-09 07:09:42 --> No URI present. Default controller set.
INFO - 2018-10-09 07:09:42 --> Config Class Initialized
INFO - 2018-10-09 07:09:42 --> Router Class Initialized
INFO - 2018-10-09 07:09:42 --> Output Class Initialized
INFO - 2018-10-09 07:09:42 --> Security Class Initialized
DEBUG - 2018-10-09 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:09:43 --> Loader Class Initialized
INFO - 2018-10-09 07:09:43 --> Input Class Initialized
INFO - 2018-10-09 07:09:43 --> Language Class Initialized
INFO - 2018-10-09 07:09:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:09:43 --> Helper loaded: form_helper
INFO - 2018-10-09 07:09:43 --> Database Driver Class Initialized
INFO - 2018-10-09 07:09:43 --> Language Class Initialized
INFO - 2018-10-09 07:09:43 --> Email Class Initialized
INFO - 2018-10-09 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:09:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:09:43 --> Config Class Initialized
INFO - 2018-10-09 07:09:43 --> Loader Class Initialized
INFO - 2018-10-09 07:09:43 --> Controller Class Initialized
DEBUG - 2018-10-09 07:09:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:09:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:09:43 --> Model Class Initialized
INFO - 2018-10-09 07:09:43 --> Helper loaded: url_helper
DEBUG - 2018-10-09 07:09:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:09:43 --> Final output sent to browser
DEBUG - 2018-10-09 07:09:44 --> Total execution time: 2.5025
INFO - 2018-10-09 07:09:44 --> Helper loaded: form_helper
INFO - 2018-10-09 07:09:44 --> Database Driver Class Initialized
INFO - 2018-10-09 07:09:44 --> Email Class Initialized
INFO - 2018-10-09 07:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:09:44 --> Form Validation Class Initialized
INFO - 2018-10-09 07:09:44 --> Controller Class Initialized
DEBUG - 2018-10-09 07:09:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:09:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:09:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:09:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:09:44 --> Final output sent to browser
DEBUG - 2018-10-09 07:09:44 --> Total execution time: 2.5900
INFO - 2018-10-09 07:10:08 --> Config Class Initialized
INFO - 2018-10-09 07:10:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:10:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:10:09 --> Utf8 Class Initialized
INFO - 2018-10-09 07:10:09 --> URI Class Initialized
DEBUG - 2018-10-09 07:10:09 --> No URI present. Default controller set.
INFO - 2018-10-09 07:10:09 --> Router Class Initialized
INFO - 2018-10-09 07:10:09 --> Output Class Initialized
INFO - 2018-10-09 07:10:09 --> Security Class Initialized
DEBUG - 2018-10-09 07:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:10:09 --> Input Class Initialized
INFO - 2018-10-09 07:10:09 --> Language Class Initialized
INFO - 2018-10-09 07:10:09 --> Language Class Initialized
INFO - 2018-10-09 07:10:09 --> Config Class Initialized
INFO - 2018-10-09 07:10:09 --> Loader Class Initialized
INFO - 2018-10-09 07:10:09 --> Helper loaded: url_helper
INFO - 2018-10-09 07:10:09 --> Helper loaded: form_helper
INFO - 2018-10-09 07:10:09 --> Database Driver Class Initialized
INFO - 2018-10-09 07:10:09 --> Email Class Initialized
INFO - 2018-10-09 07:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:10:10 --> Form Validation Class Initialized
INFO - 2018-10-09 07:10:10 --> Controller Class Initialized
DEBUG - 2018-10-09 07:10:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:10:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:10:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:10:10 --> Final output sent to browser
DEBUG - 2018-10-09 07:10:10 --> Total execution time: 1.4725
INFO - 2018-10-09 07:10:22 --> Config Class Initialized
INFO - 2018-10-09 07:10:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:10:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:10:22 --> Utf8 Class Initialized
INFO - 2018-10-09 07:10:22 --> URI Class Initialized
DEBUG - 2018-10-09 07:10:22 --> No URI present. Default controller set.
INFO - 2018-10-09 07:10:22 --> Router Class Initialized
INFO - 2018-10-09 07:10:22 --> Output Class Initialized
INFO - 2018-10-09 07:10:22 --> Security Class Initialized
DEBUG - 2018-10-09 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:10:22 --> Input Class Initialized
INFO - 2018-10-09 07:10:22 --> Language Class Initialized
INFO - 2018-10-09 07:10:22 --> Language Class Initialized
INFO - 2018-10-09 07:10:22 --> Config Class Initialized
INFO - 2018-10-09 07:10:22 --> Loader Class Initialized
INFO - 2018-10-09 07:10:22 --> Helper loaded: url_helper
INFO - 2018-10-09 07:10:22 --> Helper loaded: form_helper
INFO - 2018-10-09 07:10:23 --> Database Driver Class Initialized
INFO - 2018-10-09 07:10:23 --> Email Class Initialized
INFO - 2018-10-09 07:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:10:23 --> Form Validation Class Initialized
INFO - 2018-10-09 07:10:23 --> Controller Class Initialized
DEBUG - 2018-10-09 07:10:23 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:10:23 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:10:23 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:10:23 --> Final output sent to browser
DEBUG - 2018-10-09 07:10:23 --> Total execution time: 1.5475
INFO - 2018-10-09 07:10:35 --> Config Class Initialized
INFO - 2018-10-09 07:10:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:10:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:10:35 --> Utf8 Class Initialized
INFO - 2018-10-09 07:10:36 --> URI Class Initialized
DEBUG - 2018-10-09 07:10:36 --> No URI present. Default controller set.
INFO - 2018-10-09 07:10:36 --> Router Class Initialized
INFO - 2018-10-09 07:10:36 --> Output Class Initialized
INFO - 2018-10-09 07:10:36 --> Security Class Initialized
DEBUG - 2018-10-09 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:10:36 --> Input Class Initialized
INFO - 2018-10-09 07:10:36 --> Language Class Initialized
INFO - 2018-10-09 07:10:36 --> Language Class Initialized
INFO - 2018-10-09 07:10:36 --> Config Class Initialized
INFO - 2018-10-09 07:10:36 --> Loader Class Initialized
INFO - 2018-10-09 07:10:36 --> Helper loaded: url_helper
INFO - 2018-10-09 07:10:36 --> Helper loaded: form_helper
INFO - 2018-10-09 07:10:37 --> Database Driver Class Initialized
INFO - 2018-10-09 07:10:37 --> Email Class Initialized
INFO - 2018-10-09 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:10:37 --> Form Validation Class Initialized
INFO - 2018-10-09 07:10:37 --> Controller Class Initialized
DEBUG - 2018-10-09 07:10:37 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:10:37 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:10:37 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:10:37 --> Final output sent to browser
DEBUG - 2018-10-09 07:10:37 --> Total execution time: 2.1950
INFO - 2018-10-09 07:10:52 --> Config Class Initialized
INFO - 2018-10-09 07:10:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:10:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:10:52 --> Utf8 Class Initialized
INFO - 2018-10-09 07:10:52 --> URI Class Initialized
DEBUG - 2018-10-09 07:10:52 --> No URI present. Default controller set.
INFO - 2018-10-09 07:10:52 --> Router Class Initialized
INFO - 2018-10-09 07:10:52 --> Output Class Initialized
INFO - 2018-10-09 07:10:53 --> Security Class Initialized
DEBUG - 2018-10-09 07:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:10:53 --> Input Class Initialized
INFO - 2018-10-09 07:10:53 --> Language Class Initialized
INFO - 2018-10-09 07:10:53 --> Language Class Initialized
INFO - 2018-10-09 07:10:53 --> Config Class Initialized
INFO - 2018-10-09 07:10:53 --> Loader Class Initialized
INFO - 2018-10-09 07:10:53 --> Helper loaded: url_helper
INFO - 2018-10-09 07:10:53 --> Helper loaded: form_helper
INFO - 2018-10-09 07:10:53 --> Database Driver Class Initialized
INFO - 2018-10-09 07:10:53 --> Email Class Initialized
INFO - 2018-10-09 07:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:10:53 --> Form Validation Class Initialized
INFO - 2018-10-09 07:10:53 --> Controller Class Initialized
DEBUG - 2018-10-09 07:10:53 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:10:53 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:10:53 --> Model Class Initialized
DEBUG - 2018-10-09 07:10:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:10:54 --> Final output sent to browser
DEBUG - 2018-10-09 07:10:54 --> Total execution time: 1.6000
INFO - 2018-10-09 07:11:02 --> Config Class Initialized
INFO - 2018-10-09 07:11:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:11:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:11:02 --> Utf8 Class Initialized
INFO - 2018-10-09 07:11:02 --> URI Class Initialized
DEBUG - 2018-10-09 07:11:02 --> No URI present. Default controller set.
INFO - 2018-10-09 07:11:02 --> Router Class Initialized
INFO - 2018-10-09 07:11:02 --> Output Class Initialized
INFO - 2018-10-09 07:11:03 --> Security Class Initialized
DEBUG - 2018-10-09 07:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:11:03 --> Input Class Initialized
INFO - 2018-10-09 07:11:03 --> Language Class Initialized
INFO - 2018-10-09 07:11:03 --> Language Class Initialized
INFO - 2018-10-09 07:11:03 --> Config Class Initialized
INFO - 2018-10-09 07:11:03 --> Loader Class Initialized
INFO - 2018-10-09 07:11:03 --> Helper loaded: url_helper
INFO - 2018-10-09 07:11:03 --> Helper loaded: form_helper
INFO - 2018-10-09 07:11:03 --> Database Driver Class Initialized
INFO - 2018-10-09 07:11:03 --> Email Class Initialized
INFO - 2018-10-09 07:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:11:03 --> Form Validation Class Initialized
INFO - 2018-10-09 07:11:03 --> Controller Class Initialized
DEBUG - 2018-10-09 07:11:03 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:11:03 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:11:04 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:11:04 --> Final output sent to browser
DEBUG - 2018-10-09 07:11:04 --> Total execution time: 1.7125
INFO - 2018-10-09 07:11:19 --> Config Class Initialized
INFO - 2018-10-09 07:11:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:11:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:11:19 --> Utf8 Class Initialized
INFO - 2018-10-09 07:11:19 --> URI Class Initialized
DEBUG - 2018-10-09 07:11:19 --> No URI present. Default controller set.
INFO - 2018-10-09 07:11:19 --> Router Class Initialized
INFO - 2018-10-09 07:11:19 --> Output Class Initialized
INFO - 2018-10-09 07:11:19 --> Security Class Initialized
DEBUG - 2018-10-09 07:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:11:19 --> Input Class Initialized
INFO - 2018-10-09 07:11:19 --> Language Class Initialized
INFO - 2018-10-09 07:11:19 --> Language Class Initialized
INFO - 2018-10-09 07:11:19 --> Config Class Initialized
INFO - 2018-10-09 07:11:19 --> Loader Class Initialized
INFO - 2018-10-09 07:11:19 --> Helper loaded: url_helper
INFO - 2018-10-09 07:11:20 --> Helper loaded: form_helper
INFO - 2018-10-09 07:11:20 --> Database Driver Class Initialized
INFO - 2018-10-09 07:11:20 --> Email Class Initialized
INFO - 2018-10-09 07:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:11:20 --> Form Validation Class Initialized
INFO - 2018-10-09 07:11:20 --> Controller Class Initialized
DEBUG - 2018-10-09 07:11:20 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:11:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:11:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:11:20 --> Final output sent to browser
DEBUG - 2018-10-09 07:11:20 --> Total execution time: 1.7150
INFO - 2018-10-09 07:11:24 --> Config Class Initialized
INFO - 2018-10-09 07:11:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:11:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:11:24 --> Utf8 Class Initialized
INFO - 2018-10-09 07:11:24 --> URI Class Initialized
DEBUG - 2018-10-09 07:11:25 --> No URI present. Default controller set.
INFO - 2018-10-09 07:11:25 --> Router Class Initialized
INFO - 2018-10-09 07:11:25 --> Output Class Initialized
INFO - 2018-10-09 07:11:25 --> Security Class Initialized
DEBUG - 2018-10-09 07:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:11:25 --> Input Class Initialized
INFO - 2018-10-09 07:11:25 --> Language Class Initialized
INFO - 2018-10-09 07:11:25 --> Language Class Initialized
INFO - 2018-10-09 07:11:25 --> Config Class Initialized
INFO - 2018-10-09 07:11:25 --> Loader Class Initialized
INFO - 2018-10-09 07:11:25 --> Helper loaded: url_helper
INFO - 2018-10-09 07:11:25 --> Helper loaded: form_helper
INFO - 2018-10-09 07:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 07:11:25 --> Email Class Initialized
INFO - 2018-10-09 07:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:11:26 --> Form Validation Class Initialized
INFO - 2018-10-09 07:11:26 --> Controller Class Initialized
DEBUG - 2018-10-09 07:11:26 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:11:26 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:11:26 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:11:26 --> Final output sent to browser
DEBUG - 2018-10-09 07:11:26 --> Total execution time: 1.7825
INFO - 2018-10-09 07:11:50 --> Config Class Initialized
INFO - 2018-10-09 07:11:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:11:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:11:51 --> Utf8 Class Initialized
INFO - 2018-10-09 07:11:51 --> URI Class Initialized
DEBUG - 2018-10-09 07:11:51 --> No URI present. Default controller set.
INFO - 2018-10-09 07:11:51 --> Router Class Initialized
INFO - 2018-10-09 07:11:51 --> Output Class Initialized
INFO - 2018-10-09 07:11:51 --> Security Class Initialized
DEBUG - 2018-10-09 07:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:11:51 --> Input Class Initialized
INFO - 2018-10-09 07:11:51 --> Language Class Initialized
INFO - 2018-10-09 07:11:51 --> Language Class Initialized
INFO - 2018-10-09 07:11:51 --> Config Class Initialized
INFO - 2018-10-09 07:11:51 --> Loader Class Initialized
INFO - 2018-10-09 07:11:51 --> Helper loaded: url_helper
INFO - 2018-10-09 07:11:51 --> Helper loaded: form_helper
INFO - 2018-10-09 07:11:52 --> Database Driver Class Initialized
INFO - 2018-10-09 07:11:52 --> Email Class Initialized
INFO - 2018-10-09 07:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:11:52 --> Form Validation Class Initialized
INFO - 2018-10-09 07:11:52 --> Controller Class Initialized
DEBUG - 2018-10-09 07:11:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:11:52 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:11:52 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:11:52 --> Final output sent to browser
DEBUG - 2018-10-09 07:11:52 --> Total execution time: 1.7575
INFO - 2018-10-09 07:11:56 --> Config Class Initialized
INFO - 2018-10-09 07:11:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:11:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:11:56 --> Utf8 Class Initialized
INFO - 2018-10-09 07:11:57 --> URI Class Initialized
DEBUG - 2018-10-09 07:11:57 --> No URI present. Default controller set.
INFO - 2018-10-09 07:11:57 --> Router Class Initialized
INFO - 2018-10-09 07:11:57 --> Output Class Initialized
INFO - 2018-10-09 07:11:57 --> Security Class Initialized
DEBUG - 2018-10-09 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:11:57 --> Input Class Initialized
INFO - 2018-10-09 07:11:57 --> Language Class Initialized
INFO - 2018-10-09 07:11:57 --> Language Class Initialized
INFO - 2018-10-09 07:11:57 --> Config Class Initialized
INFO - 2018-10-09 07:11:57 --> Loader Class Initialized
INFO - 2018-10-09 07:11:57 --> Helper loaded: url_helper
INFO - 2018-10-09 07:11:57 --> Helper loaded: form_helper
INFO - 2018-10-09 07:11:57 --> Database Driver Class Initialized
INFO - 2018-10-09 07:11:57 --> Email Class Initialized
INFO - 2018-10-09 07:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:11:58 --> Form Validation Class Initialized
INFO - 2018-10-09 07:11:58 --> Controller Class Initialized
DEBUG - 2018-10-09 07:11:58 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:11:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:11:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:11:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:11:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:11:58 --> Total execution time: 1.7375
INFO - 2018-10-09 07:12:08 --> Config Class Initialized
INFO - 2018-10-09 07:12:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:12:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:12:08 --> Utf8 Class Initialized
INFO - 2018-10-09 07:12:09 --> URI Class Initialized
DEBUG - 2018-10-09 07:12:09 --> No URI present. Default controller set.
INFO - 2018-10-09 07:12:09 --> Router Class Initialized
INFO - 2018-10-09 07:12:09 --> Output Class Initialized
INFO - 2018-10-09 07:12:09 --> Security Class Initialized
DEBUG - 2018-10-09 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:12:09 --> Input Class Initialized
INFO - 2018-10-09 07:12:09 --> Language Class Initialized
INFO - 2018-10-09 07:12:09 --> Language Class Initialized
INFO - 2018-10-09 07:12:09 --> Config Class Initialized
INFO - 2018-10-09 07:12:09 --> Loader Class Initialized
INFO - 2018-10-09 07:12:09 --> Helper loaded: url_helper
INFO - 2018-10-09 07:12:09 --> Helper loaded: form_helper
INFO - 2018-10-09 07:12:09 --> Database Driver Class Initialized
INFO - 2018-10-09 07:12:09 --> Email Class Initialized
INFO - 2018-10-09 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:12:10 --> Form Validation Class Initialized
INFO - 2018-10-09 07:12:10 --> Controller Class Initialized
DEBUG - 2018-10-09 07:12:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:12:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:12:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:12:10 --> Final output sent to browser
DEBUG - 2018-10-09 07:12:10 --> Total execution time: 1.7925
INFO - 2018-10-09 07:12:22 --> Config Class Initialized
INFO - 2018-10-09 07:12:22 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:12:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:12:22 --> Utf8 Class Initialized
INFO - 2018-10-09 07:12:22 --> URI Class Initialized
DEBUG - 2018-10-09 07:12:22 --> No URI present. Default controller set.
INFO - 2018-10-09 07:12:22 --> Router Class Initialized
INFO - 2018-10-09 07:12:22 --> Output Class Initialized
INFO - 2018-10-09 07:12:22 --> Security Class Initialized
DEBUG - 2018-10-09 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:12:23 --> Input Class Initialized
INFO - 2018-10-09 07:12:23 --> Language Class Initialized
INFO - 2018-10-09 07:12:23 --> Language Class Initialized
INFO - 2018-10-09 07:12:23 --> Config Class Initialized
INFO - 2018-10-09 07:12:23 --> Loader Class Initialized
INFO - 2018-10-09 07:12:23 --> Helper loaded: url_helper
INFO - 2018-10-09 07:12:23 --> Helper loaded: form_helper
INFO - 2018-10-09 07:12:23 --> Database Driver Class Initialized
INFO - 2018-10-09 07:12:23 --> Email Class Initialized
INFO - 2018-10-09 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:12:23 --> Form Validation Class Initialized
INFO - 2018-10-09 07:12:23 --> Controller Class Initialized
DEBUG - 2018-10-09 07:12:23 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:12:23 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:12:24 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:12:24 --> Final output sent to browser
DEBUG - 2018-10-09 07:12:24 --> Total execution time: 1.9625
INFO - 2018-10-09 07:12:31 --> Config Class Initialized
INFO - 2018-10-09 07:12:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:12:31 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:12:31 --> Utf8 Class Initialized
INFO - 2018-10-09 07:12:31 --> URI Class Initialized
DEBUG - 2018-10-09 07:12:31 --> No URI present. Default controller set.
INFO - 2018-10-09 07:12:31 --> Router Class Initialized
INFO - 2018-10-09 07:12:31 --> Output Class Initialized
INFO - 2018-10-09 07:12:31 --> Security Class Initialized
DEBUG - 2018-10-09 07:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:12:31 --> Input Class Initialized
INFO - 2018-10-09 07:12:32 --> Language Class Initialized
INFO - 2018-10-09 07:12:32 --> Language Class Initialized
INFO - 2018-10-09 07:12:32 --> Config Class Initialized
INFO - 2018-10-09 07:12:32 --> Loader Class Initialized
INFO - 2018-10-09 07:12:32 --> Helper loaded: url_helper
INFO - 2018-10-09 07:12:32 --> Helper loaded: form_helper
INFO - 2018-10-09 07:12:32 --> Database Driver Class Initialized
INFO - 2018-10-09 07:12:32 --> Email Class Initialized
INFO - 2018-10-09 07:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:12:32 --> Form Validation Class Initialized
INFO - 2018-10-09 07:12:32 --> Controller Class Initialized
DEBUG - 2018-10-09 07:12:32 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:12:32 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:32 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:12:33 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:12:33 --> Final output sent to browser
DEBUG - 2018-10-09 07:12:33 --> Total execution time: 2.0725
INFO - 2018-10-09 07:12:42 --> Config Class Initialized
INFO - 2018-10-09 07:12:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:12:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:12:42 --> Utf8 Class Initialized
INFO - 2018-10-09 07:12:42 --> URI Class Initialized
DEBUG - 2018-10-09 07:12:42 --> No URI present. Default controller set.
INFO - 2018-10-09 07:12:42 --> Router Class Initialized
INFO - 2018-10-09 07:12:42 --> Output Class Initialized
INFO - 2018-10-09 07:12:42 --> Security Class Initialized
DEBUG - 2018-10-09 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:12:42 --> Input Class Initialized
INFO - 2018-10-09 07:12:43 --> Language Class Initialized
INFO - 2018-10-09 07:12:43 --> Language Class Initialized
INFO - 2018-10-09 07:12:43 --> Config Class Initialized
INFO - 2018-10-09 07:12:43 --> Loader Class Initialized
INFO - 2018-10-09 07:12:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:12:43 --> Helper loaded: form_helper
INFO - 2018-10-09 07:12:43 --> Database Driver Class Initialized
INFO - 2018-10-09 07:12:43 --> Email Class Initialized
INFO - 2018-10-09 07:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:12:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:12:43 --> Controller Class Initialized
DEBUG - 2018-10-09 07:12:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:12:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:12:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:12:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:12:44 --> Final output sent to browser
DEBUG - 2018-10-09 07:12:44 --> Total execution time: 2.2825
INFO - 2018-10-09 07:13:40 --> Config Class Initialized
INFO - 2018-10-09 07:13:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:13:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:13:40 --> Utf8 Class Initialized
INFO - 2018-10-09 07:13:40 --> URI Class Initialized
DEBUG - 2018-10-09 07:13:40 --> No URI present. Default controller set.
INFO - 2018-10-09 07:13:40 --> Router Class Initialized
INFO - 2018-10-09 07:13:40 --> Output Class Initialized
INFO - 2018-10-09 07:13:40 --> Security Class Initialized
DEBUG - 2018-10-09 07:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:13:40 --> Input Class Initialized
INFO - 2018-10-09 07:13:40 --> Language Class Initialized
INFO - 2018-10-09 07:13:41 --> Language Class Initialized
INFO - 2018-10-09 07:13:41 --> Config Class Initialized
INFO - 2018-10-09 07:13:41 --> Loader Class Initialized
INFO - 2018-10-09 07:13:41 --> Helper loaded: url_helper
INFO - 2018-10-09 07:13:41 --> Helper loaded: form_helper
INFO - 2018-10-09 07:13:41 --> Database Driver Class Initialized
INFO - 2018-10-09 07:13:41 --> Email Class Initialized
INFO - 2018-10-09 07:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:13:41 --> Form Validation Class Initialized
INFO - 2018-10-09 07:13:41 --> Controller Class Initialized
DEBUG - 2018-10-09 07:13:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:13:41 --> Model Class Initialized
DEBUG - 2018-10-09 07:13:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:13:41 --> Model Class Initialized
DEBUG - 2018-10-09 07:13:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:13:42 --> Final output sent to browser
DEBUG - 2018-10-09 07:13:42 --> Total execution time: 2.0025
INFO - 2018-10-09 07:13:47 --> Config Class Initialized
INFO - 2018-10-09 07:13:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:13:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:13:47 --> Utf8 Class Initialized
INFO - 2018-10-09 07:13:47 --> URI Class Initialized
DEBUG - 2018-10-09 07:13:47 --> No URI present. Default controller set.
INFO - 2018-10-09 07:13:47 --> Router Class Initialized
INFO - 2018-10-09 07:13:47 --> Output Class Initialized
INFO - 2018-10-09 07:13:47 --> Security Class Initialized
DEBUG - 2018-10-09 07:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:13:47 --> Input Class Initialized
INFO - 2018-10-09 07:13:47 --> Language Class Initialized
INFO - 2018-10-09 07:13:47 --> Language Class Initialized
INFO - 2018-10-09 07:13:48 --> Config Class Initialized
INFO - 2018-10-09 07:13:48 --> Loader Class Initialized
INFO - 2018-10-09 07:13:48 --> Helper loaded: url_helper
INFO - 2018-10-09 07:13:48 --> Helper loaded: form_helper
INFO - 2018-10-09 07:13:48 --> Database Driver Class Initialized
INFO - 2018-10-09 07:13:48 --> Email Class Initialized
INFO - 2018-10-09 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:13:48 --> Form Validation Class Initialized
INFO - 2018-10-09 07:13:48 --> Controller Class Initialized
DEBUG - 2018-10-09 07:13:48 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:13:48 --> Model Class Initialized
DEBUG - 2018-10-09 07:13:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:13:48 --> Model Class Initialized
DEBUG - 2018-10-09 07:13:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:13:49 --> Final output sent to browser
DEBUG - 2018-10-09 07:13:49 --> Total execution time: 1.9725
INFO - 2018-10-09 07:15:00 --> Config Class Initialized
INFO - 2018-10-09 07:15:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:15:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:15:00 --> Utf8 Class Initialized
INFO - 2018-10-09 07:15:00 --> URI Class Initialized
DEBUG - 2018-10-09 07:15:00 --> No URI present. Default controller set.
INFO - 2018-10-09 07:15:00 --> Router Class Initialized
INFO - 2018-10-09 07:15:01 --> Output Class Initialized
INFO - 2018-10-09 07:15:01 --> Security Class Initialized
DEBUG - 2018-10-09 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:15:01 --> Input Class Initialized
INFO - 2018-10-09 07:15:01 --> Language Class Initialized
INFO - 2018-10-09 07:15:01 --> Language Class Initialized
INFO - 2018-10-09 07:15:01 --> Config Class Initialized
INFO - 2018-10-09 07:15:01 --> Loader Class Initialized
INFO - 2018-10-09 07:15:01 --> Helper loaded: url_helper
INFO - 2018-10-09 07:15:01 --> Helper loaded: form_helper
INFO - 2018-10-09 07:15:01 --> Database Driver Class Initialized
INFO - 2018-10-09 07:15:01 --> Email Class Initialized
INFO - 2018-10-09 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:15:02 --> Form Validation Class Initialized
INFO - 2018-10-09 07:15:02 --> Controller Class Initialized
DEBUG - 2018-10-09 07:15:02 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:15:02 --> Model Class Initialized
DEBUG - 2018-10-09 07:15:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:15:02 --> Model Class Initialized
DEBUG - 2018-10-09 07:15:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:15:02 --> Final output sent to browser
DEBUG - 2018-10-09 07:15:02 --> Total execution time: 2.0350
INFO - 2018-10-09 07:17:10 --> Config Class Initialized
INFO - 2018-10-09 07:17:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:17:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:17:10 --> Utf8 Class Initialized
INFO - 2018-10-09 07:17:10 --> URI Class Initialized
DEBUG - 2018-10-09 07:17:10 --> No URI present. Default controller set.
INFO - 2018-10-09 07:17:10 --> Router Class Initialized
INFO - 2018-10-09 07:17:10 --> Output Class Initialized
INFO - 2018-10-09 07:17:10 --> Security Class Initialized
DEBUG - 2018-10-09 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:17:11 --> Input Class Initialized
INFO - 2018-10-09 07:17:11 --> Language Class Initialized
INFO - 2018-10-09 07:17:11 --> Language Class Initialized
INFO - 2018-10-09 07:17:11 --> Config Class Initialized
INFO - 2018-10-09 07:17:11 --> Loader Class Initialized
INFO - 2018-10-09 07:17:11 --> Helper loaded: url_helper
INFO - 2018-10-09 07:17:11 --> Helper loaded: form_helper
INFO - 2018-10-09 07:17:11 --> Database Driver Class Initialized
INFO - 2018-10-09 07:17:11 --> Email Class Initialized
INFO - 2018-10-09 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:17:11 --> Form Validation Class Initialized
INFO - 2018-10-09 07:17:11 --> Controller Class Initialized
DEBUG - 2018-10-09 07:17:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:17:12 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:17:12 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:17:12 --> Final output sent to browser
DEBUG - 2018-10-09 07:17:12 --> Total execution time: 2.0925
INFO - 2018-10-09 07:17:16 --> Config Class Initialized
INFO - 2018-10-09 07:17:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:17:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:17:16 --> Utf8 Class Initialized
INFO - 2018-10-09 07:17:16 --> URI Class Initialized
DEBUG - 2018-10-09 07:17:16 --> No URI present. Default controller set.
INFO - 2018-10-09 07:17:16 --> Router Class Initialized
INFO - 2018-10-09 07:17:16 --> Output Class Initialized
INFO - 2018-10-09 07:17:16 --> Security Class Initialized
DEBUG - 2018-10-09 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:17:17 --> Input Class Initialized
INFO - 2018-10-09 07:17:17 --> Language Class Initialized
INFO - 2018-10-09 07:17:17 --> Language Class Initialized
INFO - 2018-10-09 07:17:17 --> Config Class Initialized
INFO - 2018-10-09 07:17:17 --> Loader Class Initialized
INFO - 2018-10-09 07:17:17 --> Helper loaded: url_helper
INFO - 2018-10-09 07:17:17 --> Helper loaded: form_helper
INFO - 2018-10-09 07:17:17 --> Database Driver Class Initialized
INFO - 2018-10-09 07:17:17 --> Email Class Initialized
INFO - 2018-10-09 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:17:17 --> Form Validation Class Initialized
INFO - 2018-10-09 07:17:17 --> Controller Class Initialized
DEBUG - 2018-10-09 07:17:17 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:17:17 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:17:18 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:17:18 --> Final output sent to browser
DEBUG - 2018-10-09 07:17:18 --> Total execution time: 1.9125
INFO - 2018-10-09 07:17:33 --> Config Class Initialized
INFO - 2018-10-09 07:17:33 --> Hooks Class Initialized
INFO - 2018-10-09 07:17:33 --> Config Class Initialized
INFO - 2018-10-09 07:17:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:17:33 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 07:17:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:17:33 --> Utf8 Class Initialized
INFO - 2018-10-09 07:17:34 --> Utf8 Class Initialized
INFO - 2018-10-09 07:17:34 --> URI Class Initialized
INFO - 2018-10-09 07:17:34 --> URI Class Initialized
INFO - 2018-10-09 07:17:34 --> Router Class Initialized
INFO - 2018-10-09 07:17:34 --> Output Class Initialized
INFO - 2018-10-09 07:17:34 --> Security Class Initialized
DEBUG - 2018-10-09 07:17:34 --> No URI present. Default controller set.
INFO - 2018-10-09 07:17:34 --> Router Class Initialized
INFO - 2018-10-09 07:17:34 --> Output Class Initialized
DEBUG - 2018-10-09 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:17:34 --> Input Class Initialized
INFO - 2018-10-09 07:17:34 --> Security Class Initialized
INFO - 2018-10-09 07:17:34 --> Language Class Initialized
DEBUG - 2018-10-09 07:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:17:35 --> Input Class Initialized
INFO - 2018-10-09 07:17:35 --> Language Class Initialized
INFO - 2018-10-09 07:17:35 --> Language Class Initialized
INFO - 2018-10-09 07:17:35 --> Config Class Initialized
INFO - 2018-10-09 07:17:35 --> Loader Class Initialized
INFO - 2018-10-09 07:17:35 --> Helper loaded: url_helper
INFO - 2018-10-09 07:17:35 --> Language Class Initialized
INFO - 2018-10-09 07:17:35 --> Config Class Initialized
INFO - 2018-10-09 07:17:35 --> Helper loaded: form_helper
INFO - 2018-10-09 07:17:35 --> Database Driver Class Initialized
INFO - 2018-10-09 07:17:35 --> Email Class Initialized
INFO - 2018-10-09 07:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:17:35 --> Form Validation Class Initialized
INFO - 2018-10-09 07:17:36 --> Loader Class Initialized
INFO - 2018-10-09 07:17:36 --> Helper loaded: url_helper
INFO - 2018-10-09 07:17:36 --> Helper loaded: form_helper
INFO - 2018-10-09 07:17:36 --> Controller Class Initialized
INFO - 2018-10-09 07:17:36 --> Database Driver Class Initialized
INFO - 2018-10-09 07:17:36 --> Email Class Initialized
INFO - 2018-10-09 07:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:17:36 --> Form Validation Class Initialized
INFO - 2018-10-09 07:17:36 --> Controller Class Initialized
DEBUG - 2018-10-09 07:17:36 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:17:36 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:36 --> Person MX_Controller Initialized
DEBUG - 2018-10-09 07:17:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:17:36 --> Model Class Initialized
INFO - 2018-10-09 07:17:37 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
DEBUG - 2018-10-09 07:17:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:17:37 --> Final output sent to browser
INFO - 2018-10-09 07:17:37 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:37 --> Total execution time: 3.7151
INFO - 2018-10-09 07:17:37 --> Final output sent to browser
DEBUG - 2018-10-09 07:17:37 --> Total execution time: 4.0151
INFO - 2018-10-09 07:17:43 --> Config Class Initialized
INFO - 2018-10-09 07:17:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:17:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:17:43 --> Utf8 Class Initialized
INFO - 2018-10-09 07:17:43 --> URI Class Initialized
DEBUG - 2018-10-09 07:17:44 --> No URI present. Default controller set.
INFO - 2018-10-09 07:17:44 --> Router Class Initialized
INFO - 2018-10-09 07:17:44 --> Output Class Initialized
INFO - 2018-10-09 07:17:44 --> Security Class Initialized
DEBUG - 2018-10-09 07:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:17:44 --> Input Class Initialized
INFO - 2018-10-09 07:17:44 --> Language Class Initialized
INFO - 2018-10-09 07:17:44 --> Language Class Initialized
INFO - 2018-10-09 07:17:44 --> Config Class Initialized
INFO - 2018-10-09 07:17:45 --> Loader Class Initialized
INFO - 2018-10-09 07:17:45 --> Helper loaded: url_helper
INFO - 2018-10-09 07:17:45 --> Helper loaded: form_helper
INFO - 2018-10-09 07:17:45 --> Database Driver Class Initialized
INFO - 2018-10-09 07:17:45 --> Email Class Initialized
INFO - 2018-10-09 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:17:45 --> Form Validation Class Initialized
INFO - 2018-10-09 07:17:45 --> Controller Class Initialized
DEBUG - 2018-10-09 07:17:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:17:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:17:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:17:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:17:46 --> Final output sent to browser
DEBUG - 2018-10-09 07:17:46 --> Total execution time: 2.4550
INFO - 2018-10-09 07:19:55 --> Config Class Initialized
INFO - 2018-10-09 07:19:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:19:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:19:55 --> Utf8 Class Initialized
INFO - 2018-10-09 07:19:55 --> URI Class Initialized
DEBUG - 2018-10-09 07:19:55 --> No URI present. Default controller set.
INFO - 2018-10-09 07:19:55 --> Router Class Initialized
INFO - 2018-10-09 07:19:55 --> Output Class Initialized
INFO - 2018-10-09 07:19:55 --> Security Class Initialized
DEBUG - 2018-10-09 07:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:19:55 --> Input Class Initialized
INFO - 2018-10-09 07:19:55 --> Language Class Initialized
INFO - 2018-10-09 07:19:55 --> Language Class Initialized
INFO - 2018-10-09 07:19:56 --> Config Class Initialized
INFO - 2018-10-09 07:19:56 --> Loader Class Initialized
INFO - 2018-10-09 07:19:56 --> Helper loaded: url_helper
INFO - 2018-10-09 07:19:56 --> Helper loaded: form_helper
INFO - 2018-10-09 07:19:56 --> Database Driver Class Initialized
INFO - 2018-10-09 07:19:56 --> Email Class Initialized
INFO - 2018-10-09 07:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:19:56 --> Form Validation Class Initialized
INFO - 2018-10-09 07:19:56 --> Controller Class Initialized
DEBUG - 2018-10-09 07:19:56 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:19:56 --> Model Class Initialized
DEBUG - 2018-10-09 07:19:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:19:56 --> Model Class Initialized
DEBUG - 2018-10-09 07:19:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:19:57 --> Final output sent to browser
DEBUG - 2018-10-09 07:19:57 --> Total execution time: 2.0125
INFO - 2018-10-09 07:20:36 --> Config Class Initialized
INFO - 2018-10-09 07:20:36 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:20:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:20:36 --> Utf8 Class Initialized
INFO - 2018-10-09 07:20:36 --> URI Class Initialized
DEBUG - 2018-10-09 07:20:37 --> No URI present. Default controller set.
INFO - 2018-10-09 07:20:37 --> Router Class Initialized
INFO - 2018-10-09 07:20:37 --> Output Class Initialized
INFO - 2018-10-09 07:20:37 --> Config Class Initialized
INFO - 2018-10-09 07:20:37 --> Security Class Initialized
DEBUG - 2018-10-09 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:20:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:20:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:20:37 --> Input Class Initialized
INFO - 2018-10-09 07:20:37 --> Utf8 Class Initialized
INFO - 2018-10-09 07:20:38 --> Language Class Initialized
INFO - 2018-10-09 07:20:38 --> URI Class Initialized
DEBUG - 2018-10-09 07:20:38 --> No URI present. Default controller set.
INFO - 2018-10-09 07:20:38 --> Router Class Initialized
INFO - 2018-10-09 07:20:38 --> Language Class Initialized
INFO - 2018-10-09 07:20:38 --> Config Class Initialized
INFO - 2018-10-09 07:20:38 --> Loader Class Initialized
INFO - 2018-10-09 07:20:38 --> Config Class Initialized
INFO - 2018-10-09 07:20:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:20:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:20:38 --> Utf8 Class Initialized
INFO - 2018-10-09 07:20:38 --> URI Class Initialized
INFO - 2018-10-09 07:20:39 --> Helper loaded: url_helper
DEBUG - 2018-10-09 07:20:39 --> No URI present. Default controller set.
INFO - 2018-10-09 07:20:39 --> Helper loaded: form_helper
INFO - 2018-10-09 07:20:39 --> Database Driver Class Initialized
INFO - 2018-10-09 07:20:39 --> Output Class Initialized
INFO - 2018-10-09 07:20:39 --> Security Class Initialized
INFO - 2018-10-09 07:20:39 --> Router Class Initialized
INFO - 2018-10-09 07:20:39 --> Output Class Initialized
INFO - 2018-10-09 07:20:39 --> Security Class Initialized
DEBUG - 2018-10-09 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:20:39 --> Input Class Initialized
INFO - 2018-10-09 07:20:39 --> Language Class Initialized
INFO - 2018-10-09 07:20:39 --> Language Class Initialized
INFO - 2018-10-09 07:20:40 --> Config Class Initialized
INFO - 2018-10-09 07:20:40 --> Loader Class Initialized
INFO - 2018-10-09 07:20:40 --> Helper loaded: url_helper
INFO - 2018-10-09 07:20:40 --> Email Class Initialized
INFO - 2018-10-09 07:20:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-09 07:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:20:40 --> Input Class Initialized
INFO - 2018-10-09 07:20:40 --> Helper loaded: form_helper
INFO - 2018-10-09 07:20:40 --> Form Validation Class Initialized
INFO - 2018-10-09 07:20:40 --> Controller Class Initialized
INFO - 2018-10-09 07:20:40 --> Language Class Initialized
INFO - 2018-10-09 07:20:40 --> Language Class Initialized
INFO - 2018-10-09 07:20:40 --> Config Class Initialized
INFO - 2018-10-09 07:20:40 --> Loader Class Initialized
INFO - 2018-10-09 07:20:41 --> Helper loaded: url_helper
INFO - 2018-10-09 07:20:41 --> Database Driver Class Initialized
INFO - 2018-10-09 07:20:41 --> Email Class Initialized
INFO - 2018-10-09 07:20:41 --> Helper loaded: form_helper
INFO - 2018-10-09 07:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:20:41 --> Form Validation Class Initialized
INFO - 2018-10-09 07:20:41 --> Database Driver Class Initialized
INFO - 2018-10-09 07:20:41 --> Email Class Initialized
INFO - 2018-10-09 07:20:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-09 07:20:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:20:41 --> Controller Class Initialized
INFO - 2018-10-09 07:20:41 --> Form Validation Class Initialized
INFO - 2018-10-09 07:20:41 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:20:42 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:20:42 --> Final output sent to browser
DEBUG - 2018-10-09 07:20:42 --> Total execution time: 5.9126
DEBUG - 2018-10-09 07:20:42 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:20:42 --> Controller Class Initialized
DEBUG - 2018-10-09 07:20:42 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:20:42 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:20:42 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:20:42 --> Final output sent to browser
DEBUG - 2018-10-09 07:20:42 --> Total execution time: 5.5526
INFO - 2018-10-09 07:20:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:20:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:20:43 --> Final output sent to browser
DEBUG - 2018-10-09 07:20:43 --> Total execution time: 4.9076
INFO - 2018-10-09 07:20:44 --> Config Class Initialized
INFO - 2018-10-09 07:20:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:20:45 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:20:45 --> Utf8 Class Initialized
INFO - 2018-10-09 07:20:45 --> URI Class Initialized
DEBUG - 2018-10-09 07:20:45 --> No URI present. Default controller set.
INFO - 2018-10-09 07:20:45 --> Router Class Initialized
INFO - 2018-10-09 07:20:45 --> Output Class Initialized
INFO - 2018-10-09 07:20:45 --> Security Class Initialized
DEBUG - 2018-10-09 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:20:45 --> Input Class Initialized
INFO - 2018-10-09 07:20:46 --> Language Class Initialized
INFO - 2018-10-09 07:20:46 --> Language Class Initialized
INFO - 2018-10-09 07:20:46 --> Config Class Initialized
INFO - 2018-10-09 07:20:46 --> Loader Class Initialized
INFO - 2018-10-09 07:20:46 --> Helper loaded: url_helper
INFO - 2018-10-09 07:20:46 --> Helper loaded: form_helper
INFO - 2018-10-09 07:20:46 --> Database Driver Class Initialized
INFO - 2018-10-09 07:20:46 --> Email Class Initialized
INFO - 2018-10-09 07:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:20:46 --> Form Validation Class Initialized
INFO - 2018-10-09 07:20:46 --> Controller Class Initialized
DEBUG - 2018-10-09 07:20:46 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:20:46 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:20:47 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:20:47 --> Final output sent to browser
DEBUG - 2018-10-09 07:20:47 --> Total execution time: 2.5175
INFO - 2018-10-09 07:20:53 --> Config Class Initialized
INFO - 2018-10-09 07:20:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:20:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:20:53 --> Utf8 Class Initialized
INFO - 2018-10-09 07:20:53 --> URI Class Initialized
DEBUG - 2018-10-09 07:20:54 --> No URI present. Default controller set.
INFO - 2018-10-09 07:20:54 --> Router Class Initialized
INFO - 2018-10-09 07:20:54 --> Output Class Initialized
INFO - 2018-10-09 07:20:54 --> Security Class Initialized
DEBUG - 2018-10-09 07:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:20:54 --> Input Class Initialized
INFO - 2018-10-09 07:20:54 --> Language Class Initialized
INFO - 2018-10-09 07:20:54 --> Language Class Initialized
INFO - 2018-10-09 07:20:54 --> Config Class Initialized
INFO - 2018-10-09 07:20:54 --> Loader Class Initialized
INFO - 2018-10-09 07:20:54 --> Helper loaded: url_helper
INFO - 2018-10-09 07:20:54 --> Helper loaded: form_helper
INFO - 2018-10-09 07:20:55 --> Database Driver Class Initialized
INFO - 2018-10-09 07:20:55 --> Email Class Initialized
INFO - 2018-10-09 07:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:20:55 --> Form Validation Class Initialized
INFO - 2018-10-09 07:20:55 --> Controller Class Initialized
DEBUG - 2018-10-09 07:20:55 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:20:55 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:20:55 --> Model Class Initialized
DEBUG - 2018-10-09 07:20:55 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:20:55 --> Final output sent to browser
DEBUG - 2018-10-09 07:20:55 --> Total execution time: 2.4275
INFO - 2018-10-09 07:22:19 --> Config Class Initialized
INFO - 2018-10-09 07:22:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:22:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:22:19 --> Utf8 Class Initialized
INFO - 2018-10-09 07:22:19 --> URI Class Initialized
DEBUG - 2018-10-09 07:22:19 --> No URI present. Default controller set.
INFO - 2018-10-09 07:22:19 --> Router Class Initialized
INFO - 2018-10-09 07:22:19 --> Output Class Initialized
INFO - 2018-10-09 07:22:19 --> Security Class Initialized
DEBUG - 2018-10-09 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:22:20 --> Input Class Initialized
INFO - 2018-10-09 07:22:20 --> Language Class Initialized
INFO - 2018-10-09 07:22:20 --> Language Class Initialized
INFO - 2018-10-09 07:22:20 --> Config Class Initialized
INFO - 2018-10-09 07:22:20 --> Loader Class Initialized
INFO - 2018-10-09 07:22:20 --> Helper loaded: url_helper
INFO - 2018-10-09 07:22:20 --> Helper loaded: form_helper
INFO - 2018-10-09 07:22:20 --> Database Driver Class Initialized
INFO - 2018-10-09 07:22:20 --> Email Class Initialized
INFO - 2018-10-09 07:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:22:20 --> Form Validation Class Initialized
INFO - 2018-10-09 07:22:20 --> Controller Class Initialized
DEBUG - 2018-10-09 07:22:21 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:22:21 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:22:21 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:22:21 --> Final output sent to browser
DEBUG - 2018-10-09 07:22:21 --> Total execution time: 2.2175
INFO - 2018-10-09 07:22:25 --> Config Class Initialized
INFO - 2018-10-09 07:22:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:22:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:22:25 --> Utf8 Class Initialized
INFO - 2018-10-09 07:22:26 --> URI Class Initialized
DEBUG - 2018-10-09 07:22:26 --> No URI present. Default controller set.
INFO - 2018-10-09 07:22:26 --> Router Class Initialized
INFO - 2018-10-09 07:22:26 --> Output Class Initialized
INFO - 2018-10-09 07:22:26 --> Security Class Initialized
DEBUG - 2018-10-09 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:22:26 --> Input Class Initialized
INFO - 2018-10-09 07:22:26 --> Language Class Initialized
INFO - 2018-10-09 07:22:26 --> Language Class Initialized
INFO - 2018-10-09 07:22:26 --> Config Class Initialized
INFO - 2018-10-09 07:22:26 --> Loader Class Initialized
INFO - 2018-10-09 07:22:26 --> Helper loaded: url_helper
INFO - 2018-10-09 07:22:27 --> Helper loaded: form_helper
INFO - 2018-10-09 07:22:27 --> Database Driver Class Initialized
INFO - 2018-10-09 07:22:27 --> Email Class Initialized
INFO - 2018-10-09 07:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:22:27 --> Form Validation Class Initialized
INFO - 2018-10-09 07:22:27 --> Controller Class Initialized
DEBUG - 2018-10-09 07:22:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:22:27 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:22:27 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:22:27 --> Final output sent to browser
DEBUG - 2018-10-09 07:22:28 --> Total execution time: 2.3550
INFO - 2018-10-09 07:22:42 --> Config Class Initialized
INFO - 2018-10-09 07:22:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:22:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:22:42 --> Utf8 Class Initialized
INFO - 2018-10-09 07:22:43 --> URI Class Initialized
DEBUG - 2018-10-09 07:22:43 --> No URI present. Default controller set.
INFO - 2018-10-09 07:22:43 --> Router Class Initialized
INFO - 2018-10-09 07:22:43 --> Output Class Initialized
INFO - 2018-10-09 07:22:43 --> Security Class Initialized
DEBUG - 2018-10-09 07:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:22:43 --> Input Class Initialized
INFO - 2018-10-09 07:22:43 --> Language Class Initialized
INFO - 2018-10-09 07:22:43 --> Language Class Initialized
INFO - 2018-10-09 07:22:43 --> Config Class Initialized
INFO - 2018-10-09 07:22:43 --> Loader Class Initialized
INFO - 2018-10-09 07:22:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:22:44 --> Helper loaded: form_helper
INFO - 2018-10-09 07:22:44 --> Database Driver Class Initialized
INFO - 2018-10-09 07:22:44 --> Email Class Initialized
INFO - 2018-10-09 07:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:22:44 --> Form Validation Class Initialized
INFO - 2018-10-09 07:22:44 --> Controller Class Initialized
DEBUG - 2018-10-09 07:22:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:22:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:22:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:22:44 --> Final output sent to browser
DEBUG - 2018-10-09 07:22:44 --> Total execution time: 2.2050
INFO - 2018-10-09 07:22:54 --> Config Class Initialized
INFO - 2018-10-09 07:22:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:22:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:22:54 --> Utf8 Class Initialized
INFO - 2018-10-09 07:22:54 --> URI Class Initialized
DEBUG - 2018-10-09 07:22:54 --> No URI present. Default controller set.
INFO - 2018-10-09 07:22:54 --> Router Class Initialized
INFO - 2018-10-09 07:22:54 --> Output Class Initialized
INFO - 2018-10-09 07:22:54 --> Security Class Initialized
DEBUG - 2018-10-09 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:22:55 --> Input Class Initialized
INFO - 2018-10-09 07:22:55 --> Language Class Initialized
INFO - 2018-10-09 07:22:55 --> Language Class Initialized
INFO - 2018-10-09 07:22:55 --> Config Class Initialized
INFO - 2018-10-09 07:22:55 --> Loader Class Initialized
INFO - 2018-10-09 07:22:55 --> Helper loaded: url_helper
INFO - 2018-10-09 07:22:55 --> Helper loaded: form_helper
INFO - 2018-10-09 07:22:55 --> Database Driver Class Initialized
INFO - 2018-10-09 07:22:55 --> Email Class Initialized
INFO - 2018-10-09 07:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:22:55 --> Form Validation Class Initialized
INFO - 2018-10-09 07:22:55 --> Controller Class Initialized
DEBUG - 2018-10-09 07:22:56 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:22:56 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:22:56 --> Model Class Initialized
DEBUG - 2018-10-09 07:22:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:22:56 --> Final output sent to browser
DEBUG - 2018-10-09 07:22:56 --> Total execution time: 2.4925
INFO - 2018-10-09 07:23:35 --> Config Class Initialized
INFO - 2018-10-09 07:23:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:23:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:23:36 --> Utf8 Class Initialized
INFO - 2018-10-09 07:23:36 --> URI Class Initialized
DEBUG - 2018-10-09 07:23:36 --> No URI present. Default controller set.
INFO - 2018-10-09 07:23:36 --> Router Class Initialized
INFO - 2018-10-09 07:23:36 --> Output Class Initialized
INFO - 2018-10-09 07:23:36 --> Security Class Initialized
DEBUG - 2018-10-09 07:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:23:36 --> Input Class Initialized
INFO - 2018-10-09 07:23:36 --> Language Class Initialized
INFO - 2018-10-09 07:23:37 --> Language Class Initialized
INFO - 2018-10-09 07:23:37 --> Config Class Initialized
INFO - 2018-10-09 07:23:37 --> Loader Class Initialized
INFO - 2018-10-09 07:23:37 --> Helper loaded: url_helper
INFO - 2018-10-09 07:23:37 --> Helper loaded: form_helper
INFO - 2018-10-09 07:23:37 --> Database Driver Class Initialized
INFO - 2018-10-09 07:23:37 --> Email Class Initialized
INFO - 2018-10-09 07:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:23:37 --> Form Validation Class Initialized
INFO - 2018-10-09 07:23:37 --> Controller Class Initialized
DEBUG - 2018-10-09 07:23:37 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:23:38 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:23:38 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:23:38 --> Final output sent to browser
DEBUG - 2018-10-09 07:23:38 --> Total execution time: 3.0150
INFO - 2018-10-09 07:23:41 --> Config Class Initialized
INFO - 2018-10-09 07:23:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:23:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:23:41 --> Utf8 Class Initialized
INFO - 2018-10-09 07:23:42 --> URI Class Initialized
DEBUG - 2018-10-09 07:23:42 --> No URI present. Default controller set.
INFO - 2018-10-09 07:23:42 --> Router Class Initialized
INFO - 2018-10-09 07:23:42 --> Output Class Initialized
INFO - 2018-10-09 07:23:42 --> Security Class Initialized
DEBUG - 2018-10-09 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:23:42 --> Input Class Initialized
INFO - 2018-10-09 07:23:42 --> Language Class Initialized
INFO - 2018-10-09 07:23:42 --> Language Class Initialized
INFO - 2018-10-09 07:23:42 --> Config Class Initialized
INFO - 2018-10-09 07:23:43 --> Loader Class Initialized
INFO - 2018-10-09 07:23:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:23:43 --> Helper loaded: form_helper
INFO - 2018-10-09 07:23:43 --> Database Driver Class Initialized
INFO - 2018-10-09 07:23:43 --> Email Class Initialized
INFO - 2018-10-09 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:23:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:23:44 --> Controller Class Initialized
DEBUG - 2018-10-09 07:23:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:23:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:23:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:23:45 --> Final output sent to browser
INFO - 2018-10-09 07:23:45 --> Config Class Initialized
INFO - 2018-10-09 07:23:45 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:23:45 --> Total execution time: 4.3101
DEBUG - 2018-10-09 07:23:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:23:46 --> Utf8 Class Initialized
INFO - 2018-10-09 07:23:46 --> URI Class Initialized
DEBUG - 2018-10-09 07:23:46 --> No URI present. Default controller set.
INFO - 2018-10-09 07:23:46 --> Router Class Initialized
INFO - 2018-10-09 07:23:46 --> Output Class Initialized
INFO - 2018-10-09 07:23:46 --> Security Class Initialized
DEBUG - 2018-10-09 07:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:23:46 --> Input Class Initialized
INFO - 2018-10-09 07:23:46 --> Language Class Initialized
INFO - 2018-10-09 07:23:47 --> Language Class Initialized
INFO - 2018-10-09 07:23:47 --> Config Class Initialized
INFO - 2018-10-09 07:23:47 --> Loader Class Initialized
INFO - 2018-10-09 07:23:47 --> Helper loaded: url_helper
INFO - 2018-10-09 07:23:47 --> Helper loaded: form_helper
INFO - 2018-10-09 07:23:47 --> Database Driver Class Initialized
INFO - 2018-10-09 07:23:47 --> Email Class Initialized
INFO - 2018-10-09 07:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:23:48 --> Form Validation Class Initialized
INFO - 2018-10-09 07:23:48 --> Controller Class Initialized
DEBUG - 2018-10-09 07:23:48 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:23:48 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:23:48 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:23:48 --> Final output sent to browser
DEBUG - 2018-10-09 07:23:48 --> Total execution time: 3.2450
INFO - 2018-10-09 07:23:56 --> Config Class Initialized
INFO - 2018-10-09 07:23:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:23:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:23:57 --> Utf8 Class Initialized
INFO - 2018-10-09 07:23:57 --> URI Class Initialized
DEBUG - 2018-10-09 07:23:57 --> No URI present. Default controller set.
INFO - 2018-10-09 07:23:57 --> Router Class Initialized
INFO - 2018-10-09 07:23:57 --> Output Class Initialized
INFO - 2018-10-09 07:23:57 --> Security Class Initialized
DEBUG - 2018-10-09 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:23:57 --> Input Class Initialized
INFO - 2018-10-09 07:23:57 --> Language Class Initialized
INFO - 2018-10-09 07:23:57 --> Language Class Initialized
INFO - 2018-10-09 07:23:57 --> Config Class Initialized
INFO - 2018-10-09 07:23:58 --> Loader Class Initialized
INFO - 2018-10-09 07:23:58 --> Helper loaded: url_helper
INFO - 2018-10-09 07:23:58 --> Helper loaded: form_helper
INFO - 2018-10-09 07:23:58 --> Database Driver Class Initialized
INFO - 2018-10-09 07:23:58 --> Email Class Initialized
INFO - 2018-10-09 07:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:23:58 --> Form Validation Class Initialized
INFO - 2018-10-09 07:23:58 --> Controller Class Initialized
DEBUG - 2018-10-09 07:23:58 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:23:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:23:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:23:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:23:59 --> Final output sent to browser
DEBUG - 2018-10-09 07:23:59 --> Total execution time: 2.5325
INFO - 2018-10-09 07:27:35 --> Config Class Initialized
INFO - 2018-10-09 07:27:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:27:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:27:36 --> Utf8 Class Initialized
INFO - 2018-10-09 07:27:36 --> URI Class Initialized
DEBUG - 2018-10-09 07:27:36 --> No URI present. Default controller set.
INFO - 2018-10-09 07:27:36 --> Router Class Initialized
INFO - 2018-10-09 07:27:36 --> Output Class Initialized
INFO - 2018-10-09 07:27:37 --> Security Class Initialized
DEBUG - 2018-10-09 07:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:27:37 --> Input Class Initialized
INFO - 2018-10-09 07:27:37 --> Language Class Initialized
INFO - 2018-10-09 07:27:37 --> Language Class Initialized
INFO - 2018-10-09 07:27:37 --> Config Class Initialized
INFO - 2018-10-09 07:27:37 --> Loader Class Initialized
INFO - 2018-10-09 07:27:37 --> Helper loaded: url_helper
INFO - 2018-10-09 07:27:37 --> Helper loaded: form_helper
INFO - 2018-10-09 07:27:37 --> Database Driver Class Initialized
INFO - 2018-10-09 07:27:37 --> Email Class Initialized
INFO - 2018-10-09 07:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:27:38 --> Form Validation Class Initialized
INFO - 2018-10-09 07:27:38 --> Controller Class Initialized
DEBUG - 2018-10-09 07:27:38 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:27:38 --> Model Class Initialized
DEBUG - 2018-10-09 07:27:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:27:38 --> Model Class Initialized
DEBUG - 2018-10-09 07:27:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:27:38 --> Final output sent to browser
DEBUG - 2018-10-09 07:27:38 --> Total execution time: 2.7425
INFO - 2018-10-09 07:27:44 --> Config Class Initialized
INFO - 2018-10-09 07:27:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:27:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:27:44 --> Utf8 Class Initialized
INFO - 2018-10-09 07:27:44 --> URI Class Initialized
DEBUG - 2018-10-09 07:27:44 --> No URI present. Default controller set.
INFO - 2018-10-09 07:27:44 --> Router Class Initialized
INFO - 2018-10-09 07:27:44 --> Output Class Initialized
INFO - 2018-10-09 07:27:44 --> Security Class Initialized
DEBUG - 2018-10-09 07:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:27:45 --> Input Class Initialized
INFO - 2018-10-09 07:27:45 --> Language Class Initialized
INFO - 2018-10-09 07:27:45 --> Language Class Initialized
INFO - 2018-10-09 07:27:45 --> Config Class Initialized
INFO - 2018-10-09 07:27:45 --> Loader Class Initialized
INFO - 2018-10-09 07:27:45 --> Helper loaded: url_helper
INFO - 2018-10-09 07:27:45 --> Helper loaded: form_helper
INFO - 2018-10-09 07:27:45 --> Database Driver Class Initialized
INFO - 2018-10-09 07:27:45 --> Email Class Initialized
INFO - 2018-10-09 07:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:27:46 --> Form Validation Class Initialized
INFO - 2018-10-09 07:27:46 --> Controller Class Initialized
DEBUG - 2018-10-09 07:27:46 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:27:46 --> Model Class Initialized
DEBUG - 2018-10-09 07:27:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:27:46 --> Model Class Initialized
DEBUG - 2018-10-09 07:27:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:27:46 --> Final output sent to browser
DEBUG - 2018-10-09 07:27:46 --> Total execution time: 2.6775
INFO - 2018-10-09 07:28:05 --> Config Class Initialized
INFO - 2018-10-09 07:28:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:28:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:28:06 --> Utf8 Class Initialized
INFO - 2018-10-09 07:28:06 --> URI Class Initialized
DEBUG - 2018-10-09 07:28:06 --> No URI present. Default controller set.
INFO - 2018-10-09 07:28:06 --> Router Class Initialized
INFO - 2018-10-09 07:28:06 --> Output Class Initialized
INFO - 2018-10-09 07:28:06 --> Security Class Initialized
DEBUG - 2018-10-09 07:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:28:06 --> Input Class Initialized
INFO - 2018-10-09 07:28:06 --> Language Class Initialized
INFO - 2018-10-09 07:28:06 --> Language Class Initialized
INFO - 2018-10-09 07:28:07 --> Config Class Initialized
INFO - 2018-10-09 07:28:07 --> Loader Class Initialized
INFO - 2018-10-09 07:28:07 --> Helper loaded: url_helper
INFO - 2018-10-09 07:28:07 --> Helper loaded: form_helper
INFO - 2018-10-09 07:28:07 --> Database Driver Class Initialized
INFO - 2018-10-09 07:28:07 --> Email Class Initialized
INFO - 2018-10-09 07:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:28:07 --> Form Validation Class Initialized
INFO - 2018-10-09 07:28:07 --> Controller Class Initialized
DEBUG - 2018-10-09 07:28:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:28:08 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:28:08 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:28:08 --> Final output sent to browser
DEBUG - 2018-10-09 07:28:08 --> Total execution time: 2.6675
INFO - 2018-10-09 07:28:15 --> Config Class Initialized
INFO - 2018-10-09 07:28:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:28:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:28:15 --> Utf8 Class Initialized
INFO - 2018-10-09 07:28:15 --> URI Class Initialized
DEBUG - 2018-10-09 07:28:15 --> No URI present. Default controller set.
INFO - 2018-10-09 07:28:16 --> Router Class Initialized
INFO - 2018-10-09 07:28:16 --> Output Class Initialized
INFO - 2018-10-09 07:28:16 --> Security Class Initialized
DEBUG - 2018-10-09 07:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:28:16 --> Input Class Initialized
INFO - 2018-10-09 07:28:16 --> Language Class Initialized
INFO - 2018-10-09 07:28:16 --> Language Class Initialized
INFO - 2018-10-09 07:28:16 --> Config Class Initialized
INFO - 2018-10-09 07:28:16 --> Loader Class Initialized
INFO - 2018-10-09 07:28:16 --> Helper loaded: url_helper
INFO - 2018-10-09 07:28:17 --> Helper loaded: form_helper
INFO - 2018-10-09 07:28:17 --> Database Driver Class Initialized
INFO - 2018-10-09 07:28:17 --> Email Class Initialized
INFO - 2018-10-09 07:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:28:17 --> Form Validation Class Initialized
INFO - 2018-10-09 07:28:17 --> Controller Class Initialized
DEBUG - 2018-10-09 07:28:17 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:28:17 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:28:17 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:28:18 --> Final output sent to browser
DEBUG - 2018-10-09 07:28:18 --> Total execution time: 2.7800
INFO - 2018-10-09 07:28:37 --> Config Class Initialized
INFO - 2018-10-09 07:28:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:28:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:28:37 --> Utf8 Class Initialized
INFO - 2018-10-09 07:28:38 --> URI Class Initialized
DEBUG - 2018-10-09 07:28:38 --> No URI present. Default controller set.
INFO - 2018-10-09 07:28:38 --> Router Class Initialized
INFO - 2018-10-09 07:28:38 --> Output Class Initialized
INFO - 2018-10-09 07:28:38 --> Security Class Initialized
DEBUG - 2018-10-09 07:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:28:38 --> Input Class Initialized
INFO - 2018-10-09 07:28:39 --> Language Class Initialized
INFO - 2018-10-09 07:28:39 --> Language Class Initialized
INFO - 2018-10-09 07:28:39 --> Config Class Initialized
INFO - 2018-10-09 07:28:39 --> Loader Class Initialized
INFO - 2018-10-09 07:28:39 --> Helper loaded: url_helper
INFO - 2018-10-09 07:28:39 --> Helper loaded: form_helper
INFO - 2018-10-09 07:28:39 --> Database Driver Class Initialized
INFO - 2018-10-09 07:28:39 --> Email Class Initialized
INFO - 2018-10-09 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:28:39 --> Form Validation Class Initialized
INFO - 2018-10-09 07:28:39 --> Controller Class Initialized
DEBUG - 2018-10-09 07:28:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:28:40 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:28:40 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:28:40 --> Final output sent to browser
DEBUG - 2018-10-09 07:28:40 --> Total execution time: 2.9400
INFO - 2018-10-09 07:28:49 --> Config Class Initialized
INFO - 2018-10-09 07:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:28:49 --> Utf8 Class Initialized
INFO - 2018-10-09 07:28:49 --> URI Class Initialized
DEBUG - 2018-10-09 07:28:50 --> No URI present. Default controller set.
INFO - 2018-10-09 07:28:50 --> Router Class Initialized
INFO - 2018-10-09 07:28:50 --> Output Class Initialized
INFO - 2018-10-09 07:28:50 --> Security Class Initialized
DEBUG - 2018-10-09 07:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:28:50 --> Input Class Initialized
INFO - 2018-10-09 07:28:51 --> Language Class Initialized
INFO - 2018-10-09 07:28:51 --> Language Class Initialized
INFO - 2018-10-09 07:28:51 --> Config Class Initialized
INFO - 2018-10-09 07:28:51 --> Loader Class Initialized
INFO - 2018-10-09 07:28:51 --> Helper loaded: url_helper
INFO - 2018-10-09 07:28:51 --> Helper loaded: form_helper
INFO - 2018-10-09 07:28:51 --> Database Driver Class Initialized
INFO - 2018-10-09 07:28:51 --> Email Class Initialized
INFO - 2018-10-09 07:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:28:51 --> Form Validation Class Initialized
INFO - 2018-10-09 07:28:52 --> Controller Class Initialized
DEBUG - 2018-10-09 07:28:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:28:52 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:28:52 --> Model Class Initialized
DEBUG - 2018-10-09 07:28:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:28:52 --> Final output sent to browser
DEBUG - 2018-10-09 07:28:52 --> Total execution time: 3.0450
INFO - 2018-10-09 07:29:53 --> Config Class Initialized
INFO - 2018-10-09 07:29:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:29:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:29:54 --> Utf8 Class Initialized
INFO - 2018-10-09 07:29:54 --> URI Class Initialized
DEBUG - 2018-10-09 07:29:55 --> No URI present. Default controller set.
INFO - 2018-10-09 07:29:55 --> Router Class Initialized
INFO - 2018-10-09 07:29:55 --> Output Class Initialized
INFO - 2018-10-09 07:29:55 --> Security Class Initialized
DEBUG - 2018-10-09 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:29:55 --> Input Class Initialized
INFO - 2018-10-09 07:29:55 --> Language Class Initialized
INFO - 2018-10-09 07:29:56 --> Language Class Initialized
INFO - 2018-10-09 07:29:56 --> Config Class Initialized
INFO - 2018-10-09 07:29:56 --> Loader Class Initialized
INFO - 2018-10-09 07:29:56 --> Helper loaded: url_helper
INFO - 2018-10-09 07:29:56 --> Helper loaded: form_helper
INFO - 2018-10-09 07:29:56 --> Database Driver Class Initialized
INFO - 2018-10-09 07:29:57 --> Email Class Initialized
INFO - 2018-10-09 07:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:29:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:29:57 --> Controller Class Initialized
DEBUG - 2018-10-09 07:29:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:29:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:29:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:29:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:29:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:29:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:29:58 --> Total execution time: 4.2176
INFO - 2018-10-09 07:30:04 --> Config Class Initialized
INFO - 2018-10-09 07:30:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:30:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:30:04 --> Utf8 Class Initialized
INFO - 2018-10-09 07:30:05 --> URI Class Initialized
DEBUG - 2018-10-09 07:30:05 --> No URI present. Default controller set.
INFO - 2018-10-09 07:30:05 --> Router Class Initialized
INFO - 2018-10-09 07:30:05 --> Output Class Initialized
INFO - 2018-10-09 07:30:05 --> Security Class Initialized
DEBUG - 2018-10-09 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:30:06 --> Input Class Initialized
INFO - 2018-10-09 07:30:06 --> Language Class Initialized
INFO - 2018-10-09 07:30:06 --> Language Class Initialized
INFO - 2018-10-09 07:30:06 --> Config Class Initialized
INFO - 2018-10-09 07:30:07 --> Loader Class Initialized
INFO - 2018-10-09 07:30:07 --> Helper loaded: url_helper
INFO - 2018-10-09 07:30:07 --> Helper loaded: form_helper
INFO - 2018-10-09 07:30:07 --> Database Driver Class Initialized
INFO - 2018-10-09 07:30:07 --> Email Class Initialized
INFO - 2018-10-09 07:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:30:08 --> Form Validation Class Initialized
INFO - 2018-10-09 07:30:08 --> Controller Class Initialized
DEBUG - 2018-10-09 07:30:08 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:30:08 --> Model Class Initialized
DEBUG - 2018-10-09 07:30:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:30:08 --> Model Class Initialized
DEBUG - 2018-10-09 07:30:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:30:08 --> Final output sent to browser
DEBUG - 2018-10-09 07:30:08 --> Total execution time: 4.5901
INFO - 2018-10-09 07:32:24 --> Config Class Initialized
INFO - 2018-10-09 07:32:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:32:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:32:24 --> Utf8 Class Initialized
INFO - 2018-10-09 07:32:24 --> URI Class Initialized
DEBUG - 2018-10-09 07:32:25 --> No URI present. Default controller set.
INFO - 2018-10-09 07:32:25 --> Router Class Initialized
INFO - 2018-10-09 07:32:25 --> Output Class Initialized
INFO - 2018-10-09 07:32:25 --> Security Class Initialized
DEBUG - 2018-10-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:32:26 --> Input Class Initialized
INFO - 2018-10-09 07:32:26 --> Language Class Initialized
INFO - 2018-10-09 07:32:26 --> Language Class Initialized
INFO - 2018-10-09 07:32:26 --> Config Class Initialized
INFO - 2018-10-09 07:32:26 --> Loader Class Initialized
INFO - 2018-10-09 07:32:26 --> Helper loaded: url_helper
INFO - 2018-10-09 07:32:26 --> Helper loaded: form_helper
INFO - 2018-10-09 07:32:26 --> Database Driver Class Initialized
INFO - 2018-10-09 07:32:27 --> Email Class Initialized
INFO - 2018-10-09 07:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:32:27 --> Form Validation Class Initialized
INFO - 2018-10-09 07:32:27 --> Controller Class Initialized
DEBUG - 2018-10-09 07:32:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:32:27 --> Model Class Initialized
DEBUG - 2018-10-09 07:32:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:32:27 --> Model Class Initialized
DEBUG - 2018-10-09 07:32:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:32:27 --> Final output sent to browser
DEBUG - 2018-10-09 07:32:28 --> Total execution time: 3.5851
INFO - 2018-10-09 07:32:45 --> Config Class Initialized
INFO - 2018-10-09 07:32:45 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:32:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:32:46 --> Utf8 Class Initialized
INFO - 2018-10-09 07:32:46 --> URI Class Initialized
DEBUG - 2018-10-09 07:32:46 --> No URI present. Default controller set.
INFO - 2018-10-09 07:32:46 --> Router Class Initialized
INFO - 2018-10-09 07:32:46 --> Output Class Initialized
INFO - 2018-10-09 07:32:47 --> Security Class Initialized
DEBUG - 2018-10-09 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:32:47 --> Input Class Initialized
INFO - 2018-10-09 07:32:47 --> Language Class Initialized
INFO - 2018-10-09 07:32:47 --> Language Class Initialized
INFO - 2018-10-09 07:32:47 --> Config Class Initialized
INFO - 2018-10-09 07:32:47 --> Loader Class Initialized
INFO - 2018-10-09 07:32:48 --> Helper loaded: url_helper
INFO - 2018-10-09 07:32:48 --> Helper loaded: form_helper
INFO - 2018-10-09 07:32:48 --> Database Driver Class Initialized
INFO - 2018-10-09 07:32:48 --> Email Class Initialized
INFO - 2018-10-09 07:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:32:48 --> Form Validation Class Initialized
INFO - 2018-10-09 07:32:48 --> Controller Class Initialized
DEBUG - 2018-10-09 07:32:49 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:32:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:32:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:32:49 --> Model Class Initialized
DEBUG - 2018-10-09 07:32:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:32:49 --> Final output sent to browser
DEBUG - 2018-10-09 07:32:50 --> Total execution time: 4.0901
INFO - 2018-10-09 07:33:47 --> Config Class Initialized
INFO - 2018-10-09 07:33:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:33:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:33:47 --> Utf8 Class Initialized
INFO - 2018-10-09 07:33:48 --> URI Class Initialized
DEBUG - 2018-10-09 07:33:48 --> No URI present. Default controller set.
INFO - 2018-10-09 07:33:48 --> Router Class Initialized
INFO - 2018-10-09 07:33:48 --> Output Class Initialized
INFO - 2018-10-09 07:33:48 --> Security Class Initialized
DEBUG - 2018-10-09 07:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:33:48 --> Input Class Initialized
INFO - 2018-10-09 07:33:49 --> Language Class Initialized
INFO - 2018-10-09 07:33:49 --> Language Class Initialized
INFO - 2018-10-09 07:33:49 --> Config Class Initialized
INFO - 2018-10-09 07:33:49 --> Loader Class Initialized
INFO - 2018-10-09 07:33:49 --> Helper loaded: url_helper
INFO - 2018-10-09 07:33:49 --> Helper loaded: form_helper
INFO - 2018-10-09 07:33:49 --> Database Driver Class Initialized
INFO - 2018-10-09 07:33:49 --> Email Class Initialized
INFO - 2018-10-09 07:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:33:50 --> Form Validation Class Initialized
INFO - 2018-10-09 07:33:50 --> Controller Class Initialized
DEBUG - 2018-10-09 07:33:50 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:33:50 --> Model Class Initialized
DEBUG - 2018-10-09 07:33:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:33:50 --> Model Class Initialized
DEBUG - 2018-10-09 07:33:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:33:50 --> Final output sent to browser
DEBUG - 2018-10-09 07:33:50 --> Total execution time: 3.3901
INFO - 2018-10-09 07:34:39 --> Config Class Initialized
INFO - 2018-10-09 07:34:39 --> Hooks Class Initialized
INFO - 2018-10-09 07:34:39 --> Config Class Initialized
INFO - 2018-10-09 07:34:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 07:34:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:34:40 --> Utf8 Class Initialized
INFO - 2018-10-09 07:34:40 --> URI Class Initialized
DEBUG - 2018-10-09 07:34:40 --> No URI present. Default controller set.
INFO - 2018-10-09 07:34:40 --> Router Class Initialized
INFO - 2018-10-09 07:34:40 --> Output Class Initialized
INFO - 2018-10-09 07:34:40 --> Security Class Initialized
DEBUG - 2018-10-09 07:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:34:41 --> Utf8 Class Initialized
INFO - 2018-10-09 07:34:41 --> URI Class Initialized
INFO - 2018-10-09 07:34:41 --> Router Class Initialized
INFO - 2018-10-09 07:34:41 --> Output Class Initialized
INFO - 2018-10-09 07:34:41 --> Input Class Initialized
INFO - 2018-10-09 07:34:41 --> Security Class Initialized
INFO - 2018-10-09 07:34:41 --> Language Class Initialized
INFO - 2018-10-09 07:34:41 --> Language Class Initialized
DEBUG - 2018-10-09 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:34:42 --> Config Class Initialized
INFO - 2018-10-09 07:34:42 --> Input Class Initialized
INFO - 2018-10-09 07:34:42 --> Language Class Initialized
INFO - 2018-10-09 07:34:42 --> Loader Class Initialized
INFO - 2018-10-09 07:34:42 --> Helper loaded: url_helper
INFO - 2018-10-09 07:34:42 --> Language Class Initialized
INFO - 2018-10-09 07:34:42 --> Helper loaded: form_helper
INFO - 2018-10-09 07:34:42 --> Database Driver Class Initialized
INFO - 2018-10-09 07:34:42 --> Email Class Initialized
INFO - 2018-10-09 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:34:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:34:43 --> Controller Class Initialized
INFO - 2018-10-09 07:34:43 --> Config Class Initialized
DEBUG - 2018-10-09 07:34:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:34:43 --> Model Class Initialized
INFO - 2018-10-09 07:34:43 --> Loader Class Initialized
DEBUG - 2018-10-09 07:34:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:34:43 --> Model Class Initialized
DEBUG - 2018-10-09 07:34:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:34:43 --> Final output sent to browser
INFO - 2018-10-09 07:34:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:34:43 --> Helper loaded: form_helper
DEBUG - 2018-10-09 07:34:44 --> Total execution time: 4.0926
INFO - 2018-10-09 07:34:44 --> Database Driver Class Initialized
INFO - 2018-10-09 07:34:44 --> Email Class Initialized
INFO - 2018-10-09 07:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:34:45 --> Form Validation Class Initialized
INFO - 2018-10-09 07:34:45 --> Controller Class Initialized
DEBUG - 2018-10-09 07:34:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:34:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:34:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 07:34:46 --> Model Class Initialized
INFO - 2018-10-09 07:34:46 --> Final output sent to browser
DEBUG - 2018-10-09 07:34:46 --> Total execution time: 6.8526
INFO - 2018-10-09 07:35:01 --> Config Class Initialized
INFO - 2018-10-09 07:35:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:35:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:35:01 --> Utf8 Class Initialized
INFO - 2018-10-09 07:35:01 --> URI Class Initialized
DEBUG - 2018-10-09 07:35:01 --> No URI present. Default controller set.
INFO - 2018-10-09 07:35:01 --> Router Class Initialized
INFO - 2018-10-09 07:35:02 --> Output Class Initialized
INFO - 2018-10-09 07:35:02 --> Security Class Initialized
DEBUG - 2018-10-09 07:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:35:02 --> Input Class Initialized
INFO - 2018-10-09 07:35:02 --> Language Class Initialized
INFO - 2018-10-09 07:35:02 --> Language Class Initialized
INFO - 2018-10-09 07:35:02 --> Config Class Initialized
INFO - 2018-10-09 07:35:02 --> Loader Class Initialized
INFO - 2018-10-09 07:35:02 --> Helper loaded: url_helper
INFO - 2018-10-09 07:35:02 --> Helper loaded: form_helper
INFO - 2018-10-09 07:35:03 --> Database Driver Class Initialized
INFO - 2018-10-09 07:35:03 --> Email Class Initialized
INFO - 2018-10-09 07:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:35:03 --> Form Validation Class Initialized
INFO - 2018-10-09 07:35:03 --> Controller Class Initialized
DEBUG - 2018-10-09 07:35:03 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:35:03 --> Model Class Initialized
DEBUG - 2018-10-09 07:35:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:35:03 --> Model Class Initialized
DEBUG - 2018-10-09 07:35:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:35:03 --> Final output sent to browser
DEBUG - 2018-10-09 07:35:04 --> Total execution time: 2.9450
INFO - 2018-10-09 07:35:10 --> Config Class Initialized
INFO - 2018-10-09 07:35:10 --> Hooks Class Initialized
INFO - 2018-10-09 07:35:10 --> Config Class Initialized
INFO - 2018-10-09 07:35:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:35:10 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 07:35:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:35:10 --> Utf8 Class Initialized
INFO - 2018-10-09 07:35:10 --> URI Class Initialized
INFO - 2018-10-09 07:35:11 --> Router Class Initialized
INFO - 2018-10-09 07:35:11 --> Output Class Initialized
INFO - 2018-10-09 07:35:11 --> Security Class Initialized
DEBUG - 2018-10-09 07:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:35:11 --> Input Class Initialized
INFO - 2018-10-09 07:35:11 --> Language Class Initialized
INFO - 2018-10-09 07:35:11 --> Language Class Initialized
INFO - 2018-10-09 07:35:11 --> Utf8 Class Initialized
INFO - 2018-10-09 07:35:11 --> URI Class Initialized
INFO - 2018-10-09 07:35:12 --> Config Class Initialized
INFO - 2018-10-09 07:35:12 --> Loader Class Initialized
INFO - 2018-10-09 07:35:12 --> Helper loaded: url_helper
INFO - 2018-10-09 07:35:12 --> Helper loaded: form_helper
INFO - 2018-10-09 07:35:12 --> Database Driver Class Initialized
DEBUG - 2018-10-09 07:35:12 --> No URI present. Default controller set.
INFO - 2018-10-09 07:35:12 --> Email Class Initialized
INFO - 2018-10-09 07:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:35:12 --> Form Validation Class Initialized
INFO - 2018-10-09 07:35:13 --> Controller Class Initialized
INFO - 2018-10-09 07:35:13 --> Router Class Initialized
INFO - 2018-10-09 07:35:13 --> Output Class Initialized
INFO - 2018-10-09 07:35:13 --> Security Class Initialized
DEBUG - 2018-10-09 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:35:13 --> Input Class Initialized
INFO - 2018-10-09 07:35:13 --> Language Class Initialized
INFO - 2018-10-09 07:35:13 --> Language Class Initialized
DEBUG - 2018-10-09 07:35:13 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:35:13 --> Config Class Initialized
INFO - 2018-10-09 07:35:14 --> Loader Class Initialized
INFO - 2018-10-09 07:35:14 --> Model Class Initialized
INFO - 2018-10-09 07:35:14 --> Helper loaded: url_helper
INFO - 2018-10-09 07:35:14 --> Helper loaded: form_helper
DEBUG - 2018-10-09 07:35:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 07:35:14 --> Database Driver Class Initialized
INFO - 2018-10-09 07:35:14 --> Email Class Initialized
INFO - 2018-10-09 07:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:35:14 --> Form Validation Class Initialized
INFO - 2018-10-09 07:35:15 --> Model Class Initialized
INFO - 2018-10-09 07:35:15 --> Controller Class Initialized
DEBUG - 2018-10-09 07:35:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:35:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:35:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:35:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:35:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:35:15 --> Final output sent to browser
DEBUG - 2018-10-09 07:35:15 --> Total execution time: 5.5101
INFO - 2018-10-09 07:35:17 --> Final output sent to browser
DEBUG - 2018-10-09 07:35:17 --> Total execution time: 7.5460
INFO - 2018-10-09 07:36:09 --> Config Class Initialized
INFO - 2018-10-09 07:36:09 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:36:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:36:09 --> Utf8 Class Initialized
INFO - 2018-10-09 07:36:09 --> URI Class Initialized
DEBUG - 2018-10-09 07:36:09 --> No URI present. Default controller set.
INFO - 2018-10-09 07:36:10 --> Router Class Initialized
INFO - 2018-10-09 07:36:10 --> Output Class Initialized
INFO - 2018-10-09 07:36:10 --> Security Class Initialized
DEBUG - 2018-10-09 07:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:36:10 --> Input Class Initialized
INFO - 2018-10-09 07:36:10 --> Language Class Initialized
INFO - 2018-10-09 07:36:10 --> Language Class Initialized
INFO - 2018-10-09 07:36:10 --> Config Class Initialized
INFO - 2018-10-09 07:36:10 --> Loader Class Initialized
INFO - 2018-10-09 07:36:10 --> Helper loaded: url_helper
INFO - 2018-10-09 07:36:10 --> Helper loaded: form_helper
INFO - 2018-10-09 07:36:11 --> Database Driver Class Initialized
INFO - 2018-10-09 07:36:11 --> Email Class Initialized
INFO - 2018-10-09 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:36:11 --> Form Validation Class Initialized
INFO - 2018-10-09 07:36:11 --> Controller Class Initialized
DEBUG - 2018-10-09 07:36:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:36:11 --> Model Class Initialized
DEBUG - 2018-10-09 07:36:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:36:11 --> Model Class Initialized
DEBUG - 2018-10-09 07:36:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:36:12 --> Final output sent to browser
DEBUG - 2018-10-09 07:36:12 --> Total execution time: 2.7550
INFO - 2018-10-09 07:36:52 --> Config Class Initialized
INFO - 2018-10-09 07:36:52 --> Hooks Class Initialized
INFO - 2018-10-09 07:36:52 --> Config Class Initialized
INFO - 2018-10-09 07:36:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:36:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:36:52 --> Utf8 Class Initialized
INFO - 2018-10-09 07:36:52 --> URI Class Initialized
INFO - 2018-10-09 07:36:53 --> Router Class Initialized
DEBUG - 2018-10-09 07:36:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:36:53 --> Utf8 Class Initialized
INFO - 2018-10-09 07:36:53 --> URI Class Initialized
DEBUG - 2018-10-09 07:36:53 --> No URI present. Default controller set.
INFO - 2018-10-09 07:36:53 --> Router Class Initialized
INFO - 2018-10-09 07:36:53 --> Output Class Initialized
INFO - 2018-10-09 07:36:53 --> Output Class Initialized
INFO - 2018-10-09 07:36:54 --> Security Class Initialized
DEBUG - 2018-10-09 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:36:54 --> Input Class Initialized
INFO - 2018-10-09 07:36:54 --> Security Class Initialized
INFO - 2018-10-09 07:36:54 --> Language Class Initialized
DEBUG - 2018-10-09 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:36:55 --> Input Class Initialized
INFO - 2018-10-09 07:36:55 --> Language Class Initialized
INFO - 2018-10-09 07:36:55 --> Language Class Initialized
INFO - 2018-10-09 07:36:55 --> Config Class Initialized
INFO - 2018-10-09 07:36:55 --> Language Class Initialized
INFO - 2018-10-09 07:36:55 --> Config Class Initialized
INFO - 2018-10-09 07:36:55 --> Loader Class Initialized
INFO - 2018-10-09 07:36:55 --> Loader Class Initialized
INFO - 2018-10-09 07:36:56 --> Helper loaded: url_helper
INFO - 2018-10-09 07:36:56 --> Helper loaded: url_helper
INFO - 2018-10-09 07:36:56 --> Helper loaded: form_helper
INFO - 2018-10-09 07:36:56 --> Helper loaded: form_helper
INFO - 2018-10-09 07:36:56 --> Database Driver Class Initialized
INFO - 2018-10-09 07:36:56 --> Email Class Initialized
INFO - 2018-10-09 07:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:36:57 --> Database Driver Class Initialized
INFO - 2018-10-09 07:36:57 --> Email Class Initialized
INFO - 2018-10-09 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:36:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:36:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:36:57 --> Controller Class Initialized
INFO - 2018-10-09 07:36:57 --> Controller Class Initialized
DEBUG - 2018-10-09 07:36:57 --> Person MX_Controller Initialized
DEBUG - 2018-10-09 07:36:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:36:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:36:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:36:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:36:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:36:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:36:58 --> Total execution time: 6.4926
INFO - 2018-10-09 07:36:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:36:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 07:36:59 --> Model Class Initialized
INFO - 2018-10-09 07:37:00 --> Final output sent to browser
DEBUG - 2018-10-09 07:37:00 --> Total execution time: 8.3376
INFO - 2018-10-09 07:37:08 --> Config Class Initialized
INFO - 2018-10-09 07:37:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:37:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:37:08 --> Utf8 Class Initialized
INFO - 2018-10-09 07:37:08 --> URI Class Initialized
DEBUG - 2018-10-09 07:37:08 --> No URI present. Default controller set.
INFO - 2018-10-09 07:37:09 --> Router Class Initialized
INFO - 2018-10-09 07:37:09 --> Output Class Initialized
INFO - 2018-10-09 07:37:09 --> Security Class Initialized
DEBUG - 2018-10-09 07:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:37:09 --> Input Class Initialized
INFO - 2018-10-09 07:37:09 --> Language Class Initialized
INFO - 2018-10-09 07:37:09 --> Language Class Initialized
INFO - 2018-10-09 07:37:10 --> Config Class Initialized
INFO - 2018-10-09 07:37:10 --> Loader Class Initialized
INFO - 2018-10-09 07:37:10 --> Helper loaded: url_helper
INFO - 2018-10-09 07:37:10 --> Helper loaded: form_helper
INFO - 2018-10-09 07:37:11 --> Database Driver Class Initialized
INFO - 2018-10-09 07:37:11 --> Config Class Initialized
INFO - 2018-10-09 07:37:11 --> Email Class Initialized
INFO - 2018-10-09 07:37:11 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:37:12 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:37:12 --> Utf8 Class Initialized
INFO - 2018-10-09 07:37:12 --> URI Class Initialized
DEBUG - 2018-10-09 07:37:12 --> No URI present. Default controller set.
INFO - 2018-10-09 07:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:37:12 --> Form Validation Class Initialized
INFO - 2018-10-09 07:37:13 --> Controller Class Initialized
INFO - 2018-10-09 07:37:13 --> Router Class Initialized
DEBUG - 2018-10-09 07:37:13 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:37:13 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:37:14 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:37:14 --> Final output sent to browser
INFO - 2018-10-09 07:37:14 --> Output Class Initialized
DEBUG - 2018-10-09 07:37:14 --> Total execution time: 6.3051
INFO - 2018-10-09 07:37:15 --> Security Class Initialized
DEBUG - 2018-10-09 07:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:37:15 --> Input Class Initialized
INFO - 2018-10-09 07:37:15 --> Language Class Initialized
INFO - 2018-10-09 07:37:15 --> Language Class Initialized
INFO - 2018-10-09 07:37:15 --> Config Class Initialized
INFO - 2018-10-09 07:37:15 --> Loader Class Initialized
INFO - 2018-10-09 07:37:16 --> Helper loaded: url_helper
INFO - 2018-10-09 07:37:16 --> Helper loaded: form_helper
INFO - 2018-10-09 07:37:16 --> Database Driver Class Initialized
INFO - 2018-10-09 07:37:16 --> Email Class Initialized
INFO - 2018-10-09 07:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:37:16 --> Form Validation Class Initialized
INFO - 2018-10-09 07:37:17 --> Controller Class Initialized
DEBUG - 2018-10-09 07:37:17 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:37:17 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:37:17 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:37:17 --> Final output sent to browser
DEBUG - 2018-10-09 07:37:18 --> Total execution time: 6.0476
INFO - 2018-10-09 07:37:40 --> Config Class Initialized
INFO - 2018-10-09 07:37:40 --> Hooks Class Initialized
INFO - 2018-10-09 07:37:40 --> Config Class Initialized
INFO - 2018-10-09 07:37:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:37:40 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:37:40 --> Utf8 Class Initialized
DEBUG - 2018-10-09 07:37:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:37:41 --> Utf8 Class Initialized
INFO - 2018-10-09 07:37:41 --> URI Class Initialized
INFO - 2018-10-09 07:37:41 --> URI Class Initialized
DEBUG - 2018-10-09 07:37:41 --> No URI present. Default controller set.
INFO - 2018-10-09 07:37:41 --> Router Class Initialized
INFO - 2018-10-09 07:37:41 --> Router Class Initialized
INFO - 2018-10-09 07:37:41 --> Output Class Initialized
INFO - 2018-10-09 07:37:41 --> Security Class Initialized
INFO - 2018-10-09 07:37:42 --> Output Class Initialized
DEBUG - 2018-10-09 07:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:37:42 --> Input Class Initialized
INFO - 2018-10-09 07:37:42 --> Language Class Initialized
INFO - 2018-10-09 07:37:42 --> Language Class Initialized
INFO - 2018-10-09 07:37:42 --> Security Class Initialized
INFO - 2018-10-09 07:37:42 --> Config Class Initialized
INFO - 2018-10-09 07:37:42 --> Loader Class Initialized
DEBUG - 2018-10-09 07:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:37:42 --> Input Class Initialized
INFO - 2018-10-09 07:37:43 --> Helper loaded: url_helper
INFO - 2018-10-09 07:37:43 --> Helper loaded: form_helper
INFO - 2018-10-09 07:37:43 --> Database Driver Class Initialized
INFO - 2018-10-09 07:37:43 --> Email Class Initialized
INFO - 2018-10-09 07:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:37:43 --> Language Class Initialized
INFO - 2018-10-09 07:37:43 --> Form Validation Class Initialized
INFO - 2018-10-09 07:37:43 --> Language Class Initialized
INFO - 2018-10-09 07:37:43 --> Controller Class Initialized
DEBUG - 2018-10-09 07:37:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:37:44 --> Config Class Initialized
INFO - 2018-10-09 07:37:44 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 07:37:44 --> Loader Class Initialized
INFO - 2018-10-09 07:37:44 --> Helper loaded: url_helper
INFO - 2018-10-09 07:37:44 --> Helper loaded: form_helper
INFO - 2018-10-09 07:37:44 --> Database Driver Class Initialized
INFO - 2018-10-09 07:37:44 --> Email Class Initialized
INFO - 2018-10-09 07:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:37:45 --> Form Validation Class Initialized
INFO - 2018-10-09 07:37:45 --> Model Class Initialized
INFO - 2018-10-09 07:37:45 --> Final output sent to browser
DEBUG - 2018-10-09 07:37:45 --> Total execution time: 5.0176
INFO - 2018-10-09 07:37:45 --> Controller Class Initialized
DEBUG - 2018-10-09 07:37:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:37:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:37:45 --> Model Class Initialized
DEBUG - 2018-10-09 07:37:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:37:46 --> Final output sent to browser
DEBUG - 2018-10-09 07:37:46 --> Total execution time: 5.8026
INFO - 2018-10-09 07:39:56 --> Config Class Initialized
INFO - 2018-10-09 07:39:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:39:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:39:57 --> Utf8 Class Initialized
INFO - 2018-10-09 07:39:57 --> URI Class Initialized
DEBUG - 2018-10-09 07:39:57 --> No URI present. Default controller set.
INFO - 2018-10-09 07:39:57 --> Router Class Initialized
INFO - 2018-10-09 07:39:57 --> Output Class Initialized
INFO - 2018-10-09 07:39:57 --> Security Class Initialized
DEBUG - 2018-10-09 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:39:57 --> Input Class Initialized
INFO - 2018-10-09 07:39:58 --> Language Class Initialized
INFO - 2018-10-09 07:39:58 --> Language Class Initialized
INFO - 2018-10-09 07:39:58 --> Config Class Initialized
INFO - 2018-10-09 07:39:58 --> Loader Class Initialized
INFO - 2018-10-09 07:39:58 --> Helper loaded: url_helper
INFO - 2018-10-09 07:39:58 --> Helper loaded: form_helper
INFO - 2018-10-09 07:39:58 --> Database Driver Class Initialized
INFO - 2018-10-09 07:39:58 --> Email Class Initialized
INFO - 2018-10-09 07:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:39:59 --> Form Validation Class Initialized
INFO - 2018-10-09 07:39:59 --> Controller Class Initialized
DEBUG - 2018-10-09 07:39:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:39:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:39:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:39:59 --> Model Class Initialized
DEBUG - 2018-10-09 07:39:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:39:59 --> Final output sent to browser
DEBUG - 2018-10-09 07:39:59 --> Total execution time: 3.0425
INFO - 2018-10-09 07:46:52 --> Config Class Initialized
INFO - 2018-10-09 07:46:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:46:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:46:54 --> Utf8 Class Initialized
INFO - 2018-10-09 07:46:54 --> URI Class Initialized
DEBUG - 2018-10-09 07:46:54 --> No URI present. Default controller set.
INFO - 2018-10-09 07:46:54 --> Router Class Initialized
INFO - 2018-10-09 07:46:55 --> Output Class Initialized
INFO - 2018-10-09 07:46:55 --> Security Class Initialized
DEBUG - 2018-10-09 07:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:46:55 --> Input Class Initialized
INFO - 2018-10-09 07:46:55 --> Language Class Initialized
INFO - 2018-10-09 07:46:56 --> Language Class Initialized
INFO - 2018-10-09 07:46:56 --> Config Class Initialized
INFO - 2018-10-09 07:46:56 --> Loader Class Initialized
INFO - 2018-10-09 07:46:56 --> Helper loaded: url_helper
INFO - 2018-10-09 07:46:56 --> Helper loaded: form_helper
INFO - 2018-10-09 07:46:56 --> Database Driver Class Initialized
INFO - 2018-10-09 07:46:56 --> Email Class Initialized
INFO - 2018-10-09 07:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:46:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:46:57 --> Controller Class Initialized
DEBUG - 2018-10-09 07:46:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:46:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:46:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:46:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:46:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:46:57 --> Final output sent to browser
DEBUG - 2018-10-09 07:46:57 --> Total execution time: 5.2001
INFO - 2018-10-09 07:47:19 --> Config Class Initialized
INFO - 2018-10-09 07:47:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:47:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:47:19 --> Utf8 Class Initialized
INFO - 2018-10-09 07:47:20 --> URI Class Initialized
DEBUG - 2018-10-09 07:47:20 --> No URI present. Default controller set.
INFO - 2018-10-09 07:47:20 --> Router Class Initialized
INFO - 2018-10-09 07:47:20 --> Output Class Initialized
INFO - 2018-10-09 07:47:20 --> Security Class Initialized
DEBUG - 2018-10-09 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:47:21 --> Input Class Initialized
INFO - 2018-10-09 07:47:21 --> Language Class Initialized
INFO - 2018-10-09 07:47:21 --> Language Class Initialized
INFO - 2018-10-09 07:47:21 --> Config Class Initialized
INFO - 2018-10-09 07:47:22 --> Loader Class Initialized
INFO - 2018-10-09 07:47:22 --> Helper loaded: url_helper
INFO - 2018-10-09 07:47:23 --> Helper loaded: form_helper
INFO - 2018-10-09 07:47:23 --> Database Driver Class Initialized
INFO - 2018-10-09 07:47:23 --> Email Class Initialized
INFO - 2018-10-09 07:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:47:24 --> Form Validation Class Initialized
INFO - 2018-10-09 07:47:24 --> Controller Class Initialized
DEBUG - 2018-10-09 07:47:24 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:47:24 --> Config Class Initialized
INFO - 2018-10-09 07:47:25 --> Hooks Class Initialized
INFO - 2018-10-09 07:47:25 --> Model Class Initialized
DEBUG - 2018-10-09 07:47:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:47:25 --> Model Class Initialized
DEBUG - 2018-10-09 07:47:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:47:26 --> Final output sent to browser
DEBUG - 2018-10-09 07:47:26 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:47:26 --> Utf8 Class Initialized
DEBUG - 2018-10-09 07:47:26 --> Total execution time: 7.0701
INFO - 2018-10-09 07:47:26 --> URI Class Initialized
DEBUG - 2018-10-09 07:47:26 --> No URI present. Default controller set.
INFO - 2018-10-09 07:47:27 --> Router Class Initialized
INFO - 2018-10-09 07:47:27 --> Output Class Initialized
INFO - 2018-10-09 07:47:27 --> Security Class Initialized
DEBUG - 2018-10-09 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:47:28 --> Input Class Initialized
INFO - 2018-10-09 07:47:28 --> Language Class Initialized
INFO - 2018-10-09 07:47:28 --> Language Class Initialized
INFO - 2018-10-09 07:47:28 --> Config Class Initialized
INFO - 2018-10-09 07:47:28 --> Loader Class Initialized
INFO - 2018-10-09 07:47:29 --> Helper loaded: url_helper
INFO - 2018-10-09 07:47:29 --> Helper loaded: form_helper
INFO - 2018-10-09 07:47:29 --> Database Driver Class Initialized
INFO - 2018-10-09 07:47:29 --> Email Class Initialized
INFO - 2018-10-09 07:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:47:30 --> Form Validation Class Initialized
INFO - 2018-10-09 07:47:30 --> Controller Class Initialized
DEBUG - 2018-10-09 07:47:30 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:47:31 --> Model Class Initialized
DEBUG - 2018-10-09 07:47:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:47:31 --> Model Class Initialized
DEBUG - 2018-10-09 07:47:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:47:32 --> Final output sent to browser
DEBUG - 2018-10-09 07:47:32 --> Total execution time: 7.3026
INFO - 2018-10-09 07:48:16 --> Config Class Initialized
INFO - 2018-10-09 07:48:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:48:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:48:16 --> Utf8 Class Initialized
INFO - 2018-10-09 07:48:17 --> URI Class Initialized
DEBUG - 2018-10-09 07:48:17 --> No URI present. Default controller set.
INFO - 2018-10-09 07:48:17 --> Router Class Initialized
INFO - 2018-10-09 07:48:17 --> Output Class Initialized
INFO - 2018-10-09 07:48:17 --> Security Class Initialized
DEBUG - 2018-10-09 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:48:17 --> Input Class Initialized
INFO - 2018-10-09 07:48:17 --> Language Class Initialized
INFO - 2018-10-09 07:48:17 --> Language Class Initialized
INFO - 2018-10-09 07:48:18 --> Config Class Initialized
INFO - 2018-10-09 07:48:18 --> Loader Class Initialized
INFO - 2018-10-09 07:48:18 --> Helper loaded: url_helper
INFO - 2018-10-09 07:48:18 --> Helper loaded: form_helper
INFO - 2018-10-09 07:48:18 --> Database Driver Class Initialized
INFO - 2018-10-09 07:48:18 --> Email Class Initialized
INFO - 2018-10-09 07:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:48:18 --> Form Validation Class Initialized
INFO - 2018-10-09 07:48:18 --> Controller Class Initialized
DEBUG - 2018-10-09 07:48:19 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:48:19 --> Model Class Initialized
DEBUG - 2018-10-09 07:48:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:48:19 --> Model Class Initialized
DEBUG - 2018-10-09 07:48:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:48:19 --> Final output sent to browser
DEBUG - 2018-10-09 07:48:19 --> Total execution time: 3.1050
INFO - 2018-10-09 07:52:55 --> Config Class Initialized
INFO - 2018-10-09 07:52:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:52:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:52:56 --> Utf8 Class Initialized
INFO - 2018-10-09 07:52:56 --> URI Class Initialized
DEBUG - 2018-10-09 07:52:56 --> No URI present. Default controller set.
INFO - 2018-10-09 07:52:56 --> Router Class Initialized
INFO - 2018-10-09 07:52:56 --> Output Class Initialized
INFO - 2018-10-09 07:52:56 --> Security Class Initialized
DEBUG - 2018-10-09 07:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:52:56 --> Input Class Initialized
INFO - 2018-10-09 07:52:57 --> Language Class Initialized
INFO - 2018-10-09 07:52:57 --> Language Class Initialized
INFO - 2018-10-09 07:52:57 --> Config Class Initialized
INFO - 2018-10-09 07:52:57 --> Loader Class Initialized
INFO - 2018-10-09 07:52:57 --> Helper loaded: url_helper
INFO - 2018-10-09 07:52:57 --> Helper loaded: form_helper
INFO - 2018-10-09 07:52:57 --> Database Driver Class Initialized
INFO - 2018-10-09 07:52:57 --> Email Class Initialized
INFO - 2018-10-09 07:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:52:58 --> Form Validation Class Initialized
INFO - 2018-10-09 07:52:58 --> Controller Class Initialized
DEBUG - 2018-10-09 07:52:58 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:52:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:52:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:52:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:52:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:52:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:52:59 --> Total execution time: 3.0925
INFO - 2018-10-09 07:53:07 --> Config Class Initialized
INFO - 2018-10-09 07:53:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:53:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:53:07 --> Utf8 Class Initialized
INFO - 2018-10-09 07:53:07 --> URI Class Initialized
DEBUG - 2018-10-09 07:53:07 --> No URI present. Default controller set.
INFO - 2018-10-09 07:53:08 --> Router Class Initialized
INFO - 2018-10-09 07:53:08 --> Output Class Initialized
INFO - 2018-10-09 07:53:08 --> Security Class Initialized
DEBUG - 2018-10-09 07:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:53:08 --> Input Class Initialized
INFO - 2018-10-09 07:53:08 --> Language Class Initialized
INFO - 2018-10-09 07:53:08 --> Language Class Initialized
INFO - 2018-10-09 07:53:08 --> Config Class Initialized
INFO - 2018-10-09 07:53:08 --> Loader Class Initialized
INFO - 2018-10-09 07:53:09 --> Helper loaded: url_helper
INFO - 2018-10-09 07:53:09 --> Helper loaded: form_helper
INFO - 2018-10-09 07:53:09 --> Database Driver Class Initialized
INFO - 2018-10-09 07:53:09 --> Email Class Initialized
INFO - 2018-10-09 07:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:53:09 --> Form Validation Class Initialized
INFO - 2018-10-09 07:53:09 --> Controller Class Initialized
DEBUG - 2018-10-09 07:53:09 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:53:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:53:10 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:53:10 --> Final output sent to browser
DEBUG - 2018-10-09 07:53:10 --> Total execution time: 3.3601
INFO - 2018-10-09 07:53:16 --> Config Class Initialized
INFO - 2018-10-09 07:53:16 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:53:17 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:53:17 --> Utf8 Class Initialized
INFO - 2018-10-09 07:53:17 --> URI Class Initialized
DEBUG - 2018-10-09 07:53:17 --> No URI present. Default controller set.
INFO - 2018-10-09 07:53:17 --> Router Class Initialized
INFO - 2018-10-09 07:53:17 --> Output Class Initialized
INFO - 2018-10-09 07:53:17 --> Security Class Initialized
DEBUG - 2018-10-09 07:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:53:18 --> Input Class Initialized
INFO - 2018-10-09 07:53:18 --> Language Class Initialized
INFO - 2018-10-09 07:53:18 --> Language Class Initialized
INFO - 2018-10-09 07:53:18 --> Config Class Initialized
INFO - 2018-10-09 07:53:18 --> Loader Class Initialized
INFO - 2018-10-09 07:53:18 --> Helper loaded: url_helper
INFO - 2018-10-09 07:53:18 --> Helper loaded: form_helper
INFO - 2018-10-09 07:53:19 --> Database Driver Class Initialized
INFO - 2018-10-09 07:53:19 --> Email Class Initialized
INFO - 2018-10-09 07:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:53:19 --> Form Validation Class Initialized
INFO - 2018-10-09 07:53:19 --> Controller Class Initialized
DEBUG - 2018-10-09 07:53:19 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:53:19 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:53:20 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:53:20 --> Final output sent to browser
DEBUG - 2018-10-09 07:53:20 --> Total execution time: 3.4701
INFO - 2018-10-09 07:53:43 --> Config Class Initialized
INFO - 2018-10-09 07:53:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:53:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:53:44 --> Utf8 Class Initialized
INFO - 2018-10-09 07:53:44 --> URI Class Initialized
DEBUG - 2018-10-09 07:53:44 --> No URI present. Default controller set.
INFO - 2018-10-09 07:53:44 --> Router Class Initialized
INFO - 2018-10-09 07:53:45 --> Output Class Initialized
INFO - 2018-10-09 07:53:45 --> Security Class Initialized
DEBUG - 2018-10-09 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:53:45 --> Input Class Initialized
INFO - 2018-10-09 07:53:45 --> Language Class Initialized
INFO - 2018-10-09 07:53:45 --> Language Class Initialized
INFO - 2018-10-09 07:53:45 --> Config Class Initialized
INFO - 2018-10-09 07:53:45 --> Loader Class Initialized
INFO - 2018-10-09 07:53:45 --> Helper loaded: url_helper
INFO - 2018-10-09 07:53:46 --> Helper loaded: form_helper
INFO - 2018-10-09 07:53:46 --> Database Driver Class Initialized
INFO - 2018-10-09 07:53:46 --> Email Class Initialized
INFO - 2018-10-09 07:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:53:46 --> Form Validation Class Initialized
INFO - 2018-10-09 07:53:46 --> Controller Class Initialized
DEBUG - 2018-10-09 07:53:46 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:53:46 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:53:47 --> Model Class Initialized
DEBUG - 2018-10-09 07:53:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:53:47 --> Final output sent to browser
DEBUG - 2018-10-09 07:53:47 --> Total execution time: 3.7001
INFO - 2018-10-09 07:55:12 --> Config Class Initialized
INFO - 2018-10-09 07:55:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:55:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:55:13 --> Utf8 Class Initialized
INFO - 2018-10-09 07:55:13 --> URI Class Initialized
DEBUG - 2018-10-09 07:55:13 --> No URI present. Default controller set.
INFO - 2018-10-09 07:55:13 --> Router Class Initialized
INFO - 2018-10-09 07:55:13 --> Output Class Initialized
INFO - 2018-10-09 07:55:13 --> Security Class Initialized
DEBUG - 2018-10-09 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:55:14 --> Input Class Initialized
INFO - 2018-10-09 07:55:14 --> Language Class Initialized
INFO - 2018-10-09 07:55:14 --> Language Class Initialized
INFO - 2018-10-09 07:55:14 --> Config Class Initialized
INFO - 2018-10-09 07:55:14 --> Loader Class Initialized
INFO - 2018-10-09 07:55:14 --> Helper loaded: url_helper
INFO - 2018-10-09 07:55:14 --> Helper loaded: form_helper
INFO - 2018-10-09 07:55:14 --> Database Driver Class Initialized
INFO - 2018-10-09 07:55:15 --> Email Class Initialized
INFO - 2018-10-09 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:55:15 --> Form Validation Class Initialized
INFO - 2018-10-09 07:55:15 --> Controller Class Initialized
DEBUG - 2018-10-09 07:55:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:55:15 --> Model Class Initialized
DEBUG - 2018-10-09 07:55:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:55:16 --> Model Class Initialized
DEBUG - 2018-10-09 07:55:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:55:16 --> Final output sent to browser
DEBUG - 2018-10-09 07:55:16 --> Total execution time: 3.6926
INFO - 2018-10-09 07:55:55 --> Config Class Initialized
INFO - 2018-10-09 07:55:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:55:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:55:55 --> Utf8 Class Initialized
INFO - 2018-10-09 07:55:55 --> URI Class Initialized
DEBUG - 2018-10-09 07:55:55 --> No URI present. Default controller set.
INFO - 2018-10-09 07:55:56 --> Router Class Initialized
INFO - 2018-10-09 07:55:56 --> Output Class Initialized
INFO - 2018-10-09 07:55:56 --> Security Class Initialized
DEBUG - 2018-10-09 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:55:56 --> Input Class Initialized
INFO - 2018-10-09 07:55:56 --> Language Class Initialized
INFO - 2018-10-09 07:55:56 --> Language Class Initialized
INFO - 2018-10-09 07:55:56 --> Config Class Initialized
INFO - 2018-10-09 07:55:56 --> Loader Class Initialized
INFO - 2018-10-09 07:55:57 --> Helper loaded: url_helper
INFO - 2018-10-09 07:55:57 --> Helper loaded: form_helper
INFO - 2018-10-09 07:55:57 --> Database Driver Class Initialized
INFO - 2018-10-09 07:55:57 --> Email Class Initialized
INFO - 2018-10-09 07:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:55:57 --> Form Validation Class Initialized
INFO - 2018-10-09 07:55:57 --> Controller Class Initialized
DEBUG - 2018-10-09 07:55:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:55:57 --> Model Class Initialized
DEBUG - 2018-10-09 07:55:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:55:58 --> Model Class Initialized
DEBUG - 2018-10-09 07:55:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:55:58 --> Final output sent to browser
DEBUG - 2018-10-09 07:55:59 --> Total execution time: 3.2201
INFO - 2018-10-09 07:56:06 --> Config Class Initialized
INFO - 2018-10-09 07:56:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 07:56:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 07:56:06 --> Utf8 Class Initialized
INFO - 2018-10-09 07:56:06 --> URI Class Initialized
DEBUG - 2018-10-09 07:56:06 --> No URI present. Default controller set.
INFO - 2018-10-09 07:56:06 --> Router Class Initialized
INFO - 2018-10-09 07:56:06 --> Output Class Initialized
INFO - 2018-10-09 07:56:07 --> Security Class Initialized
DEBUG - 2018-10-09 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 07:56:07 --> Input Class Initialized
INFO - 2018-10-09 07:56:07 --> Language Class Initialized
INFO - 2018-10-09 07:56:07 --> Language Class Initialized
INFO - 2018-10-09 07:56:07 --> Config Class Initialized
INFO - 2018-10-09 07:56:07 --> Loader Class Initialized
INFO - 2018-10-09 07:56:08 --> Helper loaded: url_helper
INFO - 2018-10-09 07:56:08 --> Helper loaded: form_helper
INFO - 2018-10-09 07:56:08 --> Database Driver Class Initialized
INFO - 2018-10-09 07:56:08 --> Email Class Initialized
INFO - 2018-10-09 07:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 07:56:08 --> Form Validation Class Initialized
INFO - 2018-10-09 07:56:08 --> Controller Class Initialized
DEBUG - 2018-10-09 07:56:08 --> Person MX_Controller Initialized
INFO - 2018-10-09 07:56:08 --> Model Class Initialized
DEBUG - 2018-10-09 07:56:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 07:56:09 --> Model Class Initialized
DEBUG - 2018-10-09 07:56:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 07:56:09 --> Final output sent to browser
DEBUG - 2018-10-09 07:56:10 --> Total execution time: 3.5051
INFO - 2018-10-09 08:01:47 --> Config Class Initialized
INFO - 2018-10-09 08:01:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:01:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:01:48 --> Utf8 Class Initialized
INFO - 2018-10-09 08:01:48 --> URI Class Initialized
DEBUG - 2018-10-09 08:01:48 --> No URI present. Default controller set.
INFO - 2018-10-09 08:01:48 --> Router Class Initialized
INFO - 2018-10-09 08:01:48 --> Output Class Initialized
INFO - 2018-10-09 08:01:48 --> Security Class Initialized
DEBUG - 2018-10-09 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:01:49 --> Input Class Initialized
INFO - 2018-10-09 08:01:49 --> Language Class Initialized
INFO - 2018-10-09 08:01:49 --> Language Class Initialized
INFO - 2018-10-09 08:01:49 --> Config Class Initialized
INFO - 2018-10-09 08:01:49 --> Loader Class Initialized
INFO - 2018-10-09 08:01:49 --> Helper loaded: url_helper
INFO - 2018-10-09 08:01:49 --> Helper loaded: form_helper
INFO - 2018-10-09 08:01:49 --> Database Driver Class Initialized
INFO - 2018-10-09 08:01:50 --> Email Class Initialized
INFO - 2018-10-09 08:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:01:50 --> Form Validation Class Initialized
INFO - 2018-10-09 08:01:50 --> Controller Class Initialized
DEBUG - 2018-10-09 08:01:50 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:01:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:01:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:01:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:01:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:01:51 --> Final output sent to browser
DEBUG - 2018-10-09 08:01:51 --> Total execution time: 3.2326
INFO - 2018-10-09 08:02:01 --> Config Class Initialized
INFO - 2018-10-09 08:02:01 --> Hooks Class Initialized
INFO - 2018-10-09 08:02:02 --> Config Class Initialized
INFO - 2018-10-09 08:02:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:02:02 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:02:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:02:02 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:02 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:02 --> URI Class Initialized
INFO - 2018-10-09 08:02:03 --> URI Class Initialized
INFO - 2018-10-09 08:02:03 --> Router Class Initialized
DEBUG - 2018-10-09 08:02:03 --> No URI present. Default controller set.
INFO - 2018-10-09 08:02:03 --> Output Class Initialized
INFO - 2018-10-09 08:02:03 --> Security Class Initialized
INFO - 2018-10-09 08:02:03 --> Router Class Initialized
DEBUG - 2018-10-09 08:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:03 --> Input Class Initialized
INFO - 2018-10-09 08:02:03 --> Output Class Initialized
INFO - 2018-10-09 08:02:04 --> Language Class Initialized
INFO - 2018-10-09 08:02:04 --> Security Class Initialized
DEBUG - 2018-10-09 08:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:04 --> Language Class Initialized
INFO - 2018-10-09 08:02:04 --> Config Class Initialized
INFO - 2018-10-09 08:02:04 --> Input Class Initialized
INFO - 2018-10-09 08:02:04 --> Language Class Initialized
INFO - 2018-10-09 08:02:04 --> Loader Class Initialized
INFO - 2018-10-09 08:02:05 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:05 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:05 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:05 --> Email Class Initialized
INFO - 2018-10-09 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:02:05 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:05 --> Language Class Initialized
INFO - 2018-10-09 08:02:05 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:02:06 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:02:06 --> Model Class Initialized
INFO - 2018-10-09 08:02:06 --> Config Class Initialized
INFO - 2018-10-09 08:02:06 --> Loader Class Initialized
INFO - 2018-10-09 08:02:06 --> Final output sent to browser
DEBUG - 2018-10-09 08:02:06 --> Total execution time: 4.7426
INFO - 2018-10-09 08:02:06 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:07 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:07 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:07 --> Email Class Initialized
INFO - 2018-10-09 08:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:02:07 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:07 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:02:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:02:08 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:02:08 --> Final output sent to browser
DEBUG - 2018-10-09 08:02:08 --> Total execution time: 6.6176
INFO - 2018-10-09 08:02:13 --> Config Class Initialized
INFO - 2018-10-09 08:02:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:02:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:02:14 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:14 --> URI Class Initialized
DEBUG - 2018-10-09 08:02:14 --> No URI present. Default controller set.
INFO - 2018-10-09 08:02:14 --> Router Class Initialized
INFO - 2018-10-09 08:02:14 --> Output Class Initialized
INFO - 2018-10-09 08:02:14 --> Security Class Initialized
DEBUG - 2018-10-09 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:15 --> Input Class Initialized
INFO - 2018-10-09 08:02:15 --> Language Class Initialized
INFO - 2018-10-09 08:02:15 --> Language Class Initialized
INFO - 2018-10-09 08:02:15 --> Config Class Initialized
INFO - 2018-10-09 08:02:15 --> Loader Class Initialized
INFO - 2018-10-09 08:02:15 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:15 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:15 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:16 --> Email Class Initialized
INFO - 2018-10-09 08:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:02:16 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:16 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:16 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:02:16 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:02:16 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:02:17 --> Final output sent to browser
DEBUG - 2018-10-09 08:02:17 --> Total execution time: 3.3976
INFO - 2018-10-09 08:02:41 --> Config Class Initialized
INFO - 2018-10-09 08:02:41 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:02:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:02:42 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:42 --> URI Class Initialized
DEBUG - 2018-10-09 08:02:42 --> No URI present. Default controller set.
INFO - 2018-10-09 08:02:42 --> Router Class Initialized
INFO - 2018-10-09 08:02:42 --> Output Class Initialized
INFO - 2018-10-09 08:02:42 --> Security Class Initialized
DEBUG - 2018-10-09 08:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:43 --> Input Class Initialized
INFO - 2018-10-09 08:02:43 --> Language Class Initialized
INFO - 2018-10-09 08:02:43 --> Language Class Initialized
INFO - 2018-10-09 08:02:43 --> Config Class Initialized
INFO - 2018-10-09 08:02:43 --> Loader Class Initialized
INFO - 2018-10-09 08:02:43 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:43 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:44 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:44 --> Email Class Initialized
INFO - 2018-10-09 08:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:02:44 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:44 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:02:44 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:02:44 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:02:45 --> Final output sent to browser
DEBUG - 2018-10-09 08:02:45 --> Total execution time: 3.2451
INFO - 2018-10-09 08:02:50 --> Config Class Initialized
INFO - 2018-10-09 08:02:50 --> Hooks Class Initialized
INFO - 2018-10-09 08:02:50 --> Config Class Initialized
INFO - 2018-10-09 08:02:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:02:50 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:02:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:02:50 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:50 --> URI Class Initialized
INFO - 2018-10-09 08:02:50 --> Utf8 Class Initialized
INFO - 2018-10-09 08:02:51 --> URI Class Initialized
INFO - 2018-10-09 08:02:51 --> Router Class Initialized
DEBUG - 2018-10-09 08:02:51 --> No URI present. Default controller set.
INFO - 2018-10-09 08:02:51 --> Router Class Initialized
INFO - 2018-10-09 08:02:51 --> Output Class Initialized
INFO - 2018-10-09 08:02:51 --> Security Class Initialized
INFO - 2018-10-09 08:02:52 --> Output Class Initialized
DEBUG - 2018-10-09 08:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:52 --> Input Class Initialized
INFO - 2018-10-09 08:02:52 --> Language Class Initialized
INFO - 2018-10-09 08:02:55 --> Language Class Initialized
INFO - 2018-10-09 08:02:55 --> Config Class Initialized
INFO - 2018-10-09 08:02:56 --> Loader Class Initialized
INFO - 2018-10-09 08:02:56 --> Security Class Initialized
DEBUG - 2018-10-09 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:02:56 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:56 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:56 --> Input Class Initialized
INFO - 2018-10-09 08:02:57 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:57 --> Email Class Initialized
INFO - 2018-10-09 08:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:02:57 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:57 --> Language Class Initialized
INFO - 2018-10-09 08:02:57 --> Language Class Initialized
INFO - 2018-10-09 08:02:57 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:02:58 --> Model Class Initialized
DEBUG - 2018-10-09 08:02:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:02:58 --> Model Class Initialized
INFO - 2018-10-09 08:02:58 --> Config Class Initialized
INFO - 2018-10-09 08:02:58 --> Loader Class Initialized
INFO - 2018-10-09 08:02:58 --> Helper loaded: url_helper
INFO - 2018-10-09 08:02:58 --> Helper loaded: form_helper
INFO - 2018-10-09 08:02:59 --> Database Driver Class Initialized
INFO - 2018-10-09 08:02:59 --> Email Class Initialized
INFO - 2018-10-09 08:02:59 --> Final output sent to browser
INFO - 2018-10-09 08:02:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-09 08:02:59 --> Total execution time: 9.2951
INFO - 2018-10-09 08:02:59 --> Form Validation Class Initialized
INFO - 2018-10-09 08:02:59 --> Controller Class Initialized
DEBUG - 2018-10-09 08:02:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:03:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:03:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:03:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:03:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:03:00 --> Final output sent to browser
DEBUG - 2018-10-09 08:03:00 --> Total execution time: 10.4527
INFO - 2018-10-09 08:03:37 --> Config Class Initialized
INFO - 2018-10-09 08:03:37 --> Hooks Class Initialized
INFO - 2018-10-09 08:03:37 --> Config Class Initialized
INFO - 2018-10-09 08:03:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:03:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:03:38 --> Utf8 Class Initialized
INFO - 2018-10-09 08:03:38 --> URI Class Initialized
INFO - 2018-10-09 08:03:38 --> Utf8 Class Initialized
INFO - 2018-10-09 08:03:38 --> URI Class Initialized
DEBUG - 2018-10-09 08:03:38 --> No URI present. Default controller set.
INFO - 2018-10-09 08:03:38 --> Router Class Initialized
INFO - 2018-10-09 08:03:39 --> Output Class Initialized
INFO - 2018-10-09 08:03:39 --> Security Class Initialized
DEBUG - 2018-10-09 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:03:39 --> Input Class Initialized
INFO - 2018-10-09 08:03:39 --> Language Class Initialized
INFO - 2018-10-09 08:03:39 --> Router Class Initialized
INFO - 2018-10-09 08:03:39 --> Output Class Initialized
INFO - 2018-10-09 08:03:39 --> Language Class Initialized
INFO - 2018-10-09 08:03:40 --> Security Class Initialized
DEBUG - 2018-10-09 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:03:40 --> Config Class Initialized
INFO - 2018-10-09 08:03:40 --> Input Class Initialized
INFO - 2018-10-09 08:03:40 --> Language Class Initialized
INFO - 2018-10-09 08:03:40 --> Language Class Initialized
INFO - 2018-10-09 08:03:40 --> Config Class Initialized
INFO - 2018-10-09 08:03:40 --> Loader Class Initialized
INFO - 2018-10-09 08:03:41 --> Helper loaded: url_helper
INFO - 2018-10-09 08:03:41 --> Loader Class Initialized
INFO - 2018-10-09 08:03:41 --> Helper loaded: form_helper
INFO - 2018-10-09 08:03:41 --> Helper loaded: url_helper
INFO - 2018-10-09 08:03:41 --> Helper loaded: form_helper
INFO - 2018-10-09 08:03:41 --> Database Driver Class Initialized
INFO - 2018-10-09 08:03:41 --> Email Class Initialized
INFO - 2018-10-09 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:03:42 --> Form Validation Class Initialized
INFO - 2018-10-09 08:03:42 --> Controller Class Initialized
DEBUG - 2018-10-09 08:03:42 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:03:42 --> Model Class Initialized
DEBUG - 2018-10-09 08:03:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:03:42 --> Model Class Initialized
INFO - 2018-10-09 08:03:42 --> Database Driver Class Initialized
INFO - 2018-10-09 08:03:42 --> Email Class Initialized
INFO - 2018-10-09 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:03:43 --> Form Validation Class Initialized
INFO - 2018-10-09 08:03:43 --> Controller Class Initialized
DEBUG - 2018-10-09 08:03:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:03:43 --> Final output sent to browser
DEBUG - 2018-10-09 08:03:43 --> Total execution time: 6.0451
INFO - 2018-10-09 08:03:43 --> Model Class Initialized
DEBUG - 2018-10-09 08:03:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:03:44 --> Model Class Initialized
DEBUG - 2018-10-09 08:03:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:03:44 --> Final output sent to browser
DEBUG - 2018-10-09 08:03:44 --> Total execution time: 6.9151
INFO - 2018-10-09 08:05:05 --> Config Class Initialized
INFO - 2018-10-09 08:05:05 --> Hooks Class Initialized
INFO - 2018-10-09 08:05:05 --> Config Class Initialized
INFO - 2018-10-09 08:05:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:05:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:05:05 --> Utf8 Class Initialized
INFO - 2018-10-09 08:05:05 --> URI Class Initialized
DEBUG - 2018-10-09 08:05:05 --> No URI present. Default controller set.
INFO - 2018-10-09 08:05:06 --> Router Class Initialized
INFO - 2018-10-09 08:05:06 --> Output Class Initialized
INFO - 2018-10-09 08:05:06 --> Security Class Initialized
DEBUG - 2018-10-09 08:05:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:05:06 --> Utf8 Class Initialized
INFO - 2018-10-09 08:05:06 --> URI Class Initialized
INFO - 2018-10-09 08:05:06 --> Router Class Initialized
DEBUG - 2018-10-09 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:05:07 --> Input Class Initialized
INFO - 2018-10-09 08:05:07 --> Language Class Initialized
INFO - 2018-10-09 08:05:07 --> Output Class Initialized
INFO - 2018-10-09 08:05:07 --> Security Class Initialized
INFO - 2018-10-09 08:05:07 --> Language Class Initialized
INFO - 2018-10-09 08:05:07 --> Config Class Initialized
DEBUG - 2018-10-09 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:05:07 --> Loader Class Initialized
INFO - 2018-10-09 08:05:08 --> Helper loaded: url_helper
INFO - 2018-10-09 08:05:08 --> Helper loaded: form_helper
INFO - 2018-10-09 08:05:08 --> Input Class Initialized
INFO - 2018-10-09 08:05:08 --> Database Driver Class Initialized
INFO - 2018-10-09 08:05:08 --> Language Class Initialized
INFO - 2018-10-09 08:05:08 --> Language Class Initialized
INFO - 2018-10-09 08:05:08 --> Email Class Initialized
INFO - 2018-10-09 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:05:09 --> Form Validation Class Initialized
INFO - 2018-10-09 08:05:09 --> Config Class Initialized
INFO - 2018-10-09 08:05:09 --> Loader Class Initialized
INFO - 2018-10-09 08:05:09 --> Helper loaded: url_helper
INFO - 2018-10-09 08:05:09 --> Helper loaded: form_helper
INFO - 2018-10-09 08:05:09 --> Database Driver Class Initialized
INFO - 2018-10-09 08:05:09 --> Email Class Initialized
INFO - 2018-10-09 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:05:10 --> Form Validation Class Initialized
INFO - 2018-10-09 08:05:10 --> Controller Class Initialized
DEBUG - 2018-10-09 08:05:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:05:10 --> Model Class Initialized
DEBUG - 2018-10-09 08:05:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:05:11 --> Model Class Initialized
INFO - 2018-10-09 08:05:11 --> Controller Class Initialized
INFO - 2018-10-09 08:05:11 --> Final output sent to browser
DEBUG - 2018-10-09 08:05:11 --> Total execution time: 6.5801
DEBUG - 2018-10-09 08:05:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:05:11 --> Model Class Initialized
DEBUG - 2018-10-09 08:05:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:05:12 --> Model Class Initialized
DEBUG - 2018-10-09 08:05:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:05:12 --> Final output sent to browser
DEBUG - 2018-10-09 08:05:12 --> Total execution time: 7.5176
INFO - 2018-10-09 08:05:21 --> Config Class Initialized
INFO - 2018-10-09 08:05:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:05:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:05:21 --> Utf8 Class Initialized
INFO - 2018-10-09 08:05:21 --> URI Class Initialized
DEBUG - 2018-10-09 08:05:22 --> No URI present. Default controller set.
INFO - 2018-10-09 08:05:22 --> Router Class Initialized
INFO - 2018-10-09 08:05:22 --> Output Class Initialized
INFO - 2018-10-09 08:05:22 --> Security Class Initialized
DEBUG - 2018-10-09 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:05:22 --> Input Class Initialized
INFO - 2018-10-09 08:05:22 --> Language Class Initialized
INFO - 2018-10-09 08:05:22 --> Language Class Initialized
INFO - 2018-10-09 08:05:23 --> Config Class Initialized
INFO - 2018-10-09 08:05:23 --> Loader Class Initialized
INFO - 2018-10-09 08:05:23 --> Helper loaded: url_helper
INFO - 2018-10-09 08:05:23 --> Helper loaded: form_helper
INFO - 2018-10-09 08:05:23 --> Database Driver Class Initialized
INFO - 2018-10-09 08:05:23 --> Email Class Initialized
INFO - 2018-10-09 08:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:05:24 --> Form Validation Class Initialized
INFO - 2018-10-09 08:05:24 --> Controller Class Initialized
DEBUG - 2018-10-09 08:05:24 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:05:24 --> Model Class Initialized
DEBUG - 2018-10-09 08:05:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:05:24 --> Model Class Initialized
DEBUG - 2018-10-09 08:05:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:05:24 --> Final output sent to browser
DEBUG - 2018-10-09 08:05:25 --> Total execution time: 3.6026
INFO - 2018-10-09 08:06:17 --> Config Class Initialized
INFO - 2018-10-09 08:06:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:06:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:06:18 --> Utf8 Class Initialized
INFO - 2018-10-09 08:06:18 --> URI Class Initialized
DEBUG - 2018-10-09 08:06:18 --> No URI present. Default controller set.
INFO - 2018-10-09 08:06:19 --> Router Class Initialized
INFO - 2018-10-09 08:06:19 --> Output Class Initialized
INFO - 2018-10-09 08:06:19 --> Security Class Initialized
DEBUG - 2018-10-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:06:19 --> Input Class Initialized
INFO - 2018-10-09 08:06:19 --> Language Class Initialized
INFO - 2018-10-09 08:06:19 --> Language Class Initialized
INFO - 2018-10-09 08:06:19 --> Config Class Initialized
INFO - 2018-10-09 08:06:20 --> Loader Class Initialized
INFO - 2018-10-09 08:06:20 --> Helper loaded: url_helper
INFO - 2018-10-09 08:06:20 --> Helper loaded: form_helper
INFO - 2018-10-09 08:06:20 --> Database Driver Class Initialized
INFO - 2018-10-09 08:06:20 --> Email Class Initialized
INFO - 2018-10-09 08:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:06:20 --> Form Validation Class Initialized
INFO - 2018-10-09 08:06:21 --> Controller Class Initialized
DEBUG - 2018-10-09 08:06:21 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:06:21 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:06:21 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:06:21 --> Final output sent to browser
DEBUG - 2018-10-09 08:06:22 --> Total execution time: 3.8551
INFO - 2018-10-09 08:06:34 --> Config Class Initialized
INFO - 2018-10-09 08:06:34 --> Hooks Class Initialized
INFO - 2018-10-09 08:06:34 --> Config Class Initialized
INFO - 2018-10-09 08:06:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:06:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:06:35 --> Utf8 Class Initialized
INFO - 2018-10-09 08:06:35 --> URI Class Initialized
INFO - 2018-10-09 08:06:35 --> Router Class Initialized
DEBUG - 2018-10-09 08:06:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:06:35 --> Utf8 Class Initialized
INFO - 2018-10-09 08:06:35 --> URI Class Initialized
INFO - 2018-10-09 08:06:35 --> Output Class Initialized
INFO - 2018-10-09 08:06:36 --> Security Class Initialized
DEBUG - 2018-10-09 08:06:36 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:06:36 --> Input Class Initialized
INFO - 2018-10-09 08:06:36 --> Language Class Initialized
INFO - 2018-10-09 08:06:36 --> Language Class Initialized
INFO - 2018-10-09 08:06:36 --> Router Class Initialized
INFO - 2018-10-09 08:06:37 --> Output Class Initialized
INFO - 2018-10-09 08:06:37 --> Security Class Initialized
INFO - 2018-10-09 08:06:37 --> Config Class Initialized
INFO - 2018-10-09 08:06:37 --> Loader Class Initialized
INFO - 2018-10-09 08:06:37 --> Helper loaded: url_helper
INFO - 2018-10-09 08:06:37 --> Helper loaded: form_helper
DEBUG - 2018-10-09 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:06:37 --> Input Class Initialized
INFO - 2018-10-09 08:06:38 --> Database Driver Class Initialized
INFO - 2018-10-09 08:06:38 --> Email Class Initialized
INFO - 2018-10-09 08:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:06:38 --> Form Validation Class Initialized
INFO - 2018-10-09 08:06:38 --> Controller Class Initialized
DEBUG - 2018-10-09 08:06:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:06:39 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:06:39 --> Language Class Initialized
INFO - 2018-10-09 08:06:39 --> Language Class Initialized
INFO - 2018-10-09 08:06:39 --> Model Class Initialized
INFO - 2018-10-09 08:06:40 --> Final output sent to browser
DEBUG - 2018-10-09 08:06:40 --> Total execution time: 5.7826
INFO - 2018-10-09 08:06:40 --> Config Class Initialized
INFO - 2018-10-09 08:06:40 --> Loader Class Initialized
INFO - 2018-10-09 08:06:40 --> Helper loaded: url_helper
INFO - 2018-10-09 08:06:40 --> Helper loaded: form_helper
INFO - 2018-10-09 08:06:41 --> Database Driver Class Initialized
INFO - 2018-10-09 08:06:41 --> Email Class Initialized
INFO - 2018-10-09 08:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:06:41 --> Form Validation Class Initialized
INFO - 2018-10-09 08:06:41 --> Controller Class Initialized
DEBUG - 2018-10-09 08:06:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:06:41 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:06:42 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:06:42 --> Final output sent to browser
DEBUG - 2018-10-09 08:06:43 --> Total execution time: 7.8601
INFO - 2018-10-09 08:06:47 --> Config Class Initialized
INFO - 2018-10-09 08:06:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:06:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:06:48 --> Utf8 Class Initialized
INFO - 2018-10-09 08:06:48 --> URI Class Initialized
DEBUG - 2018-10-09 08:06:48 --> No URI present. Default controller set.
INFO - 2018-10-09 08:06:48 --> Router Class Initialized
INFO - 2018-10-09 08:06:48 --> Output Class Initialized
INFO - 2018-10-09 08:06:48 --> Security Class Initialized
DEBUG - 2018-10-09 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:06:49 --> Input Class Initialized
INFO - 2018-10-09 08:06:49 --> Language Class Initialized
INFO - 2018-10-09 08:06:49 --> Language Class Initialized
INFO - 2018-10-09 08:06:49 --> Config Class Initialized
INFO - 2018-10-09 08:06:49 --> Loader Class Initialized
INFO - 2018-10-09 08:06:49 --> Helper loaded: url_helper
INFO - 2018-10-09 08:06:49 --> Helper loaded: form_helper
INFO - 2018-10-09 08:06:50 --> Database Driver Class Initialized
INFO - 2018-10-09 08:06:50 --> Email Class Initialized
INFO - 2018-10-09 08:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:06:50 --> Form Validation Class Initialized
INFO - 2018-10-09 08:06:50 --> Controller Class Initialized
DEBUG - 2018-10-09 08:06:50 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:06:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:06:51 --> Model Class Initialized
DEBUG - 2018-10-09 08:06:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:06:51 --> Final output sent to browser
DEBUG - 2018-10-09 08:06:51 --> Total execution time: 3.8251
INFO - 2018-10-09 08:07:21 --> Config Class Initialized
INFO - 2018-10-09 08:07:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:07:22 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:07:22 --> Utf8 Class Initialized
INFO - 2018-10-09 08:07:22 --> URI Class Initialized
DEBUG - 2018-10-09 08:07:22 --> No URI present. Default controller set.
INFO - 2018-10-09 08:07:22 --> Router Class Initialized
INFO - 2018-10-09 08:07:22 --> Output Class Initialized
INFO - 2018-10-09 08:07:23 --> Security Class Initialized
DEBUG - 2018-10-09 08:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:07:23 --> Input Class Initialized
INFO - 2018-10-09 08:07:23 --> Language Class Initialized
INFO - 2018-10-09 08:07:23 --> Language Class Initialized
INFO - 2018-10-09 08:07:23 --> Config Class Initialized
INFO - 2018-10-09 08:07:23 --> Loader Class Initialized
INFO - 2018-10-09 08:07:23 --> Helper loaded: url_helper
INFO - 2018-10-09 08:07:24 --> Helper loaded: form_helper
INFO - 2018-10-09 08:07:24 --> Database Driver Class Initialized
INFO - 2018-10-09 08:07:24 --> Email Class Initialized
INFO - 2018-10-09 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:07:24 --> Form Validation Class Initialized
INFO - 2018-10-09 08:07:24 --> Controller Class Initialized
DEBUG - 2018-10-09 08:07:24 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:07:24 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:07:25 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:07:25 --> Final output sent to browser
DEBUG - 2018-10-09 08:07:25 --> Total execution time: 3.4651
INFO - 2018-10-09 08:07:37 --> Config Class Initialized
INFO - 2018-10-09 08:07:37 --> Hooks Class Initialized
INFO - 2018-10-09 08:07:37 --> Config Class Initialized
INFO - 2018-10-09 08:07:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:07:38 --> Utf8 Class Initialized
INFO - 2018-10-09 08:07:38 --> URI Class Initialized
DEBUG - 2018-10-09 08:07:38 --> No URI present. Default controller set.
INFO - 2018-10-09 08:07:38 --> Router Class Initialized
DEBUG - 2018-10-09 08:07:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:07:38 --> Utf8 Class Initialized
INFO - 2018-10-09 08:07:39 --> URI Class Initialized
INFO - 2018-10-09 08:07:39 --> Router Class Initialized
INFO - 2018-10-09 08:07:39 --> Output Class Initialized
INFO - 2018-10-09 08:07:39 --> Security Class Initialized
INFO - 2018-10-09 08:07:39 --> Output Class Initialized
INFO - 2018-10-09 08:07:39 --> Security Class Initialized
DEBUG - 2018-10-09 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:07:40 --> Input Class Initialized
DEBUG - 2018-10-09 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:07:40 --> Language Class Initialized
INFO - 2018-10-09 08:07:40 --> Input Class Initialized
INFO - 2018-10-09 08:07:40 --> Language Class Initialized
INFO - 2018-10-09 08:07:40 --> Language Class Initialized
INFO - 2018-10-09 08:07:40 --> Config Class Initialized
INFO - 2018-10-09 08:07:40 --> Loader Class Initialized
INFO - 2018-10-09 08:07:41 --> Language Class Initialized
INFO - 2018-10-09 08:07:41 --> Config Class Initialized
INFO - 2018-10-09 08:07:41 --> Loader Class Initialized
INFO - 2018-10-09 08:07:41 --> Helper loaded: url_helper
INFO - 2018-10-09 08:07:41 --> Helper loaded: form_helper
INFO - 2018-10-09 08:07:41 --> Helper loaded: url_helper
INFO - 2018-10-09 08:07:41 --> Helper loaded: form_helper
INFO - 2018-10-09 08:07:42 --> Database Driver Class Initialized
INFO - 2018-10-09 08:07:42 --> Email Class Initialized
INFO - 2018-10-09 08:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:07:42 --> Form Validation Class Initialized
INFO - 2018-10-09 08:07:42 --> Controller Class Initialized
DEBUG - 2018-10-09 08:07:42 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:07:42 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:07:43 --> Database Driver Class Initialized
INFO - 2018-10-09 08:07:43 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:07:43 --> Final output sent to browser
DEBUG - 2018-10-09 08:07:43 --> Total execution time: 5.6251
INFO - 2018-10-09 08:07:45 --> Email Class Initialized
INFO - 2018-10-09 08:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:07:45 --> Form Validation Class Initialized
INFO - 2018-10-09 08:07:45 --> Controller Class Initialized
DEBUG - 2018-10-09 08:07:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:07:45 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:07:45 --> Model Class Initialized
INFO - 2018-10-09 08:07:46 --> Final output sent to browser
DEBUG - 2018-10-09 08:07:46 --> Total execution time: 8.8346
INFO - 2018-10-09 08:07:53 --> Config Class Initialized
INFO - 2018-10-09 08:07:53 --> Hooks Class Initialized
INFO - 2018-10-09 08:07:54 --> Config Class Initialized
INFO - 2018-10-09 08:07:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:07:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:07:54 --> Utf8 Class Initialized
INFO - 2018-10-09 08:07:54 --> URI Class Initialized
DEBUG - 2018-10-09 08:07:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:07:55 --> Utf8 Class Initialized
INFO - 2018-10-09 08:07:55 --> URI Class Initialized
INFO - 2018-10-09 08:07:55 --> Router Class Initialized
INFO - 2018-10-09 08:07:55 --> Output Class Initialized
INFO - 2018-10-09 08:07:55 --> Security Class Initialized
DEBUG - 2018-10-09 08:07:55 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:07:56 --> Input Class Initialized
INFO - 2018-10-09 08:07:56 --> Language Class Initialized
INFO - 2018-10-09 08:07:56 --> Router Class Initialized
INFO - 2018-10-09 08:07:56 --> Output Class Initialized
INFO - 2018-10-09 08:07:56 --> Security Class Initialized
INFO - 2018-10-09 08:07:56 --> Language Class Initialized
DEBUG - 2018-10-09 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:07:57 --> Config Class Initialized
INFO - 2018-10-09 08:07:57 --> Input Class Initialized
INFO - 2018-10-09 08:07:57 --> Language Class Initialized
INFO - 2018-10-09 08:07:57 --> Language Class Initialized
INFO - 2018-10-09 08:07:57 --> Config Class Initialized
INFO - 2018-10-09 08:07:57 --> Loader Class Initialized
INFO - 2018-10-09 08:07:57 --> Loader Class Initialized
INFO - 2018-10-09 08:07:57 --> Helper loaded: url_helper
INFO - 2018-10-09 08:07:58 --> Helper loaded: form_helper
INFO - 2018-10-09 08:07:58 --> Database Driver Class Initialized
INFO - 2018-10-09 08:07:58 --> Email Class Initialized
INFO - 2018-10-09 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:07:58 --> Form Validation Class Initialized
INFO - 2018-10-09 08:07:58 --> Helper loaded: url_helper
INFO - 2018-10-09 08:07:58 --> Controller Class Initialized
DEBUG - 2018-10-09 08:07:58 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:07:59 --> Model Class Initialized
DEBUG - 2018-10-09 08:07:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:07:59 --> Helper loaded: form_helper
INFO - 2018-10-09 08:07:59 --> Database Driver Class Initialized
INFO - 2018-10-09 08:07:59 --> Email Class Initialized
INFO - 2018-10-09 08:07:59 --> Model Class Initialized
INFO - 2018-10-09 08:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:08:00 --> Form Validation Class Initialized
INFO - 2018-10-09 08:08:00 --> Controller Class Initialized
INFO - 2018-10-09 08:08:00 --> Final output sent to browser
DEBUG - 2018-10-09 08:08:00 --> Total execution time: 6.4601
DEBUG - 2018-10-09 08:08:00 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:08:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:08:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:08:01 --> Final output sent to browser
DEBUG - 2018-10-09 08:08:01 --> Total execution time: 7.2426
INFO - 2018-10-09 08:08:08 --> Config Class Initialized
INFO - 2018-10-09 08:08:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:08:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:08:09 --> Utf8 Class Initialized
INFO - 2018-10-09 08:08:09 --> URI Class Initialized
DEBUG - 2018-10-09 08:08:09 --> No URI present. Default controller set.
INFO - 2018-10-09 08:08:09 --> Router Class Initialized
INFO - 2018-10-09 08:08:10 --> Output Class Initialized
INFO - 2018-10-09 08:08:10 --> Security Class Initialized
DEBUG - 2018-10-09 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:08:11 --> Input Class Initialized
INFO - 2018-10-09 08:08:11 --> Language Class Initialized
INFO - 2018-10-09 08:08:11 --> Language Class Initialized
INFO - 2018-10-09 08:08:12 --> Config Class Initialized
INFO - 2018-10-09 08:08:12 --> Loader Class Initialized
INFO - 2018-10-09 08:08:12 --> Helper loaded: url_helper
INFO - 2018-10-09 08:08:12 --> Helper loaded: form_helper
INFO - 2018-10-09 08:08:12 --> Database Driver Class Initialized
INFO - 2018-10-09 08:08:13 --> Email Class Initialized
INFO - 2018-10-09 08:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:08:13 --> Config Class Initialized
INFO - 2018-10-09 08:08:13 --> Hooks Class Initialized
INFO - 2018-10-09 08:08:13 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:08:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:08:14 --> Utf8 Class Initialized
INFO - 2018-10-09 08:08:14 --> URI Class Initialized
DEBUG - 2018-10-09 08:08:14 --> No URI present. Default controller set.
INFO - 2018-10-09 08:08:14 --> Router Class Initialized
INFO - 2018-10-09 08:08:14 --> Output Class Initialized
INFO - 2018-10-09 08:08:14 --> Security Class Initialized
DEBUG - 2018-10-09 08:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:08:15 --> Controller Class Initialized
INFO - 2018-10-09 08:08:15 --> Input Class Initialized
DEBUG - 2018-10-09 08:08:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:08:15 --> Language Class Initialized
INFO - 2018-10-09 08:08:15 --> Language Class Initialized
INFO - 2018-10-09 08:08:16 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:08:16 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:08:16 --> Final output sent to browser
INFO - 2018-10-09 08:08:16 --> Config Class Initialized
DEBUG - 2018-10-09 08:08:17 --> Total execution time: 8.0251
INFO - 2018-10-09 08:08:17 --> Loader Class Initialized
INFO - 2018-10-09 08:08:17 --> Helper loaded: url_helper
INFO - 2018-10-09 08:08:17 --> Helper loaded: form_helper
INFO - 2018-10-09 08:08:18 --> Database Driver Class Initialized
INFO - 2018-10-09 08:08:18 --> Email Class Initialized
INFO - 2018-10-09 08:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:08:18 --> Form Validation Class Initialized
INFO - 2018-10-09 08:08:18 --> Controller Class Initialized
DEBUG - 2018-10-09 08:08:18 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:08:18 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:08:19 --> Model Class Initialized
DEBUG - 2018-10-09 08:08:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:08:19 --> Final output sent to browser
DEBUG - 2018-10-09 08:08:19 --> Total execution time: 6.3101
INFO - 2018-10-09 08:09:07 --> Config Class Initialized
INFO - 2018-10-09 08:09:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:09:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:09:07 --> Utf8 Class Initialized
INFO - 2018-10-09 08:09:07 --> URI Class Initialized
DEBUG - 2018-10-09 08:09:08 --> No URI present. Default controller set.
INFO - 2018-10-09 08:09:08 --> Router Class Initialized
INFO - 2018-10-09 08:09:08 --> Output Class Initialized
INFO - 2018-10-09 08:09:08 --> Security Class Initialized
DEBUG - 2018-10-09 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:09:08 --> Input Class Initialized
INFO - 2018-10-09 08:09:08 --> Language Class Initialized
INFO - 2018-10-09 08:09:09 --> Language Class Initialized
INFO - 2018-10-09 08:09:09 --> Config Class Initialized
INFO - 2018-10-09 08:09:09 --> Loader Class Initialized
INFO - 2018-10-09 08:09:09 --> Helper loaded: url_helper
INFO - 2018-10-09 08:09:09 --> Helper loaded: form_helper
INFO - 2018-10-09 08:09:09 --> Database Driver Class Initialized
INFO - 2018-10-09 08:09:09 --> Email Class Initialized
INFO - 2018-10-09 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:09:10 --> Form Validation Class Initialized
INFO - 2018-10-09 08:09:10 --> Controller Class Initialized
DEBUG - 2018-10-09 08:09:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:09:10 --> Model Class Initialized
DEBUG - 2018-10-09 08:09:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:09:10 --> Model Class Initialized
DEBUG - 2018-10-09 08:09:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:09:11 --> Final output sent to browser
DEBUG - 2018-10-09 08:09:11 --> Total execution time: 3.9507
INFO - 2018-10-09 08:10:02 --> Config Class Initialized
INFO - 2018-10-09 08:10:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:10:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:10:02 --> Utf8 Class Initialized
INFO - 2018-10-09 08:10:02 --> URI Class Initialized
DEBUG - 2018-10-09 08:10:03 --> No URI present. Default controller set.
INFO - 2018-10-09 08:10:03 --> Router Class Initialized
INFO - 2018-10-09 08:10:03 --> Output Class Initialized
INFO - 2018-10-09 08:10:03 --> Security Class Initialized
DEBUG - 2018-10-09 08:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:10:03 --> Input Class Initialized
INFO - 2018-10-09 08:10:03 --> Language Class Initialized
INFO - 2018-10-09 08:10:04 --> Language Class Initialized
INFO - 2018-10-09 08:10:04 --> Config Class Initialized
INFO - 2018-10-09 08:10:04 --> Loader Class Initialized
INFO - 2018-10-09 08:10:04 --> Helper loaded: url_helper
INFO - 2018-10-09 08:10:04 --> Helper loaded: form_helper
INFO - 2018-10-09 08:10:04 --> Database Driver Class Initialized
INFO - 2018-10-09 08:10:04 --> Email Class Initialized
INFO - 2018-10-09 08:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:10:05 --> Form Validation Class Initialized
INFO - 2018-10-09 08:10:05 --> Controller Class Initialized
DEBUG - 2018-10-09 08:10:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:10:05 --> Model Class Initialized
DEBUG - 2018-10-09 08:10:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:10:05 --> Model Class Initialized
DEBUG - 2018-10-09 08:10:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:10:06 --> Final output sent to browser
DEBUG - 2018-10-09 08:10:06 --> Total execution time: 3.8776
INFO - 2018-10-09 08:10:14 --> Config Class Initialized
INFO - 2018-10-09 08:10:15 --> Hooks Class Initialized
INFO - 2018-10-09 08:10:15 --> Config Class Initialized
INFO - 2018-10-09 08:10:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:10:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:10:15 --> Utf8 Class Initialized
INFO - 2018-10-09 08:10:15 --> URI Class Initialized
DEBUG - 2018-10-09 08:10:16 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:10:16 --> Utf8 Class Initialized
INFO - 2018-10-09 08:10:16 --> Router Class Initialized
INFO - 2018-10-09 08:10:16 --> Output Class Initialized
INFO - 2018-10-09 08:10:16 --> URI Class Initialized
INFO - 2018-10-09 08:10:16 --> Security Class Initialized
DEBUG - 2018-10-09 08:10:16 --> No URI present. Default controller set.
INFO - 2018-10-09 08:10:17 --> Router Class Initialized
INFO - 2018-10-09 08:10:17 --> Output Class Initialized
DEBUG - 2018-10-09 08:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:10:17 --> Security Class Initialized
INFO - 2018-10-09 08:10:17 --> Input Class Initialized
INFO - 2018-10-09 08:10:17 --> Language Class Initialized
INFO - 2018-10-09 08:10:17 --> Language Class Initialized
DEBUG - 2018-10-09 08:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:10:18 --> Config Class Initialized
INFO - 2018-10-09 08:10:18 --> Loader Class Initialized
INFO - 2018-10-09 08:10:18 --> Input Class Initialized
INFO - 2018-10-09 08:10:18 --> Helper loaded: url_helper
INFO - 2018-10-09 08:10:18 --> Language Class Initialized
INFO - 2018-10-09 08:10:18 --> Language Class Initialized
INFO - 2018-10-09 08:10:18 --> Helper loaded: form_helper
INFO - 2018-10-09 08:10:19 --> Database Driver Class Initialized
INFO - 2018-10-09 08:10:19 --> Config Class Initialized
INFO - 2018-10-09 08:10:19 --> Loader Class Initialized
INFO - 2018-10-09 08:10:19 --> Helper loaded: url_helper
INFO - 2018-10-09 08:10:19 --> Email Class Initialized
INFO - 2018-10-09 08:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:10:19 --> Form Validation Class Initialized
INFO - 2018-10-09 08:10:20 --> Controller Class Initialized
INFO - 2018-10-09 08:10:20 --> Helper loaded: form_helper
INFO - 2018-10-09 08:10:20 --> Database Driver Class Initialized
DEBUG - 2018-10-09 08:10:20 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:10:20 --> Email Class Initialized
INFO - 2018-10-09 08:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:10:20 --> Model Class Initialized
INFO - 2018-10-09 08:10:21 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:10:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:10:21 --> Controller Class Initialized
DEBUG - 2018-10-09 08:10:21 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:10:21 --> Model Class Initialized
INFO - 2018-10-09 08:10:21 --> Model Class Initialized
DEBUG - 2018-10-09 08:10:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:10:21 --> Model Class Initialized
INFO - 2018-10-09 08:10:22 --> Final output sent to browser
DEBUG - 2018-10-09 08:10:22 --> Total execution time: 7.3626
DEBUG - 2018-10-09 08:10:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:10:22 --> Final output sent to browser
DEBUG - 2018-10-09 08:10:22 --> Total execution time: 7.4976
INFO - 2018-10-09 08:10:42 --> Config Class Initialized
INFO - 2018-10-09 08:10:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:10:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:10:43 --> Utf8 Class Initialized
INFO - 2018-10-09 08:10:43 --> URI Class Initialized
DEBUG - 2018-10-09 08:10:43 --> No URI present. Default controller set.
INFO - 2018-10-09 08:10:43 --> Router Class Initialized
INFO - 2018-10-09 08:10:43 --> Output Class Initialized
INFO - 2018-10-09 08:10:44 --> Security Class Initialized
DEBUG - 2018-10-09 08:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:10:44 --> Input Class Initialized
INFO - 2018-10-09 08:10:44 --> Language Class Initialized
INFO - 2018-10-09 08:10:44 --> Language Class Initialized
INFO - 2018-10-09 08:10:44 --> Config Class Initialized
INFO - 2018-10-09 08:10:44 --> Loader Class Initialized
INFO - 2018-10-09 08:10:45 --> Helper loaded: url_helper
INFO - 2018-10-09 08:10:45 --> Helper loaded: form_helper
INFO - 2018-10-09 08:10:45 --> Database Driver Class Initialized
INFO - 2018-10-09 08:10:45 --> Email Class Initialized
INFO - 2018-10-09 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:10:45 --> Form Validation Class Initialized
INFO - 2018-10-09 08:10:46 --> Controller Class Initialized
DEBUG - 2018-10-09 08:10:46 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:10:46 --> Model Class Initialized
DEBUG - 2018-10-09 08:10:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:10:46 --> Model Class Initialized
DEBUG - 2018-10-09 08:10:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:10:46 --> Final output sent to browser
DEBUG - 2018-10-09 08:10:47 --> Total execution time: 4.0876
INFO - 2018-10-09 08:10:57 --> Config Class Initialized
INFO - 2018-10-09 08:10:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:10:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:10:57 --> Utf8 Class Initialized
INFO - 2018-10-09 08:10:58 --> URI Class Initialized
DEBUG - 2018-10-09 08:10:58 --> No URI present. Default controller set.
INFO - 2018-10-09 08:10:58 --> Router Class Initialized
INFO - 2018-10-09 08:10:58 --> Output Class Initialized
INFO - 2018-10-09 08:10:58 --> Security Class Initialized
DEBUG - 2018-10-09 08:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:10:59 --> Input Class Initialized
INFO - 2018-10-09 08:10:59 --> Language Class Initialized
INFO - 2018-10-09 08:10:59 --> Language Class Initialized
INFO - 2018-10-09 08:10:59 --> Config Class Initialized
INFO - 2018-10-09 08:10:59 --> Loader Class Initialized
INFO - 2018-10-09 08:11:00 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:00 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:00 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:00 --> Email Class Initialized
INFO - 2018-10-09 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:01 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:01 --> Controller Class Initialized
DEBUG - 2018-10-09 08:11:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:11:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:11:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:11:02 --> Final output sent to browser
DEBUG - 2018-10-09 08:11:02 --> Total execution time: 4.9101
INFO - 2018-10-09 08:11:23 --> Config Class Initialized
INFO - 2018-10-09 08:11:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:11:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:11:23 --> Utf8 Class Initialized
INFO - 2018-10-09 08:11:23 --> URI Class Initialized
DEBUG - 2018-10-09 08:11:24 --> No URI present. Default controller set.
INFO - 2018-10-09 08:11:24 --> Router Class Initialized
INFO - 2018-10-09 08:11:24 --> Output Class Initialized
INFO - 2018-10-09 08:11:24 --> Security Class Initialized
DEBUG - 2018-10-09 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:11:24 --> Input Class Initialized
INFO - 2018-10-09 08:11:24 --> Language Class Initialized
INFO - 2018-10-09 08:11:25 --> Language Class Initialized
INFO - 2018-10-09 08:11:25 --> Config Class Initialized
INFO - 2018-10-09 08:11:25 --> Loader Class Initialized
INFO - 2018-10-09 08:11:25 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:25 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:25 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:25 --> Email Class Initialized
INFO - 2018-10-09 08:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:26 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:26 --> Controller Class Initialized
DEBUG - 2018-10-09 08:11:26 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:11:26 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:11:26 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:11:27 --> Final output sent to browser
DEBUG - 2018-10-09 08:11:27 --> Total execution time: 3.7951
INFO - 2018-10-09 08:11:32 --> Config Class Initialized
INFO - 2018-10-09 08:11:32 --> Hooks Class Initialized
INFO - 2018-10-09 08:11:32 --> Config Class Initialized
DEBUG - 2018-10-09 08:11:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:11:32 --> Utf8 Class Initialized
INFO - 2018-10-09 08:11:33 --> URI Class Initialized
INFO - 2018-10-09 08:11:33 --> Hooks Class Initialized
INFO - 2018-10-09 08:11:33 --> Router Class Initialized
INFO - 2018-10-09 08:11:33 --> Output Class Initialized
INFO - 2018-10-09 08:11:33 --> Security Class Initialized
DEBUG - 2018-10-09 08:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:11:33 --> Input Class Initialized
DEBUG - 2018-10-09 08:11:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:11:34 --> Language Class Initialized
INFO - 2018-10-09 08:11:34 --> Utf8 Class Initialized
INFO - 2018-10-09 08:11:34 --> URI Class Initialized
DEBUG - 2018-10-09 08:11:34 --> No URI present. Default controller set.
INFO - 2018-10-09 08:11:34 --> Router Class Initialized
INFO - 2018-10-09 08:11:34 --> Output Class Initialized
INFO - 2018-10-09 08:11:35 --> Security Class Initialized
DEBUG - 2018-10-09 08:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:11:35 --> Input Class Initialized
INFO - 2018-10-09 08:11:35 --> Language Class Initialized
INFO - 2018-10-09 08:11:35 --> Language Class Initialized
INFO - 2018-10-09 08:11:35 --> Config Class Initialized
INFO - 2018-10-09 08:11:35 --> Language Class Initialized
INFO - 2018-10-09 08:11:35 --> Config Class Initialized
INFO - 2018-10-09 08:11:36 --> Loader Class Initialized
INFO - 2018-10-09 08:11:36 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:36 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:36 --> Loader Class Initialized
INFO - 2018-10-09 08:11:36 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:36 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:36 --> Email Class Initialized
INFO - 2018-10-09 08:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:37 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:37 --> Controller Class Initialized
DEBUG - 2018-10-09 08:11:37 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:11:37 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:37 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:11:38 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:38 --> Model Class Initialized
INFO - 2018-10-09 08:11:38 --> Final output sent to browser
DEBUG - 2018-10-09 08:11:38 --> Total execution time: 6.4201
INFO - 2018-10-09 08:11:38 --> Email Class Initialized
INFO - 2018-10-09 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:39 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:39 --> Controller Class Initialized
DEBUG - 2018-10-09 08:11:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:11:39 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:11:39 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:39 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:11:40 --> Final output sent to browser
DEBUG - 2018-10-09 08:11:40 --> Total execution time: 7.8151
INFO - 2018-10-09 08:11:50 --> Config Class Initialized
INFO - 2018-10-09 08:11:50 --> Hooks Class Initialized
INFO - 2018-10-09 08:11:50 --> Config Class Initialized
INFO - 2018-10-09 08:11:50 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:11:50 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:11:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:11:51 --> Utf8 Class Initialized
INFO - 2018-10-09 08:11:51 --> URI Class Initialized
DEBUG - 2018-10-09 08:11:51 --> No URI present. Default controller set.
INFO - 2018-10-09 08:11:51 --> Router Class Initialized
INFO - 2018-10-09 08:11:51 --> Output Class Initialized
INFO - 2018-10-09 08:11:51 --> Utf8 Class Initialized
INFO - 2018-10-09 08:11:51 --> URI Class Initialized
INFO - 2018-10-09 08:11:52 --> Security Class Initialized
DEBUG - 2018-10-09 08:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:11:52 --> Router Class Initialized
INFO - 2018-10-09 08:11:52 --> Input Class Initialized
INFO - 2018-10-09 08:11:52 --> Language Class Initialized
INFO - 2018-10-09 08:11:52 --> Language Class Initialized
INFO - 2018-10-09 08:11:53 --> Config Class Initialized
INFO - 2018-10-09 08:11:53 --> Loader Class Initialized
INFO - 2018-10-09 08:11:53 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:53 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:53 --> Output Class Initialized
INFO - 2018-10-09 08:11:53 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:53 --> Email Class Initialized
INFO - 2018-10-09 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:54 --> Security Class Initialized
DEBUG - 2018-10-09 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:11:54 --> Input Class Initialized
INFO - 2018-10-09 08:11:55 --> Language Class Initialized
INFO - 2018-10-09 08:11:55 --> Language Class Initialized
INFO - 2018-10-09 08:11:56 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:56 --> Config Class Initialized
INFO - 2018-10-09 08:11:56 --> Controller Class Initialized
INFO - 2018-10-09 08:11:56 --> Loader Class Initialized
DEBUG - 2018-10-09 08:11:56 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:11:57 --> Helper loaded: url_helper
INFO - 2018-10-09 08:11:57 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:11:57 --> Helper loaded: form_helper
INFO - 2018-10-09 08:11:57 --> Database Driver Class Initialized
INFO - 2018-10-09 08:11:57 --> Model Class Initialized
DEBUG - 2018-10-09 08:11:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:11:58 --> Final output sent to browser
DEBUG - 2018-10-09 08:11:58 --> Total execution time: 7.7476
INFO - 2018-10-09 08:11:58 --> Email Class Initialized
INFO - 2018-10-09 08:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:11:59 --> Form Validation Class Initialized
INFO - 2018-10-09 08:11:59 --> Controller Class Initialized
DEBUG - 2018-10-09 08:11:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:12:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:12:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:12:00 --> Model Class Initialized
INFO - 2018-10-09 08:12:00 --> Final output sent to browser
DEBUG - 2018-10-09 08:12:00 --> Total execution time: 10.6318
INFO - 2018-10-09 08:13:24 --> Config Class Initialized
INFO - 2018-10-09 08:13:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:13:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:13:24 --> Utf8 Class Initialized
INFO - 2018-10-09 08:13:24 --> URI Class Initialized
DEBUG - 2018-10-09 08:13:24 --> No URI present. Default controller set.
INFO - 2018-10-09 08:13:24 --> Router Class Initialized
INFO - 2018-10-09 08:13:25 --> Output Class Initialized
INFO - 2018-10-09 08:13:25 --> Security Class Initialized
DEBUG - 2018-10-09 08:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:13:25 --> Input Class Initialized
INFO - 2018-10-09 08:13:25 --> Language Class Initialized
INFO - 2018-10-09 08:13:25 --> Language Class Initialized
INFO - 2018-10-09 08:13:25 --> Config Class Initialized
INFO - 2018-10-09 08:13:26 --> Loader Class Initialized
INFO - 2018-10-09 08:13:26 --> Helper loaded: url_helper
INFO - 2018-10-09 08:13:26 --> Helper loaded: form_helper
INFO - 2018-10-09 08:13:26 --> Database Driver Class Initialized
INFO - 2018-10-09 08:13:26 --> Email Class Initialized
INFO - 2018-10-09 08:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:13:27 --> Form Validation Class Initialized
INFO - 2018-10-09 08:13:27 --> Controller Class Initialized
DEBUG - 2018-10-09 08:13:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:13:27 --> Model Class Initialized
DEBUG - 2018-10-09 08:13:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:13:27 --> Model Class Initialized
DEBUG - 2018-10-09 08:13:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:13:28 --> Final output sent to browser
DEBUG - 2018-10-09 08:13:28 --> Total execution time: 4.1751
INFO - 2018-10-09 08:13:40 --> Config Class Initialized
INFO - 2018-10-09 08:13:40 --> Hooks Class Initialized
INFO - 2018-10-09 08:13:40 --> Config Class Initialized
INFO - 2018-10-09 08:13:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:13:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:13:41 --> Utf8 Class Initialized
INFO - 2018-10-09 08:13:41 --> Utf8 Class Initialized
INFO - 2018-10-09 08:13:41 --> URI Class Initialized
INFO - 2018-10-09 08:13:41 --> Router Class Initialized
INFO - 2018-10-09 08:13:41 --> Output Class Initialized
INFO - 2018-10-09 08:13:42 --> Security Class Initialized
INFO - 2018-10-09 08:13:42 --> URI Class Initialized
DEBUG - 2018-10-09 08:13:42 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:13:42 --> Input Class Initialized
INFO - 2018-10-09 08:13:42 --> Router Class Initialized
INFO - 2018-10-09 08:13:42 --> Output Class Initialized
INFO - 2018-10-09 08:13:43 --> Language Class Initialized
INFO - 2018-10-09 08:13:43 --> Security Class Initialized
INFO - 2018-10-09 08:13:43 --> Language Class Initialized
INFO - 2018-10-09 08:13:43 --> Config Class Initialized
DEBUG - 2018-10-09 08:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:13:43 --> Loader Class Initialized
INFO - 2018-10-09 08:13:43 --> Helper loaded: url_helper
INFO - 2018-10-09 08:13:44 --> Input Class Initialized
INFO - 2018-10-09 08:13:44 --> Language Class Initialized
INFO - 2018-10-09 08:13:44 --> Language Class Initialized
INFO - 2018-10-09 08:13:44 --> Helper loaded: form_helper
INFO - 2018-10-09 08:13:44 --> Database Driver Class Initialized
INFO - 2018-10-09 08:13:44 --> Config Class Initialized
INFO - 2018-10-09 08:13:44 --> Loader Class Initialized
INFO - 2018-10-09 08:13:45 --> Helper loaded: url_helper
INFO - 2018-10-09 08:13:45 --> Email Class Initialized
INFO - 2018-10-09 08:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:13:45 --> Form Validation Class Initialized
INFO - 2018-10-09 08:13:45 --> Controller Class Initialized
INFO - 2018-10-09 08:13:45 --> Helper loaded: form_helper
INFO - 2018-10-09 08:13:46 --> Database Driver Class Initialized
INFO - 2018-10-09 08:13:46 --> Email Class Initialized
INFO - 2018-10-09 08:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:13:46 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:13:46 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:13:46 --> Model Class Initialized
INFO - 2018-10-09 08:13:46 --> Controller Class Initialized
DEBUG - 2018-10-09 08:13:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:13:47 --> Model Class Initialized
INFO - 2018-10-09 08:13:47 --> Final output sent to browser
DEBUG - 2018-10-09 08:13:47 --> Total execution time: 7.0301
DEBUG - 2018-10-09 08:13:47 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:13:47 --> Model Class Initialized
DEBUG - 2018-10-09 08:13:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:13:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:13:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:13:48 --> Final output sent to browser
DEBUG - 2018-10-09 08:13:48 --> Total execution time: 8.0826
INFO - 2018-10-09 08:14:44 --> Config Class Initialized
INFO - 2018-10-09 08:14:44 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:14:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:14:44 --> Utf8 Class Initialized
INFO - 2018-10-09 08:14:45 --> URI Class Initialized
DEBUG - 2018-10-09 08:14:45 --> No URI present. Default controller set.
INFO - 2018-10-09 08:14:45 --> Router Class Initialized
INFO - 2018-10-09 08:14:45 --> Output Class Initialized
INFO - 2018-10-09 08:14:45 --> Security Class Initialized
DEBUG - 2018-10-09 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:14:46 --> Input Class Initialized
INFO - 2018-10-09 08:14:46 --> Language Class Initialized
INFO - 2018-10-09 08:14:46 --> Language Class Initialized
INFO - 2018-10-09 08:14:46 --> Config Class Initialized
INFO - 2018-10-09 08:14:46 --> Loader Class Initialized
INFO - 2018-10-09 08:14:46 --> Helper loaded: url_helper
INFO - 2018-10-09 08:14:47 --> Helper loaded: form_helper
INFO - 2018-10-09 08:14:47 --> Database Driver Class Initialized
INFO - 2018-10-09 08:14:47 --> Email Class Initialized
INFO - 2018-10-09 08:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:14:47 --> Form Validation Class Initialized
INFO - 2018-10-09 08:14:47 --> Controller Class Initialized
DEBUG - 2018-10-09 08:14:47 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:14:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:14:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:14:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:14:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:14:48 --> Final output sent to browser
DEBUG - 2018-10-09 08:14:48 --> Total execution time: 4.1826
INFO - 2018-10-09 08:15:01 --> Config Class Initialized
INFO - 2018-10-09 08:15:01 --> Hooks Class Initialized
INFO - 2018-10-09 08:15:01 --> Config Class Initialized
INFO - 2018-10-09 08:15:01 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:15:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:15:01 --> Utf8 Class Initialized
INFO - 2018-10-09 08:15:02 --> URI Class Initialized
DEBUG - 2018-10-09 08:15:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:15:02 --> Utf8 Class Initialized
INFO - 2018-10-09 08:15:02 --> Router Class Initialized
INFO - 2018-10-09 08:15:02 --> URI Class Initialized
DEBUG - 2018-10-09 08:15:02 --> No URI present. Default controller set.
INFO - 2018-10-09 08:15:03 --> Router Class Initialized
INFO - 2018-10-09 08:15:03 --> Output Class Initialized
INFO - 2018-10-09 08:15:03 --> Security Class Initialized
DEBUG - 2018-10-09 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:15:03 --> Output Class Initialized
INFO - 2018-10-09 08:15:03 --> Input Class Initialized
INFO - 2018-10-09 08:15:04 --> Language Class Initialized
INFO - 2018-10-09 08:15:04 --> Security Class Initialized
DEBUG - 2018-10-09 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:15:04 --> Input Class Initialized
INFO - 2018-10-09 08:15:04 --> Language Class Initialized
INFO - 2018-10-09 08:15:04 --> Language Class Initialized
INFO - 2018-10-09 08:15:04 --> Config Class Initialized
INFO - 2018-10-09 08:15:05 --> Language Class Initialized
INFO - 2018-10-09 08:15:05 --> Config Class Initialized
INFO - 2018-10-09 08:15:05 --> Loader Class Initialized
INFO - 2018-10-09 08:15:05 --> Helper loaded: url_helper
INFO - 2018-10-09 08:15:05 --> Loader Class Initialized
INFO - 2018-10-09 08:15:05 --> Helper loaded: url_helper
INFO - 2018-10-09 08:15:05 --> Helper loaded: form_helper
INFO - 2018-10-09 08:15:06 --> Helper loaded: form_helper
INFO - 2018-10-09 08:15:06 --> Database Driver Class Initialized
INFO - 2018-10-09 08:15:06 --> Database Driver Class Initialized
INFO - 2018-10-09 08:15:06 --> Email Class Initialized
INFO - 2018-10-09 08:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:15:06 --> Form Validation Class Initialized
INFO - 2018-10-09 08:15:07 --> Controller Class Initialized
INFO - 2018-10-09 08:15:07 --> Email Class Initialized
INFO - 2018-10-09 08:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2018-10-09 08:15:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:15:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:15:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:15:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:15:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:15:08 --> Final output sent to browser
DEBUG - 2018-10-09 08:15:08 --> Total execution time: 6.9576
INFO - 2018-10-09 08:15:08 --> Form Validation Class Initialized
INFO - 2018-10-09 08:15:08 --> Controller Class Initialized
DEBUG - 2018-10-09 08:15:09 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:15:09 --> Model Class Initialized
DEBUG - 2018-10-09 08:15:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:15:09 --> Model Class Initialized
INFO - 2018-10-09 08:15:09 --> Final output sent to browser
DEBUG - 2018-10-09 08:15:09 --> Total execution time: 8.4476
INFO - 2018-10-09 08:15:58 --> Config Class Initialized
INFO - 2018-10-09 08:15:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:15:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:15:58 --> Utf8 Class Initialized
INFO - 2018-10-09 08:15:58 --> URI Class Initialized
DEBUG - 2018-10-09 08:15:58 --> No URI present. Default controller set.
INFO - 2018-10-09 08:15:59 --> Router Class Initialized
INFO - 2018-10-09 08:15:59 --> Output Class Initialized
INFO - 2018-10-09 08:15:59 --> Security Class Initialized
DEBUG - 2018-10-09 08:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:15:59 --> Input Class Initialized
INFO - 2018-10-09 08:15:59 --> Language Class Initialized
INFO - 2018-10-09 08:16:00 --> Language Class Initialized
INFO - 2018-10-09 08:16:00 --> Config Class Initialized
INFO - 2018-10-09 08:16:00 --> Loader Class Initialized
INFO - 2018-10-09 08:16:00 --> Helper loaded: url_helper
INFO - 2018-10-09 08:16:00 --> Helper loaded: form_helper
INFO - 2018-10-09 08:16:00 --> Database Driver Class Initialized
INFO - 2018-10-09 08:16:00 --> Email Class Initialized
INFO - 2018-10-09 08:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:16:01 --> Form Validation Class Initialized
INFO - 2018-10-09 08:16:01 --> Controller Class Initialized
DEBUG - 2018-10-09 08:16:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:16:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:16:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:16:02 --> Final output sent to browser
DEBUG - 2018-10-09 08:16:02 --> Total execution time: 4.1251
INFO - 2018-10-09 08:16:10 --> Config Class Initialized
INFO - 2018-10-09 08:16:10 --> Hooks Class Initialized
INFO - 2018-10-09 08:16:10 --> Config Class Initialized
INFO - 2018-10-09 08:16:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:16:10 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:16:11 --> Utf8 Class Initialized
INFO - 2018-10-09 08:16:11 --> URI Class Initialized
DEBUG - 2018-10-09 08:16:11 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:16:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:16:11 --> Router Class Initialized
INFO - 2018-10-09 08:16:11 --> Output Class Initialized
INFO - 2018-10-09 08:16:12 --> Security Class Initialized
INFO - 2018-10-09 08:16:12 --> Utf8 Class Initialized
DEBUG - 2018-10-09 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:16:12 --> URI Class Initialized
INFO - 2018-10-09 08:16:12 --> Input Class Initialized
INFO - 2018-10-09 08:16:12 --> Router Class Initialized
INFO - 2018-10-09 08:16:12 --> Language Class Initialized
INFO - 2018-10-09 08:16:13 --> Output Class Initialized
INFO - 2018-10-09 08:16:13 --> Language Class Initialized
INFO - 2018-10-09 08:16:13 --> Security Class Initialized
DEBUG - 2018-10-09 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:16:13 --> Input Class Initialized
INFO - 2018-10-09 08:16:13 --> Language Class Initialized
INFO - 2018-10-09 08:16:14 --> Language Class Initialized
INFO - 2018-10-09 08:16:14 --> Config Class Initialized
INFO - 2018-10-09 08:16:14 --> Loader Class Initialized
INFO - 2018-10-09 08:16:14 --> Helper loaded: url_helper
INFO - 2018-10-09 08:16:14 --> Helper loaded: form_helper
INFO - 2018-10-09 08:16:14 --> Config Class Initialized
INFO - 2018-10-09 08:16:14 --> Loader Class Initialized
INFO - 2018-10-09 08:16:15 --> Helper loaded: url_helper
INFO - 2018-10-09 08:16:15 --> Database Driver Class Initialized
INFO - 2018-10-09 08:16:15 --> Helper loaded: form_helper
INFO - 2018-10-09 08:16:15 --> Database Driver Class Initialized
INFO - 2018-10-09 08:16:15 --> Email Class Initialized
INFO - 2018-10-09 08:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:16:15 --> Form Validation Class Initialized
INFO - 2018-10-09 08:16:16 --> Controller Class Initialized
DEBUG - 2018-10-09 08:16:16 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:16:16 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:16:16 --> Model Class Initialized
INFO - 2018-10-09 08:16:16 --> Final output sent to browser
DEBUG - 2018-10-09 08:16:16 --> Total execution time: 6.7026
INFO - 2018-10-09 08:16:17 --> Email Class Initialized
INFO - 2018-10-09 08:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:16:17 --> Form Validation Class Initialized
INFO - 2018-10-09 08:16:17 --> Controller Class Initialized
DEBUG - 2018-10-09 08:16:17 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:16:17 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:16:18 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:16:18 --> Final output sent to browser
DEBUG - 2018-10-09 08:16:18 --> Total execution time: 8.3251
INFO - 2018-10-09 08:16:34 --> Config Class Initialized
INFO - 2018-10-09 08:16:34 --> Hooks Class Initialized
INFO - 2018-10-09 08:16:34 --> Config Class Initialized
INFO - 2018-10-09 08:16:34 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:16:34 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:16:34 --> Utf8 Class Initialized
INFO - 2018-10-09 08:16:34 --> URI Class Initialized
INFO - 2018-10-09 08:16:35 --> Router Class Initialized
INFO - 2018-10-09 08:16:35 --> Output Class Initialized
INFO - 2018-10-09 08:16:35 --> Security Class Initialized
INFO - 2018-10-09 08:16:35 --> Utf8 Class Initialized
DEBUG - 2018-10-09 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:16:35 --> URI Class Initialized
INFO - 2018-10-09 08:16:36 --> Input Class Initialized
DEBUG - 2018-10-09 08:16:36 --> No URI present. Default controller set.
INFO - 2018-10-09 08:16:36 --> Language Class Initialized
INFO - 2018-10-09 08:16:36 --> Language Class Initialized
INFO - 2018-10-09 08:16:36 --> Router Class Initialized
INFO - 2018-10-09 08:16:36 --> Output Class Initialized
INFO - 2018-10-09 08:16:37 --> Security Class Initialized
INFO - 2018-10-09 08:16:37 --> Config Class Initialized
INFO - 2018-10-09 08:16:37 --> Loader Class Initialized
DEBUG - 2018-10-09 08:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:16:37 --> Input Class Initialized
INFO - 2018-10-09 08:16:37 --> Language Class Initialized
INFO - 2018-10-09 08:16:38 --> Language Class Initialized
INFO - 2018-10-09 08:16:38 --> Config Class Initialized
INFO - 2018-10-09 08:16:38 --> Helper loaded: url_helper
INFO - 2018-10-09 08:16:38 --> Helper loaded: form_helper
INFO - 2018-10-09 08:16:38 --> Database Driver Class Initialized
INFO - 2018-10-09 08:16:38 --> Email Class Initialized
INFO - 2018-10-09 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:16:39 --> Form Validation Class Initialized
INFO - 2018-10-09 08:16:39 --> Loader Class Initialized
INFO - 2018-10-09 08:16:39 --> Helper loaded: url_helper
INFO - 2018-10-09 08:16:39 --> Controller Class Initialized
DEBUG - 2018-10-09 08:16:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:16:39 --> Model Class Initialized
INFO - 2018-10-09 08:16:39 --> Helper loaded: form_helper
DEBUG - 2018-10-09 08:16:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:16:40 --> Database Driver Class Initialized
INFO - 2018-10-09 08:16:40 --> Model Class Initialized
INFO - 2018-10-09 08:16:40 --> Email Class Initialized
INFO - 2018-10-09 08:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:16:40 --> Form Validation Class Initialized
INFO - 2018-10-09 08:16:41 --> Controller Class Initialized
INFO - 2018-10-09 08:16:41 --> Final output sent to browser
DEBUG - 2018-10-09 08:16:41 --> Total execution time: 7.3351
DEBUG - 2018-10-09 08:16:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:16:41 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:16:42 --> Model Class Initialized
DEBUG - 2018-10-09 08:16:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:16:42 --> Final output sent to browser
DEBUG - 2018-10-09 08:16:42 --> Total execution time: 8.4401
INFO - 2018-10-09 08:16:50 --> Config Class Initialized
INFO - 2018-10-09 08:16:50 --> Hooks Class Initialized
INFO - 2018-10-09 08:16:54 --> Config Class Initialized
INFO - 2018-10-09 08:16:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:16:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:16:58 --> Utf8 Class Initialized
DEBUG - 2018-10-09 08:16:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:16:59 --> URI Class Initialized
DEBUG - 2018-10-09 08:16:59 --> No URI present. Default controller set.
INFO - 2018-10-09 08:16:59 --> Utf8 Class Initialized
INFO - 2018-10-09 08:16:59 --> Router Class Initialized
INFO - 2018-10-09 08:17:00 --> Output Class Initialized
INFO - 2018-10-09 08:17:00 --> Security Class Initialized
INFO - 2018-10-09 08:17:00 --> URI Class Initialized
DEBUG - 2018-10-09 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:17:00 --> Input Class Initialized
INFO - 2018-10-09 08:17:01 --> Language Class Initialized
DEBUG - 2018-10-09 08:17:01 --> No URI present. Default controller set.
INFO - 2018-10-09 08:17:01 --> Language Class Initialized
INFO - 2018-10-09 08:17:01 --> Router Class Initialized
INFO - 2018-10-09 08:17:01 --> Output Class Initialized
INFO - 2018-10-09 08:17:02 --> Security Class Initialized
INFO - 2018-10-09 08:17:02 --> Config Class Initialized
DEBUG - 2018-10-09 08:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:17:02 --> Input Class Initialized
INFO - 2018-10-09 08:17:02 --> Language Class Initialized
INFO - 2018-10-09 08:17:03 --> Language Class Initialized
INFO - 2018-10-09 08:17:03 --> Config Class Initialized
INFO - 2018-10-09 08:17:03 --> Loader Class Initialized
INFO - 2018-10-09 08:17:03 --> Loader Class Initialized
INFO - 2018-10-09 08:17:03 --> Helper loaded: url_helper
INFO - 2018-10-09 08:17:04 --> Helper loaded: form_helper
INFO - 2018-10-09 08:17:04 --> Database Driver Class Initialized
INFO - 2018-10-09 08:17:04 --> Helper loaded: url_helper
INFO - 2018-10-09 08:17:04 --> Helper loaded: form_helper
INFO - 2018-10-09 08:17:04 --> Database Driver Class Initialized
INFO - 2018-10-09 08:17:05 --> Email Class Initialized
INFO - 2018-10-09 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:17:05 --> Form Validation Class Initialized
INFO - 2018-10-09 08:17:05 --> Email Class Initialized
INFO - 2018-10-09 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:17:06 --> Form Validation Class Initialized
INFO - 2018-10-09 08:17:06 --> Controller Class Initialized
DEBUG - 2018-10-09 08:17:06 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:17:06 --> Model Class Initialized
INFO - 2018-10-09 08:17:06 --> Controller Class Initialized
DEBUG - 2018-10-09 08:17:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
DEBUG - 2018-10-09 08:17:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:17:07 --> Model Class Initialized
INFO - 2018-10-09 08:17:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:17:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:17:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:17:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:17:08 --> Final output sent to browser
DEBUG - 2018-10-09 08:17:08 --> Total execution time: 13.8902
DEBUG - 2018-10-09 08:17:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:17:10 --> Final output sent to browser
DEBUG - 2018-10-09 08:17:10 --> Total execution time: 19.8503
INFO - 2018-10-09 08:18:51 --> Config Class Initialized
INFO - 2018-10-09 08:18:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:18:51 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:18:52 --> Utf8 Class Initialized
INFO - 2018-10-09 08:18:52 --> URI Class Initialized
DEBUG - 2018-10-09 08:18:52 --> No URI present. Default controller set.
INFO - 2018-10-09 08:18:53 --> Router Class Initialized
INFO - 2018-10-09 08:18:53 --> Output Class Initialized
INFO - 2018-10-09 08:18:53 --> Security Class Initialized
DEBUG - 2018-10-09 08:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:18:54 --> Input Class Initialized
INFO - 2018-10-09 08:18:54 --> Language Class Initialized
INFO - 2018-10-09 08:18:55 --> Language Class Initialized
INFO - 2018-10-09 08:18:55 --> Config Class Initialized
INFO - 2018-10-09 08:18:55 --> Loader Class Initialized
INFO - 2018-10-09 08:18:55 --> Config Class Initialized
INFO - 2018-10-09 08:18:55 --> Helper loaded: url_helper
INFO - 2018-10-09 08:18:56 --> Helper loaded: form_helper
INFO - 2018-10-09 08:18:56 --> Database Driver Class Initialized
INFO - 2018-10-09 08:18:56 --> Email Class Initialized
INFO - 2018-10-09 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:18:56 --> Hooks Class Initialized
INFO - 2018-10-09 08:18:57 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:18:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:18:57 --> Utf8 Class Initialized
INFO - 2018-10-09 08:18:57 --> URI Class Initialized
DEBUG - 2018-10-09 08:18:57 --> No URI present. Default controller set.
INFO - 2018-10-09 08:18:58 --> Router Class Initialized
INFO - 2018-10-09 08:18:58 --> Controller Class Initialized
INFO - 2018-10-09 08:18:58 --> Output Class Initialized
INFO - 2018-10-09 08:18:58 --> Security Class Initialized
DEBUG - 2018-10-09 08:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:18:59 --> Input Class Initialized
DEBUG - 2018-10-09 08:18:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:18:59 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:19:00 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:19:00 --> Final output sent to browser
INFO - 2018-10-09 08:19:00 --> Language Class Initialized
INFO - 2018-10-09 08:19:01 --> Language Class Initialized
INFO - 2018-10-09 08:19:01 --> Config Class Initialized
INFO - 2018-10-09 08:19:01 --> Loader Class Initialized
INFO - 2018-10-09 08:19:01 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:19:02 --> Total execution time: 9.2255
INFO - 2018-10-09 08:19:02 --> Helper loaded: form_helper
INFO - 2018-10-09 08:19:02 --> Database Driver Class Initialized
INFO - 2018-10-09 08:19:02 --> Email Class Initialized
INFO - 2018-10-09 08:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:19:03 --> Form Validation Class Initialized
INFO - 2018-10-09 08:19:03 --> Controller Class Initialized
DEBUG - 2018-10-09 08:19:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:19:04 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:19:04 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:19:05 --> Final output sent to browser
DEBUG - 2018-10-09 08:19:06 --> Total execution time: 9.2005
INFO - 2018-10-09 08:19:17 --> Config Class Initialized
INFO - 2018-10-09 08:19:17 --> Hooks Class Initialized
INFO - 2018-10-09 08:19:17 --> Config Class Initialized
INFO - 2018-10-09 08:19:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:19:17 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:19:18 --> Utf8 Class Initialized
INFO - 2018-10-09 08:19:18 --> URI Class Initialized
INFO - 2018-10-09 08:19:18 --> Router Class Initialized
INFO - 2018-10-09 08:19:18 --> Output Class Initialized
DEBUG - 2018-10-09 08:19:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:19:19 --> Security Class Initialized
INFO - 2018-10-09 08:19:19 --> Utf8 Class Initialized
INFO - 2018-10-09 08:19:19 --> URI Class Initialized
DEBUG - 2018-10-09 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:19:19 --> Input Class Initialized
INFO - 2018-10-09 08:19:19 --> Language Class Initialized
INFO - 2018-10-09 08:19:20 --> Language Class Initialized
INFO - 2018-10-09 08:19:20 --> Config Class Initialized
DEBUG - 2018-10-09 08:19:20 --> No URI present. Default controller set.
INFO - 2018-10-09 08:19:20 --> Router Class Initialized
INFO - 2018-10-09 08:19:20 --> Output Class Initialized
INFO - 2018-10-09 08:19:20 --> Security Class Initialized
INFO - 2018-10-09 08:19:21 --> Loader Class Initialized
INFO - 2018-10-09 08:19:21 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:19:21 --> Input Class Initialized
INFO - 2018-10-09 08:19:21 --> Helper loaded: form_helper
INFO - 2018-10-09 08:19:21 --> Database Driver Class Initialized
INFO - 2018-10-09 08:19:22 --> Email Class Initialized
INFO - 2018-10-09 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:19:22 --> Language Class Initialized
INFO - 2018-10-09 08:19:22 --> Language Class Initialized
INFO - 2018-10-09 08:19:22 --> Form Validation Class Initialized
INFO - 2018-10-09 08:19:22 --> Controller Class Initialized
INFO - 2018-10-09 08:19:22 --> Config Class Initialized
INFO - 2018-10-09 08:19:23 --> Loader Class Initialized
INFO - 2018-10-09 08:19:23 --> Helper loaded: url_helper
INFO - 2018-10-09 08:19:23 --> Helper loaded: form_helper
DEBUG - 2018-10-09 08:19:23 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:19:23 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:19:24 --> Model Class Initialized
INFO - 2018-10-09 08:19:24 --> Final output sent to browser
DEBUG - 2018-10-09 08:19:24 --> Total execution time: 7.3754
INFO - 2018-10-09 08:19:24 --> Database Driver Class Initialized
INFO - 2018-10-09 08:19:25 --> Email Class Initialized
INFO - 2018-10-09 08:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:19:25 --> Form Validation Class Initialized
INFO - 2018-10-09 08:19:25 --> Controller Class Initialized
DEBUG - 2018-10-09 08:19:25 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:19:25 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:19:26 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:19:26 --> Final output sent to browser
DEBUG - 2018-10-09 08:19:26 --> Total execution time: 9.3015
INFO - 2018-10-09 08:19:37 --> Config Class Initialized
INFO - 2018-10-09 08:19:37 --> Config Class Initialized
INFO - 2018-10-09 08:19:37 --> Hooks Class Initialized
INFO - 2018-10-09 08:19:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:19:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:19:37 --> Utf8 Class Initialized
INFO - 2018-10-09 08:19:38 --> URI Class Initialized
INFO - 2018-10-09 08:19:38 --> Router Class Initialized
DEBUG - 2018-10-09 08:19:38 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:19:38 --> Utf8 Class Initialized
INFO - 2018-10-09 08:19:38 --> URI Class Initialized
DEBUG - 2018-10-09 08:19:39 --> No URI present. Default controller set.
INFO - 2018-10-09 08:19:39 --> Router Class Initialized
INFO - 2018-10-09 08:19:39 --> Output Class Initialized
INFO - 2018-10-09 08:19:39 --> Security Class Initialized
DEBUG - 2018-10-09 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:19:39 --> Output Class Initialized
INFO - 2018-10-09 08:19:40 --> Security Class Initialized
INFO - 2018-10-09 08:19:40 --> Input Class Initialized
INFO - 2018-10-09 08:19:40 --> Language Class Initialized
DEBUG - 2018-10-09 08:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:19:40 --> Input Class Initialized
INFO - 2018-10-09 08:19:40 --> Language Class Initialized
INFO - 2018-10-09 08:19:41 --> Config Class Initialized
INFO - 2018-10-09 08:19:41 --> Language Class Initialized
INFO - 2018-10-09 08:19:41 --> Loader Class Initialized
INFO - 2018-10-09 08:19:41 --> Helper loaded: url_helper
INFO - 2018-10-09 08:19:41 --> Language Class Initialized
INFO - 2018-10-09 08:19:41 --> Helper loaded: form_helper
INFO - 2018-10-09 08:19:42 --> Database Driver Class Initialized
INFO - 2018-10-09 08:19:42 --> Email Class Initialized
INFO - 2018-10-09 08:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:19:42 --> Form Validation Class Initialized
INFO - 2018-10-09 08:19:42 --> Controller Class Initialized
DEBUG - 2018-10-09 08:19:42 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:19:43 --> Config Class Initialized
INFO - 2018-10-09 08:19:43 --> Loader Class Initialized
INFO - 2018-10-09 08:19:43 --> Helper loaded: url_helper
INFO - 2018-10-09 08:19:43 --> Helper loaded: form_helper
INFO - 2018-10-09 08:19:43 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:19:44 --> Model Class Initialized
INFO - 2018-10-09 08:19:44 --> Final output sent to browser
DEBUG - 2018-10-09 08:19:44 --> Total execution time: 7.2854
INFO - 2018-10-09 08:19:44 --> Database Driver Class Initialized
INFO - 2018-10-09 08:19:45 --> Email Class Initialized
INFO - 2018-10-09 08:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:19:45 --> Form Validation Class Initialized
INFO - 2018-10-09 08:19:45 --> Controller Class Initialized
DEBUG - 2018-10-09 08:19:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:19:45 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:19:46 --> Model Class Initialized
DEBUG - 2018-10-09 08:19:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:19:46 --> Final output sent to browser
DEBUG - 2018-10-09 08:19:46 --> Total execution time: 9.3805
INFO - 2018-10-09 08:20:18 --> Config Class Initialized
INFO - 2018-10-09 08:20:18 --> Hooks Class Initialized
INFO - 2018-10-09 08:20:18 --> Config Class Initialized
INFO - 2018-10-09 08:20:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:20:18 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:20:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:20:19 --> Utf8 Class Initialized
INFO - 2018-10-09 08:20:19 --> URI Class Initialized
DEBUG - 2018-10-09 08:20:19 --> No URI present. Default controller set.
INFO - 2018-10-09 08:20:19 --> Router Class Initialized
INFO - 2018-10-09 08:20:19 --> Utf8 Class Initialized
INFO - 2018-10-09 08:20:20 --> Output Class Initialized
INFO - 2018-10-09 08:20:20 --> URI Class Initialized
INFO - 2018-10-09 08:20:21 --> Router Class Initialized
INFO - 2018-10-09 08:20:21 --> Output Class Initialized
INFO - 2018-10-09 08:20:21 --> Security Class Initialized
INFO - 2018-10-09 08:20:21 --> Security Class Initialized
DEBUG - 2018-10-09 08:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:20:22 --> Input Class Initialized
INFO - 2018-10-09 08:20:22 --> Language Class Initialized
INFO - 2018-10-09 08:20:22 --> Language Class Initialized
INFO - 2018-10-09 08:20:23 --> Config Class Initialized
INFO - 2018-10-09 08:20:23 --> Loader Class Initialized
INFO - 2018-10-09 08:20:23 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:20:24 --> Helper loaded: form_helper
INFO - 2018-10-09 08:20:24 --> Input Class Initialized
INFO - 2018-10-09 08:20:24 --> Language Class Initialized
INFO - 2018-10-09 08:20:25 --> Database Driver Class Initialized
INFO - 2018-10-09 08:20:25 --> Email Class Initialized
INFO - 2018-10-09 08:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:20:26 --> Language Class Initialized
INFO - 2018-10-09 08:20:26 --> Config Class Initialized
INFO - 2018-10-09 08:20:26 --> Form Validation Class Initialized
INFO - 2018-10-09 08:20:26 --> Controller Class Initialized
DEBUG - 2018-10-09 08:20:26 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:20:27 --> Model Class Initialized
DEBUG - 2018-10-09 08:20:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:20:27 --> Model Class Initialized
DEBUG - 2018-10-09 08:20:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:20:27 --> Final output sent to browser
DEBUG - 2018-10-09 08:20:28 --> Total execution time: 9.3225
INFO - 2018-10-09 08:20:28 --> Loader Class Initialized
INFO - 2018-10-09 08:20:28 --> Helper loaded: url_helper
INFO - 2018-10-09 08:20:28 --> Helper loaded: form_helper
INFO - 2018-10-09 08:20:29 --> Database Driver Class Initialized
INFO - 2018-10-09 08:20:29 --> Email Class Initialized
INFO - 2018-10-09 08:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:20:29 --> Form Validation Class Initialized
INFO - 2018-10-09 08:20:29 --> Controller Class Initialized
DEBUG - 2018-10-09 08:20:29 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:20:30 --> Model Class Initialized
DEBUG - 2018-10-09 08:20:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:20:30 --> Model Class Initialized
INFO - 2018-10-09 08:20:31 --> Final output sent to browser
DEBUG - 2018-10-09 08:20:31 --> Total execution time: 13.1638
INFO - 2018-10-09 08:27:49 --> Config Class Initialized
INFO - 2018-10-09 08:27:49 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:27:50 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:27:50 --> Utf8 Class Initialized
INFO - 2018-10-09 08:27:50 --> URI Class Initialized
DEBUG - 2018-10-09 08:27:50 --> No URI present. Default controller set.
INFO - 2018-10-09 08:27:50 --> Router Class Initialized
INFO - 2018-10-09 08:27:50 --> Output Class Initialized
INFO - 2018-10-09 08:27:51 --> Security Class Initialized
DEBUG - 2018-10-09 08:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:27:51 --> Input Class Initialized
INFO - 2018-10-09 08:27:51 --> Language Class Initialized
INFO - 2018-10-09 08:27:51 --> Language Class Initialized
INFO - 2018-10-09 08:27:51 --> Config Class Initialized
INFO - 2018-10-09 08:27:52 --> Loader Class Initialized
INFO - 2018-10-09 08:27:52 --> Helper loaded: url_helper
INFO - 2018-10-09 08:27:52 --> Helper loaded: form_helper
INFO - 2018-10-09 08:27:52 --> Database Driver Class Initialized
INFO - 2018-10-09 08:27:52 --> Email Class Initialized
INFO - 2018-10-09 08:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:27:53 --> Form Validation Class Initialized
INFO - 2018-10-09 08:27:53 --> Controller Class Initialized
DEBUG - 2018-10-09 08:27:53 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:27:53 --> Model Class Initialized
DEBUG - 2018-10-09 08:27:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:27:54 --> Model Class Initialized
DEBUG - 2018-10-09 08:27:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:27:54 --> Final output sent to browser
DEBUG - 2018-10-09 08:27:55 --> Total execution time: 5.0923
INFO - 2018-10-09 08:28:14 --> Config Class Initialized
INFO - 2018-10-09 08:28:14 --> Hooks Class Initialized
INFO - 2018-10-09 08:28:14 --> Config Class Initialized
DEBUG - 2018-10-09 08:28:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:28:15 --> Utf8 Class Initialized
INFO - 2018-10-09 08:28:15 --> Hooks Class Initialized
INFO - 2018-10-09 08:28:15 --> URI Class Initialized
DEBUG - 2018-10-09 08:28:15 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:28:16 --> No URI present. Default controller set.
INFO - 2018-10-09 08:28:16 --> Utf8 Class Initialized
INFO - 2018-10-09 08:28:16 --> URI Class Initialized
DEBUG - 2018-10-09 08:28:16 --> No URI present. Default controller set.
INFO - 2018-10-09 08:28:17 --> Router Class Initialized
INFO - 2018-10-09 08:28:17 --> Output Class Initialized
INFO - 2018-10-09 08:28:17 --> Router Class Initialized
INFO - 2018-10-09 08:28:17 --> Output Class Initialized
INFO - 2018-10-09 08:28:17 --> Security Class Initialized
INFO - 2018-10-09 08:28:18 --> Security Class Initialized
DEBUG - 2018-10-09 08:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-09 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:28:18 --> Input Class Initialized
INFO - 2018-10-09 08:28:18 --> Language Class Initialized
INFO - 2018-10-09 08:28:18 --> Language Class Initialized
INFO - 2018-10-09 08:28:19 --> Input Class Initialized
INFO - 2018-10-09 08:28:19 --> Language Class Initialized
INFO - 2018-10-09 08:28:19 --> Config Class Initialized
INFO - 2018-10-09 08:28:19 --> Loader Class Initialized
INFO - 2018-10-09 08:28:19 --> Language Class Initialized
INFO - 2018-10-09 08:28:19 --> Config Class Initialized
INFO - 2018-10-09 08:28:20 --> Loader Class Initialized
INFO - 2018-10-09 08:28:20 --> Helper loaded: url_helper
INFO - 2018-10-09 08:28:20 --> Helper loaded: url_helper
INFO - 2018-10-09 08:28:20 --> Helper loaded: form_helper
INFO - 2018-10-09 08:28:20 --> Helper loaded: form_helper
INFO - 2018-10-09 08:28:20 --> Database Driver Class Initialized
INFO - 2018-10-09 08:28:21 --> Email Class Initialized
INFO - 2018-10-09 08:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:28:21 --> Database Driver Class Initialized
INFO - 2018-10-09 08:28:21 --> Form Validation Class Initialized
INFO - 2018-10-09 08:28:21 --> Email Class Initialized
INFO - 2018-10-09 08:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:28:22 --> Form Validation Class Initialized
INFO - 2018-10-09 08:28:22 --> Controller Class Initialized
INFO - 2018-10-09 08:28:22 --> Controller Class Initialized
DEBUG - 2018-10-09 08:28:22 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:28:23 --> Model Class Initialized
DEBUG - 2018-10-09 08:28:23 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:28:23 --> Model Class Initialized
DEBUG - 2018-10-09 08:28:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:28:23 --> Model Class Initialized
DEBUG - 2018-10-09 08:28:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:28:24 --> Final output sent to browser
DEBUG - 2018-10-09 08:28:24 --> Total execution time: 9.2495
DEBUG - 2018-10-09 08:28:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:28:24 --> Model Class Initialized
DEBUG - 2018-10-09 08:28:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:28:25 --> Final output sent to browser
DEBUG - 2018-10-09 08:28:25 --> Total execution time: 10.7026
INFO - 2018-10-09 08:31:19 --> Config Class Initialized
INFO - 2018-10-09 08:31:19 --> Hooks Class Initialized
INFO - 2018-10-09 08:31:19 --> Config Class Initialized
DEBUG - 2018-10-09 08:31:20 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:31:20 --> Utf8 Class Initialized
INFO - 2018-10-09 08:31:20 --> URI Class Initialized
DEBUG - 2018-10-09 08:31:20 --> No URI present. Default controller set.
INFO - 2018-10-09 08:31:20 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:31:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:31:21 --> Utf8 Class Initialized
INFO - 2018-10-09 08:31:21 --> URI Class Initialized
DEBUG - 2018-10-09 08:31:21 --> No URI present. Default controller set.
INFO - 2018-10-09 08:31:21 --> Router Class Initialized
INFO - 2018-10-09 08:31:22 --> Output Class Initialized
INFO - 2018-10-09 08:31:22 --> Security Class Initialized
DEBUG - 2018-10-09 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:31:22 --> Router Class Initialized
INFO - 2018-10-09 08:31:22 --> Output Class Initialized
INFO - 2018-10-09 08:31:22 --> Security Class Initialized
DEBUG - 2018-10-09 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:31:23 --> Input Class Initialized
INFO - 2018-10-09 08:31:23 --> Language Class Initialized
INFO - 2018-10-09 08:31:23 --> Language Class Initialized
INFO - 2018-10-09 08:31:23 --> Input Class Initialized
INFO - 2018-10-09 08:31:23 --> Language Class Initialized
INFO - 2018-10-09 08:31:23 --> Config Class Initialized
INFO - 2018-10-09 08:31:24 --> Loader Class Initialized
INFO - 2018-10-09 08:31:24 --> Language Class Initialized
INFO - 2018-10-09 08:31:24 --> Config Class Initialized
INFO - 2018-10-09 08:31:24 --> Helper loaded: url_helper
INFO - 2018-10-09 08:31:24 --> Helper loaded: form_helper
INFO - 2018-10-09 08:31:24 --> Database Driver Class Initialized
INFO - 2018-10-09 08:31:25 --> Loader Class Initialized
INFO - 2018-10-09 08:31:25 --> Email Class Initialized
INFO - 2018-10-09 08:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:31:25 --> Helper loaded: url_helper
INFO - 2018-10-09 08:31:25 --> Form Validation Class Initialized
INFO - 2018-10-09 08:31:25 --> Controller Class Initialized
DEBUG - 2018-10-09 08:31:26 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:31:26 --> Model Class Initialized
DEBUG - 2018-10-09 08:31:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:31:26 --> Model Class Initialized
INFO - 2018-10-09 08:31:26 --> Helper loaded: form_helper
INFO - 2018-10-09 08:31:26 --> Database Driver Class Initialized
DEBUG - 2018-10-09 08:31:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:31:27 --> Email Class Initialized
INFO - 2018-10-09 08:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:31:27 --> Final output sent to browser
INFO - 2018-10-09 08:31:27 --> Form Validation Class Initialized
INFO - 2018-10-09 08:31:28 --> Controller Class Initialized
DEBUG - 2018-10-09 08:31:28 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:31:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:31:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:31:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:31:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:31:28 --> Final output sent to browser
DEBUG - 2018-10-09 08:31:29 --> Total execution time: 9.1055
DEBUG - 2018-10-09 08:31:29 --> Total execution time: 7.7404
INFO - 2018-10-09 08:31:48 --> Config Class Initialized
INFO - 2018-10-09 08:31:48 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:31:48 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:31:49 --> Utf8 Class Initialized
INFO - 2018-10-09 08:31:49 --> URI Class Initialized
DEBUG - 2018-10-09 08:31:49 --> No URI present. Default controller set.
INFO - 2018-10-09 08:31:49 --> Router Class Initialized
INFO - 2018-10-09 08:31:49 --> Output Class Initialized
INFO - 2018-10-09 08:31:49 --> Security Class Initialized
DEBUG - 2018-10-09 08:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:31:50 --> Input Class Initialized
INFO - 2018-10-09 08:31:50 --> Language Class Initialized
INFO - 2018-10-09 08:31:50 --> Language Class Initialized
INFO - 2018-10-09 08:31:50 --> Config Class Initialized
INFO - 2018-10-09 08:31:50 --> Loader Class Initialized
INFO - 2018-10-09 08:31:51 --> Helper loaded: url_helper
INFO - 2018-10-09 08:31:51 --> Helper loaded: form_helper
INFO - 2018-10-09 08:31:51 --> Database Driver Class Initialized
INFO - 2018-10-09 08:31:51 --> Email Class Initialized
INFO - 2018-10-09 08:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:31:52 --> Form Validation Class Initialized
INFO - 2018-10-09 08:31:52 --> Controller Class Initialized
DEBUG - 2018-10-09 08:31:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:31:52 --> Model Class Initialized
DEBUG - 2018-10-09 08:31:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:31:52 --> Model Class Initialized
DEBUG - 2018-10-09 08:31:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:31:53 --> Final output sent to browser
DEBUG - 2018-10-09 08:31:53 --> Total execution time: 4.6523
INFO - 2018-10-09 08:32:05 --> Config Class Initialized
INFO - 2018-10-09 08:32:05 --> Hooks Class Initialized
INFO - 2018-10-09 08:32:05 --> Config Class Initialized
DEBUG - 2018-10-09 08:32:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:32:06 --> Utf8 Class Initialized
INFO - 2018-10-09 08:32:06 --> URI Class Initialized
INFO - 2018-10-09 08:32:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:32:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:32:07 --> Router Class Initialized
INFO - 2018-10-09 08:32:07 --> Output Class Initialized
INFO - 2018-10-09 08:32:07 --> Security Class Initialized
INFO - 2018-10-09 08:32:08 --> Utf8 Class Initialized
INFO - 2018-10-09 08:32:08 --> URI Class Initialized
DEBUG - 2018-10-09 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:32:08 --> Input Class Initialized
DEBUG - 2018-10-09 08:32:08 --> No URI present. Default controller set.
INFO - 2018-10-09 08:32:08 --> Router Class Initialized
INFO - 2018-10-09 08:32:09 --> Language Class Initialized
INFO - 2018-10-09 08:32:09 --> Output Class Initialized
INFO - 2018-10-09 08:32:09 --> Language Class Initialized
INFO - 2018-10-09 08:32:09 --> Security Class Initialized
INFO - 2018-10-09 08:32:09 --> Config Class Initialized
DEBUG - 2018-10-09 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:32:10 --> Input Class Initialized
INFO - 2018-10-09 08:32:10 --> Loader Class Initialized
INFO - 2018-10-09 08:32:10 --> Language Class Initialized
INFO - 2018-10-09 08:32:10 --> Language Class Initialized
INFO - 2018-10-09 08:32:10 --> Helper loaded: url_helper
INFO - 2018-10-09 08:32:11 --> Config Class Initialized
INFO - 2018-10-09 08:32:11 --> Loader Class Initialized
INFO - 2018-10-09 08:32:11 --> Helper loaded: form_helper
INFO - 2018-10-09 08:32:11 --> Helper loaded: url_helper
INFO - 2018-10-09 08:32:11 --> Helper loaded: form_helper
INFO - 2018-10-09 08:32:11 --> Database Driver Class Initialized
INFO - 2018-10-09 08:32:12 --> Database Driver Class Initialized
INFO - 2018-10-09 08:32:12 --> Email Class Initialized
INFO - 2018-10-09 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:32:12 --> Form Validation Class Initialized
INFO - 2018-10-09 08:32:12 --> Email Class Initialized
INFO - 2018-10-09 08:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:32:13 --> Form Validation Class Initialized
INFO - 2018-10-09 08:32:13 --> Controller Class Initialized
INFO - 2018-10-09 08:32:13 --> Controller Class Initialized
DEBUG - 2018-10-09 08:32:13 --> Person MX_Controller Initialized
DEBUG - 2018-10-09 08:32:13 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:32:14 --> Model Class Initialized
DEBUG - 2018-10-09 08:32:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:32:14 --> Model Class Initialized
DEBUG - 2018-10-09 08:32:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:32:14 --> Final output sent to browser
DEBUG - 2018-10-09 08:32:15 --> Total execution time: 9.1705
INFO - 2018-10-09 08:32:15 --> Model Class Initialized
DEBUG - 2018-10-09 08:32:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:32:15 --> Model Class Initialized
INFO - 2018-10-09 08:32:16 --> Final output sent to browser
DEBUG - 2018-10-09 08:32:16 --> Total execution time: 10.9036
INFO - 2018-10-09 08:32:55 --> Config Class Initialized
INFO - 2018-10-09 08:32:55 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:32:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:32:56 --> Utf8 Class Initialized
INFO - 2018-10-09 08:32:57 --> URI Class Initialized
DEBUG - 2018-10-09 08:32:57 --> No URI present. Default controller set.
INFO - 2018-10-09 08:32:58 --> Router Class Initialized
INFO - 2018-10-09 08:32:58 --> Output Class Initialized
INFO - 2018-10-09 08:32:58 --> Security Class Initialized
DEBUG - 2018-10-09 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:32:59 --> Input Class Initialized
INFO - 2018-10-09 08:32:59 --> Language Class Initialized
INFO - 2018-10-09 08:32:59 --> Language Class Initialized
INFO - 2018-10-09 08:32:59 --> Config Class Initialized
INFO - 2018-10-09 08:33:00 --> Config Class Initialized
INFO - 2018-10-09 08:33:00 --> Hooks Class Initialized
INFO - 2018-10-09 08:33:00 --> Loader Class Initialized
INFO - 2018-10-09 08:33:00 --> Helper loaded: url_helper
INFO - 2018-10-09 08:33:01 --> Helper loaded: form_helper
INFO - 2018-10-09 08:33:01 --> Database Driver Class Initialized
INFO - 2018-10-09 08:33:01 --> Email Class Initialized
INFO - 2018-10-09 08:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:33:02 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:33:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:33:03 --> Utf8 Class Initialized
INFO - 2018-10-09 08:33:03 --> Controller Class Initialized
DEBUG - 2018-10-09 08:33:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:33:04 --> Model Class Initialized
DEBUG - 2018-10-09 08:33:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:33:04 --> Model Class Initialized
DEBUG - 2018-10-09 08:33:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:33:05 --> Final output sent to browser
INFO - 2018-10-09 08:33:05 --> URI Class Initialized
DEBUG - 2018-10-09 08:33:05 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:33:05 --> Total execution time: 10.1446
INFO - 2018-10-09 08:33:05 --> Router Class Initialized
INFO - 2018-10-09 08:33:06 --> Output Class Initialized
INFO - 2018-10-09 08:33:06 --> Security Class Initialized
DEBUG - 2018-10-09 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:33:07 --> Input Class Initialized
INFO - 2018-10-09 08:33:07 --> Language Class Initialized
INFO - 2018-10-09 08:33:07 --> Language Class Initialized
INFO - 2018-10-09 08:33:07 --> Config Class Initialized
INFO - 2018-10-09 08:33:07 --> Loader Class Initialized
INFO - 2018-10-09 08:33:08 --> Helper loaded: url_helper
INFO - 2018-10-09 08:33:08 --> Helper loaded: form_helper
INFO - 2018-10-09 08:33:08 --> Database Driver Class Initialized
INFO - 2018-10-09 08:33:08 --> Email Class Initialized
INFO - 2018-10-09 08:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:33:09 --> Form Validation Class Initialized
INFO - 2018-10-09 08:33:09 --> Controller Class Initialized
DEBUG - 2018-10-09 08:33:09 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:33:09 --> Model Class Initialized
DEBUG - 2018-10-09 08:33:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:33:10 --> Model Class Initialized
DEBUG - 2018-10-09 08:33:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:33:10 --> Final output sent to browser
DEBUG - 2018-10-09 08:33:11 --> Total execution time: 10.4596
INFO - 2018-10-09 08:36:23 --> Config Class Initialized
INFO - 2018-10-09 08:36:23 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:36:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:36:24 --> Utf8 Class Initialized
INFO - 2018-10-09 08:36:24 --> URI Class Initialized
DEBUG - 2018-10-09 08:36:24 --> No URI present. Default controller set.
INFO - 2018-10-09 08:36:25 --> Router Class Initialized
INFO - 2018-10-09 08:36:25 --> Output Class Initialized
INFO - 2018-10-09 08:36:25 --> Security Class Initialized
DEBUG - 2018-10-09 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:36:25 --> Input Class Initialized
INFO - 2018-10-09 08:36:25 --> Language Class Initialized
INFO - 2018-10-09 08:36:26 --> Language Class Initialized
INFO - 2018-10-09 08:36:26 --> Config Class Initialized
INFO - 2018-10-09 08:36:26 --> Loader Class Initialized
INFO - 2018-10-09 08:36:26 --> Helper loaded: url_helper
INFO - 2018-10-09 08:36:26 --> Helper loaded: form_helper
INFO - 2018-10-09 08:36:27 --> Database Driver Class Initialized
INFO - 2018-10-09 08:36:27 --> Email Class Initialized
INFO - 2018-10-09 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:36:27 --> Form Validation Class Initialized
INFO - 2018-10-09 08:36:27 --> Controller Class Initialized
DEBUG - 2018-10-09 08:36:28 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:36:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:36:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:36:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:36:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:36:28 --> Final output sent to browser
DEBUG - 2018-10-09 08:36:29 --> Total execution time: 5.0773
INFO - 2018-10-09 08:36:42 --> Config Class Initialized
INFO - 2018-10-09 08:36:42 --> Hooks Class Initialized
INFO - 2018-10-09 08:36:42 --> Config Class Initialized
INFO - 2018-10-09 08:36:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:36:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:36:43 --> Utf8 Class Initialized
INFO - 2018-10-09 08:36:43 --> URI Class Initialized
INFO - 2018-10-09 08:36:43 --> Router Class Initialized
INFO - 2018-10-09 08:36:43 --> Output Class Initialized
INFO - 2018-10-09 08:36:44 --> Security Class Initialized
DEBUG - 2018-10-09 08:36:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:36:44 --> Utf8 Class Initialized
INFO - 2018-10-09 08:36:44 --> URI Class Initialized
DEBUG - 2018-10-09 08:36:44 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:36:45 --> Input Class Initialized
INFO - 2018-10-09 08:36:45 --> Language Class Initialized
INFO - 2018-10-09 08:36:45 --> Language Class Initialized
INFO - 2018-10-09 08:36:45 --> Config Class Initialized
INFO - 2018-10-09 08:36:45 --> Loader Class Initialized
INFO - 2018-10-09 08:36:46 --> Helper loaded: url_helper
INFO - 2018-10-09 08:36:46 --> Helper loaded: form_helper
INFO - 2018-10-09 08:36:46 --> Database Driver Class Initialized
INFO - 2018-10-09 08:36:47 --> Email Class Initialized
INFO - 2018-10-09 08:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:36:47 --> Router Class Initialized
INFO - 2018-10-09 08:36:47 --> Output Class Initialized
INFO - 2018-10-09 08:36:47 --> Security Class Initialized
INFO - 2018-10-09 08:36:48 --> Form Validation Class Initialized
INFO - 2018-10-09 08:36:48 --> Controller Class Initialized
DEBUG - 2018-10-09 08:36:48 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:36:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:36:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:36:48 --> Model Class Initialized
INFO - 2018-10-09 08:36:49 --> Final output sent to browser
DEBUG - 2018-10-09 08:36:49 --> Total execution time: 6.5894
DEBUG - 2018-10-09 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:36:49 --> Input Class Initialized
INFO - 2018-10-09 08:36:49 --> Language Class Initialized
INFO - 2018-10-09 08:36:50 --> Language Class Initialized
INFO - 2018-10-09 08:36:50 --> Config Class Initialized
INFO - 2018-10-09 08:36:50 --> Loader Class Initialized
INFO - 2018-10-09 08:36:50 --> Helper loaded: url_helper
INFO - 2018-10-09 08:36:50 --> Helper loaded: form_helper
INFO - 2018-10-09 08:36:51 --> Database Driver Class Initialized
INFO - 2018-10-09 08:36:51 --> Email Class Initialized
INFO - 2018-10-09 08:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:36:51 --> Form Validation Class Initialized
INFO - 2018-10-09 08:36:51 --> Controller Class Initialized
DEBUG - 2018-10-09 08:36:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:36:52 --> Model Class Initialized
DEBUG - 2018-10-09 08:36:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:36:52 --> Model Class Initialized
DEBUG - 2018-10-09 08:36:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:36:53 --> Final output sent to browser
DEBUG - 2018-10-09 08:36:53 --> Total execution time: 10.4706
INFO - 2018-10-09 08:37:02 --> Config Class Initialized
INFO - 2018-10-09 08:37:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:37:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:37:02 --> Utf8 Class Initialized
INFO - 2018-10-09 08:37:02 --> URI Class Initialized
DEBUG - 2018-10-09 08:37:03 --> No URI present. Default controller set.
INFO - 2018-10-09 08:37:03 --> Router Class Initialized
INFO - 2018-10-09 08:37:03 --> Output Class Initialized
INFO - 2018-10-09 08:37:03 --> Security Class Initialized
DEBUG - 2018-10-09 08:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:37:04 --> Input Class Initialized
INFO - 2018-10-09 08:37:04 --> Language Class Initialized
INFO - 2018-10-09 08:37:04 --> Language Class Initialized
INFO - 2018-10-09 08:37:05 --> Config Class Initialized
INFO - 2018-10-09 08:37:05 --> Loader Class Initialized
INFO - 2018-10-09 08:37:06 --> Helper loaded: url_helper
INFO - 2018-10-09 08:37:06 --> Helper loaded: form_helper
INFO - 2018-10-09 08:37:07 --> Database Driver Class Initialized
INFO - 2018-10-09 08:37:07 --> Email Class Initialized
INFO - 2018-10-09 08:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:37:07 --> Form Validation Class Initialized
INFO - 2018-10-09 08:37:08 --> Controller Class Initialized
DEBUG - 2018-10-09 08:37:08 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:37:08 --> Model Class Initialized
DEBUG - 2018-10-09 08:37:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:37:09 --> Model Class Initialized
DEBUG - 2018-10-09 08:37:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:37:09 --> Final output sent to browser
DEBUG - 2018-10-09 08:37:10 --> Total execution time: 7.9195
INFO - 2018-10-09 08:37:32 --> Config Class Initialized
INFO - 2018-10-09 08:37:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:37:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:37:33 --> Utf8 Class Initialized
INFO - 2018-10-09 08:37:34 --> URI Class Initialized
DEBUG - 2018-10-09 08:37:34 --> No URI present. Default controller set.
INFO - 2018-10-09 08:37:34 --> Router Class Initialized
INFO - 2018-10-09 08:37:35 --> Output Class Initialized
INFO - 2018-10-09 08:37:35 --> Security Class Initialized
DEBUG - 2018-10-09 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:37:35 --> Input Class Initialized
INFO - 2018-10-09 08:37:36 --> Language Class Initialized
INFO - 2018-10-09 08:37:36 --> Language Class Initialized
INFO - 2018-10-09 08:37:36 --> Config Class Initialized
INFO - 2018-10-09 08:37:37 --> Loader Class Initialized
INFO - 2018-10-09 08:37:37 --> Helper loaded: url_helper
INFO - 2018-10-09 08:37:37 --> Helper loaded: form_helper
INFO - 2018-10-09 08:37:38 --> Database Driver Class Initialized
INFO - 2018-10-09 08:37:39 --> Email Class Initialized
INFO - 2018-10-09 08:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:37:39 --> Form Validation Class Initialized
INFO - 2018-10-09 08:37:40 --> Controller Class Initialized
DEBUG - 2018-10-09 08:37:40 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:37:40 --> Model Class Initialized
DEBUG - 2018-10-09 08:37:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:37:40 --> Model Class Initialized
DEBUG - 2018-10-09 08:37:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:37:41 --> Final output sent to browser
DEBUG - 2018-10-09 08:37:41 --> Total execution time: 9.0725
INFO - 2018-10-09 08:39:39 --> Config Class Initialized
INFO - 2018-10-09 08:39:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:39:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:39:39 --> Utf8 Class Initialized
INFO - 2018-10-09 08:39:40 --> URI Class Initialized
DEBUG - 2018-10-09 08:39:40 --> No URI present. Default controller set.
INFO - 2018-10-09 08:39:40 --> Router Class Initialized
INFO - 2018-10-09 08:39:40 --> Output Class Initialized
INFO - 2018-10-09 08:39:40 --> Security Class Initialized
DEBUG - 2018-10-09 08:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:39:41 --> Input Class Initialized
INFO - 2018-10-09 08:39:41 --> Language Class Initialized
INFO - 2018-10-09 08:39:41 --> Language Class Initialized
INFO - 2018-10-09 08:39:41 --> Config Class Initialized
INFO - 2018-10-09 08:39:42 --> Loader Class Initialized
INFO - 2018-10-09 08:39:42 --> Helper loaded: url_helper
INFO - 2018-10-09 08:39:42 --> Helper loaded: form_helper
INFO - 2018-10-09 08:39:42 --> Database Driver Class Initialized
INFO - 2018-10-09 08:39:42 --> Email Class Initialized
INFO - 2018-10-09 08:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:39:43 --> Form Validation Class Initialized
INFO - 2018-10-09 08:39:43 --> Controller Class Initialized
DEBUG - 2018-10-09 08:39:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:39:43 --> Model Class Initialized
DEBUG - 2018-10-09 08:39:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:39:43 --> Model Class Initialized
DEBUG - 2018-10-09 08:39:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:39:44 --> Final output sent to browser
DEBUG - 2018-10-09 08:39:44 --> Total execution time: 4.9773
INFO - 2018-10-09 08:39:56 --> Config Class Initialized
INFO - 2018-10-09 08:39:56 --> Hooks Class Initialized
INFO - 2018-10-09 08:39:56 --> Config Class Initialized
INFO - 2018-10-09 08:39:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:39:57 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:39:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:39:57 --> Utf8 Class Initialized
INFO - 2018-10-09 08:39:58 --> Utf8 Class Initialized
INFO - 2018-10-09 08:39:58 --> URI Class Initialized
DEBUG - 2018-10-09 08:39:58 --> No URI present. Default controller set.
INFO - 2018-10-09 08:39:58 --> URI Class Initialized
INFO - 2018-10-09 08:39:58 --> Router Class Initialized
INFO - 2018-10-09 08:39:59 --> Router Class Initialized
INFO - 2018-10-09 08:39:59 --> Output Class Initialized
INFO - 2018-10-09 08:39:59 --> Security Class Initialized
INFO - 2018-10-09 08:39:59 --> Output Class Initialized
INFO - 2018-10-09 08:39:59 --> Security Class Initialized
DEBUG - 2018-10-09 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:40:00 --> Input Class Initialized
INFO - 2018-10-09 08:40:00 --> Language Class Initialized
DEBUG - 2018-10-09 08:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:40:00 --> Input Class Initialized
INFO - 2018-10-09 08:40:00 --> Language Class Initialized
INFO - 2018-10-09 08:40:00 --> Language Class Initialized
INFO - 2018-10-09 08:40:01 --> Language Class Initialized
INFO - 2018-10-09 08:40:01 --> Config Class Initialized
INFO - 2018-10-09 08:40:01 --> Loader Class Initialized
INFO - 2018-10-09 08:40:01 --> Helper loaded: url_helper
INFO - 2018-10-09 08:40:01 --> Helper loaded: form_helper
INFO - 2018-10-09 08:40:02 --> Database Driver Class Initialized
INFO - 2018-10-09 08:40:02 --> Email Class Initialized
INFO - 2018-10-09 08:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:40:02 --> Form Validation Class Initialized
INFO - 2018-10-09 08:40:02 --> Controller Class Initialized
DEBUG - 2018-10-09 08:40:02 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:40:03 --> Model Class Initialized
DEBUG - 2018-10-09 08:40:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:40:03 --> Model Class Initialized
DEBUG - 2018-10-09 08:40:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:40:03 --> Final output sent to browser
DEBUG - 2018-10-09 08:40:04 --> Total execution time: 6.9464
INFO - 2018-10-09 08:40:04 --> Config Class Initialized
INFO - 2018-10-09 08:40:04 --> Loader Class Initialized
INFO - 2018-10-09 08:40:04 --> Helper loaded: url_helper
INFO - 2018-10-09 08:40:05 --> Helper loaded: form_helper
INFO - 2018-10-09 08:40:05 --> Database Driver Class Initialized
INFO - 2018-10-09 08:40:05 --> Email Class Initialized
INFO - 2018-10-09 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:40:05 --> Form Validation Class Initialized
INFO - 2018-10-09 08:40:06 --> Controller Class Initialized
DEBUG - 2018-10-09 08:40:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:40:08 --> Model Class Initialized
DEBUG - 2018-10-09 08:40:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:40:08 --> Model Class Initialized
INFO - 2018-10-09 08:40:08 --> Final output sent to browser
DEBUG - 2018-10-09 08:40:08 --> Total execution time: 11.8482
INFO - 2018-10-09 08:46:58 --> Config Class Initialized
INFO - 2018-10-09 08:46:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:47:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:47:00 --> Utf8 Class Initialized
INFO - 2018-10-09 08:47:00 --> URI Class Initialized
DEBUG - 2018-10-09 08:47:01 --> No URI present. Default controller set.
INFO - 2018-10-09 08:47:01 --> Router Class Initialized
INFO - 2018-10-09 08:47:01 --> Output Class Initialized
INFO - 2018-10-09 08:47:02 --> Security Class Initialized
DEBUG - 2018-10-09 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:47:02 --> Input Class Initialized
INFO - 2018-10-09 08:47:02 --> Language Class Initialized
INFO - 2018-10-09 08:47:03 --> Language Class Initialized
INFO - 2018-10-09 08:47:03 --> Config Class Initialized
INFO - 2018-10-09 08:47:03 --> Loader Class Initialized
INFO - 2018-10-09 08:47:03 --> Helper loaded: url_helper
INFO - 2018-10-09 08:47:03 --> Helper loaded: form_helper
INFO - 2018-10-09 08:47:04 --> Database Driver Class Initialized
INFO - 2018-10-09 08:47:04 --> Email Class Initialized
INFO - 2018-10-09 08:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:47:05 --> Form Validation Class Initialized
INFO - 2018-10-09 08:47:05 --> Controller Class Initialized
DEBUG - 2018-10-09 08:47:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:47:05 --> Model Class Initialized
DEBUG - 2018-10-09 08:47:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:47:06 --> Model Class Initialized
DEBUG - 2018-10-09 08:47:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:47:06 --> Final output sent to browser
DEBUG - 2018-10-09 08:47:07 --> Total execution time: 8.4615
INFO - 2018-10-09 08:47:37 --> Config Class Initialized
INFO - 2018-10-09 08:47:37 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:47:37 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:47:37 --> Utf8 Class Initialized
INFO - 2018-10-09 08:47:37 --> URI Class Initialized
DEBUG - 2018-10-09 08:47:38 --> No URI present. Default controller set.
INFO - 2018-10-09 08:47:38 --> Router Class Initialized
INFO - 2018-10-09 08:47:38 --> Output Class Initialized
INFO - 2018-10-09 08:47:38 --> Security Class Initialized
DEBUG - 2018-10-09 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:47:38 --> Input Class Initialized
INFO - 2018-10-09 08:47:39 --> Language Class Initialized
INFO - 2018-10-09 08:47:39 --> Language Class Initialized
INFO - 2018-10-09 08:47:39 --> Config Class Initialized
INFO - 2018-10-09 08:47:39 --> Loader Class Initialized
INFO - 2018-10-09 08:47:39 --> Helper loaded: url_helper
INFO - 2018-10-09 08:47:40 --> Helper loaded: form_helper
INFO - 2018-10-09 08:47:40 --> Database Driver Class Initialized
INFO - 2018-10-09 08:47:40 --> Email Class Initialized
INFO - 2018-10-09 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:47:40 --> Form Validation Class Initialized
INFO - 2018-10-09 08:47:41 --> Controller Class Initialized
DEBUG - 2018-10-09 08:47:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:47:41 --> Model Class Initialized
DEBUG - 2018-10-09 08:47:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:47:41 --> Model Class Initialized
DEBUG - 2018-10-09 08:47:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:47:42 --> Final output sent to browser
DEBUG - 2018-10-09 08:47:42 --> Total execution time: 5.1603
INFO - 2018-10-09 08:47:58 --> Config Class Initialized
INFO - 2018-10-09 08:47:58 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:47:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:47:59 --> Utf8 Class Initialized
INFO - 2018-10-09 08:47:59 --> URI Class Initialized
INFO - 2018-10-09 08:47:59 --> Router Class Initialized
INFO - 2018-10-09 08:47:59 --> Config Class Initialized
INFO - 2018-10-09 08:47:59 --> Hooks Class Initialized
INFO - 2018-10-09 08:48:00 --> Output Class Initialized
DEBUG - 2018-10-09 08:48:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:48:00 --> Utf8 Class Initialized
INFO - 2018-10-09 08:48:00 --> URI Class Initialized
DEBUG - 2018-10-09 08:48:00 --> No URI present. Default controller set.
INFO - 2018-10-09 08:48:01 --> Router Class Initialized
INFO - 2018-10-09 08:48:01 --> Output Class Initialized
INFO - 2018-10-09 08:48:01 --> Security Class Initialized
DEBUG - 2018-10-09 08:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:48:01 --> Input Class Initialized
INFO - 2018-10-09 08:48:01 --> Language Class Initialized
INFO - 2018-10-09 08:48:02 --> Language Class Initialized
INFO - 2018-10-09 08:48:02 --> Config Class Initialized
INFO - 2018-10-09 08:48:02 --> Loader Class Initialized
INFO - 2018-10-09 08:48:02 --> Security Class Initialized
INFO - 2018-10-09 08:48:02 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:48:03 --> Helper loaded: form_helper
INFO - 2018-10-09 08:48:03 --> Database Driver Class Initialized
INFO - 2018-10-09 08:48:03 --> Email Class Initialized
INFO - 2018-10-09 08:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:48:04 --> Form Validation Class Initialized
INFO - 2018-10-09 08:48:04 --> Input Class Initialized
INFO - 2018-10-09 08:48:04 --> Language Class Initialized
INFO - 2018-10-09 08:48:04 --> Language Class Initialized
INFO - 2018-10-09 08:48:04 --> Config Class Initialized
INFO - 2018-10-09 08:48:05 --> Loader Class Initialized
INFO - 2018-10-09 08:48:05 --> Controller Class Initialized
INFO - 2018-10-09 08:48:05 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:48:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:48:05 --> Model Class Initialized
DEBUG - 2018-10-09 08:48:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:48:06 --> Model Class Initialized
INFO - 2018-10-09 08:48:06 --> Helper loaded: form_helper
INFO - 2018-10-09 08:48:06 --> Database Driver Class Initialized
DEBUG - 2018-10-09 08:48:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:48:06 --> Final output sent to browser
DEBUG - 2018-10-09 08:48:07 --> Total execution time: 7.1434
INFO - 2018-10-09 08:48:07 --> Email Class Initialized
INFO - 2018-10-09 08:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:48:07 --> Form Validation Class Initialized
INFO - 2018-10-09 08:48:08 --> Controller Class Initialized
DEBUG - 2018-10-09 08:48:08 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:48:08 --> Model Class Initialized
DEBUG - 2018-10-09 08:48:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:48:08 --> Model Class Initialized
INFO - 2018-10-09 08:48:09 --> Final output sent to browser
DEBUG - 2018-10-09 08:48:09 --> Total execution time: 11.3356
INFO - 2018-10-09 08:51:56 --> Config Class Initialized
INFO - 2018-10-09 08:51:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:51:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:51:57 --> Utf8 Class Initialized
INFO - 2018-10-09 08:51:57 --> URI Class Initialized
DEBUG - 2018-10-09 08:51:57 --> No URI present. Default controller set.
INFO - 2018-10-09 08:51:57 --> Router Class Initialized
INFO - 2018-10-09 08:51:58 --> Output Class Initialized
INFO - 2018-10-09 08:51:58 --> Security Class Initialized
DEBUG - 2018-10-09 08:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:51:58 --> Input Class Initialized
INFO - 2018-10-09 08:51:58 --> Language Class Initialized
INFO - 2018-10-09 08:51:59 --> Language Class Initialized
INFO - 2018-10-09 08:51:59 --> Config Class Initialized
INFO - 2018-10-09 08:51:59 --> Loader Class Initialized
INFO - 2018-10-09 08:51:59 --> Helper loaded: url_helper
INFO - 2018-10-09 08:52:00 --> Helper loaded: form_helper
INFO - 2018-10-09 08:52:00 --> Database Driver Class Initialized
INFO - 2018-10-09 08:52:00 --> Email Class Initialized
INFO - 2018-10-09 08:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:52:00 --> Form Validation Class Initialized
INFO - 2018-10-09 08:52:00 --> Controller Class Initialized
DEBUG - 2018-10-09 08:52:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:52:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:52:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:52:01 --> Model Class Initialized
DEBUG - 2018-10-09 08:52:01 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:52:02 --> Final output sent to browser
DEBUG - 2018-10-09 08:52:03 --> Total execution time: 5.2713
INFO - 2018-10-09 08:52:40 --> Config Class Initialized
INFO - 2018-10-09 08:52:40 --> Hooks Class Initialized
INFO - 2018-10-09 08:52:40 --> Config Class Initialized
INFO - 2018-10-09 08:52:40 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:52:40 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 08:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:52:41 --> Utf8 Class Initialized
INFO - 2018-10-09 08:52:41 --> URI Class Initialized
INFO - 2018-10-09 08:52:41 --> Router Class Initialized
INFO - 2018-10-09 08:52:42 --> Output Class Initialized
INFO - 2018-10-09 08:52:42 --> Security Class Initialized
DEBUG - 2018-10-09 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:52:42 --> Utf8 Class Initialized
INFO - 2018-10-09 08:52:43 --> URI Class Initialized
DEBUG - 2018-10-09 08:52:43 --> No URI present. Default controller set.
INFO - 2018-10-09 08:52:43 --> Input Class Initialized
INFO - 2018-10-09 08:52:43 --> Language Class Initialized
INFO - 2018-10-09 08:52:43 --> Language Class Initialized
INFO - 2018-10-09 08:52:44 --> Config Class Initialized
INFO - 2018-10-09 08:52:44 --> Router Class Initialized
INFO - 2018-10-09 08:52:44 --> Loader Class Initialized
INFO - 2018-10-09 08:52:44 --> Helper loaded: url_helper
INFO - 2018-10-09 08:52:44 --> Helper loaded: form_helper
INFO - 2018-10-09 08:52:45 --> Database Driver Class Initialized
INFO - 2018-10-09 08:52:45 --> Email Class Initialized
INFO - 2018-10-09 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:52:45 --> Form Validation Class Initialized
INFO - 2018-10-09 08:52:45 --> Output Class Initialized
INFO - 2018-10-09 08:52:45 --> Security Class Initialized
DEBUG - 2018-10-09 08:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:52:46 --> Input Class Initialized
INFO - 2018-10-09 08:52:46 --> Language Class Initialized
INFO - 2018-10-09 08:52:46 --> Language Class Initialized
INFO - 2018-10-09 08:52:46 --> Config Class Initialized
INFO - 2018-10-09 08:52:47 --> Loader Class Initialized
INFO - 2018-10-09 08:52:47 --> Helper loaded: url_helper
INFO - 2018-10-09 08:52:47 --> Helper loaded: form_helper
INFO - 2018-10-09 08:52:47 --> Controller Class Initialized
INFO - 2018-10-09 08:52:47 --> Database Driver Class Initialized
DEBUG - 2018-10-09 08:52:47 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:52:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:52:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:52:48 --> Model Class Initialized
INFO - 2018-10-09 08:52:48 --> Final output sent to browser
DEBUG - 2018-10-09 08:52:48 --> Total execution time: 8.6565
INFO - 2018-10-09 08:52:49 --> Email Class Initialized
INFO - 2018-10-09 08:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:52:49 --> Form Validation Class Initialized
INFO - 2018-10-09 08:52:49 --> Controller Class Initialized
DEBUG - 2018-10-09 08:52:50 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:52:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:52:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:52:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:52:54 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:52:54 --> Final output sent to browser
DEBUG - 2018-10-09 08:52:55 --> Total execution time: 14.0418
INFO - 2018-10-09 08:54:46 --> Config Class Initialized
INFO - 2018-10-09 08:54:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:54:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:54:46 --> Utf8 Class Initialized
INFO - 2018-10-09 08:54:46 --> URI Class Initialized
DEBUG - 2018-10-09 08:54:47 --> No URI present. Default controller set.
INFO - 2018-10-09 08:54:47 --> Router Class Initialized
INFO - 2018-10-09 08:54:47 --> Output Class Initialized
INFO - 2018-10-09 08:54:47 --> Security Class Initialized
DEBUG - 2018-10-09 08:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:54:48 --> Input Class Initialized
INFO - 2018-10-09 08:54:48 --> Language Class Initialized
INFO - 2018-10-09 08:54:48 --> Language Class Initialized
INFO - 2018-10-09 08:54:48 --> Config Class Initialized
INFO - 2018-10-09 08:54:48 --> Loader Class Initialized
INFO - 2018-10-09 08:54:49 --> Helper loaded: url_helper
INFO - 2018-10-09 08:54:49 --> Helper loaded: form_helper
INFO - 2018-10-09 08:54:49 --> Database Driver Class Initialized
INFO - 2018-10-09 08:54:49 --> Email Class Initialized
INFO - 2018-10-09 08:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:54:50 --> Form Validation Class Initialized
INFO - 2018-10-09 08:54:50 --> Controller Class Initialized
DEBUG - 2018-10-09 08:54:50 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:54:50 --> Model Class Initialized
DEBUG - 2018-10-09 08:54:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:54:51 --> Model Class Initialized
DEBUG - 2018-10-09 08:54:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:54:51 --> Final output sent to browser
DEBUG - 2018-10-09 08:54:52 --> Total execution time: 5.2663
INFO - 2018-10-09 08:55:04 --> Config Class Initialized
INFO - 2018-10-09 08:55:04 --> Config Class Initialized
INFO - 2018-10-09 08:55:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:55:04 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:55:05 --> Utf8 Class Initialized
INFO - 2018-10-09 08:55:05 --> URI Class Initialized
DEBUG - 2018-10-09 08:55:05 --> No URI present. Default controller set.
INFO - 2018-10-09 08:55:05 --> Router Class Initialized
INFO - 2018-10-09 08:55:05 --> Output Class Initialized
INFO - 2018-10-09 08:55:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:55:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:55:06 --> Utf8 Class Initialized
INFO - 2018-10-09 08:55:06 --> Security Class Initialized
DEBUG - 2018-10-09 08:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:55:07 --> URI Class Initialized
INFO - 2018-10-09 08:55:07 --> Input Class Initialized
INFO - 2018-10-09 08:55:07 --> Language Class Initialized
INFO - 2018-10-09 08:55:07 --> Router Class Initialized
INFO - 2018-10-09 08:55:07 --> Output Class Initialized
INFO - 2018-10-09 08:55:07 --> Security Class Initialized
INFO - 2018-10-09 08:55:08 --> Language Class Initialized
INFO - 2018-10-09 08:55:08 --> Config Class Initialized
INFO - 2018-10-09 08:55:08 --> Loader Class Initialized
INFO - 2018-10-09 08:55:09 --> Helper loaded: url_helper
DEBUG - 2018-10-09 08:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:55:09 --> Input Class Initialized
INFO - 2018-10-09 08:55:09 --> Helper loaded: form_helper
INFO - 2018-10-09 08:55:09 --> Language Class Initialized
INFO - 2018-10-09 08:55:10 --> Language Class Initialized
INFO - 2018-10-09 08:55:10 --> Database Driver Class Initialized
INFO - 2018-10-09 08:55:10 --> Config Class Initialized
INFO - 2018-10-09 08:55:10 --> Loader Class Initialized
INFO - 2018-10-09 08:55:10 --> Helper loaded: url_helper
INFO - 2018-10-09 08:55:11 --> Helper loaded: form_helper
INFO - 2018-10-09 08:55:11 --> Email Class Initialized
INFO - 2018-10-09 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:55:11 --> Form Validation Class Initialized
INFO - 2018-10-09 08:55:11 --> Controller Class Initialized
DEBUG - 2018-10-09 08:55:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:55:12 --> Model Class Initialized
DEBUG - 2018-10-09 08:55:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:55:12 --> Model Class Initialized
DEBUG - 2018-10-09 08:55:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:55:12 --> Final output sent to browser
INFO - 2018-10-09 08:55:13 --> Database Driver Class Initialized
INFO - 2018-10-09 08:55:13 --> Email Class Initialized
INFO - 2018-10-09 08:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:55:13 --> Form Validation Class Initialized
DEBUG - 2018-10-09 08:55:13 --> Total execution time: 8.4795
INFO - 2018-10-09 08:55:14 --> Controller Class Initialized
DEBUG - 2018-10-09 08:55:14 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:55:15 --> Model Class Initialized
DEBUG - 2018-10-09 08:55:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:55:15 --> Model Class Initialized
INFO - 2018-10-09 08:55:15 --> Final output sent to browser
DEBUG - 2018-10-09 08:55:16 --> Total execution time: 11.6097
INFO - 2018-10-09 08:55:43 --> Config Class Initialized
INFO - 2018-10-09 08:55:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:55:44 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:55:44 --> Utf8 Class Initialized
INFO - 2018-10-09 08:55:44 --> URI Class Initialized
DEBUG - 2018-10-09 08:55:45 --> No URI present. Default controller set.
INFO - 2018-10-09 08:55:45 --> Router Class Initialized
INFO - 2018-10-09 08:55:45 --> Output Class Initialized
INFO - 2018-10-09 08:55:45 --> Security Class Initialized
DEBUG - 2018-10-09 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:55:46 --> Input Class Initialized
INFO - 2018-10-09 08:55:46 --> Language Class Initialized
INFO - 2018-10-09 08:55:46 --> Language Class Initialized
INFO - 2018-10-09 08:55:46 --> Config Class Initialized
INFO - 2018-10-09 08:55:46 --> Loader Class Initialized
INFO - 2018-10-09 08:55:46 --> Helper loaded: url_helper
INFO - 2018-10-09 08:55:47 --> Helper loaded: form_helper
INFO - 2018-10-09 08:55:47 --> Database Driver Class Initialized
INFO - 2018-10-09 08:55:47 --> Email Class Initialized
INFO - 2018-10-09 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:55:47 --> Form Validation Class Initialized
INFO - 2018-10-09 08:55:48 --> Controller Class Initialized
DEBUG - 2018-10-09 08:55:48 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:55:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:55:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:55:48 --> Model Class Initialized
DEBUG - 2018-10-09 08:55:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:55:49 --> Final output sent to browser
DEBUG - 2018-10-09 08:55:50 --> Total execution time: 5.5933
INFO - 2018-10-09 08:55:56 --> Config Class Initialized
INFO - 2018-10-09 08:55:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:55:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:55:57 --> Utf8 Class Initialized
INFO - 2018-10-09 08:55:57 --> Config Class Initialized
INFO - 2018-10-09 08:55:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:55:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:55:58 --> Utf8 Class Initialized
INFO - 2018-10-09 08:55:58 --> URI Class Initialized
INFO - 2018-10-09 08:55:59 --> Router Class Initialized
INFO - 2018-10-09 08:55:59 --> Output Class Initialized
INFO - 2018-10-09 08:55:59 --> Security Class Initialized
INFO - 2018-10-09 08:55:59 --> URI Class Initialized
DEBUG - 2018-10-09 08:56:00 --> No URI present. Default controller set.
DEBUG - 2018-10-09 08:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:56:00 --> Router Class Initialized
INFO - 2018-10-09 08:56:00 --> Input Class Initialized
INFO - 2018-10-09 08:56:00 --> Language Class Initialized
INFO - 2018-10-09 08:56:01 --> Language Class Initialized
INFO - 2018-10-09 08:56:01 --> Output Class Initialized
INFO - 2018-10-09 08:56:01 --> Config Class Initialized
INFO - 2018-10-09 08:56:01 --> Loader Class Initialized
INFO - 2018-10-09 08:56:01 --> Helper loaded: url_helper
INFO - 2018-10-09 08:56:02 --> Helper loaded: form_helper
INFO - 2018-10-09 08:56:02 --> Security Class Initialized
DEBUG - 2018-10-09 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:56:02 --> Input Class Initialized
INFO - 2018-10-09 08:56:02 --> Language Class Initialized
INFO - 2018-10-09 08:56:03 --> Database Driver Class Initialized
INFO - 2018-10-09 08:56:03 --> Language Class Initialized
INFO - 2018-10-09 08:56:03 --> Email Class Initialized
INFO - 2018-10-09 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:56:03 --> Config Class Initialized
INFO - 2018-10-09 08:56:03 --> Form Validation Class Initialized
INFO - 2018-10-09 08:56:04 --> Controller Class Initialized
DEBUG - 2018-10-09 08:56:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:56:04 --> Model Class Initialized
DEBUG - 2018-10-09 08:56:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:56:04 --> Loader Class Initialized
INFO - 2018-10-09 08:56:05 --> Helper loaded: url_helper
INFO - 2018-10-09 08:56:05 --> Helper loaded: form_helper
INFO - 2018-10-09 08:56:05 --> Model Class Initialized
INFO - 2018-10-09 08:56:05 --> Database Driver Class Initialized
INFO - 2018-10-09 08:56:05 --> Final output sent to browser
DEBUG - 2018-10-09 08:56:06 --> Total execution time: 9.2355
INFO - 2018-10-09 08:56:06 --> Email Class Initialized
INFO - 2018-10-09 08:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:56:06 --> Form Validation Class Initialized
INFO - 2018-10-09 08:56:07 --> Controller Class Initialized
DEBUG - 2018-10-09 08:56:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:56:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:56:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:56:07 --> Model Class Initialized
DEBUG - 2018-10-09 08:56:08 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:56:08 --> Final output sent to browser
DEBUG - 2018-10-09 08:56:09 --> Total execution time: 10.6676
INFO - 2018-10-09 08:56:17 --> Config Class Initialized
INFO - 2018-10-09 08:56:17 --> Hooks Class Initialized
INFO - 2018-10-09 08:56:17 --> Config Class Initialized
DEBUG - 2018-10-09 08:56:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:56:18 --> Utf8 Class Initialized
INFO - 2018-10-09 08:56:18 --> URI Class Initialized
INFO - 2018-10-09 08:56:18 --> Router Class Initialized
INFO - 2018-10-09 08:56:19 --> Output Class Initialized
INFO - 2018-10-09 08:56:19 --> Security Class Initialized
DEBUG - 2018-10-09 08:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:56:19 --> Input Class Initialized
INFO - 2018-10-09 08:56:20 --> Hooks Class Initialized
DEBUG - 2018-10-09 08:56:20 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:56:20 --> Language Class Initialized
INFO - 2018-10-09 08:56:20 --> Language Class Initialized
INFO - 2018-10-09 08:56:20 --> Utf8 Class Initialized
INFO - 2018-10-09 08:56:20 --> Config Class Initialized
INFO - 2018-10-09 08:56:21 --> Loader Class Initialized
INFO - 2018-10-09 08:56:21 --> URI Class Initialized
DEBUG - 2018-10-09 08:56:21 --> No URI present. Default controller set.
INFO - 2018-10-09 08:56:21 --> Helper loaded: url_helper
INFO - 2018-10-09 08:56:21 --> Helper loaded: form_helper
INFO - 2018-10-09 08:56:22 --> Router Class Initialized
INFO - 2018-10-09 08:56:22 --> Database Driver Class Initialized
INFO - 2018-10-09 08:56:22 --> Email Class Initialized
INFO - 2018-10-09 08:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:56:22 --> Form Validation Class Initialized
INFO - 2018-10-09 08:56:23 --> Controller Class Initialized
INFO - 2018-10-09 08:56:23 --> Output Class Initialized
DEBUG - 2018-10-09 08:56:23 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:56:23 --> Model Class Initialized
INFO - 2018-10-09 08:56:23 --> Security Class Initialized
DEBUG - 2018-10-09 08:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-09 08:56:24 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:56:24 --> Model Class Initialized
INFO - 2018-10-09 08:56:24 --> Final output sent to browser
DEBUG - 2018-10-09 08:56:24 --> Total execution time: 6.8734
INFO - 2018-10-09 08:56:25 --> Input Class Initialized
INFO - 2018-10-09 08:56:25 --> Language Class Initialized
INFO - 2018-10-09 08:56:25 --> Language Class Initialized
INFO - 2018-10-09 08:56:25 --> Config Class Initialized
INFO - 2018-10-09 08:56:26 --> Loader Class Initialized
INFO - 2018-10-09 08:56:26 --> Helper loaded: url_helper
INFO - 2018-10-09 08:56:26 --> Helper loaded: form_helper
INFO - 2018-10-09 08:56:26 --> Database Driver Class Initialized
INFO - 2018-10-09 08:56:26 --> Email Class Initialized
INFO - 2018-10-09 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:56:27 --> Form Validation Class Initialized
INFO - 2018-10-09 08:56:27 --> Controller Class Initialized
DEBUG - 2018-10-09 08:56:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:56:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:56:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:56:28 --> Model Class Initialized
DEBUG - 2018-10-09 08:56:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:56:28 --> Final output sent to browser
DEBUG - 2018-10-09 08:56:28 --> Total execution time: 10.9256
INFO - 2018-10-09 08:59:03 --> Config Class Initialized
INFO - 2018-10-09 08:59:03 --> Hooks Class Initialized
INFO - 2018-10-09 08:59:03 --> Config Class Initialized
DEBUG - 2018-10-09 08:59:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:59:04 --> Utf8 Class Initialized
INFO - 2018-10-09 08:59:05 --> Hooks Class Initialized
INFO - 2018-10-09 08:59:05 --> URI Class Initialized
DEBUG - 2018-10-09 08:59:05 --> No URI present. Default controller set.
INFO - 2018-10-09 08:59:06 --> Router Class Initialized
INFO - 2018-10-09 08:59:06 --> Output Class Initialized
INFO - 2018-10-09 08:59:07 --> Security Class Initialized
DEBUG - 2018-10-09 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:59:08 --> Input Class Initialized
DEBUG - 2018-10-09 08:59:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 08:59:08 --> Utf8 Class Initialized
INFO - 2018-10-09 08:59:09 --> URI Class Initialized
INFO - 2018-10-09 08:59:09 --> Router Class Initialized
INFO - 2018-10-09 08:59:10 --> Output Class Initialized
INFO - 2018-10-09 08:59:10 --> Language Class Initialized
INFO - 2018-10-09 08:59:10 --> Security Class Initialized
DEBUG - 2018-10-09 08:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 08:59:11 --> Input Class Initialized
INFO - 2018-10-09 08:59:11 --> Language Class Initialized
INFO - 2018-10-09 08:59:11 --> Language Class Initialized
INFO - 2018-10-09 08:59:11 --> Config Class Initialized
INFO - 2018-10-09 08:59:12 --> Language Class Initialized
INFO - 2018-10-09 08:59:12 --> Config Class Initialized
INFO - 2018-10-09 08:59:12 --> Loader Class Initialized
INFO - 2018-10-09 08:59:12 --> Helper loaded: url_helper
INFO - 2018-10-09 08:59:13 --> Helper loaded: form_helper
INFO - 2018-10-09 08:59:13 --> Loader Class Initialized
INFO - 2018-10-09 08:59:13 --> Database Driver Class Initialized
INFO - 2018-10-09 08:59:13 --> Email Class Initialized
INFO - 2018-10-09 08:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:59:14 --> Form Validation Class Initialized
INFO - 2018-10-09 08:59:14 --> Controller Class Initialized
DEBUG - 2018-10-09 08:59:14 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:59:15 --> Model Class Initialized
DEBUG - 2018-10-09 08:59:15 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 08:59:15 --> Model Class Initialized
INFO - 2018-10-09 08:59:15 --> Final output sent to browser
DEBUG - 2018-10-09 08:59:16 --> Total execution time: 12.7557
INFO - 2018-10-09 08:59:16 --> Helper loaded: url_helper
INFO - 2018-10-09 08:59:17 --> Helper loaded: form_helper
INFO - 2018-10-09 08:59:18 --> Database Driver Class Initialized
INFO - 2018-10-09 08:59:18 --> Email Class Initialized
INFO - 2018-10-09 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 08:59:19 --> Form Validation Class Initialized
INFO - 2018-10-09 08:59:19 --> Controller Class Initialized
DEBUG - 2018-10-09 08:59:19 --> Person MX_Controller Initialized
INFO - 2018-10-09 08:59:20 --> Model Class Initialized
DEBUG - 2018-10-09 08:59:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 08:59:20 --> Model Class Initialized
DEBUG - 2018-10-09 08:59:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 08:59:21 --> Final output sent to browser
DEBUG - 2018-10-09 08:59:21 --> Total execution time: 17.8840
INFO - 2018-10-09 09:10:51 --> Config Class Initialized
INFO - 2018-10-09 09:10:51 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:10:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:10:54 --> Utf8 Class Initialized
INFO - 2018-10-09 09:10:54 --> URI Class Initialized
DEBUG - 2018-10-09 09:10:55 --> No URI present. Default controller set.
INFO - 2018-10-09 09:10:55 --> Router Class Initialized
INFO - 2018-10-09 09:10:55 --> Output Class Initialized
INFO - 2018-10-09 09:10:55 --> Security Class Initialized
DEBUG - 2018-10-09 09:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:10:56 --> Input Class Initialized
INFO - 2018-10-09 09:10:56 --> Language Class Initialized
INFO - 2018-10-09 09:10:56 --> Language Class Initialized
INFO - 2018-10-09 09:10:56 --> Config Class Initialized
INFO - 2018-10-09 09:10:56 --> Loader Class Initialized
INFO - 2018-10-09 09:10:57 --> Helper loaded: url_helper
INFO - 2018-10-09 09:10:57 --> Helper loaded: form_helper
INFO - 2018-10-09 09:10:57 --> Database Driver Class Initialized
INFO - 2018-10-09 09:10:57 --> Email Class Initialized
INFO - 2018-10-09 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:10:58 --> Form Validation Class Initialized
INFO - 2018-10-09 09:10:58 --> Controller Class Initialized
DEBUG - 2018-10-09 09:10:58 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:10:58 --> Model Class Initialized
DEBUG - 2018-10-09 09:10:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:10:59 --> Model Class Initialized
DEBUG - 2018-10-09 09:10:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:10:59 --> Final output sent to browser
DEBUG - 2018-10-09 09:10:59 --> Total execution time: 7.7294
INFO - 2018-10-09 09:11:06 --> Config Class Initialized
INFO - 2018-10-09 09:11:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:11:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:11:07 --> Utf8 Class Initialized
INFO - 2018-10-09 09:11:07 --> URI Class Initialized
INFO - 2018-10-09 09:11:07 --> Router Class Initialized
INFO - 2018-10-09 09:11:07 --> Output Class Initialized
INFO - 2018-10-09 09:11:07 --> Security Class Initialized
DEBUG - 2018-10-09 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:11:08 --> Input Class Initialized
INFO - 2018-10-09 09:11:08 --> Language Class Initialized
INFO - 2018-10-09 09:11:08 --> Language Class Initialized
INFO - 2018-10-09 09:11:08 --> Config Class Initialized
INFO - 2018-10-09 09:11:09 --> Loader Class Initialized
INFO - 2018-10-09 09:11:09 --> Helper loaded: url_helper
INFO - 2018-10-09 09:11:09 --> Helper loaded: form_helper
INFO - 2018-10-09 09:11:09 --> Database Driver Class Initialized
INFO - 2018-10-09 09:11:10 --> Email Class Initialized
INFO - 2018-10-09 09:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:11:10 --> Form Validation Class Initialized
INFO - 2018-10-09 09:11:10 --> Controller Class Initialized
DEBUG - 2018-10-09 09:11:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:11:11 --> Model Class Initialized
DEBUG - 2018-10-09 09:11:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 09:11:11 --> Model Class Initialized
INFO - 2018-10-09 09:11:12 --> Final output sent to browser
DEBUG - 2018-10-09 09:11:12 --> Total execution time: 5.6534
INFO - 2018-10-09 09:12:30 --> Config Class Initialized
INFO - 2018-10-09 09:12:30 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:12:30 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:12:30 --> Utf8 Class Initialized
INFO - 2018-10-09 09:12:31 --> URI Class Initialized
DEBUG - 2018-10-09 09:12:31 --> No URI present. Default controller set.
INFO - 2018-10-09 09:12:31 --> Router Class Initialized
INFO - 2018-10-09 09:12:31 --> Output Class Initialized
INFO - 2018-10-09 09:12:31 --> Security Class Initialized
DEBUG - 2018-10-09 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:12:32 --> Input Class Initialized
INFO - 2018-10-09 09:12:32 --> Language Class Initialized
INFO - 2018-10-09 09:12:32 --> Language Class Initialized
INFO - 2018-10-09 09:12:32 --> Config Class Initialized
INFO - 2018-10-09 09:12:33 --> Loader Class Initialized
INFO - 2018-10-09 09:12:33 --> Helper loaded: url_helper
INFO - 2018-10-09 09:12:33 --> Helper loaded: form_helper
INFO - 2018-10-09 09:12:33 --> Database Driver Class Initialized
INFO - 2018-10-09 09:12:33 --> Email Class Initialized
INFO - 2018-10-09 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:12:34 --> Form Validation Class Initialized
INFO - 2018-10-09 09:12:34 --> Controller Class Initialized
DEBUG - 2018-10-09 09:12:34 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:12:34 --> Model Class Initialized
DEBUG - 2018-10-09 09:12:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:12:35 --> Model Class Initialized
DEBUG - 2018-10-09 09:12:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:12:35 --> Final output sent to browser
DEBUG - 2018-10-09 09:12:35 --> Total execution time: 5.3813
INFO - 2018-10-09 09:14:53 --> Config Class Initialized
INFO - 2018-10-09 09:14:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:14:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:14:55 --> Utf8 Class Initialized
INFO - 2018-10-09 09:14:55 --> URI Class Initialized
DEBUG - 2018-10-09 09:14:55 --> No URI present. Default controller set.
INFO - 2018-10-09 09:14:56 --> Router Class Initialized
INFO - 2018-10-09 09:14:56 --> Output Class Initialized
INFO - 2018-10-09 09:14:56 --> Security Class Initialized
DEBUG - 2018-10-09 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:14:57 --> Input Class Initialized
INFO - 2018-10-09 09:14:57 --> Language Class Initialized
INFO - 2018-10-09 09:14:57 --> Language Class Initialized
INFO - 2018-10-09 09:14:58 --> Config Class Initialized
INFO - 2018-10-09 09:14:58 --> Loader Class Initialized
INFO - 2018-10-09 09:14:59 --> Helper loaded: url_helper
INFO - 2018-10-09 09:14:59 --> Helper loaded: form_helper
INFO - 2018-10-09 09:14:59 --> Database Driver Class Initialized
INFO - 2018-10-09 09:15:00 --> Config Class Initialized
INFO - 2018-10-09 09:15:00 --> Email Class Initialized
INFO - 2018-10-09 09:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:15:00 --> Form Validation Class Initialized
INFO - 2018-10-09 09:15:01 --> Hooks Class Initialized
INFO - 2018-10-09 09:15:01 --> Controller Class Initialized
DEBUG - 2018-10-09 09:15:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:15:01 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
DEBUG - 2018-10-09 09:15:02 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:15:02 --> Utf8 Class Initialized
INFO - 2018-10-09 09:15:02 --> URI Class Initialized
DEBUG - 2018-10-09 09:15:03 --> No URI present. Default controller set.
INFO - 2018-10-09 09:15:03 --> Router Class Initialized
INFO - 2018-10-09 09:15:03 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:15:04 --> Final output sent to browser
DEBUG - 2018-10-09 09:15:04 --> Total execution time: 10.2416
INFO - 2018-10-09 09:15:04 --> Output Class Initialized
INFO - 2018-10-09 09:15:05 --> Security Class Initialized
DEBUG - 2018-10-09 09:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:15:05 --> Input Class Initialized
INFO - 2018-10-09 09:15:06 --> Language Class Initialized
INFO - 2018-10-09 09:15:06 --> Language Class Initialized
INFO - 2018-10-09 09:15:06 --> Config Class Initialized
INFO - 2018-10-09 09:15:06 --> Loader Class Initialized
INFO - 2018-10-09 09:15:07 --> Helper loaded: url_helper
INFO - 2018-10-09 09:15:07 --> Helper loaded: form_helper
INFO - 2018-10-09 09:15:07 --> Database Driver Class Initialized
INFO - 2018-10-09 09:15:07 --> Email Class Initialized
INFO - 2018-10-09 09:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:15:08 --> Form Validation Class Initialized
INFO - 2018-10-09 09:15:08 --> Controller Class Initialized
DEBUG - 2018-10-09 09:15:08 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:15:09 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:15:09 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:09 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:15:10 --> Final output sent to browser
DEBUG - 2018-10-09 09:15:10 --> Total execution time: 10.0156
INFO - 2018-10-09 09:15:32 --> Config Class Initialized
INFO - 2018-10-09 09:15:32 --> Hooks Class Initialized
INFO - 2018-10-09 09:15:32 --> Config Class Initialized
INFO - 2018-10-09 09:15:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2018-10-09 09:15:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:15:33 --> Utf8 Class Initialized
INFO - 2018-10-09 09:15:34 --> Utf8 Class Initialized
INFO - 2018-10-09 09:15:34 --> URI Class Initialized
INFO - 2018-10-09 09:15:34 --> URI Class Initialized
DEBUG - 2018-10-09 09:15:34 --> No URI present. Default controller set.
INFO - 2018-10-09 09:15:35 --> Router Class Initialized
INFO - 2018-10-09 09:15:35 --> Output Class Initialized
INFO - 2018-10-09 09:15:35 --> Security Class Initialized
DEBUG - 2018-10-09 09:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:15:35 --> Router Class Initialized
INFO - 2018-10-09 09:15:36 --> Output Class Initialized
INFO - 2018-10-09 09:15:36 --> Security Class Initialized
DEBUG - 2018-10-09 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:15:36 --> Input Class Initialized
INFO - 2018-10-09 09:15:36 --> Language Class Initialized
INFO - 2018-10-09 09:15:37 --> Input Class Initialized
INFO - 2018-10-09 09:15:37 --> Language Class Initialized
INFO - 2018-10-09 09:15:37 --> Language Class Initialized
INFO - 2018-10-09 09:15:37 --> Language Class Initialized
INFO - 2018-10-09 09:15:37 --> Config Class Initialized
INFO - 2018-10-09 09:15:38 --> Loader Class Initialized
INFO - 2018-10-09 09:15:38 --> Helper loaded: url_helper
INFO - 2018-10-09 09:15:38 --> Helper loaded: form_helper
INFO - 2018-10-09 09:15:38 --> Database Driver Class Initialized
INFO - 2018-10-09 09:15:38 --> Email Class Initialized
INFO - 2018-10-09 09:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:15:39 --> Form Validation Class Initialized
INFO - 2018-10-09 09:15:39 --> Controller Class Initialized
DEBUG - 2018-10-09 09:15:39 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:15:39 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:40 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 09:15:40 --> Model Class Initialized
INFO - 2018-10-09 09:15:40 --> Config Class Initialized
INFO - 2018-10-09 09:15:40 --> Loader Class Initialized
INFO - 2018-10-09 09:15:40 --> Final output sent to browser
DEBUG - 2018-10-09 09:15:41 --> Total execution time: 8.1865
INFO - 2018-10-09 09:15:41 --> Helper loaded: url_helper
INFO - 2018-10-09 09:15:41 --> Helper loaded: form_helper
INFO - 2018-10-09 09:15:42 --> Database Driver Class Initialized
INFO - 2018-10-09 09:15:42 --> Email Class Initialized
INFO - 2018-10-09 09:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:15:42 --> Form Validation Class Initialized
INFO - 2018-10-09 09:15:42 --> Controller Class Initialized
DEBUG - 2018-10-09 09:15:43 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:15:43 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:15:43 --> Model Class Initialized
DEBUG - 2018-10-09 09:15:43 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:15:44 --> Final output sent to browser
DEBUG - 2018-10-09 09:15:44 --> Total execution time: 11.2436
INFO - 2018-10-09 09:16:18 --> Config Class Initialized
INFO - 2018-10-09 09:16:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:16:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:16:18 --> Utf8 Class Initialized
INFO - 2018-10-09 09:16:19 --> URI Class Initialized
DEBUG - 2018-10-09 09:16:19 --> No URI present. Default controller set.
INFO - 2018-10-09 09:16:19 --> Router Class Initialized
INFO - 2018-10-09 09:16:20 --> Output Class Initialized
INFO - 2018-10-09 09:16:20 --> Security Class Initialized
DEBUG - 2018-10-09 09:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:16:22 --> Input Class Initialized
INFO - 2018-10-09 09:16:22 --> Language Class Initialized
INFO - 2018-10-09 09:16:23 --> Config Class Initialized
INFO - 2018-10-09 09:16:23 --> Hooks Class Initialized
INFO - 2018-10-09 09:16:24 --> Language Class Initialized
INFO - 2018-10-09 09:16:24 --> Config Class Initialized
INFO - 2018-10-09 09:16:24 --> Loader Class Initialized
DEBUG - 2018-10-09 09:16:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:16:25 --> Utf8 Class Initialized
INFO - 2018-10-09 09:16:25 --> Helper loaded: url_helper
INFO - 2018-10-09 09:16:26 --> Helper loaded: form_helper
INFO - 2018-10-09 09:16:26 --> Database Driver Class Initialized
INFO - 2018-10-09 09:16:26 --> Email Class Initialized
INFO - 2018-10-09 09:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:16:27 --> Form Validation Class Initialized
INFO - 2018-10-09 09:16:27 --> Controller Class Initialized
DEBUG - 2018-10-09 09:16:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:16:28 --> Model Class Initialized
DEBUG - 2018-10-09 09:16:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:16:28 --> URI Class Initialized
DEBUG - 2018-10-09 09:16:28 --> No URI present. Default controller set.
INFO - 2018-10-09 09:16:29 --> Router Class Initialized
INFO - 2018-10-09 09:16:29 --> Output Class Initialized
INFO - 2018-10-09 09:16:29 --> Security Class Initialized
DEBUG - 2018-10-09 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:16:30 --> Input Class Initialized
INFO - 2018-10-09 09:16:30 --> Language Class Initialized
INFO - 2018-10-09 09:16:30 --> Language Class Initialized
INFO - 2018-10-09 09:16:30 --> Config Class Initialized
INFO - 2018-10-09 09:16:31 --> Loader Class Initialized
INFO - 2018-10-09 09:16:31 --> Helper loaded: url_helper
INFO - 2018-10-09 09:16:31 --> Model Class Initialized
INFO - 2018-10-09 09:16:31 --> Helper loaded: form_helper
INFO - 2018-10-09 09:16:32 --> Database Driver Class Initialized
INFO - 2018-10-09 09:16:32 --> Email Class Initialized
INFO - 2018-10-09 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:16:32 --> Form Validation Class Initialized
DEBUG - 2018-10-09 09:16:33 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:16:33 --> Final output sent to browser
DEBUG - 2018-10-09 09:16:33 --> Total execution time: 15.2599
INFO - 2018-10-09 09:16:34 --> Controller Class Initialized
DEBUG - 2018-10-09 09:16:34 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:16:34 --> Model Class Initialized
DEBUG - 2018-10-09 09:16:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:16:35 --> Model Class Initialized
DEBUG - 2018-10-09 09:16:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:16:35 --> Final output sent to browser
DEBUG - 2018-10-09 09:16:36 --> Total execution time: 12.7057
INFO - 2018-10-09 09:16:53 --> Config Class Initialized
INFO - 2018-10-09 09:16:53 --> Hooks Class Initialized
INFO - 2018-10-09 09:16:53 --> Config Class Initialized
DEBUG - 2018-10-09 09:16:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:16:54 --> Utf8 Class Initialized
INFO - 2018-10-09 09:16:54 --> URI Class Initialized
INFO - 2018-10-09 09:16:54 --> Router Class Initialized
INFO - 2018-10-09 09:16:55 --> Output Class Initialized
INFO - 2018-10-09 09:16:55 --> Hooks Class Initialized
INFO - 2018-10-09 09:16:55 --> Security Class Initialized
DEBUG - 2018-10-09 09:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-10-09 09:16:56 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:16:56 --> Utf8 Class Initialized
INFO - 2018-10-09 09:16:56 --> URI Class Initialized
DEBUG - 2018-10-09 09:16:56 --> No URI present. Default controller set.
INFO - 2018-10-09 09:16:56 --> Router Class Initialized
INFO - 2018-10-09 09:16:57 --> Input Class Initialized
INFO - 2018-10-09 09:16:57 --> Language Class Initialized
INFO - 2018-10-09 09:16:57 --> Language Class Initialized
INFO - 2018-10-09 09:16:57 --> Output Class Initialized
INFO - 2018-10-09 09:16:57 --> Security Class Initialized
DEBUG - 2018-10-09 09:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:16:58 --> Input Class Initialized
INFO - 2018-10-09 09:16:58 --> Language Class Initialized
INFO - 2018-10-09 09:16:58 --> Language Class Initialized
INFO - 2018-10-09 09:16:58 --> Config Class Initialized
INFO - 2018-10-09 09:16:59 --> Loader Class Initialized
INFO - 2018-10-09 09:16:59 --> Helper loaded: url_helper
INFO - 2018-10-09 09:16:59 --> Helper loaded: form_helper
INFO - 2018-10-09 09:16:59 --> Database Driver Class Initialized
INFO - 2018-10-09 09:16:59 --> Email Class Initialized
INFO - 2018-10-09 09:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:17:00 --> Form Validation Class Initialized
INFO - 2018-10-09 09:17:00 --> Config Class Initialized
INFO - 2018-10-09 09:17:00 --> Controller Class Initialized
INFO - 2018-10-09 09:17:00 --> Loader Class Initialized
INFO - 2018-10-09 09:17:01 --> Helper loaded: url_helper
INFO - 2018-10-09 09:17:01 --> Helper loaded: form_helper
INFO - 2018-10-09 09:17:01 --> Database Driver Class Initialized
DEBUG - 2018-10-09 09:17:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:17:01 --> Model Class Initialized
DEBUG - 2018-10-09 09:17:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 09:17:02 --> Model Class Initialized
INFO - 2018-10-09 09:17:02 --> Final output sent to browser
DEBUG - 2018-10-09 09:17:03 --> Total execution time: 9.2155
INFO - 2018-10-09 09:17:03 --> Email Class Initialized
INFO - 2018-10-09 09:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:17:04 --> Form Validation Class Initialized
INFO - 2018-10-09 09:17:04 --> Controller Class Initialized
DEBUG - 2018-10-09 09:17:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:17:05 --> Model Class Initialized
DEBUG - 2018-10-09 09:17:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:17:05 --> Model Class Initialized
DEBUG - 2018-10-09 09:17:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:17:05 --> Final output sent to browser
DEBUG - 2018-10-09 09:17:06 --> Total execution time: 11.9997
INFO - 2018-10-09 09:18:15 --> Config Class Initialized
INFO - 2018-10-09 09:18:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:18:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:18:16 --> Utf8 Class Initialized
INFO - 2018-10-09 09:18:16 --> URI Class Initialized
DEBUG - 2018-10-09 09:18:16 --> No URI present. Default controller set.
INFO - 2018-10-09 09:18:16 --> Router Class Initialized
INFO - 2018-10-09 09:18:16 --> Output Class Initialized
INFO - 2018-10-09 09:18:17 --> Security Class Initialized
DEBUG - 2018-10-09 09:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:18:17 --> Input Class Initialized
INFO - 2018-10-09 09:18:17 --> Language Class Initialized
INFO - 2018-10-09 09:18:17 --> Language Class Initialized
INFO - 2018-10-09 09:18:18 --> Config Class Initialized
INFO - 2018-10-09 09:18:18 --> Loader Class Initialized
INFO - 2018-10-09 09:18:18 --> Helper loaded: url_helper
INFO - 2018-10-09 09:18:18 --> Helper loaded: form_helper
INFO - 2018-10-09 09:18:19 --> Database Driver Class Initialized
INFO - 2018-10-09 09:18:19 --> Email Class Initialized
INFO - 2018-10-09 09:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:18:19 --> Form Validation Class Initialized
INFO - 2018-10-09 09:18:19 --> Controller Class Initialized
DEBUG - 2018-10-09 09:18:20 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:18:20 --> Model Class Initialized
DEBUG - 2018-10-09 09:18:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:18:20 --> Model Class Initialized
DEBUG - 2018-10-09 09:18:20 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:18:21 --> Final output sent to browser
DEBUG - 2018-10-09 09:18:21 --> Total execution time: 5.6053
INFO - 2018-10-09 09:39:18 --> Config Class Initialized
INFO - 2018-10-09 09:39:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 09:39:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 09:39:21 --> Utf8 Class Initialized
INFO - 2018-10-09 09:39:21 --> URI Class Initialized
DEBUG - 2018-10-09 09:39:22 --> No URI present. Default controller set.
INFO - 2018-10-09 09:39:22 --> Router Class Initialized
INFO - 2018-10-09 09:39:22 --> Output Class Initialized
INFO - 2018-10-09 09:39:23 --> Security Class Initialized
DEBUG - 2018-10-09 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 09:39:23 --> Input Class Initialized
INFO - 2018-10-09 09:39:23 --> Language Class Initialized
INFO - 2018-10-09 09:39:24 --> Language Class Initialized
INFO - 2018-10-09 09:39:24 --> Config Class Initialized
INFO - 2018-10-09 09:39:24 --> Loader Class Initialized
INFO - 2018-10-09 09:39:24 --> Helper loaded: url_helper
INFO - 2018-10-09 09:39:25 --> Helper loaded: form_helper
INFO - 2018-10-09 09:39:25 --> Database Driver Class Initialized
INFO - 2018-10-09 09:39:26 --> Email Class Initialized
INFO - 2018-10-09 09:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 09:39:26 --> Form Validation Class Initialized
INFO - 2018-10-09 09:39:26 --> Controller Class Initialized
DEBUG - 2018-10-09 09:39:27 --> Person MX_Controller Initialized
INFO - 2018-10-09 09:39:27 --> Model Class Initialized
DEBUG - 2018-10-09 09:39:27 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 09:39:27 --> Model Class Initialized
DEBUG - 2018-10-09 09:39:28 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 09:39:28 --> Final output sent to browser
DEBUG - 2018-10-09 09:39:28 --> Total execution time: 10.2176
INFO - 2018-10-09 11:32:38 --> Config Class Initialized
INFO - 2018-10-09 11:32:38 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:32:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:32:43 --> Utf8 Class Initialized
INFO - 2018-10-09 11:32:43 --> URI Class Initialized
DEBUG - 2018-10-09 11:32:44 --> No URI present. Default controller set.
INFO - 2018-10-09 11:32:44 --> Router Class Initialized
INFO - 2018-10-09 11:32:45 --> Output Class Initialized
INFO - 2018-10-09 11:32:45 --> Security Class Initialized
DEBUG - 2018-10-09 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:32:45 --> Input Class Initialized
INFO - 2018-10-09 11:32:46 --> Language Class Initialized
INFO - 2018-10-09 11:32:46 --> Language Class Initialized
INFO - 2018-10-09 11:32:46 --> Config Class Initialized
INFO - 2018-10-09 11:32:47 --> Loader Class Initialized
INFO - 2018-10-09 11:32:47 --> Helper loaded: url_helper
INFO - 2018-10-09 11:32:47 --> Helper loaded: form_helper
INFO - 2018-10-09 11:32:55 --> Database Driver Class Initialized
ERROR - 2018-10-09 11:33:07 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\User_Management\system\database\drivers\mysqli\mysqli_driver.php 191
INFO - 2018-10-09 11:48:10 --> Config Class Initialized
INFO - 2018-10-09 11:48:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:48:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:48:12 --> Utf8 Class Initialized
INFO - 2018-10-09 11:48:12 --> URI Class Initialized
DEBUG - 2018-10-09 11:48:13 --> No URI present. Default controller set.
INFO - 2018-10-09 11:48:13 --> Router Class Initialized
INFO - 2018-10-09 11:48:14 --> Output Class Initialized
INFO - 2018-10-09 11:48:14 --> Security Class Initialized
DEBUG - 2018-10-09 11:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:48:14 --> Input Class Initialized
INFO - 2018-10-09 11:48:15 --> Language Class Initialized
INFO - 2018-10-09 11:48:15 --> Language Class Initialized
INFO - 2018-10-09 11:48:15 --> Config Class Initialized
INFO - 2018-10-09 11:48:15 --> Loader Class Initialized
INFO - 2018-10-09 11:48:16 --> Helper loaded: url_helper
INFO - 2018-10-09 11:48:16 --> Helper loaded: form_helper
INFO - 2018-10-09 11:48:16 --> Database Driver Class Initialized
INFO - 2018-10-09 11:48:17 --> Email Class Initialized
INFO - 2018-10-09 11:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:48:17 --> Form Validation Class Initialized
INFO - 2018-10-09 11:48:18 --> Controller Class Initialized
ERROR - 2018-10-09 11:48:18 --> 404 Page Not Found: ../modules/Person/controllers/Person/index
INFO - 2018-10-09 11:49:42 --> Config Class Initialized
INFO - 2018-10-09 11:49:42 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:49:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:49:43 --> Utf8 Class Initialized
INFO - 2018-10-09 11:49:43 --> URI Class Initialized
DEBUG - 2018-10-09 11:49:43 --> No URI present. Default controller set.
INFO - 2018-10-09 11:49:43 --> Router Class Initialized
INFO - 2018-10-09 11:49:44 --> Output Class Initialized
INFO - 2018-10-09 11:49:44 --> Security Class Initialized
DEBUG - 2018-10-09 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:49:44 --> Input Class Initialized
INFO - 2018-10-09 11:49:45 --> Language Class Initialized
INFO - 2018-10-09 11:49:45 --> Language Class Initialized
INFO - 2018-10-09 11:49:45 --> Config Class Initialized
INFO - 2018-10-09 11:49:45 --> Loader Class Initialized
INFO - 2018-10-09 11:49:45 --> Helper loaded: url_helper
INFO - 2018-10-09 11:49:46 --> Helper loaded: form_helper
INFO - 2018-10-09 11:49:46 --> Database Driver Class Initialized
INFO - 2018-10-09 11:49:46 --> Email Class Initialized
INFO - 2018-10-09 11:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:49:46 --> Form Validation Class Initialized
INFO - 2018-10-09 11:49:47 --> Controller Class Initialized
DEBUG - 2018-10-09 11:49:47 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:49:47 --> Model Class Initialized
DEBUG - 2018-10-09 11:49:47 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:49:47 --> Model Class Initialized
DEBUG - 2018-10-09 11:49:48 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:49:48 --> Final output sent to browser
DEBUG - 2018-10-09 11:49:48 --> Total execution time: 5.7663
INFO - 2018-10-09 11:50:29 --> Config Class Initialized
INFO - 2018-10-09 11:50:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:50:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:50:29 --> Utf8 Class Initialized
INFO - 2018-10-09 11:50:30 --> URI Class Initialized
DEBUG - 2018-10-09 11:50:31 --> No URI present. Default controller set.
INFO - 2018-10-09 11:50:31 --> Router Class Initialized
INFO - 2018-10-09 11:50:32 --> Output Class Initialized
INFO - 2018-10-09 11:50:32 --> Security Class Initialized
DEBUG - 2018-10-09 11:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:50:32 --> Input Class Initialized
INFO - 2018-10-09 11:50:33 --> Language Class Initialized
INFO - 2018-10-09 11:50:33 --> Language Class Initialized
INFO - 2018-10-09 11:50:33 --> Config Class Initialized
INFO - 2018-10-09 11:50:33 --> Loader Class Initialized
INFO - 2018-10-09 11:50:33 --> Helper loaded: url_helper
INFO - 2018-10-09 11:50:34 --> Helper loaded: form_helper
INFO - 2018-10-09 11:50:34 --> Database Driver Class Initialized
INFO - 2018-10-09 11:50:34 --> Email Class Initialized
INFO - 2018-10-09 11:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:50:35 --> Form Validation Class Initialized
INFO - 2018-10-09 11:50:35 --> Controller Class Initialized
DEBUG - 2018-10-09 11:50:35 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:50:35 --> Model Class Initialized
DEBUG - 2018-10-09 11:50:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:50:35 --> Model Class Initialized
DEBUG - 2018-10-09 11:50:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:50:36 --> Final output sent to browser
DEBUG - 2018-10-09 11:50:36 --> Total execution time: 7.3304
INFO - 2018-10-09 11:55:57 --> Config Class Initialized
INFO - 2018-10-09 11:55:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:55:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:55:57 --> Utf8 Class Initialized
INFO - 2018-10-09 11:55:57 --> URI Class Initialized
DEBUG - 2018-10-09 11:55:58 --> No URI present. Default controller set.
INFO - 2018-10-09 11:55:58 --> Router Class Initialized
INFO - 2018-10-09 11:55:58 --> Output Class Initialized
INFO - 2018-10-09 11:55:58 --> Security Class Initialized
DEBUG - 2018-10-09 11:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:55:59 --> Input Class Initialized
INFO - 2018-10-09 11:55:59 --> Language Class Initialized
INFO - 2018-10-09 11:55:59 --> Language Class Initialized
INFO - 2018-10-09 11:56:00 --> Config Class Initialized
INFO - 2018-10-09 11:56:00 --> Loader Class Initialized
INFO - 2018-10-09 11:56:00 --> Helper loaded: url_helper
INFO - 2018-10-09 11:56:00 --> Helper loaded: form_helper
INFO - 2018-10-09 11:56:00 --> Database Driver Class Initialized
INFO - 2018-10-09 11:56:01 --> Email Class Initialized
INFO - 2018-10-09 11:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:56:01 --> Form Validation Class Initialized
INFO - 2018-10-09 11:56:01 --> Controller Class Initialized
DEBUG - 2018-10-09 11:56:01 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:56:02 --> Model Class Initialized
DEBUG - 2018-10-09 11:56:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:56:02 --> Model Class Initialized
DEBUG - 2018-10-09 11:56:02 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:56:02 --> Final output sent to browser
DEBUG - 2018-10-09 11:56:03 --> Total execution time: 5.9933
INFO - 2018-10-09 11:56:05 --> Config Class Initialized
INFO - 2018-10-09 11:56:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:56:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:56:05 --> Utf8 Class Initialized
INFO - 2018-10-09 11:56:06 --> URI Class Initialized
INFO - 2018-10-09 11:56:06 --> Router Class Initialized
INFO - 2018-10-09 11:56:06 --> Output Class Initialized
INFO - 2018-10-09 11:56:06 --> Security Class Initialized
DEBUG - 2018-10-09 11:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:56:07 --> Input Class Initialized
INFO - 2018-10-09 11:56:07 --> Language Class Initialized
INFO - 2018-10-09 11:56:07 --> Language Class Initialized
INFO - 2018-10-09 11:56:07 --> Config Class Initialized
INFO - 2018-10-09 11:56:08 --> Loader Class Initialized
INFO - 2018-10-09 11:56:08 --> Helper loaded: url_helper
INFO - 2018-10-09 11:56:08 --> Helper loaded: form_helper
INFO - 2018-10-09 11:56:08 --> Database Driver Class Initialized
INFO - 2018-10-09 11:56:08 --> Email Class Initialized
INFO - 2018-10-09 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:56:09 --> Form Validation Class Initialized
INFO - 2018-10-09 11:56:09 --> Controller Class Initialized
DEBUG - 2018-10-09 11:56:09 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:56:09 --> Model Class Initialized
DEBUG - 2018-10-09 11:56:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 11:56:10 --> Model Class Initialized
INFO - 2018-10-09 11:56:11 --> Final output sent to browser
DEBUG - 2018-10-09 11:56:11 --> Total execution time: 6.6824
INFO - 2018-10-09 11:56:54 --> Config Class Initialized
INFO - 2018-10-09 11:56:54 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:56:55 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:56:55 --> Utf8 Class Initialized
INFO - 2018-10-09 11:56:55 --> URI Class Initialized
DEBUG - 2018-10-09 11:56:56 --> No URI present. Default controller set.
INFO - 2018-10-09 11:56:56 --> Router Class Initialized
INFO - 2018-10-09 11:56:56 --> Output Class Initialized
INFO - 2018-10-09 11:56:56 --> Security Class Initialized
DEBUG - 2018-10-09 11:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:56:57 --> Input Class Initialized
INFO - 2018-10-09 11:56:57 --> Language Class Initialized
INFO - 2018-10-09 11:56:57 --> Language Class Initialized
INFO - 2018-10-09 11:56:57 --> Config Class Initialized
INFO - 2018-10-09 11:56:57 --> Loader Class Initialized
INFO - 2018-10-09 11:56:58 --> Helper loaded: url_helper
INFO - 2018-10-09 11:56:58 --> Helper loaded: form_helper
INFO - 2018-10-09 11:56:58 --> Database Driver Class Initialized
INFO - 2018-10-09 11:56:58 --> Email Class Initialized
INFO - 2018-10-09 11:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:56:59 --> Form Validation Class Initialized
INFO - 2018-10-09 11:56:59 --> Controller Class Initialized
DEBUG - 2018-10-09 11:56:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:56:59 --> Model Class Initialized
DEBUG - 2018-10-09 11:57:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:57:00 --> Model Class Initialized
DEBUG - 2018-10-09 11:57:00 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:57:00 --> Final output sent to browser
DEBUG - 2018-10-09 11:57:00 --> Total execution time: 5.9213
INFO - 2018-10-09 11:57:02 --> Config Class Initialized
INFO - 2018-10-09 11:57:02 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:57:03 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:57:03 --> Utf8 Class Initialized
INFO - 2018-10-09 11:57:03 --> URI Class Initialized
INFO - 2018-10-09 11:57:03 --> Router Class Initialized
INFO - 2018-10-09 11:57:04 --> Output Class Initialized
INFO - 2018-10-09 11:57:04 --> Security Class Initialized
DEBUG - 2018-10-09 11:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:57:04 --> Input Class Initialized
INFO - 2018-10-09 11:57:04 --> Language Class Initialized
INFO - 2018-10-09 11:57:05 --> Language Class Initialized
INFO - 2018-10-09 11:57:05 --> Config Class Initialized
INFO - 2018-10-09 11:57:05 --> Loader Class Initialized
INFO - 2018-10-09 11:57:05 --> Helper loaded: url_helper
INFO - 2018-10-09 11:57:05 --> Helper loaded: form_helper
INFO - 2018-10-09 11:57:06 --> Database Driver Class Initialized
INFO - 2018-10-09 11:57:06 --> Email Class Initialized
INFO - 2018-10-09 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:57:06 --> Form Validation Class Initialized
INFO - 2018-10-09 11:57:07 --> Controller Class Initialized
DEBUG - 2018-10-09 11:57:07 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:57:07 --> Model Class Initialized
DEBUG - 2018-10-09 11:57:07 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 11:57:07 --> Model Class Initialized
INFO - 2018-10-09 11:57:08 --> Final output sent to browser
DEBUG - 2018-10-09 11:57:08 --> Total execution time: 5.3223
INFO - 2018-10-09 11:58:00 --> Config Class Initialized
INFO - 2018-10-09 11:58:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:58:01 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:58:01 --> Utf8 Class Initialized
INFO - 2018-10-09 11:58:01 --> URI Class Initialized
DEBUG - 2018-10-09 11:58:02 --> No URI present. Default controller set.
INFO - 2018-10-09 11:58:02 --> Router Class Initialized
INFO - 2018-10-09 11:58:02 --> Output Class Initialized
INFO - 2018-10-09 11:58:02 --> Security Class Initialized
DEBUG - 2018-10-09 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:58:03 --> Input Class Initialized
INFO - 2018-10-09 11:58:03 --> Language Class Initialized
INFO - 2018-10-09 11:58:03 --> Language Class Initialized
INFO - 2018-10-09 11:58:03 --> Config Class Initialized
INFO - 2018-10-09 11:58:03 --> Loader Class Initialized
INFO - 2018-10-09 11:58:04 --> Helper loaded: url_helper
INFO - 2018-10-09 11:58:04 --> Helper loaded: form_helper
INFO - 2018-10-09 11:58:04 --> Database Driver Class Initialized
INFO - 2018-10-09 11:58:04 --> Email Class Initialized
INFO - 2018-10-09 11:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:58:05 --> Form Validation Class Initialized
INFO - 2018-10-09 11:58:05 --> Controller Class Initialized
DEBUG - 2018-10-09 11:58:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:58:05 --> Model Class Initialized
DEBUG - 2018-10-09 11:58:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:58:06 --> Model Class Initialized
DEBUG - 2018-10-09 11:58:06 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:58:06 --> Final output sent to browser
DEBUG - 2018-10-09 11:58:06 --> Total execution time: 6.0129
INFO - 2018-10-09 11:58:08 --> Config Class Initialized
INFO - 2018-10-09 11:58:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:58:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:58:09 --> Utf8 Class Initialized
INFO - 2018-10-09 11:58:09 --> URI Class Initialized
INFO - 2018-10-09 11:58:09 --> Router Class Initialized
INFO - 2018-10-09 11:58:09 --> Output Class Initialized
INFO - 2018-10-09 11:58:10 --> Security Class Initialized
DEBUG - 2018-10-09 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:58:10 --> Input Class Initialized
INFO - 2018-10-09 11:58:10 --> Language Class Initialized
INFO - 2018-10-09 11:58:11 --> Language Class Initialized
INFO - 2018-10-09 11:58:11 --> Config Class Initialized
INFO - 2018-10-09 11:58:11 --> Loader Class Initialized
INFO - 2018-10-09 11:58:11 --> Helper loaded: url_helper
INFO - 2018-10-09 11:58:11 --> Helper loaded: form_helper
INFO - 2018-10-09 11:58:12 --> Database Driver Class Initialized
INFO - 2018-10-09 11:58:12 --> Email Class Initialized
INFO - 2018-10-09 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:58:12 --> Form Validation Class Initialized
INFO - 2018-10-09 11:58:13 --> Controller Class Initialized
DEBUG - 2018-10-09 11:58:13 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:58:13 --> Model Class Initialized
DEBUG - 2018-10-09 11:58:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 11:58:14 --> Model Class Initialized
INFO - 2018-10-09 11:58:14 --> Final output sent to browser
DEBUG - 2018-10-09 11:58:14 --> Total execution time: 5.7663
INFO - 2018-10-09 11:58:47 --> Config Class Initialized
INFO - 2018-10-09 11:58:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:58:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:58:48 --> Utf8 Class Initialized
INFO - 2018-10-09 11:58:48 --> URI Class Initialized
DEBUG - 2018-10-09 11:58:48 --> No URI present. Default controller set.
INFO - 2018-10-09 11:58:48 --> Router Class Initialized
INFO - 2018-10-09 11:58:49 --> Output Class Initialized
INFO - 2018-10-09 11:58:49 --> Security Class Initialized
DEBUG - 2018-10-09 11:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:58:49 --> Input Class Initialized
INFO - 2018-10-09 11:58:49 --> Language Class Initialized
INFO - 2018-10-09 11:58:50 --> Language Class Initialized
INFO - 2018-10-09 11:58:50 --> Config Class Initialized
INFO - 2018-10-09 11:58:50 --> Loader Class Initialized
INFO - 2018-10-09 11:58:50 --> Helper loaded: url_helper
INFO - 2018-10-09 11:58:50 --> Helper loaded: form_helper
INFO - 2018-10-09 11:58:51 --> Database Driver Class Initialized
INFO - 2018-10-09 11:58:51 --> Email Class Initialized
INFO - 2018-10-09 11:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:58:51 --> Form Validation Class Initialized
INFO - 2018-10-09 11:58:51 --> Controller Class Initialized
DEBUG - 2018-10-09 11:58:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:58:52 --> Model Class Initialized
DEBUG - 2018-10-09 11:58:56 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 11:58:56 --> Model Class Initialized
DEBUG - 2018-10-09 11:58:57 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 11:58:57 --> Final output sent to browser
DEBUG - 2018-10-09 11:58:57 --> Total execution time: 9.8506
INFO - 2018-10-09 11:58:59 --> Config Class Initialized
INFO - 2018-10-09 11:58:59 --> Hooks Class Initialized
DEBUG - 2018-10-09 11:58:59 --> UTF-8 Support Enabled
INFO - 2018-10-09 11:58:59 --> Utf8 Class Initialized
INFO - 2018-10-09 11:59:00 --> URI Class Initialized
INFO - 2018-10-09 11:59:00 --> Router Class Initialized
INFO - 2018-10-09 11:59:00 --> Output Class Initialized
INFO - 2018-10-09 11:59:00 --> Security Class Initialized
DEBUG - 2018-10-09 11:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 11:59:01 --> Input Class Initialized
INFO - 2018-10-09 11:59:01 --> Language Class Initialized
INFO - 2018-10-09 11:59:01 --> Language Class Initialized
INFO - 2018-10-09 11:59:01 --> Config Class Initialized
INFO - 2018-10-09 11:59:02 --> Loader Class Initialized
INFO - 2018-10-09 11:59:02 --> Helper loaded: url_helper
INFO - 2018-10-09 11:59:02 --> Helper loaded: form_helper
INFO - 2018-10-09 11:59:02 --> Database Driver Class Initialized
INFO - 2018-10-09 11:59:02 --> Email Class Initialized
INFO - 2018-10-09 11:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 11:59:03 --> Form Validation Class Initialized
INFO - 2018-10-09 11:59:03 --> Controller Class Initialized
DEBUG - 2018-10-09 11:59:03 --> Person MX_Controller Initialized
INFO - 2018-10-09 11:59:04 --> Model Class Initialized
DEBUG - 2018-10-09 11:59:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 11:59:04 --> Model Class Initialized
INFO - 2018-10-09 11:59:04 --> Final output sent to browser
DEBUG - 2018-10-09 11:59:04 --> Total execution time: 5.6023
INFO - 2018-10-09 12:11:21 --> Config Class Initialized
INFO - 2018-10-09 12:11:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:11:21 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:11:21 --> Utf8 Class Initialized
INFO - 2018-10-09 12:11:21 --> URI Class Initialized
DEBUG - 2018-10-09 12:11:22 --> No URI present. Default controller set.
INFO - 2018-10-09 12:11:22 --> Router Class Initialized
INFO - 2018-10-09 12:11:22 --> Output Class Initialized
INFO - 2018-10-09 12:11:22 --> Security Class Initialized
DEBUG - 2018-10-09 12:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:11:23 --> Input Class Initialized
INFO - 2018-10-09 12:11:23 --> Language Class Initialized
INFO - 2018-10-09 12:11:23 --> Language Class Initialized
INFO - 2018-10-09 12:11:23 --> Config Class Initialized
INFO - 2018-10-09 12:11:23 --> Loader Class Initialized
INFO - 2018-10-09 12:11:24 --> Helper loaded: url_helper
INFO - 2018-10-09 12:11:24 --> Helper loaded: form_helper
INFO - 2018-10-09 12:11:24 --> Database Driver Class Initialized
INFO - 2018-10-09 12:11:24 --> Email Class Initialized
INFO - 2018-10-09 12:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:11:25 --> Form Validation Class Initialized
INFO - 2018-10-09 12:11:25 --> Controller Class Initialized
DEBUG - 2018-10-09 12:11:25 --> Person MX_Controller Initialized
INFO - 2018-10-09 12:11:25 --> Model Class Initialized
DEBUG - 2018-10-09 12:11:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 12:11:26 --> Model Class Initialized
DEBUG - 2018-10-09 12:11:26 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 12:11:26 --> Final output sent to browser
DEBUG - 2018-10-09 12:11:26 --> Total execution time: 5.7503
INFO - 2018-10-09 12:11:29 --> Config Class Initialized
INFO - 2018-10-09 12:11:29 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:11:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:11:30 --> Utf8 Class Initialized
INFO - 2018-10-09 12:11:30 --> URI Class Initialized
INFO - 2018-10-09 12:11:30 --> Router Class Initialized
INFO - 2018-10-09 12:11:30 --> Output Class Initialized
INFO - 2018-10-09 12:11:31 --> Security Class Initialized
DEBUG - 2018-10-09 12:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:11:31 --> Input Class Initialized
INFO - 2018-10-09 12:11:31 --> Language Class Initialized
INFO - 2018-10-09 12:11:31 --> Language Class Initialized
INFO - 2018-10-09 12:11:32 --> Config Class Initialized
INFO - 2018-10-09 12:11:32 --> Loader Class Initialized
INFO - 2018-10-09 12:11:32 --> Helper loaded: url_helper
INFO - 2018-10-09 12:11:32 --> Helper loaded: form_helper
INFO - 2018-10-09 12:11:33 --> Database Driver Class Initialized
INFO - 2018-10-09 12:11:33 --> Email Class Initialized
INFO - 2018-10-09 12:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:11:33 --> Form Validation Class Initialized
INFO - 2018-10-09 12:11:33 --> Controller Class Initialized
DEBUG - 2018-10-09 12:11:34 --> Person MX_Controller Initialized
INFO - 2018-10-09 12:11:34 --> Model Class Initialized
DEBUG - 2018-10-09 12:11:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 12:11:34 --> Model Class Initialized
INFO - 2018-10-09 12:11:35 --> Final output sent to browser
DEBUG - 2018-10-09 12:11:35 --> Total execution time: 5.5483
INFO - 2018-10-09 12:12:18 --> Config Class Initialized
INFO - 2018-10-09 12:12:18 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:12:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:12:18 --> Utf8 Class Initialized
INFO - 2018-10-09 12:12:19 --> URI Class Initialized
INFO - 2018-10-09 12:12:19 --> Router Class Initialized
INFO - 2018-10-09 12:12:19 --> Output Class Initialized
INFO - 2018-10-09 12:12:19 --> Security Class Initialized
DEBUG - 2018-10-09 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:12:20 --> Input Class Initialized
INFO - 2018-10-09 12:12:20 --> Language Class Initialized
INFO - 2018-10-09 12:12:20 --> Language Class Initialized
INFO - 2018-10-09 12:12:20 --> Config Class Initialized
INFO - 2018-10-09 12:12:21 --> Loader Class Initialized
INFO - 2018-10-09 12:12:21 --> Helper loaded: url_helper
INFO - 2018-10-09 12:12:21 --> Helper loaded: form_helper
INFO - 2018-10-09 12:12:21 --> Database Driver Class Initialized
INFO - 2018-10-09 12:12:22 --> Email Class Initialized
INFO - 2018-10-09 12:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:12:22 --> Form Validation Class Initialized
INFO - 2018-10-09 12:12:22 --> Controller Class Initialized
DEBUG - 2018-10-09 12:12:22 --> Person MX_Controller Initialized
INFO - 2018-10-09 12:12:23 --> Model Class Initialized
DEBUG - 2018-10-09 12:12:23 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 12:12:23 --> Model Class Initialized
INFO - 2018-10-09 12:12:24 --> Final output sent to browser
DEBUG - 2018-10-09 12:12:24 --> Total execution time: 6.6530
INFO - 2018-10-09 12:12:25 --> Config Class Initialized
INFO - 2018-10-09 12:12:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 12:12:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 12:12:25 --> Utf8 Class Initialized
INFO - 2018-10-09 12:12:26 --> URI Class Initialized
INFO - 2018-10-09 12:12:26 --> Router Class Initialized
INFO - 2018-10-09 12:12:26 --> Output Class Initialized
INFO - 2018-10-09 12:12:26 --> Security Class Initialized
DEBUG - 2018-10-09 12:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 12:12:27 --> Input Class Initialized
INFO - 2018-10-09 12:12:27 --> Language Class Initialized
INFO - 2018-10-09 12:12:27 --> Language Class Initialized
INFO - 2018-10-09 12:12:28 --> Config Class Initialized
INFO - 2018-10-09 12:12:28 --> Loader Class Initialized
INFO - 2018-10-09 12:12:28 --> Helper loaded: url_helper
INFO - 2018-10-09 12:12:29 --> Helper loaded: form_helper
INFO - 2018-10-09 12:12:29 --> Database Driver Class Initialized
INFO - 2018-10-09 12:12:29 --> Email Class Initialized
INFO - 2018-10-09 12:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 12:12:30 --> Form Validation Class Initialized
INFO - 2018-10-09 12:12:30 --> Controller Class Initialized
DEBUG - 2018-10-09 12:12:31 --> Person MX_Controller Initialized
INFO - 2018-10-09 12:12:31 --> Model Class Initialized
DEBUG - 2018-10-09 12:12:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 12:12:32 --> Model Class Initialized
INFO - 2018-10-09 12:12:32 --> Final output sent to browser
DEBUG - 2018-10-09 12:12:32 --> Total execution time: 7.3704
INFO - 2018-10-09 13:03:39 --> Config Class Initialized
INFO - 2018-10-09 13:03:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:03:42 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:03:42 --> Utf8 Class Initialized
INFO - 2018-10-09 13:03:42 --> URI Class Initialized
DEBUG - 2018-10-09 13:03:43 --> No URI present. Default controller set.
INFO - 2018-10-09 13:03:43 --> Router Class Initialized
INFO - 2018-10-09 13:03:43 --> Output Class Initialized
INFO - 2018-10-09 13:03:44 --> Security Class Initialized
DEBUG - 2018-10-09 13:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:03:44 --> Input Class Initialized
INFO - 2018-10-09 13:03:44 --> Language Class Initialized
INFO - 2018-10-09 13:03:45 --> Language Class Initialized
INFO - 2018-10-09 13:03:45 --> Config Class Initialized
INFO - 2018-10-09 13:03:45 --> Loader Class Initialized
INFO - 2018-10-09 13:03:46 --> Helper loaded: url_helper
INFO - 2018-10-09 13:03:46 --> Helper loaded: form_helper
INFO - 2018-10-09 13:03:46 --> Database Driver Class Initialized
INFO - 2018-10-09 13:03:50 --> Email Class Initialized
INFO - 2018-10-09 13:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:03:51 --> Form Validation Class Initialized
INFO - 2018-10-09 13:03:51 --> Controller Class Initialized
DEBUG - 2018-10-09 13:03:51 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:03:52 --> Model Class Initialized
DEBUG - 2018-10-09 13:03:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:03:52 --> Model Class Initialized
DEBUG - 2018-10-09 13:03:52 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:03:53 --> Final output sent to browser
DEBUG - 2018-10-09 13:03:53 --> Total execution time: 15.0929
INFO - 2018-10-09 13:04:10 --> Config Class Initialized
INFO - 2018-10-09 13:04:10 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:04:11 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:04:11 --> Utf8 Class Initialized
INFO - 2018-10-09 13:04:11 --> URI Class Initialized
INFO - 2018-10-09 13:04:12 --> Router Class Initialized
INFO - 2018-10-09 13:04:12 --> Output Class Initialized
INFO - 2018-10-09 13:04:12 --> Security Class Initialized
DEBUG - 2018-10-09 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:04:12 --> Input Class Initialized
INFO - 2018-10-09 13:04:13 --> Language Class Initialized
INFO - 2018-10-09 13:04:13 --> Language Class Initialized
INFO - 2018-10-09 13:04:13 --> Config Class Initialized
INFO - 2018-10-09 13:04:13 --> Loader Class Initialized
INFO - 2018-10-09 13:04:14 --> Helper loaded: url_helper
INFO - 2018-10-09 13:04:14 --> Helper loaded: form_helper
INFO - 2018-10-09 13:04:14 --> Database Driver Class Initialized
INFO - 2018-10-09 13:04:14 --> Email Class Initialized
INFO - 2018-10-09 13:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:04:15 --> Form Validation Class Initialized
INFO - 2018-10-09 13:04:15 --> Controller Class Initialized
DEBUG - 2018-10-09 13:04:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:04:16 --> Model Class Initialized
DEBUG - 2018-10-09 13:04:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:04:16 --> Model Class Initialized
INFO - 2018-10-09 13:04:17 --> Final output sent to browser
DEBUG - 2018-10-09 13:04:17 --> Total execution time: 6.2514
INFO - 2018-10-09 13:04:39 --> Config Class Initialized
INFO - 2018-10-09 13:04:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:04:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:04:40 --> Utf8 Class Initialized
INFO - 2018-10-09 13:04:40 --> URI Class Initialized
DEBUG - 2018-10-09 13:04:40 --> No URI present. Default controller set.
INFO - 2018-10-09 13:04:40 --> Router Class Initialized
INFO - 2018-10-09 13:04:41 --> Output Class Initialized
INFO - 2018-10-09 13:04:41 --> Security Class Initialized
DEBUG - 2018-10-09 13:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:04:41 --> Input Class Initialized
INFO - 2018-10-09 13:04:42 --> Language Class Initialized
INFO - 2018-10-09 13:04:42 --> Language Class Initialized
INFO - 2018-10-09 13:04:42 --> Config Class Initialized
INFO - 2018-10-09 13:04:42 --> Loader Class Initialized
INFO - 2018-10-09 13:04:42 --> Helper loaded: url_helper
INFO - 2018-10-09 13:04:43 --> Helper loaded: form_helper
INFO - 2018-10-09 13:04:43 --> Database Driver Class Initialized
INFO - 2018-10-09 13:04:43 --> Email Class Initialized
INFO - 2018-10-09 13:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:04:44 --> Form Validation Class Initialized
INFO - 2018-10-09 13:04:44 --> Controller Class Initialized
DEBUG - 2018-10-09 13:04:44 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:04:44 --> Model Class Initialized
DEBUG - 2018-10-09 13:04:44 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:04:45 --> Model Class Initialized
DEBUG - 2018-10-09 13:04:45 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:04:45 --> Final output sent to browser
DEBUG - 2018-10-09 13:04:46 --> Total execution time: 6.1033
INFO - 2018-10-09 13:04:47 --> Config Class Initialized
INFO - 2018-10-09 13:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:04:47 --> Utf8 Class Initialized
INFO - 2018-10-09 13:04:47 --> URI Class Initialized
INFO - 2018-10-09 13:04:48 --> Router Class Initialized
INFO - 2018-10-09 13:04:48 --> Output Class Initialized
INFO - 2018-10-09 13:04:48 --> Security Class Initialized
DEBUG - 2018-10-09 13:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:04:49 --> Input Class Initialized
INFO - 2018-10-09 13:04:49 --> Language Class Initialized
INFO - 2018-10-09 13:04:49 --> Language Class Initialized
INFO - 2018-10-09 13:04:50 --> Config Class Initialized
INFO - 2018-10-09 13:04:50 --> Loader Class Initialized
INFO - 2018-10-09 13:04:50 --> Helper loaded: url_helper
INFO - 2018-10-09 13:04:50 --> Helper loaded: form_helper
INFO - 2018-10-09 13:04:51 --> Database Driver Class Initialized
INFO - 2018-10-09 13:04:51 --> Email Class Initialized
INFO - 2018-10-09 13:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:04:52 --> Form Validation Class Initialized
INFO - 2018-10-09 13:04:52 --> Controller Class Initialized
DEBUG - 2018-10-09 13:04:52 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:04:52 --> Model Class Initialized
DEBUG - 2018-10-09 13:04:53 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:04:53 --> Model Class Initialized
INFO - 2018-10-09 13:04:53 --> Final output sent to browser
DEBUG - 2018-10-09 13:04:53 --> Total execution time: 6.5264
INFO - 2018-10-09 13:05:04 --> Config Class Initialized
INFO - 2018-10-09 13:05:04 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:05:05 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:05:05 --> Utf8 Class Initialized
INFO - 2018-10-09 13:05:05 --> URI Class Initialized
DEBUG - 2018-10-09 13:05:05 --> No URI present. Default controller set.
INFO - 2018-10-09 13:05:06 --> Router Class Initialized
INFO - 2018-10-09 13:05:06 --> Output Class Initialized
INFO - 2018-10-09 13:05:06 --> Security Class Initialized
DEBUG - 2018-10-09 13:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:05:07 --> Input Class Initialized
INFO - 2018-10-09 13:05:07 --> Language Class Initialized
INFO - 2018-10-09 13:05:07 --> Language Class Initialized
INFO - 2018-10-09 13:05:07 --> Config Class Initialized
INFO - 2018-10-09 13:05:08 --> Loader Class Initialized
INFO - 2018-10-09 13:05:08 --> Helper loaded: url_helper
INFO - 2018-10-09 13:05:08 --> Helper loaded: form_helper
INFO - 2018-10-09 13:05:08 --> Database Driver Class Initialized
INFO - 2018-10-09 13:05:09 --> Email Class Initialized
INFO - 2018-10-09 13:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:05:09 --> Form Validation Class Initialized
INFO - 2018-10-09 13:05:09 --> Controller Class Initialized
DEBUG - 2018-10-09 13:05:10 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:05:10 --> Model Class Initialized
DEBUG - 2018-10-09 13:05:10 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:05:10 --> Model Class Initialized
DEBUG - 2018-10-09 13:05:11 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:05:11 --> Final output sent to browser
DEBUG - 2018-10-09 13:05:11 --> Total execution time: 6.6174
INFO - 2018-10-09 13:05:13 --> Config Class Initialized
INFO - 2018-10-09 13:05:13 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:05:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:05:14 --> Utf8 Class Initialized
INFO - 2018-10-09 13:05:14 --> URI Class Initialized
INFO - 2018-10-09 13:05:14 --> Router Class Initialized
INFO - 2018-10-09 13:05:14 --> Output Class Initialized
INFO - 2018-10-09 13:05:15 --> Security Class Initialized
DEBUG - 2018-10-09 13:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:05:15 --> Input Class Initialized
INFO - 2018-10-09 13:05:15 --> Language Class Initialized
INFO - 2018-10-09 13:05:16 --> Language Class Initialized
INFO - 2018-10-09 13:05:16 --> Config Class Initialized
INFO - 2018-10-09 13:05:16 --> Loader Class Initialized
INFO - 2018-10-09 13:05:16 --> Helper loaded: url_helper
INFO - 2018-10-09 13:05:16 --> Helper loaded: form_helper
INFO - 2018-10-09 13:05:17 --> Database Driver Class Initialized
INFO - 2018-10-09 13:05:17 --> Email Class Initialized
INFO - 2018-10-09 13:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:05:17 --> Form Validation Class Initialized
INFO - 2018-10-09 13:05:18 --> Controller Class Initialized
DEBUG - 2018-10-09 13:05:18 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:05:18 --> Model Class Initialized
DEBUG - 2018-10-09 13:05:18 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:05:19 --> Model Class Initialized
INFO - 2018-10-09 13:05:19 --> Final output sent to browser
DEBUG - 2018-10-09 13:05:19 --> Total execution time: 5.7523
INFO - 2018-10-09 13:05:35 --> Config Class Initialized
INFO - 2018-10-09 13:05:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:05:36 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:05:36 --> Utf8 Class Initialized
INFO - 2018-10-09 13:05:36 --> URI Class Initialized
INFO - 2018-10-09 13:05:37 --> Router Class Initialized
INFO - 2018-10-09 13:05:37 --> Output Class Initialized
INFO - 2018-10-09 13:05:37 --> Security Class Initialized
DEBUG - 2018-10-09 13:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:05:38 --> Input Class Initialized
INFO - 2018-10-09 13:05:38 --> Language Class Initialized
INFO - 2018-10-09 13:05:38 --> Language Class Initialized
INFO - 2018-10-09 13:05:39 --> Config Class Initialized
INFO - 2018-10-09 13:05:39 --> Loader Class Initialized
INFO - 2018-10-09 13:05:39 --> Helper loaded: url_helper
INFO - 2018-10-09 13:05:39 --> Helper loaded: form_helper
INFO - 2018-10-09 13:05:39 --> Database Driver Class Initialized
INFO - 2018-10-09 13:05:40 --> Email Class Initialized
INFO - 2018-10-09 13:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:05:40 --> Form Validation Class Initialized
INFO - 2018-10-09 13:05:40 --> Controller Class Initialized
DEBUG - 2018-10-09 13:05:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:05:41 --> Model Class Initialized
DEBUG - 2018-10-09 13:05:41 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:05:41 --> Model Class Initialized
INFO - 2018-10-09 13:05:42 --> Final output sent to browser
DEBUG - 2018-10-09 13:05:42 --> Total execution time: 6.8705
INFO - 2018-10-09 13:05:43 --> Config Class Initialized
INFO - 2018-10-09 13:05:43 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:05:43 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:05:43 --> Utf8 Class Initialized
INFO - 2018-10-09 13:05:44 --> URI Class Initialized
INFO - 2018-10-09 13:05:44 --> Router Class Initialized
INFO - 2018-10-09 13:05:44 --> Output Class Initialized
INFO - 2018-10-09 13:05:45 --> Security Class Initialized
DEBUG - 2018-10-09 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:05:45 --> Input Class Initialized
INFO - 2018-10-09 13:05:45 --> Language Class Initialized
INFO - 2018-10-09 13:05:45 --> Language Class Initialized
INFO - 2018-10-09 13:05:46 --> Config Class Initialized
INFO - 2018-10-09 13:05:46 --> Loader Class Initialized
INFO - 2018-10-09 13:05:46 --> Helper loaded: url_helper
INFO - 2018-10-09 13:05:46 --> Helper loaded: form_helper
INFO - 2018-10-09 13:05:47 --> Database Driver Class Initialized
INFO - 2018-10-09 13:05:47 --> Email Class Initialized
INFO - 2018-10-09 13:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:05:47 --> Form Validation Class Initialized
INFO - 2018-10-09 13:05:48 --> Controller Class Initialized
DEBUG - 2018-10-09 13:05:48 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:05:48 --> Model Class Initialized
DEBUG - 2018-10-09 13:05:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:05:49 --> Model Class Initialized
INFO - 2018-10-09 13:05:49 --> Final output sent to browser
DEBUG - 2018-10-09 13:05:50 --> Total execution time: 6.7314
INFO - 2018-10-09 13:12:33 --> Config Class Initialized
INFO - 2018-10-09 13:12:33 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:35 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:35 --> URI Class Initialized
DEBUG - 2018-10-09 13:12:36 --> No URI present. Default controller set.
INFO - 2018-10-09 13:12:36 --> Router Class Initialized
INFO - 2018-10-09 13:12:36 --> Output Class Initialized
INFO - 2018-10-09 13:12:37 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:37 --> Input Class Initialized
INFO - 2018-10-09 13:12:38 --> Language Class Initialized
INFO - 2018-10-09 13:12:38 --> Language Class Initialized
INFO - 2018-10-09 13:12:38 --> Config Class Initialized
INFO - 2018-10-09 13:12:39 --> Loader Class Initialized
INFO - 2018-10-09 13:12:39 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:39 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:47 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:47 --> Email Class Initialized
INFO - 2018-10-09 13:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:48 --> Form Validation Class Initialized
INFO - 2018-10-09 13:12:48 --> Controller Class Initialized
DEBUG - 2018-10-09 13:12:49 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:12:49 --> Model Class Initialized
DEBUG - 2018-10-09 13:12:49 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:12:50 --> Model Class Initialized
DEBUG - 2018-10-09 13:12:50 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:12:50 --> Final output sent to browser
DEBUG - 2018-10-09 13:12:51 --> Total execution time: 17.9170
INFO - 2018-10-09 13:12:53 --> Config Class Initialized
INFO - 2018-10-09 13:12:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:12:53 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:12:53 --> Utf8 Class Initialized
INFO - 2018-10-09 13:12:54 --> URI Class Initialized
INFO - 2018-10-09 13:12:54 --> Router Class Initialized
INFO - 2018-10-09 13:12:54 --> Output Class Initialized
INFO - 2018-10-09 13:12:54 --> Security Class Initialized
DEBUG - 2018-10-09 13:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:12:55 --> Input Class Initialized
INFO - 2018-10-09 13:12:55 --> Language Class Initialized
INFO - 2018-10-09 13:12:56 --> Language Class Initialized
INFO - 2018-10-09 13:12:56 --> Config Class Initialized
INFO - 2018-10-09 13:12:56 --> Loader Class Initialized
INFO - 2018-10-09 13:12:57 --> Helper loaded: url_helper
INFO - 2018-10-09 13:12:57 --> Helper loaded: form_helper
INFO - 2018-10-09 13:12:57 --> Database Driver Class Initialized
INFO - 2018-10-09 13:12:57 --> Email Class Initialized
INFO - 2018-10-09 13:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:12:58 --> Form Validation Class Initialized
INFO - 2018-10-09 13:12:58 --> Controller Class Initialized
DEBUG - 2018-10-09 13:12:59 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:12:59 --> Model Class Initialized
DEBUG - 2018-10-09 13:12:59 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:12:59 --> Model Class Initialized
INFO - 2018-10-09 13:13:00 --> Final output sent to browser
DEBUG - 2018-10-09 13:13:00 --> Total execution time: 7.1774
INFO - 2018-10-09 13:14:12 --> Config Class Initialized
INFO - 2018-10-09 13:14:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:14:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:14:14 --> Utf8 Class Initialized
INFO - 2018-10-09 13:14:15 --> URI Class Initialized
DEBUG - 2018-10-09 13:14:15 --> No URI present. Default controller set.
INFO - 2018-10-09 13:14:15 --> Router Class Initialized
INFO - 2018-10-09 13:14:16 --> Output Class Initialized
INFO - 2018-10-09 13:14:16 --> Security Class Initialized
DEBUG - 2018-10-09 13:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:14:17 --> Input Class Initialized
INFO - 2018-10-09 13:14:17 --> Language Class Initialized
INFO - 2018-10-09 13:14:18 --> Language Class Initialized
INFO - 2018-10-09 13:14:18 --> Config Class Initialized
INFO - 2018-10-09 13:14:18 --> Loader Class Initialized
INFO - 2018-10-09 13:14:19 --> Helper loaded: url_helper
INFO - 2018-10-09 13:14:19 --> Helper loaded: form_helper
INFO - 2018-10-09 13:14:20 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:20 --> Email Class Initialized
INFO - 2018-10-09 13:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:14:20 --> Form Validation Class Initialized
INFO - 2018-10-09 13:14:21 --> Controller Class Initialized
DEBUG - 2018-10-09 13:14:21 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:14:21 --> Model Class Initialized
DEBUG - 2018-10-09 13:14:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:14:22 --> Model Class Initialized
DEBUG - 2018-10-09 13:14:22 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:14:22 --> Final output sent to browser
DEBUG - 2018-10-09 13:14:23 --> Total execution time: 9.8596
INFO - 2018-10-09 13:14:25 --> Config Class Initialized
INFO - 2018-10-09 13:14:25 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:14:25 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:14:26 --> Utf8 Class Initialized
INFO - 2018-10-09 13:14:26 --> URI Class Initialized
INFO - 2018-10-09 13:14:26 --> Router Class Initialized
INFO - 2018-10-09 13:14:27 --> Output Class Initialized
INFO - 2018-10-09 13:14:27 --> Security Class Initialized
DEBUG - 2018-10-09 13:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:14:27 --> Input Class Initialized
INFO - 2018-10-09 13:14:28 --> Language Class Initialized
INFO - 2018-10-09 13:14:28 --> Language Class Initialized
INFO - 2018-10-09 13:14:28 --> Config Class Initialized
INFO - 2018-10-09 13:14:28 --> Loader Class Initialized
INFO - 2018-10-09 13:14:29 --> Helper loaded: url_helper
INFO - 2018-10-09 13:14:29 --> Helper loaded: form_helper
INFO - 2018-10-09 13:14:29 --> Database Driver Class Initialized
INFO - 2018-10-09 13:14:29 --> Email Class Initialized
INFO - 2018-10-09 13:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:14:30 --> Form Validation Class Initialized
INFO - 2018-10-09 13:14:30 --> Controller Class Initialized
DEBUG - 2018-10-09 13:14:30 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:14:31 --> Model Class Initialized
DEBUG - 2018-10-09 13:14:31 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:14:31 --> Model Class Initialized
INFO - 2018-10-09 13:14:31 --> Final output sent to browser
DEBUG - 2018-10-09 13:14:32 --> Total execution time: 6.7904
INFO - 2018-10-09 13:14:56 --> Config Class Initialized
INFO - 2018-10-09 13:14:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:14:57 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:14:57 --> Utf8 Class Initialized
INFO - 2018-10-09 13:14:58 --> URI Class Initialized
INFO - 2018-10-09 13:14:59 --> Router Class Initialized
INFO - 2018-10-09 13:14:59 --> Output Class Initialized
INFO - 2018-10-09 13:14:59 --> Security Class Initialized
DEBUG - 2018-10-09 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:15:00 --> Input Class Initialized
INFO - 2018-10-09 13:15:00 --> Language Class Initialized
INFO - 2018-10-09 13:15:01 --> Language Class Initialized
INFO - 2018-10-09 13:15:01 --> Config Class Initialized
INFO - 2018-10-09 13:15:01 --> Loader Class Initialized
INFO - 2018-10-09 13:15:02 --> Helper loaded: url_helper
INFO - 2018-10-09 13:15:02 --> Helper loaded: form_helper
INFO - 2018-10-09 13:15:02 --> Database Driver Class Initialized
INFO - 2018-10-09 13:15:02 --> Email Class Initialized
INFO - 2018-10-09 13:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:15:03 --> Form Validation Class Initialized
INFO - 2018-10-09 13:15:03 --> Controller Class Initialized
DEBUG - 2018-10-09 13:15:03 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:15:04 --> Model Class Initialized
DEBUG - 2018-10-09 13:15:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:15:04 --> Model Class Initialized
INFO - 2018-10-09 13:15:06 --> Final output sent to browser
DEBUG - 2018-10-09 13:15:06 --> Total execution time: 9.8576
INFO - 2018-10-09 13:15:07 --> Config Class Initialized
INFO - 2018-10-09 13:15:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:15:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:15:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:15:08 --> URI Class Initialized
INFO - 2018-10-09 13:15:08 --> Router Class Initialized
INFO - 2018-10-09 13:15:08 --> Output Class Initialized
INFO - 2018-10-09 13:15:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:15:09 --> Input Class Initialized
INFO - 2018-10-09 13:15:09 --> Language Class Initialized
INFO - 2018-10-09 13:15:10 --> Language Class Initialized
INFO - 2018-10-09 13:15:10 --> Config Class Initialized
INFO - 2018-10-09 13:15:10 --> Loader Class Initialized
INFO - 2018-10-09 13:15:10 --> Helper loaded: url_helper
INFO - 2018-10-09 13:15:11 --> Helper loaded: form_helper
INFO - 2018-10-09 13:15:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:15:11 --> Email Class Initialized
INFO - 2018-10-09 13:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:15:12 --> Form Validation Class Initialized
INFO - 2018-10-09 13:15:12 --> Controller Class Initialized
DEBUG - 2018-10-09 13:15:12 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:15:13 --> Model Class Initialized
DEBUG - 2018-10-09 13:15:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:15:13 --> Model Class Initialized
INFO - 2018-10-09 13:15:13 --> Final output sent to browser
DEBUG - 2018-10-09 13:15:14 --> Total execution time: 6.6574
INFO - 2018-10-09 13:21:53 --> Config Class Initialized
INFO - 2018-10-09 13:21:53 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:21:54 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:21:55 --> Utf8 Class Initialized
INFO - 2018-10-09 13:21:55 --> URI Class Initialized
DEBUG - 2018-10-09 13:21:56 --> No URI present. Default controller set.
INFO - 2018-10-09 13:21:56 --> Router Class Initialized
INFO - 2018-10-09 13:21:56 --> Output Class Initialized
INFO - 2018-10-09 13:21:56 --> Security Class Initialized
DEBUG - 2018-10-09 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:21:57 --> Input Class Initialized
INFO - 2018-10-09 13:21:58 --> Language Class Initialized
INFO - 2018-10-09 13:21:58 --> Language Class Initialized
INFO - 2018-10-09 13:21:59 --> Config Class Initialized
INFO - 2018-10-09 13:21:59 --> Loader Class Initialized
INFO - 2018-10-09 13:21:59 --> Helper loaded: url_helper
INFO - 2018-10-09 13:21:59 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:00 --> Database Driver Class Initialized
INFO - 2018-10-09 13:22:00 --> Email Class Initialized
INFO - 2018-10-09 13:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:02 --> Form Validation Class Initialized
INFO - 2018-10-09 13:22:02 --> Controller Class Initialized
DEBUG - 2018-10-09 13:22:02 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:22:04 --> Model Class Initialized
DEBUG - 2018-10-09 13:22:04 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:22:04 --> Model Class Initialized
DEBUG - 2018-10-09 13:22:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:22:05 --> Final output sent to browser
DEBUG - 2018-10-09 13:22:05 --> Total execution time: 12.6667
INFO - 2018-10-09 13:22:08 --> Config Class Initialized
INFO - 2018-10-09 13:22:08 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:22:09 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:22:09 --> Utf8 Class Initialized
INFO - 2018-10-09 13:22:10 --> URI Class Initialized
INFO - 2018-10-09 13:22:10 --> Router Class Initialized
INFO - 2018-10-09 13:22:11 --> Output Class Initialized
INFO - 2018-10-09 13:22:11 --> Security Class Initialized
DEBUG - 2018-10-09 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:22:11 --> Input Class Initialized
INFO - 2018-10-09 13:22:12 --> Language Class Initialized
INFO - 2018-10-09 13:22:12 --> Language Class Initialized
INFO - 2018-10-09 13:22:12 --> Config Class Initialized
INFO - 2018-10-09 13:22:13 --> Loader Class Initialized
INFO - 2018-10-09 13:22:13 --> Helper loaded: url_helper
INFO - 2018-10-09 13:22:13 --> Helper loaded: form_helper
INFO - 2018-10-09 13:22:14 --> Database Driver Class Initialized
INFO - 2018-10-09 13:22:14 --> Email Class Initialized
INFO - 2018-10-09 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:22:15 --> Form Validation Class Initialized
INFO - 2018-10-09 13:22:15 --> Controller Class Initialized
DEBUG - 2018-10-09 13:22:15 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:22:16 --> Model Class Initialized
DEBUG - 2018-10-09 13:22:16 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:22:16 --> Model Class Initialized
INFO - 2018-10-09 13:22:17 --> Final output sent to browser
DEBUG - 2018-10-09 13:22:17 --> Total execution time: 8.4925
INFO - 2018-10-09 13:23:06 --> Config Class Initialized
INFO - 2018-10-09 13:23:06 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:07 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:07 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:08 --> URI Class Initialized
INFO - 2018-10-09 13:23:08 --> Router Class Initialized
INFO - 2018-10-09 13:23:09 --> Output Class Initialized
INFO - 2018-10-09 13:23:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:09 --> Input Class Initialized
INFO - 2018-10-09 13:23:09 --> Language Class Initialized
INFO - 2018-10-09 13:23:10 --> Language Class Initialized
INFO - 2018-10-09 13:23:10 --> Config Class Initialized
INFO - 2018-10-09 13:23:10 --> Loader Class Initialized
INFO - 2018-10-09 13:23:10 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:11 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:11 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:11 --> Email Class Initialized
INFO - 2018-10-09 13:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:12 --> Form Validation Class Initialized
INFO - 2018-10-09 13:23:12 --> Controller Class Initialized
DEBUG - 2018-10-09 13:23:12 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:23:12 --> Model Class Initialized
DEBUG - 2018-10-09 13:23:13 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:23:13 --> Model Class Initialized
INFO - 2018-10-09 13:23:14 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:14 --> Total execution time: 8.0868
INFO - 2018-10-09 13:23:15 --> Config Class Initialized
INFO - 2018-10-09 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:15 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:16 --> URI Class Initialized
INFO - 2018-10-09 13:23:16 --> Router Class Initialized
INFO - 2018-10-09 13:23:16 --> Output Class Initialized
INFO - 2018-10-09 13:23:17 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:17 --> Input Class Initialized
INFO - 2018-10-09 13:23:17 --> Language Class Initialized
INFO - 2018-10-09 13:23:18 --> Language Class Initialized
INFO - 2018-10-09 13:23:18 --> Config Class Initialized
INFO - 2018-10-09 13:23:18 --> Loader Class Initialized
INFO - 2018-10-09 13:23:18 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:19 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:19 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:19 --> Email Class Initialized
INFO - 2018-10-09 13:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:20 --> Form Validation Class Initialized
INFO - 2018-10-09 13:23:20 --> Controller Class Initialized
DEBUG - 2018-10-09 13:23:20 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:23:20 --> Model Class Initialized
DEBUG - 2018-10-09 13:23:21 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:23:21 --> Model Class Initialized
INFO - 2018-10-09 13:23:21 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:22 --> Total execution time: 6.8644
INFO - 2018-10-09 13:23:31 --> Config Class Initialized
INFO - 2018-10-09 13:23:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:32 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:32 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:32 --> URI Class Initialized
INFO - 2018-10-09 13:23:33 --> Router Class Initialized
INFO - 2018-10-09 13:23:33 --> Output Class Initialized
INFO - 2018-10-09 13:23:33 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:34 --> Input Class Initialized
INFO - 2018-10-09 13:23:34 --> Language Class Initialized
INFO - 2018-10-09 13:23:34 --> Language Class Initialized
INFO - 2018-10-09 13:23:34 --> Config Class Initialized
INFO - 2018-10-09 13:23:35 --> Loader Class Initialized
INFO - 2018-10-09 13:23:35 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:35 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:35 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:36 --> Email Class Initialized
INFO - 2018-10-09 13:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:36 --> Form Validation Class Initialized
INFO - 2018-10-09 13:23:36 --> Controller Class Initialized
DEBUG - 2018-10-09 13:23:37 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:23:37 --> Model Class Initialized
DEBUG - 2018-10-09 13:23:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:23:37 --> Model Class Initialized
INFO - 2018-10-09 13:23:38 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:38 --> Total execution time: 6.9768
INFO - 2018-10-09 13:23:38 --> Config Class Initialized
INFO - 2018-10-09 13:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:23:40 --> Utf8 Class Initialized
INFO - 2018-10-09 13:23:40 --> URI Class Initialized
INFO - 2018-10-09 13:23:40 --> Router Class Initialized
INFO - 2018-10-09 13:23:40 --> Output Class Initialized
INFO - 2018-10-09 13:23:41 --> Security Class Initialized
DEBUG - 2018-10-09 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:23:41 --> Input Class Initialized
INFO - 2018-10-09 13:23:42 --> Language Class Initialized
INFO - 2018-10-09 13:23:42 --> Language Class Initialized
INFO - 2018-10-09 13:23:43 --> Config Class Initialized
INFO - 2018-10-09 13:23:43 --> Loader Class Initialized
INFO - 2018-10-09 13:23:43 --> Helper loaded: url_helper
INFO - 2018-10-09 13:23:44 --> Helper loaded: form_helper
INFO - 2018-10-09 13:23:44 --> Database Driver Class Initialized
INFO - 2018-10-09 13:23:44 --> Email Class Initialized
INFO - 2018-10-09 13:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:23:45 --> Form Validation Class Initialized
INFO - 2018-10-09 13:23:45 --> Controller Class Initialized
DEBUG - 2018-10-09 13:23:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:23:45 --> Model Class Initialized
DEBUG - 2018-10-09 13:23:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:23:46 --> Model Class Initialized
INFO - 2018-10-09 13:23:46 --> Final output sent to browser
DEBUG - 2018-10-09 13:23:46 --> Total execution time: 7.9465
INFO - 2018-10-09 13:37:19 --> Config Class Initialized
INFO - 2018-10-09 13:37:19 --> Hooks Class Initialized
INFO - 2018-10-09 13:37:19 --> Config Class Initialized
INFO - 2018-10-09 13:37:21 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:37:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:37:23 --> Utf8 Class Initialized
DEBUG - 2018-10-09 13:37:23 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:37:23 --> Utf8 Class Initialized
INFO - 2018-10-09 13:37:24 --> URI Class Initialized
INFO - 2018-10-09 13:37:24 --> URI Class Initialized
DEBUG - 2018-10-09 13:37:24 --> No URI present. Default controller set.
INFO - 2018-10-09 13:37:24 --> Router Class Initialized
DEBUG - 2018-10-09 13:37:25 --> No URI present. Default controller set.
INFO - 2018-10-09 13:37:25 --> Output Class Initialized
INFO - 2018-10-09 13:37:25 --> Security Class Initialized
DEBUG - 2018-10-09 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:37:25 --> Input Class Initialized
INFO - 2018-10-09 13:37:26 --> Language Class Initialized
INFO - 2018-10-09 13:37:26 --> Language Class Initialized
INFO - 2018-10-09 13:37:26 --> Config Class Initialized
INFO - 2018-10-09 13:37:27 --> Loader Class Initialized
INFO - 2018-10-09 13:37:27 --> Helper loaded: url_helper
INFO - 2018-10-09 13:37:27 --> Helper loaded: form_helper
INFO - 2018-10-09 13:37:27 --> Router Class Initialized
INFO - 2018-10-09 13:37:28 --> Output Class Initialized
INFO - 2018-10-09 13:37:28 --> Database Driver Class Initialized
INFO - 2018-10-09 13:37:28 --> Security Class Initialized
DEBUG - 2018-10-09 13:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:37:29 --> Input Class Initialized
INFO - 2018-10-09 13:37:29 --> Language Class Initialized
INFO - 2018-10-09 13:37:29 --> Language Class Initialized
INFO - 2018-10-09 13:37:29 --> Config Class Initialized
INFO - 2018-10-09 13:37:30 --> Loader Class Initialized
INFO - 2018-10-09 13:37:30 --> Helper loaded: url_helper
INFO - 2018-10-09 13:37:30 --> Helper loaded: form_helper
INFO - 2018-10-09 13:37:31 --> Database Driver Class Initialized
INFO - 2018-10-09 13:37:32 --> Email Class Initialized
INFO - 2018-10-09 13:37:32 --> Email Class Initialized
INFO - 2018-10-09 13:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:37:33 --> Form Validation Class Initialized
INFO - 2018-10-09 13:37:33 --> Controller Class Initialized
DEBUG - 2018-10-09 13:37:34 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:37:34 --> Form Validation Class Initialized
INFO - 2018-10-09 13:37:34 --> Controller Class Initialized
INFO - 2018-10-09 13:37:35 --> Model Class Initialized
DEBUG - 2018-10-09 13:37:35 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:37:35 --> Model Class Initialized
DEBUG - 2018-10-09 13:37:35 --> Person MX_Controller Initialized
DEBUG - 2018-10-09 13:37:36 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:37:36 --> Model Class Initialized
INFO - 2018-10-09 13:37:36 --> Final output sent to browser
DEBUG - 2018-10-09 13:37:36 --> Total execution time: 18.7361
DEBUG - 2018-10-09 13:37:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:37:37 --> Model Class Initialized
DEBUG - 2018-10-09 13:37:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:37:37 --> Final output sent to browser
DEBUG - 2018-10-09 13:37:38 --> Total execution time: 20.1562
INFO - 2018-10-09 13:37:57 --> Config Class Initialized
INFO - 2018-10-09 13:37:57 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:37:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:37:58 --> Utf8 Class Initialized
INFO - 2018-10-09 13:37:58 --> URI Class Initialized
INFO - 2018-10-09 13:37:59 --> Router Class Initialized
INFO - 2018-10-09 13:37:59 --> Output Class Initialized
INFO - 2018-10-09 13:37:59 --> Security Class Initialized
DEBUG - 2018-10-09 13:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:37:59 --> Input Class Initialized
INFO - 2018-10-09 13:38:00 --> Language Class Initialized
INFO - 2018-10-09 13:38:00 --> Language Class Initialized
INFO - 2018-10-09 13:38:00 --> Config Class Initialized
INFO - 2018-10-09 13:38:00 --> Loader Class Initialized
INFO - 2018-10-09 13:38:01 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:01 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:01 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:01 --> Email Class Initialized
INFO - 2018-10-09 13:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:02 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:02 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:02 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:02 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:03 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:03 --> Model Class Initialized
INFO - 2018-10-09 13:38:04 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:04 --> Total execution time: 7.0094
INFO - 2018-10-09 13:38:12 --> Config Class Initialized
INFO - 2018-10-09 13:38:12 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:38:13 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:38:13 --> Utf8 Class Initialized
INFO - 2018-10-09 13:38:13 --> URI Class Initialized
INFO - 2018-10-09 13:38:13 --> Router Class Initialized
INFO - 2018-10-09 13:38:13 --> Output Class Initialized
INFO - 2018-10-09 13:38:14 --> Security Class Initialized
DEBUG - 2018-10-09 13:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:38:14 --> Input Class Initialized
INFO - 2018-10-09 13:38:14 --> Language Class Initialized
INFO - 2018-10-09 13:38:15 --> Language Class Initialized
INFO - 2018-10-09 13:38:15 --> Config Class Initialized
INFO - 2018-10-09 13:38:15 --> Loader Class Initialized
INFO - 2018-10-09 13:38:15 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:16 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:16 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:16 --> Email Class Initialized
INFO - 2018-10-09 13:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:16 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:17 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:17 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:17 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:17 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:17 --> Model Class Initialized
INFO - 2018-10-09 13:38:18 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:18 --> Total execution time: 6.0222
INFO - 2018-10-09 13:38:19 --> Config Class Initialized
INFO - 2018-10-09 13:38:19 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:38:19 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:38:19 --> Utf8 Class Initialized
INFO - 2018-10-09 13:38:20 --> URI Class Initialized
INFO - 2018-10-09 13:38:20 --> Router Class Initialized
INFO - 2018-10-09 13:38:20 --> Output Class Initialized
INFO - 2018-10-09 13:38:21 --> Security Class Initialized
DEBUG - 2018-10-09 13:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:38:21 --> Input Class Initialized
INFO - 2018-10-09 13:38:21 --> Language Class Initialized
INFO - 2018-10-09 13:38:22 --> Language Class Initialized
INFO - 2018-10-09 13:38:22 --> Config Class Initialized
INFO - 2018-10-09 13:38:22 --> Loader Class Initialized
INFO - 2018-10-09 13:38:22 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:23 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:23 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:23 --> Email Class Initialized
INFO - 2018-10-09 13:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:24 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:24 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:25 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:25 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:26 --> Model Class Initialized
INFO - 2018-10-09 13:38:26 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:26 --> Total execution time: 7.4054
INFO - 2018-10-09 13:38:31 --> Config Class Initialized
INFO - 2018-10-09 13:38:31 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:38:31 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:38:31 --> Utf8 Class Initialized
INFO - 2018-10-09 13:38:32 --> URI Class Initialized
INFO - 2018-10-09 13:38:32 --> Router Class Initialized
INFO - 2018-10-09 13:38:32 --> Output Class Initialized
INFO - 2018-10-09 13:38:32 --> Security Class Initialized
DEBUG - 2018-10-09 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:38:33 --> Input Class Initialized
INFO - 2018-10-09 13:38:33 --> Language Class Initialized
INFO - 2018-10-09 13:38:34 --> Language Class Initialized
INFO - 2018-10-09 13:38:34 --> Config Class Initialized
INFO - 2018-10-09 13:38:34 --> Loader Class Initialized
INFO - 2018-10-09 13:38:35 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:35 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:35 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:36 --> Email Class Initialized
INFO - 2018-10-09 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:36 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:36 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:37 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:37 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:37 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:37 --> Model Class Initialized
INFO - 2018-10-09 13:38:38 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:38 --> Total execution time: 7.2480
INFO - 2018-10-09 13:38:39 --> Config Class Initialized
INFO - 2018-10-09 13:38:39 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:38:39 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:38:40 --> Utf8 Class Initialized
INFO - 2018-10-09 13:38:40 --> URI Class Initialized
INFO - 2018-10-09 13:38:40 --> Router Class Initialized
INFO - 2018-10-09 13:38:40 --> Output Class Initialized
INFO - 2018-10-09 13:38:41 --> Security Class Initialized
DEBUG - 2018-10-09 13:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:38:41 --> Input Class Initialized
INFO - 2018-10-09 13:38:41 --> Language Class Initialized
INFO - 2018-10-09 13:38:42 --> Language Class Initialized
INFO - 2018-10-09 13:38:42 --> Config Class Initialized
INFO - 2018-10-09 13:38:42 --> Loader Class Initialized
INFO - 2018-10-09 13:38:43 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:43 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:43 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:44 --> Email Class Initialized
INFO - 2018-10-09 13:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:45 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:45 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:45 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:46 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:46 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:46 --> Model Class Initialized
INFO - 2018-10-09 13:38:47 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:47 --> Total execution time: 8.0715
INFO - 2018-10-09 13:38:52 --> Config Class Initialized
INFO - 2018-10-09 13:38:52 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:38:52 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:38:52 --> Utf8 Class Initialized
INFO - 2018-10-09 13:38:52 --> URI Class Initialized
INFO - 2018-10-09 13:38:53 --> Router Class Initialized
INFO - 2018-10-09 13:38:53 --> Output Class Initialized
INFO - 2018-10-09 13:38:53 --> Security Class Initialized
DEBUG - 2018-10-09 13:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:38:54 --> Input Class Initialized
INFO - 2018-10-09 13:38:54 --> Language Class Initialized
INFO - 2018-10-09 13:38:54 --> Language Class Initialized
INFO - 2018-10-09 13:38:55 --> Config Class Initialized
INFO - 2018-10-09 13:38:55 --> Loader Class Initialized
INFO - 2018-10-09 13:38:55 --> Helper loaded: url_helper
INFO - 2018-10-09 13:38:56 --> Helper loaded: form_helper
INFO - 2018-10-09 13:38:56 --> Database Driver Class Initialized
INFO - 2018-10-09 13:38:56 --> Email Class Initialized
INFO - 2018-10-09 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:38:57 --> Form Validation Class Initialized
INFO - 2018-10-09 13:38:57 --> Controller Class Initialized
DEBUG - 2018-10-09 13:38:57 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:38:58 --> Model Class Initialized
DEBUG - 2018-10-09 13:38:58 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:38:58 --> Model Class Initialized
INFO - 2018-10-09 13:38:59 --> Final output sent to browser
DEBUG - 2018-10-09 13:38:59 --> Total execution time: 7.2514
INFO - 2018-10-09 13:39:00 --> Config Class Initialized
INFO - 2018-10-09 13:39:00 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:39:00 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:39:00 --> Utf8 Class Initialized
INFO - 2018-10-09 13:39:01 --> URI Class Initialized
INFO - 2018-10-09 13:39:01 --> Router Class Initialized
INFO - 2018-10-09 13:39:01 --> Output Class Initialized
INFO - 2018-10-09 13:39:01 --> Security Class Initialized
DEBUG - 2018-10-09 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:39:02 --> Input Class Initialized
INFO - 2018-10-09 13:39:02 --> Language Class Initialized
INFO - 2018-10-09 13:39:02 --> Language Class Initialized
INFO - 2018-10-09 13:39:02 --> Config Class Initialized
INFO - 2018-10-09 13:39:03 --> Loader Class Initialized
INFO - 2018-10-09 13:39:03 --> Helper loaded: url_helper
INFO - 2018-10-09 13:39:03 --> Helper loaded: form_helper
INFO - 2018-10-09 13:39:03 --> Database Driver Class Initialized
INFO - 2018-10-09 13:39:04 --> Email Class Initialized
INFO - 2018-10-09 13:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:39:04 --> Form Validation Class Initialized
INFO - 2018-10-09 13:39:04 --> Controller Class Initialized
DEBUG - 2018-10-09 13:39:05 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:39:05 --> Model Class Initialized
DEBUG - 2018-10-09 13:39:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:39:06 --> Model Class Initialized
INFO - 2018-10-09 13:39:06 --> Final output sent to browser
DEBUG - 2018-10-09 13:39:06 --> Total execution time: 6.4774
INFO - 2018-10-09 13:39:24 --> Config Class Initialized
INFO - 2018-10-09 13:39:24 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:39:24 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:39:25 --> Utf8 Class Initialized
INFO - 2018-10-09 13:39:25 --> URI Class Initialized
DEBUG - 2018-10-09 13:39:25 --> No URI present. Default controller set.
INFO - 2018-10-09 13:39:25 --> Router Class Initialized
INFO - 2018-10-09 13:39:26 --> Output Class Initialized
INFO - 2018-10-09 13:39:26 --> Security Class Initialized
DEBUG - 2018-10-09 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:39:26 --> Input Class Initialized
INFO - 2018-10-09 13:39:27 --> Language Class Initialized
INFO - 2018-10-09 13:39:27 --> Language Class Initialized
INFO - 2018-10-09 13:39:27 --> Config Class Initialized
INFO - 2018-10-09 13:39:27 --> Loader Class Initialized
INFO - 2018-10-09 13:39:28 --> Helper loaded: url_helper
INFO - 2018-10-09 13:39:28 --> Helper loaded: form_helper
INFO - 2018-10-09 13:39:28 --> Database Driver Class Initialized
INFO - 2018-10-09 13:39:28 --> Email Class Initialized
INFO - 2018-10-09 13:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:39:29 --> Form Validation Class Initialized
INFO - 2018-10-09 13:39:29 --> Controller Class Initialized
DEBUG - 2018-10-09 13:39:29 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:39:29 --> Model Class Initialized
DEBUG - 2018-10-09 13:39:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 13:39:30 --> Model Class Initialized
DEBUG - 2018-10-09 13:39:30 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 13:39:30 --> Final output sent to browser
DEBUG - 2018-10-09 13:39:31 --> Total execution time: 6.3984
INFO - 2018-10-09 13:39:32 --> Config Class Initialized
INFO - 2018-10-09 13:39:32 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:39:33 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:39:33 --> Utf8 Class Initialized
INFO - 2018-10-09 13:39:33 --> URI Class Initialized
INFO - 2018-10-09 13:39:34 --> Router Class Initialized
INFO - 2018-10-09 13:39:34 --> Output Class Initialized
INFO - 2018-10-09 13:39:34 --> Security Class Initialized
DEBUG - 2018-10-09 13:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:39:35 --> Input Class Initialized
INFO - 2018-10-09 13:39:35 --> Language Class Initialized
INFO - 2018-10-09 13:39:35 --> Language Class Initialized
INFO - 2018-10-09 13:39:36 --> Config Class Initialized
INFO - 2018-10-09 13:39:36 --> Loader Class Initialized
INFO - 2018-10-09 13:39:36 --> Helper loaded: url_helper
INFO - 2018-10-09 13:39:36 --> Helper loaded: form_helper
INFO - 2018-10-09 13:39:37 --> Database Driver Class Initialized
INFO - 2018-10-09 13:39:37 --> Email Class Initialized
INFO - 2018-10-09 13:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:39:37 --> Form Validation Class Initialized
INFO - 2018-10-09 13:39:38 --> Controller Class Initialized
DEBUG - 2018-10-09 13:39:38 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:39:38 --> Model Class Initialized
DEBUG - 2018-10-09 13:39:38 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:39:39 --> Model Class Initialized
INFO - 2018-10-09 13:39:39 --> Final output sent to browser
DEBUG - 2018-10-09 13:39:39 --> Total execution time: 6.5364
INFO - 2018-10-09 13:40:28 --> Config Class Initialized
INFO - 2018-10-09 13:40:28 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:40:29 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:40:29 --> Utf8 Class Initialized
INFO - 2018-10-09 13:40:29 --> URI Class Initialized
INFO - 2018-10-09 13:40:29 --> Router Class Initialized
INFO - 2018-10-09 13:40:30 --> Output Class Initialized
INFO - 2018-10-09 13:40:30 --> Security Class Initialized
DEBUG - 2018-10-09 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:40:30 --> Input Class Initialized
INFO - 2018-10-09 13:40:31 --> Language Class Initialized
INFO - 2018-10-09 13:40:31 --> Language Class Initialized
INFO - 2018-10-09 13:40:31 --> Config Class Initialized
INFO - 2018-10-09 13:40:31 --> Loader Class Initialized
INFO - 2018-10-09 13:40:32 --> Helper loaded: url_helper
INFO - 2018-10-09 13:40:32 --> Helper loaded: form_helper
INFO - 2018-10-09 13:40:32 --> Database Driver Class Initialized
INFO - 2018-10-09 13:40:32 --> Email Class Initialized
INFO - 2018-10-09 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:40:33 --> Form Validation Class Initialized
INFO - 2018-10-09 13:40:33 --> Controller Class Initialized
DEBUG - 2018-10-09 13:40:33 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:40:33 --> Model Class Initialized
DEBUG - 2018-10-09 13:40:34 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:40:34 --> Model Class Initialized
INFO - 2018-10-09 13:40:34 --> Final output sent to browser
DEBUG - 2018-10-09 13:40:34 --> Total execution time: 5.8032
INFO - 2018-10-09 13:40:35 --> Config Class Initialized
INFO - 2018-10-09 13:40:35 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:40:35 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:40:36 --> Utf8 Class Initialized
INFO - 2018-10-09 13:40:36 --> URI Class Initialized
INFO - 2018-10-09 13:40:36 --> Router Class Initialized
INFO - 2018-10-09 13:40:37 --> Output Class Initialized
INFO - 2018-10-09 13:40:37 --> Security Class Initialized
DEBUG - 2018-10-09 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:40:37 --> Input Class Initialized
INFO - 2018-10-09 13:40:38 --> Language Class Initialized
INFO - 2018-10-09 13:40:38 --> Language Class Initialized
INFO - 2018-10-09 13:40:38 --> Config Class Initialized
INFO - 2018-10-09 13:40:39 --> Loader Class Initialized
INFO - 2018-10-09 13:40:39 --> Helper loaded: url_helper
INFO - 2018-10-09 13:40:39 --> Helper loaded: form_helper
INFO - 2018-10-09 13:40:40 --> Database Driver Class Initialized
INFO - 2018-10-09 13:40:40 --> Email Class Initialized
INFO - 2018-10-09 13:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:40:41 --> Form Validation Class Initialized
INFO - 2018-10-09 13:40:41 --> Controller Class Initialized
DEBUG - 2018-10-09 13:40:41 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:40:42 --> Model Class Initialized
DEBUG - 2018-10-09 13:40:42 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:40:42 --> Model Class Initialized
INFO - 2018-10-09 13:40:43 --> Final output sent to browser
DEBUG - 2018-10-09 13:40:43 --> Total execution time: 8.0115
INFO - 2018-10-09 13:41:05 --> Config Class Initialized
INFO - 2018-10-09 13:41:05 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:41:06 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:41:06 --> Utf8 Class Initialized
INFO - 2018-10-09 13:41:06 --> URI Class Initialized
INFO - 2018-10-09 13:41:07 --> Router Class Initialized
INFO - 2018-10-09 13:41:07 --> Output Class Initialized
INFO - 2018-10-09 13:41:07 --> Security Class Initialized
DEBUG - 2018-10-09 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:41:07 --> Input Class Initialized
INFO - 2018-10-09 13:41:08 --> Language Class Initialized
INFO - 2018-10-09 13:41:08 --> Language Class Initialized
INFO - 2018-10-09 13:41:08 --> Config Class Initialized
INFO - 2018-10-09 13:41:09 --> Loader Class Initialized
INFO - 2018-10-09 13:41:09 --> Helper loaded: url_helper
INFO - 2018-10-09 13:41:09 --> Helper loaded: form_helper
INFO - 2018-10-09 13:41:10 --> Database Driver Class Initialized
INFO - 2018-10-09 13:41:10 --> Email Class Initialized
INFO - 2018-10-09 13:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:41:11 --> Form Validation Class Initialized
INFO - 2018-10-09 13:41:11 --> Controller Class Initialized
DEBUG - 2018-10-09 13:41:11 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:41:12 --> Model Class Initialized
DEBUG - 2018-10-09 13:41:12 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:41:12 --> Model Class Initialized
INFO - 2018-10-09 13:41:13 --> Final output sent to browser
DEBUG - 2018-10-09 13:41:13 --> Total execution time: 7.3724
INFO - 2018-10-09 13:41:13 --> Config Class Initialized
INFO - 2018-10-09 13:41:14 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:41:14 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:41:14 --> Utf8 Class Initialized
INFO - 2018-10-09 13:41:14 --> URI Class Initialized
INFO - 2018-10-09 13:41:15 --> Router Class Initialized
INFO - 2018-10-09 13:41:15 --> Output Class Initialized
INFO - 2018-10-09 13:41:15 --> Security Class Initialized
DEBUG - 2018-10-09 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:41:16 --> Input Class Initialized
INFO - 2018-10-09 13:41:16 --> Language Class Initialized
INFO - 2018-10-09 13:41:16 --> Language Class Initialized
INFO - 2018-10-09 13:41:16 --> Config Class Initialized
INFO - 2018-10-09 13:41:17 --> Loader Class Initialized
INFO - 2018-10-09 13:41:17 --> Helper loaded: url_helper
INFO - 2018-10-09 13:41:17 --> Helper loaded: form_helper
INFO - 2018-10-09 13:41:17 --> Database Driver Class Initialized
INFO - 2018-10-09 13:41:18 --> Email Class Initialized
INFO - 2018-10-09 13:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:41:18 --> Form Validation Class Initialized
INFO - 2018-10-09 13:41:18 --> Controller Class Initialized
DEBUG - 2018-10-09 13:41:19 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:41:19 --> Model Class Initialized
DEBUG - 2018-10-09 13:41:19 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:41:20 --> Model Class Initialized
INFO - 2018-10-09 13:41:20 --> Final output sent to browser
DEBUG - 2018-10-09 13:41:20 --> Total execution time: 6.4994
INFO - 2018-10-09 13:56:56 --> Config Class Initialized
INFO - 2018-10-09 13:56:56 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:56:58 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:56:58 --> Utf8 Class Initialized
INFO - 2018-10-09 13:56:59 --> URI Class Initialized
INFO - 2018-10-09 13:56:59 --> Router Class Initialized
INFO - 2018-10-09 13:56:59 --> Output Class Initialized
INFO - 2018-10-09 13:57:00 --> Security Class Initialized
DEBUG - 2018-10-09 13:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:57:00 --> Input Class Initialized
INFO - 2018-10-09 13:57:01 --> Language Class Initialized
INFO - 2018-10-09 13:57:01 --> Language Class Initialized
INFO - 2018-10-09 13:57:01 --> Config Class Initialized
INFO - 2018-10-09 13:57:02 --> Loader Class Initialized
INFO - 2018-10-09 13:57:02 --> Helper loaded: url_helper
INFO - 2018-10-09 13:57:02 --> Helper loaded: form_helper
INFO - 2018-10-09 13:57:03 --> Database Driver Class Initialized
INFO - 2018-10-09 13:57:03 --> Email Class Initialized
INFO - 2018-10-09 13:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:57:04 --> Form Validation Class Initialized
INFO - 2018-10-09 13:57:04 --> Controller Class Initialized
DEBUG - 2018-10-09 13:57:04 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:57:05 --> Model Class Initialized
DEBUG - 2018-10-09 13:57:05 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:57:05 --> Model Class Initialized
INFO - 2018-10-09 13:57:06 --> Final output sent to browser
DEBUG - 2018-10-09 13:57:06 --> Total execution time: 9.6693
INFO - 2018-10-09 13:57:07 --> Config Class Initialized
INFO - 2018-10-09 13:57:07 --> Hooks Class Initialized
DEBUG - 2018-10-09 13:57:08 --> UTF-8 Support Enabled
INFO - 2018-10-09 13:57:08 --> Utf8 Class Initialized
INFO - 2018-10-09 13:57:08 --> URI Class Initialized
INFO - 2018-10-09 13:57:09 --> Router Class Initialized
INFO - 2018-10-09 13:57:09 --> Output Class Initialized
INFO - 2018-10-09 13:57:09 --> Security Class Initialized
DEBUG - 2018-10-09 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 13:57:10 --> Input Class Initialized
INFO - 2018-10-09 13:57:10 --> Language Class Initialized
INFO - 2018-10-09 13:57:10 --> Language Class Initialized
INFO - 2018-10-09 13:57:11 --> Config Class Initialized
INFO - 2018-10-09 13:57:11 --> Loader Class Initialized
INFO - 2018-10-09 13:57:11 --> Helper loaded: url_helper
INFO - 2018-10-09 13:57:12 --> Helper loaded: form_helper
INFO - 2018-10-09 13:57:12 --> Database Driver Class Initialized
INFO - 2018-10-09 13:57:12 --> Email Class Initialized
INFO - 2018-10-09 13:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 13:57:13 --> Form Validation Class Initialized
INFO - 2018-10-09 13:57:13 --> Controller Class Initialized
DEBUG - 2018-10-09 13:57:13 --> Person MX_Controller Initialized
INFO - 2018-10-09 13:57:14 --> Model Class Initialized
DEBUG - 2018-10-09 13:57:14 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 13:57:14 --> Model Class Initialized
INFO - 2018-10-09 13:57:15 --> Final output sent to browser
DEBUG - 2018-10-09 13:57:15 --> Total execution time: 7.3114
INFO - 2018-10-09 14:02:17 --> Config Class Initialized
INFO - 2018-10-09 14:02:17 --> Hooks Class Initialized
DEBUG - 2018-10-09 14:02:18 --> UTF-8 Support Enabled
INFO - 2018-10-09 14:02:18 --> Utf8 Class Initialized
INFO - 2018-10-09 14:02:19 --> URI Class Initialized
DEBUG - 2018-10-09 14:02:19 --> No URI present. Default controller set.
INFO - 2018-10-09 14:02:19 --> Router Class Initialized
INFO - 2018-10-09 14:02:20 --> Output Class Initialized
INFO - 2018-10-09 14:02:20 --> Security Class Initialized
DEBUG - 2018-10-09 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 14:02:21 --> Input Class Initialized
INFO - 2018-10-09 14:02:21 --> Language Class Initialized
INFO - 2018-10-09 14:02:22 --> Language Class Initialized
INFO - 2018-10-09 14:02:22 --> Config Class Initialized
INFO - 2018-10-09 14:02:22 --> Loader Class Initialized
INFO - 2018-10-09 14:02:22 --> Helper loaded: url_helper
INFO - 2018-10-09 14:02:22 --> Helper loaded: form_helper
INFO - 2018-10-09 14:02:23 --> Database Driver Class Initialized
INFO - 2018-10-09 14:02:23 --> Email Class Initialized
INFO - 2018-10-09 14:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 14:02:24 --> Form Validation Class Initialized
INFO - 2018-10-09 14:02:24 --> Controller Class Initialized
DEBUG - 2018-10-09 14:02:24 --> Person MX_Controller Initialized
INFO - 2018-10-09 14:02:24 --> Model Class Initialized
DEBUG - 2018-10-09 14:02:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/models/Mdl_person.php
INFO - 2018-10-09 14:02:25 --> Model Class Initialized
DEBUG - 2018-10-09 14:02:25 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/Person/views/home.php
INFO - 2018-10-09 14:02:25 --> Final output sent to browser
DEBUG - 2018-10-09 14:02:25 --> Total execution time: 7.9169
INFO - 2018-10-09 14:02:46 --> Config Class Initialized
INFO - 2018-10-09 14:02:46 --> Hooks Class Initialized
DEBUG - 2018-10-09 14:02:46 --> UTF-8 Support Enabled
INFO - 2018-10-09 14:02:46 --> Utf8 Class Initialized
INFO - 2018-10-09 14:02:47 --> URI Class Initialized
INFO - 2018-10-09 14:02:47 --> Router Class Initialized
INFO - 2018-10-09 14:02:47 --> Output Class Initialized
INFO - 2018-10-09 14:02:47 --> Security Class Initialized
DEBUG - 2018-10-09 14:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-09 14:02:48 --> Input Class Initialized
INFO - 2018-10-09 14:02:48 --> Language Class Initialized
INFO - 2018-10-09 14:02:48 --> Language Class Initialized
INFO - 2018-10-09 14:02:49 --> Config Class Initialized
INFO - 2018-10-09 14:02:49 --> Loader Class Initialized
INFO - 2018-10-09 14:02:49 --> Helper loaded: url_helper
INFO - 2018-10-09 14:02:49 --> Helper loaded: form_helper
INFO - 2018-10-09 14:02:50 --> Database Driver Class Initialized
INFO - 2018-10-09 14:02:50 --> Email Class Initialized
INFO - 2018-10-09 14:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-09 14:02:50 --> Form Validation Class Initialized
INFO - 2018-10-09 14:02:50 --> Controller Class Initialized
DEBUG - 2018-10-09 14:02:51 --> Person MX_Controller Initialized
INFO - 2018-10-09 14:02:51 --> Model Class Initialized
DEBUG - 2018-10-09 14:02:51 --> File loaded: C:\xampp\htdocs\User_Management\application\modules/person/models/Mdl_person.php
INFO - 2018-10-09 14:02:52 --> Model Class Initialized
INFO - 2018-10-09 14:02:52 --> Final output sent to browser
DEBUG - 2018-10-09 14:02:52 --> Total execution time: 6.5014
