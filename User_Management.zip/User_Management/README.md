# Codeigniter 3 with HMVC

This is the combination between 3 CodeIgniter and HMVC Modular Extension (created by "wiredesignz").

This version is already configured to work with HMVC, Eliminating the need to download the files HMVC on Bitbucket and copy to the Corresponding folders.

Just download this version and start using.
